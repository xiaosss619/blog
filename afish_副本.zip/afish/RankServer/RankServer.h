#pragma once

#include "Include/ServerDefine.h"

#define THREAD_TOTAL 3

class RedisConnection;
class RankArena;
class RankBulletin;
class RankBoard;
class RankServer : public Poolize
{
public:
	RankServer();
	virtual ~RankServer();

    bool Init();
    void SendMail(RedisConnection* pConnection, uint64 uUserId, int32 nMailType, int64 iDiamond, int64 iGold, const map<int32, int64>& mapItem, const string& title, const string& content);
public:
	RankArena* _arena;
	RankBulletin* _bulletin;
	RankBoard* _board;
};

#define sRankServer Singleton<RankServer>::Instance()
