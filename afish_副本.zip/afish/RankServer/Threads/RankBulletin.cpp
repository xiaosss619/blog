/**
 * 竞技场排名模块
*/
#include "RankBulletin.h"
#include "RedisManager/RedisManager.h"
#include "Include/RedisProtoHelper.h"
#include "DataCache/RedisData.h"
#include "HelperArena.h"
#include "HelperLottery.h"
#include "RankServer.h"

RankBulletin::RankBulletin(boost::asio::io_service& io)
    : _io_service(io), _timer(io)
{
    m_tmCrossDay = 0;
    _timer.expires_from_now(boost::posix_time::seconds(5));
    _timer.async_wait(boost::bind(&RankBulletin::OnTimer5s, this, boost::asio::placeholders::error));
}

RankBulletin::~RankBulletin() {
}

void RankBulletin::OnTimer5s(const boost::system::error_code& error) {
    if( !error ) {
        RedisConnectionIdGetter idGetter(enumRedisServerTypeData);
        auto pConnection = idGetter.GetConnection();
        if( pConnection != nullptr ) {
            int64 now = time(nullptr);
            if( m_tmCrossDay == 0 ) {
                // 返回false说明没有对应的key, 系统初始化, 则设置为当前时间, 无需跨天计算
                if( !pConnection->get(RedisKey::MakeBulletinCrossDayKey(), m_tmCrossDay) ) {
                    m_tmCrossDay = now;
                    pConnection->set(RedisKey::MakeBulletinCrossDayKey(), m_tmCrossDay);
                }
            }
            BulletinCrossDay(pConnection, now);
        }
        else {
            LOGERROR("NO REDIS");
        }
        _timer.expires_from_now(boost::posix_time::seconds(5));
        _timer.async_wait(boost::bind(&RankBulletin::OnTimer5s, this, boost::asio::placeholders::error));
    }
}

// 应该放在公用的头文件里, 暂时这么处理一下
enum E_UserSensitiveFlag {
    EUSTF_Voucher      = 0x00000001,   // 话费系统
    EUSTF_GiftCodeSet  = 0x00000002,   // 礼物系统是否设置过密码
};

bool RankBulletin::BulletinUserNoVoucher(RedisConnection* pConnection, uint64 userId) {
    // 排行榜用户未带入这个字段, 并且在遍历发奖时查找BulletinUser需要按时间段找, 太麻烦了, 这里就硬编码到redis中获取了
    string strUserKey = RedisKey::MakeUserKey(userId);
    int32 flag = 0;
    pConnection->hget(strUserKey, "sensitive_flag", flag);
    return (flag & EUSTF_Voucher);
}

void RankBulletin::BulletinCrossDay(RedisConnection* pConnection, int64 now) {
    if( !pConnection->exists("GM:BULLETIN") ) {
        if( GlobalUtils::InSameDay(now, m_tmCrossDay) ) {
            return;
        }
        m_tmCrossDay = now;
        pConnection->set(RedisKey::MakeBulletinCrossDayKey(), m_tmCrossDay);
    }
    else {
        // 强制发奖, 测试用
        pConnection->del("GM:BULLETIN");
    }

    string strBeforeLast = GlobalUtils::GetTimeByFormat(ETF_YMD_SHORT, now - TIME_DAY - TIME_DAY);
    string strLast = GlobalUtils::GetTimeByFormat(ETF_YMD_SHORT, now - TIME_DAY);
    set<int32> setBoss;
    JDATA->SummonRankRewardPtr()->ForEach([&](tagJsonSummonRankReward* ptr){
        setBoss.insert(ptr->_BossID);
    });
    for( auto& boss : setBoss ) {
        int32 maxRank = sHArena->GetBulletinMaxRank(boss);
        if( maxRank <= 0 ) {
            continue;
        }
        string strLastKill = RedisKey::MakeBulletinHornKey(boss, EBST_HornKill, strLast);
        std::vector< std::pair<int64, int64 > > values;
        if( pConnection->zrevrange(strLastKill, 0, maxRank-1, values) ) {
            for( size_t i = 0; i < values.size() ; ++i ) {
                int64 userId = values[i].first;
                tagBulletinLoot loot;
                if( sHArena->GetBulletinLoot(boss, i+1, loot) ) {
                    map<int32,int64> mapItem;
                    if( sHLottery->GetLootItem(loot._killLoot, mapItem) ) {
                        sRankServer->SendMail(pConnection, userId, loot._killMail, 0, 0, mapItem, "", GlobalUtils::ToString(i+1));
                    }
                }
            }
        }
        values.clear();
        string strLastLuck = RedisKey::MakeBulletinHornKey(boss, EBST_HornRate, strLast);
        if( pConnection->zrevrange(strLastLuck, 0, maxRank-1, values) ) {
            for( size_t i = 0; i < values.size() ; ++i ) {
                int64 userId = values[i].first;
                tagBulletinLoot loot;
                if( sHArena->GetBulletinLoot(boss, i+1, loot) ) {
                    map<int32,int64> mapItem;
                    if( sHLottery->GetLootItem(loot._luckLoot, mapItem) ) {
                        sRankServer->SendMail(pConnection, userId, loot._luckMail, 0, 0, mapItem, "", GlobalUtils::ToString(i+1));
                    }
                }
            }
        }
        values.clear();
        string strLastBomb = RedisKey::MakeBulletinHornKey(boss, EBST_BombCost, strLast);
        if( pConnection->zrevrange(strLastBomb, 0, maxRank-1, values) ) {
            for( size_t i = 0; i < values.size() ; ++i ) {
                int64 userId = values[i].first;
                tagBulletinLoot loot;
                if( sHArena->GetBulletinLoot(boss, i+1, loot) ) {
                    map<int32,int64> mapItem;
                    int32 lootId = loot._killLoot;
                    if( BulletinUserNoVoucher(pConnection, userId) ) {
                        lootId = loot._luckLoot;
                    }
                    if( sHLottery->GetLootItem(lootId, mapItem) ) {
                        sRankServer->SendMail(pConnection, userId, loot._killMail, 0, 0, mapItem, "", GlobalUtils::ToString(i+1));
                    }
                }
            }
        }
    }
}

bool RankBulletin::BulletinGetUser(RedisConnection* pConnection, const string& strUserKey, uint64 userId, BulletinUser& lhs) {
    string strUser;
    if( !pConnection->hget(strUserKey, userId, strUser) ) {
        LOGERROR("user[%lu] get bulletin user failed[%s]", userId, strUserKey.c_str());
        return false;
    }
    if( !JsonProto::ProtoFromJson(strUser, lhs) ) {
        LOGERROR("user[%lu] get bulletin user[%s] failed[%s]", userId, strUserKey.c_str(), strUser.c_str());
        return false;
    }
    return true;
}
