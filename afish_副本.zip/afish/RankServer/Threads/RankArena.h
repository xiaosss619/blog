#pragma once

#include "ServerDefine.h"

class RedisConnection;
class RankArena
{
public:
	RankArena(boost::asio::io_service& io);
	~RankArena();

	void OnTimer5s(const boost::system::error_code& error);
private:
	void ArenaCrossDay(RedisConnection* pConnection, int64 now);
	bool ArenaGetUser(RedisConnection* pConnection, uint64 userId, ArenaUser& lhs);
private:
	boost::asio::io_service& _io_service;
	boost::asio::deadline_timer _timer;
	// 排行榜跨天时间,记录在redis中
	int64 m_tmCrossDay;
};
