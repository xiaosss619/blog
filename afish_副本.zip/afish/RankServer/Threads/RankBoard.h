#pragma once

#include "ServerDefine.h"

class RedisConnection;
class RankBoard
{
public:
	RankBoard(boost::asio::io_service& io);
	~RankBoard();
	void OnTimer5s(const boost::system::error_code& error);
private:
	void BoardCrossDay(RedisConnection* pConnection, int64 now);
	void WeekBoardReward(RedisConnection* pConnection, int32 boardId);
	bool GetBoardUser(RedisConnection* pConnection, uint64 userId, BoardUser& lhs);
private:
	boost::asio::io_service& _io_service;
	boost::asio::deadline_timer _timer;
	// 排行榜跨天时间,记录在redis中
	int64 m_tmCrossDay;
};
