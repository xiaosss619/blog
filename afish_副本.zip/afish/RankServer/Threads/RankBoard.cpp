/**
 * 排名模块
*/
#include "RankBoard.h"
#include "RedisManager/RedisManager.h"
#include "Include/RedisProtoHelper.h"
#include "DataCache/RedisData.h"
#include "HelperArena.h"
#include "HelperLottery.h"
#include "RankServer.h"

RankBoard::RankBoard(boost::asio::io_service& io)
    : _io_service(io), _timer(io)
{
    m_tmCrossDay = 0;
    _timer.expires_from_now(boost::posix_time::seconds(5));
    _timer.async_wait(boost::bind(&RankBoard::OnTimer5s, this, boost::asio::placeholders::error));
}

RankBoard::~RankBoard() {
}

void RankBoard::OnTimer5s(const boost::system::error_code& error) {
    if( !error ) {
        RedisConnectionIdGetter idGetter(enumRedisServerTypeData);
        auto pConnection = idGetter.GetConnection();
        if( pConnection != nullptr ) {
            int64 now = time(nullptr);
            if( m_tmCrossDay == 0 ) {
                // 返回false说明没有对应的key, 系统初始化, 则设置为当前时间, 无需跨天计算
                if( !pConnection->get(BOARD_CROSSDAY_TIME, m_tmCrossDay) ) {
                    m_tmCrossDay = now;
                    pConnection->set(BOARD_CROSSDAY_TIME, m_tmCrossDay);
                }
            }
            BoardCrossDay(pConnection, now);
        }

        _timer.expires_from_now(boost::posix_time::seconds(5));
        _timer.async_wait(boost::bind(&RankBoard::OnTimer5s, this, boost::asio::placeholders::error));
    }
}

void RankBoard::BoardCrossDay(RedisConnection* pConnection, int64 now) {
    // 大于0,每秒判定一次跨天
    bool isMonday = false;
    if( !pConnection->exists("GM:BOARD") ) {
        if( GlobalUtils::InSameDay(now, m_tmCrossDay) ) {
            return;
        }
        m_tmCrossDay = now;
        pConnection->set(BOARD_CROSSDAY_TIME, m_tmCrossDay);
        isMonday = GlobalUtils::IsMonday(now);
    }
    else {
        // 强制发一次奖励, 测试用
        isMonday = true;
        pConnection->del("GM:BOARD");
    }

    // 数据量过大的话,把redis中排行榜rename,单独在其他线程中每次取部分发奖励
    if( isMonday ) {
        // 跨周
        WeekBoardReward(pConnection, e_jsonRankRewardRankID_GoldIncome);
        WeekBoardReward(pConnection, e_jsonRankRewardRankID_GoldExpense);
        WeekBoardReward(pConnection, e_jsonRankRewardRankID_NuclearIncome);
        WeekBoardReward(pConnection, e_jsonRankRewardRankID_NuclearExpense);
        WeekBoardReward(pConnection, e_jsonRankRewardRankID_CrystalIncome);
        WeekBoardReward(pConnection, e_jsonRankRewardRankID_CrystalExpense);
        WeekBoardReward(pConnection, e_jsonRankRewardRankID_VIP);
        pConnection->del(BOARD_USER_INFO_KEY);
    }
}

void RankBoard::WeekBoardReward(RedisConnection* pConnection, int32 boardId) {
    int32 maxRank = sHArena->GetBoardMaxRank(boardId);
    std::vector< std::pair<int64, int64 > > values;
    if( pConnection->zrevrange(RedisKey::MakeBoardDataKey(boardId), 0, maxRank-1, values) ) {
        for( size_t i = 0; i < values.size() ; ++i ) {
            int64 userId = values[i].first;
            map<int32,int64> mapItem;
            tagBoardLoot loot;
            if( sHArena->GetBoardLoot(boardId, i+1, loot) ) {
                if( sHLottery->GetLootItem(loot._loot, mapItem) ) {
                    sRankServer->SendMail(pConnection, userId, loot._mail, 0, 0, mapItem, "", GlobalUtils::ToString(i+1));
                }
            }
        }
        pConnection->del(RedisKey::MakeBoardDataKey(boardId));
    }
}

bool RankBoard::GetBoardUser(RedisConnection* pConnection, uint64 userId, BoardUser& lhs) {
    string strUser;
    if( !pConnection->hget(BOARD_USER_INFO_KEY, userId, strUser) ) {
        LOGERROR("user[%lu] failed to get info", userId);
        return false;
    }
    if( !JsonProto::ProtoFromJson(strUser, lhs) ) {
        LOGERROR("user[%lu] failed to get info[%s]", userId, strUser.data());
        return false;
    }
    return true;
}
