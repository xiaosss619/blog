/**
 * 竞技场排名模块
*/
#include "RankArena.h"
#include "RedisManager/RedisManager.h"
#include "Include/RedisProtoHelper.h"
#include "DataCache/RedisData.h"
#include "HelperArena.h"
#include "HelperLottery.h"
#include "RankServer.h"

RankArena::RankArena(boost::asio::io_service& io)
    : _io_service(io), _timer(io)
{
    m_tmCrossDay = 0;
    _timer.expires_from_now(boost::posix_time::seconds(5));
    _timer.async_wait(boost::bind(&RankArena::OnTimer5s, this, boost::asio::placeholders::error));
}

RankArena::~RankArena() {
}

void RankArena::OnTimer5s(const boost::system::error_code& error) {
    if( !error ) {
        RedisConnectionIdGetter idGetter(enumRedisServerTypeData);
        auto pConnection = idGetter.GetConnection();
        if( pConnection != nullptr ) {
            int64 now = time(nullptr);
            if( m_tmCrossDay == 0 ) {
                // 返回false说明没有对应的key, 系统初始化, 则设置为当前时间, 无需跨天计算
                if( !pConnection->get(RedisKey::MakeArenaCrossDayKey(), m_tmCrossDay) ) {
                    m_tmCrossDay = now;
                    pConnection->set(RedisKey::MakeArenaCrossDayKey(), m_tmCrossDay);
                }
            }
            ArenaCrossDay(pConnection, now);
            // 核弹场开奖名单缩减一下, 保持在50个
            RedisData::ShrinkListUsingRPop(pConnection, RedisKey::MakeSysBombGamePoolListKey(), 50);
        }
        else {
            LOGERROR("NO REDIS");
        }
        _timer.expires_from_now(boost::posix_time::seconds(5));
        _timer.async_wait(boost::bind(&RankArena::OnTimer5s, this, boost::asio::placeholders::error));
    }
}

void RankArena::ArenaCrossDay(RedisConnection* pConnection, int64 now) {
    bool isMonday = false;
    if( !pConnection->exists("GM:ARENA") ) {
        if( GlobalUtils::InSameDay(now, m_tmCrossDay) ) {
            return;
        }
        m_tmCrossDay = now;
        pConnection->set(RedisKey::MakeArenaCrossDayKey(), m_tmCrossDay);
        isMonday = GlobalUtils::IsMonday(now);
    }
    else {
        // 强制发奖, 测试用
        isMonday = true;
        pConnection->del("GM:ARENA");
    }
    int64 totalNum = 0;
    pConnection->zcard(RedisKey::MakeArenaDayKey(), totalNum);
    if( totalNum > 0 ) {
        LOGINFO("Start daily board reward, total[%ld]", totalNum);
        int64 rewardNum = 0;
        int64 start = 0;
        int64 end = 0;
        std::vector< std::pair<int64, int64 > > values;
        while( rewardNum < totalNum ) {
            values.clear();
            start = rewardNum;
            end = start + 1000;
            if( pConnection->zrevrange(RedisKey::MakeArenaDayKey(), start, end, values) ) {
                if( values.size() == 0 ) {
                    LOGERROR("empty result set encoutered, cur[%ld] total[%ld]", rewardNum, totalNum);
                    break;
                }
                for( size_t i = 0; i < values.size() ; ++i ) {
                    int64 userId = values[i].first;
                    map<int32,int64> mapItem;
                    auto loot = sHArena->GetArenaLoot(i+1);
                    if( sHLottery->GetLootItem(TUPLE0(loot), mapItem) ) {
                        sRankServer->SendMail(pConnection, userId, TUPLE2(loot), 0, 0, mapItem, "", GlobalUtils::ToString(i+1));
                    }
                    // 往周榜上累计
                    pConnection->zincrby(RedisKey::MakeArenaWeekKey(), userId, values[i].second);
                    ++rewardNum;
                }
            }
            else {
                LOGINFO("No Data anymore cur[%ld] total[%ld]", rewardNum, totalNum);
                break;
            }
        }
        pConnection->del(RedisKey::MakeArenaDayKey());
        LOGINFO("End daily board reward...");
    }

    // 每天清理一次15天内没打过竞技场的玩家
    LOGINFO("Daily cleanup expire users start");
    int32 cleaned = 0;
    map<uint64, ArenaUser> mapUser;
    RedisProtoHelper::RedisLoadArenaUser(pConnection, RedisKey::MakeArenaUserKey(), mapUser);
    for( auto& it : mapUser) {
        // 一周清理一次过期的竞技场用户
        if( now - it.second.user_time() >= TIME_DAY*15 ) {
            // 超过15天的用户应该已经没用了
            pConnection->hdel(RedisKey::MakeArenaUserKey(), GlobalUtils::ToString(it.first));
            ++cleaned;
        }
    }
    LOGINFO("Daily cleanup end, total[%lu] cleaned[%d]", mapUser.size(), cleaned);

    // 周一发奖后清空双榜
    if( !isMonday ) {
        return;
    }
    pConnection->del(RedisKey::MakeArenaLastWeekKey());
    
    totalNum = 0;
    pConnection->zcard(RedisKey::MakeArenaWeekKey(), totalNum);
    if( totalNum > 0 ) {
        LOGINFO("Start week board reward, total[%ld]", totalNum);
        int64 rewardNum = 0;
        int64 start = 0;
        int64 end = 0;
        std::vector< std::pair<int64, int64> > values;
        int32 iLastWeek = 0;
        while( rewardNum < totalNum ) {
            values.clear();
            start = rewardNum;
            end = start + 1000;
            if( pConnection->zrevrange(RedisKey::MakeArenaWeekKey(), start, end, values) ) {
                if( values.size() == 0 ) {
                    LOGERROR("empty result set encoutered, cur[%ld] total[%ld]", rewardNum, totalNum);
                    break;
                }
                for( size_t i = 0; i < values.size() ; ++i ) {
                    int64 userId = values[i].first;
                    int32 score = U_RankScore::GetScore(values[i].second);
                    map<int32,int64> mapItem;
                    auto loot = sHArena->GetArenaLoot(i+1);
                    if( sHLottery->GetLootItem(TUPLE1(loot), mapItem) ) {
                        sRankServer->SendMail(pConnection, userId, TUPLE3(loot), 0, 0, mapItem, "", GlobalUtils::ToString(i+1));
                    }
                    if( iLastWeek < 3 ) {
                        // 上周前三名
                        ArenaUser top3;
                        if( ArenaGetUser(pConnection, userId, top3) ) {
                            top3.set_user_score(score);
                            top3.set_user_rank(i+1);
                            ++iLastWeek;
                            RedisProtoHelper::RedisSaveHSET(pConnection, RedisKey::MakeArenaLastWeekKey(), GlobalUtils::ToString(iLastWeek), top3);
                        }
                    }
                    ++rewardNum;
                }
            }
            else {
                LOGINFO("No Data anymore cur[%ld] total[%ld]", rewardNum, totalNum);
                break;
            }
        }
        pConnection->del(RedisKey::MakeArenaWeekKey());
        LOGINFO("End week board reward... cur[%ld] total[%ld]", rewardNum, totalNum);
    }
}

bool RankArena::ArenaGetUser(RedisConnection* pConnection, uint64 userId, ArenaUser& lhs) {
    string strUser;
    pConnection->hget(RedisKey::MakeArenaUserKey(), userId, strUser);
    if( !JsonProto::ProtoFromJson(strUser, lhs) ) {
        LOGERROR("user[%lu] arena info failed[%s]", userId, strUser.data());
        return false;
    }
    return true;
}
