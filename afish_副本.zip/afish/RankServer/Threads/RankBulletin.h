#pragma once

#include "ServerDefine.h"

class RedisConnection;
class RankBulletin
{
public:
	RankBulletin(boost::asio::io_service& io);
	~RankBulletin();

	void OnTimer5s(const boost::system::error_code& error);
private:
	void BulletinCrossDay(RedisConnection* pConnection, int64 now);
	bool BulletinGetUser(RedisConnection* pConnection, const string& strUserKey, uint64 userId, BulletinUser& lhs);

    bool BulletinUserNoVoucher(RedisConnection* pConnection, uint64 userId);
private:
	boost::asio::io_service& _io_service;
	boost::asio::deadline_timer _timer;
	// 排行榜跨天时间,记录在redis中
	int64 m_tmCrossDay;
};
