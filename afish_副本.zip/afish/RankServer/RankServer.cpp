#include "RankServer.h"
#include "DataCache/RedisData.h"
#include "DataCache/SqlLink.h"
#include "Include/RedisKey.h"
#include "Include/MySQLProtoHelper.h"
#include "Threads/HelperArena.h"
#include "Threads/HelperLottery.h"
#include "Threads/RankBulletin.h"
#include "Threads/RankArena.h"
#include "Threads/RankBoard.h"

RankServer::RankServer()
	: Poolize(THREAD_TOTAL)
{
	_bulletin = new RankBulletin(get_io_service(0));
	_arena = new RankArena(get_io_service(1));
	_board = new RankBoard(get_io_service(2));
}

RankServer::~RankServer() {
}

bool RankServer::Init() {
    if( !sHArena->Init() ) {
        LOGERROR("sHArena init failed");
        return false;
    }
    if( !sHLottery->Init() ) {
        LOGERROR("sHLottery init failed");
        return false;
    }
    return true;
}

void RankServer::SendMail(RedisConnection* pConnection, uint64 uUserId, int32 nMailType, int64 iDiamond, int64 iGold, const map<int32, int64>& mapItem, const string& title, const string& content) {
    LxMail mail;
	mail.set_mail_id(0);
	mail.set_mail_type(nMailType);
	mail.set_mail_time(time(nullptr));
	mail.set_mail_read(0);
	mail.set_mail_diamond(max(iDiamond, 0L));
	mail.set_mail_gold(max(iGold, 0L));
	mail.set_mail_title(title);
	mail.set_mail_content(content);
	if( mapItem.size() == 0 && iDiamond == 0 && iGold == 0 ) {
		mail.set_mail_rewarded(1);
	}
	else {
		mail.set_mail_rewarded(0);
	}
	for( auto& item : mapItem ) {
        if( item.second > 0 ) {
            auto pItem = mail.add_mail_items();
            pItem->set_item_id(item.first);
            pItem->set_item_change(item.second);
            pItem->set_item_num(item.second);
        }
	}
    pConnection->lpush(RedisKey::MakeUserOfflineMailKey(uUserId), JsonProto::ProtoToJson(mail));
}
