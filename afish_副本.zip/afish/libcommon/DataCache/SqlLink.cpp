#include "SqlLink.h"

#include <time.h>
#include <typeinfo>
#include <stdarg.h>

#include <boost/algorithm/string.hpp>
#include <boost/date_time/gregorian/gregorian.hpp>
using namespace boost::gregorian;
using namespace boost::posix_time;
#include "ThreadLog/ThreadLog.h"

#include "Utils/base64.h"
#include "Utils/fasthash.h"
#include "Utils/GlobalUtils.h"
#include "LxGame.pb.h"

SqlLink::SqlLink() : m_isDbConnected(false)
{
	m_bInited = false;

	int i = 0;
	for (i = 0; i < MAX_DB_NUM; ++i)
	{
		m_arDriver[i] = nullptr;
	}

	for (i = 0; i < MAX_DB_NUM; ++i)
	{
		m_arConnections[i] = nullptr;
	}

	m_bClosingDB = false;
	m_bConnecttingDB = false;

}

SqlLink::~SqlLink(void)
{
	closeMasterDB();
}

void SqlLink::Init(const string &strUrl, const string &strUserName, const string &strPassword)
{
	if (!m_bInited)
	{
		for (int n = 0; n < MAX_DB_NUM; ++n)
		{
			m_mapUserDBUrl[n] = strUrl;
		}
		m_strUserName = strUserName;
		m_strPassword = strPassword;

		connectMasterDB(true);
		m_bInited = true;
	}
}

void SqlLink::closeMasterDB()
{
	if (!m_bClosingDB && !m_bConnecttingDB)
	{
		m_bClosingDB = true;
	}
	else
	{
		return;
	}

	m_bClosingDB = false;
	m_isDbConnected = false;

	return;
}

bool SqlLink::execute(int dbPos, const std::string &command)
{
	boost::posix_time::ptime time_begin = boost::posix_time::microsec_clock::universal_time();

	boost::posix_time::ptime time_begin_mutex;

	bool bRtn = false;
	bool bExecuteSucc = false;

	Statement *state = nullptr;
	for (int i = 0; i < 5; i++)
	{
		time_begin_mutex = boost::posix_time::microsec_clock::universal_time();
		try
		{
			if (nullptr == m_arConnections[dbPos])
			{
				break;
			}
			if (!m_arConnections[dbPos]->isClosed())
			{
				state = m_arConnections[dbPos]->createStatement();
				state->execute(command);
				bRtn = true;
				bExecuteSucc = true;
				state->close();
				delete state;
				state = nullptr;
			}
			else
			{
				closeMasterDB();
			}
		}
		catch (SQLException &e)
		{
			if (nullptr != state)
			{
				state->close();
				delete state;
				state = nullptr;
			}
			bExecuteSucc = !FuncHandleSqlException(dbPos, command, e);
		}
		catch (...)
		{
			if (nullptr != state)
			{
				state->close();
				delete state;
				state = nullptr;
			}
			LOGERROR("# ERR: SQLException sql[%s]", command.c_str());
		}
		if (bExecuteSucc)
		{
			break;
		}
	}

	boost::posix_time::ptime time_end = boost::posix_time::microsec_clock::universal_time();

	boost::posix_time::millisec_posix_time_system_config::time_duration_type time_elapse = time_end - time_begin;
	int ticks = time_elapse.ticks();
	if (ticks >= 5000)
	{
	}

	time_elapse = time_end - time_begin_mutex;
	ticks = time_elapse.ticks();
	if (ticks >= 5000)
	{
	}

	return bRtn;
}

void SqlLink::connectMasterDB(bool init)
{
	if (!m_bConnecttingDB && !m_bClosingDB)
	{
		m_bConnecttingDB = true;
	}
	else
	{
		return;
	}
	if (m_isDbConnected)
	{
		m_bConnecttingDB = false;
		return;
	}

	Statement *state = nullptr;
	{
		for (int i = 0; i < MAX_DB_NUM; ++i)
		{
			try
			{
				if (m_arConnections[i] != nullptr && !m_arConnections[i]->isClosed())
				{
					continue;
				}

				if (nullptr != m_arDriver[i])
				{
					m_arDriver[i] = nullptr;
				}

				// 初始化驱动
				m_arDriver[i] = sql::mysql::get_mysql_driver_instance();
				if (nullptr == m_arDriver[i])
				{
					m_bConnecttingDB = false;
					return;
				}

				if (nullptr != m_arConnections[i])
				{
					if (!m_arConnections[i]->isClosed())
					{
						m_arConnections[i]->close();
					}

					delete m_arConnections[i];
					m_arConnections[i] = nullptr;
				}

				// 建立链接
				map<int, string>::const_iterator iter = m_mapUserDBUrl.find(i);
				if (iter == m_mapUserDBUrl.end())
				{
					continue;
				}

				ConnectOptionsMap mapConnectionProperties;
				CreateConnectionProperties(iter->second, m_strUserName, m_strPassword, mapConnectionProperties);
				m_arConnections[i] = m_arDriver[i]->connect(mapConnectionProperties);
				if (nullptr == m_arConnections[i])
				{
					m_bConnecttingDB = false;
					return;
				}

				state = m_arConnections[i]->createStatement();
				if (nullptr == state)
				{
					m_bConnecttingDB = false;
					return;
				}
				std::ostringstream osCreate;
				osCreate << "create database if not exists Fish_" << i << ";";
				state->execute(osCreate.str());
				std::ostringstream ostrDB;
				ostrDB << "use Fish_" << i << ";";
				state->execute(ostrDB.str());

				state->close();
				delete state;
				state = nullptr;
			}
			catch (SQLException &e)
			{
				if (nullptr != state)
				{
					state->close();
					delete state;
					state = nullptr;
				}
				LOGERROR("# ERR: SQLException in db[%d] ERR[%s]", i, e.what());
				m_bConnecttingDB = false;
			}
			catch (...)
			{
				if (nullptr != state)
				{
					state->close();
					delete state;
					state = nullptr;
				}
				LOGERROR("# ERR: SQLException in db[%d]", i);
				m_bConnecttingDB = false;
			}
		}
	}

	if (m_bConnecttingDB)
	{
		m_isDbConnected = true;
		m_bConnecttingDB = false;
	}
}

void SqlLink::ping()
{
	ostringstream osPingCmd;
	string strPingCmd;
	for (int i = 0; i < MAX_DB_NUM; i++)
	{
		osPingCmd.str("");
		osPingCmd << "use Fish_" << i;
		strPingCmd = osPingCmd.str();
		execute(i, strPingCmd);
	}
}

void SqlLink::check_database()
{
	if (!m_isDbConnected)
	{
		connectMasterDB(false);
	}
	ping();
}

ConnectPropertyVal SqlLink::CreateConnectPropertyVal(const string &strValue)
{
	ConnectPropertyVal val(strValue);
	return val;
}

ConnectPropertyVal SqlLink::CreateConnectPropertyVal(int iValue)
{
	ConnectPropertyVal val(iValue);
	return val;
}

ConnectPropertyVal SqlLink::CreateConnectPropertyValBool(bool bValue)
{
	ConnectPropertyVal val(bValue);
	return val;
}

void SqlLink::CreateConnectionProperties(const string &strHostName,
											const string &strUserName, const string &strPassword,
											ConnectOptionsMap &mapConnectionProperties)
{
	mapConnectionProperties["hostName"] = CreateConnectPropertyVal(strHostName);
	mapConnectionProperties["userName"] = CreateConnectPropertyVal(strUserName);
	mapConnectionProperties["password"] = CreateConnectPropertyVal(strPassword);
	int iTimeOut = 2;
	mapConnectionProperties["OPT_WRITE_TIMEOUT"] = CreateConnectPropertyVal(iTimeOut);
	mapConnectionProperties["OPT_READ_TIMEOUT"] = CreateConnectPropertyVal(iTimeOut);
	bool bCompress = true;
	mapConnectionProperties["CLIENT_COMPRESS"] = CreateConnectPropertyValBool(bCompress);
	bool bMultiStatements = true;
	mapConnectionProperties["CLIENT_MULTI_STATEMENTS"] = CreateConnectPropertyValBool(bMultiStatements);
}

bool SqlLink::IsErrorCodeNeedReconnect(int iErrorCode)
{
	if ((iErrorCode == 0x7dd) || (iErrorCode == 1043) || (iErrorCode == 1130) || (iErrorCode == 1158) || (iErrorCode == 1159) || (iErrorCode == 1160) || (iErrorCode == 1161) || (iErrorCode == 2001) || (iErrorCode == 2002) || (iErrorCode == 2003) || (iErrorCode == 2004) || (iErrorCode == 2005) || (iErrorCode == 2006) || (iErrorCode == 2014) || (iErrorCode == 2048))
	{
		return true;
	}

	return false;
}

bool SqlLink::FuncHandleSqlException(int dbPos, const std::string &command, SQLException &e)
{
	LOGERROR("# ERR: SQLException sql[%s] ERR[%s]", command.c_str(), e.what());
	int errorCode = e.getErrorCode();
	if (IsErrorCodeNeedReconnect(errorCode))
	{
		closeMasterDB();
		ReConnectDB(dbPos);
		return true;
	}

	return false;
}

void SqlLink::ReConnectDB(int iDBPos)
{
	Statement *state = nullptr;
	//注意,所有ReconnectDB操作都应该在一个db操作里面,所以这里不能再加锁,否则就死锁了
	//相应的,这个操作也不能在无锁条件下调用

	try
	{
		if (nullptr != m_arConnections[iDBPos])
		{
			if (!m_arConnections[iDBPos]->isClosed())
			{
				m_arConnections[iDBPos]->close();
			}

			delete m_arConnections[iDBPos];
			m_arConnections[iDBPos] = nullptr;
		}

		map<int, string>::const_iterator iter = m_mapUserDBUrl.find(iDBPos);
		if (iter == m_mapUserDBUrl.end())
		{
			return;
		}

		ConnectOptionsMap mapConnectionProperties;
		CreateConnectionProperties(iter->second, m_strUserName, m_strPassword, mapConnectionProperties);

		m_arConnections[iDBPos] = m_arDriver[iDBPos]->connect(mapConnectionProperties);
		if (nullptr == m_arConnections[iDBPos])
		{
			m_bConnecttingDB = false;
			return;
		}

		state = m_arConnections[iDBPos]->createStatement();
		if (nullptr == state)
		{
			m_bConnecttingDB = false;
			return;
		}
		std::ostringstream ostrDB;
		ostrDB << "use Fish_" << iDBPos << ";";

		state->execute(ostrDB.str());

		state->close();
		delete state;
		state = nullptr;
	}
	catch (SQLException &e)
	{
		if (nullptr != state)
		{
			state->close();
			delete state;
			state = nullptr;
		}
		LOGERROR("# ERR: SQLException reconnect db[%d] ERR[%s]", iDBPos, e.what());
		int errorCode = e.getErrorCode();
		if (IsErrorCodeNeedReconnect(errorCode))
		{
			closeMasterDB();
		}
	}
	catch (...)
	{
		if (nullptr != state)
		{
			state->close();
			delete state;
			state = nullptr;
		}
		LOGERROR("# ERR: SQLException in db[%d]", iDBPos);
	}
}
