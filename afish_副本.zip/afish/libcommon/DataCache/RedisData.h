#pragma once

#include "Include/ServerDefine.h"

class RedisData {
public:
    // 用户自增id,由incrby实现
    static uint64 GenerateUserId(RedisConnection* pConnection);
    static bool GenerateUserId(int32 nNum, vector<uint64>& vecUserId, RedisConnection* pConnection);

    static string GetUserDefineData(uint64 uUserId, RedisConnection* pConnection);
    static bool SetUserDefineData(uint64 uUserId, const string& value);

    static uint64 GetUserIdByOpenId(const string& strOpenId, RedisConnection* pConnection);
    static bool SetUserIdWithOpenId(const string& strOpenId, uint64 uUserId, RedisConnection* pConnection);
    static bool HasUser(uint64 uUserId, RedisConnection* pConnection);

    // 获得指定奖池指定位置进度条数据
    static int64 GetSlotBarData(RedisConnection* pConnection, int32 serverId, int32 slotId, int32 idx);
    static bool SetSlotBarData(RedisConnection* pConnection, int32 serverId, int32 slotId, int32 idx, int64 cur);

    // 获得指定奖池当前累计赌注数额
    static int64 GetSlotPoolData(RedisConnection* pConnection, int32 serverId, int32 slotId);
    static bool SetSlotPoolData(RedisConnection* pConnection, int32 serverId, int32 slotId, int64 cur);

    static bool PassWhiteList(RedisConnection* pConnection, const string& userId);

    // 用rpop方式把列表收缩到maxLen长度
    static void ShrinkListUsingRPop(RedisConnection* pConnection, const string& strKey, int32 maxLen);

    static bool IsApplyListFull(RedisConnection* pConnection, uint64 userId);
    static bool IsFriendListFull(RedisConnection* pConnection, uint64 userId);

    static bool SetUserTargetInfo(RedisConnection* pConnection, const TargetInfo& info);
    static bool GetUserTargetInfo(RedisConnection* pConnection, uint64 userId, TargetInfo& lhs);

    static bool IsUserOnline(RedisConnection* pConnection, uint64 userId);
    static bool IsUserBlocked(RedisConnection* pConnection, uint64 src, uint64 dst);

    static void GetTableSkillLockFlag(RedisConnection* pConnection, int32 tableId, GameRoomLimit* pLimit);

    static int64 GenerateGiftId(RedisConnection* pConnection);
    static int64 GenerateChatGroupId(RedisConnection* pConnection);
    static int64 GenerateChatMsgId(RedisConnection* pConnection);
    static int64 GenerateBossGuid();

    static string GetUserGiftCode(RedisConnection* pConnection, uint64 userId);
    static bool IsInMuteTime(RedisConnection* pConnection, uint64 userId, int64 now);
    static int32 GetUserPopularity(RedisConnection* pConnection, uint64 userId);
    static string GetUserPhone(RedisConnection* pConnection, uint64 userId);

    static int32 GetSysFireInterval();

    static bool GetGift(RedisConnection* pConnection, int64 guid, GiftData& lhs);
};
