#include "ProtoCmdHelper.h"
#include "Include/RedisKey.h"

#define SIMPLE_CMD "[{\"uid\":\"<T1>\", \"cmd\":<T2>, \"param\":\"<T3>\"}]"

void ProtoCmdHelper::PushUserCmd(RedisConnection* pConnection, uint64 userId, const UserProtoCmd& proto) {
    pConnection->lpush(RedisKey::MakeUserProtoCmdKey(userId), JsonProto::ProtoToJson(proto));
}

void ProtoCmdHelper::ForEachUserCmd(RedisConnection* pConnection, uint64 userId, boost::function<void(const UserProtoCmd&)> func) {
    vector<string> vecCmd;
    pConnection->rpop(RedisKey::MakeUserProtoCmdKey(userId), 50, vecCmd);
    for( size_t n = 0 ; n < vecCmd.size() ; n++ ) {
        UserProtoCmd proto;
        if( !JsonProto::ProtoFromJson(vecCmd[n], proto)) {
            LOGERROR("UserProtoCmd failed[%s]", vecCmd[n].c_str());
            continue;
        }
        func(proto);
    }
}

void ProtoCmdHelper::PushServerCmd(RedisConnection* pConnection, int32 serverId, const ServerProtoCmd& proto) {
    pConnection->lpush(RedisKey::MakeServerCmdKey(serverId), JsonProto::ProtoToJson(proto));
}

void ProtoCmdHelper::ForEachServerCmd(RedisConnection* pConnection, int32 serverId, boost::function<void(const ServerProtoCmd&)> func) {
    vector<string> vecCmd;
    pConnection->rpop(RedisKey::MakeServerCmdKey(serverId), 50, vecCmd);
    for( size_t n = 0 ; n < vecCmd.size() ; n++ ) {
        ServerProtoCmd proto;
        if( !JsonProto::ProtoFromJson(vecCmd[n], proto)) {
            LOGERROR("UserProtoCmd failed[%s]", vecCmd[n].c_str());
            continue;
        }
        func(proto);
    }
}

void ProtoCmdHelper::PushGmCmd(RedisConnection* pConnection, uint64 userId, int32 cmd) {
    vector<string> vec;
    PushGmCmd(pConnection, userId, cmd, vec);
}

void ProtoCmdHelper::PushGmCmd(RedisConnection* pConnection, uint64 userId, int32 cmd, const vector<string>& params) {
    string strData = SIMPLE_CMD;
    strData = GlobalUtils::ReplaceAll(strData, "<T1>", GlobalUtils::ToString(userId));
    strData = GlobalUtils::ReplaceAll(strData, "<T2>", GlobalUtils::ToString(cmd));
    if( params.size() > 0 ) {
        string strParam = GlobalUtils::JoinArray(params, "|");
        strData = GlobalUtils::ReplaceAll(strData, "<T3>", strParam);
    }
    else {
        strData = GlobalUtils::ReplaceAll(strData, "<T3>", "");
    }
    pConnection->lpush(RedisKey::MakeUserGmCmdKey(userId), strData);
}

void ProtoCmdHelper::ForEachGmCmd(RedisConnection* pConnection, uint64 userId, boost::function<void(const string&)> func) {
    vector<string> vecCmd;
    pConnection->rpop(RedisKey::MakeUserGmCmdKey(userId), 100, vecCmd);
    for( size_t n = 0 ; n < vecCmd.size() ; n++ ) {
        func(vecCmd[n]);
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// 使用stream
void ProtoCmdHelper::PushChatCmd(RedisConnection* pConnection, const ChatChannelCmd& proto) {
    pConnection->xadd(SYS_CHANNEL_CHAT_KEY, GlobalUtils::ToString(proto.cmd()), JsonProto::ProtoToJson(proto));
}

void ProtoCmdHelper::PushGiftCmd(RedisConnection* pConnection, const GiftChannelCmd& proto) {
    pConnection->xadd(SYS_CHANNEL_GIFT_KEY, GlobalUtils::ToString(proto.cmd()), JsonProto::ProtoToJson(proto));
}

