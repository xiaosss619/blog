#pragma once

#include "ThreadLog/ThreadLog.h"
#include <mysql_connection.h>
#include <mysql_driver.h>
#include <cppconn/statement.h>
#include <cppconn/exception.h>
#include <cppconn/prepared_statement.h>
using namespace sql;

#include <boost/asio.hpp>
#include <boost/thread/thread.hpp>
#include <boost/bind.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/noncopyable.hpp>
#include <boost/scoped_ptr.hpp>
#include <boost/function.hpp>

#include <string>
using namespace std;

#define MAX_DB_NUM 16
#define MAX_TATBLE_NUM 16

enum EnumDBOperReturnCode
{
    ENUM_DBOP_RTNCODE_SUCCESS = 0,
    ENUM_DBOP_RTNCODE_RESULTNOTFOUND,
    ENUM_DBOP_RTNCODE_DBFAILED,
    ENUM_DBOP_RTNCODE_MAX
};

template <class T>
struct BinaryPredicateType {
  using type = std::function<bool(ResultSet*, T&)>;
};

class SqlLink
{
public:
    void Init(const string& strUrl, const string& strUserName, const string& strPassword);
public:
	SqlLink();
	virtual ~SqlLink(void);
	void check_database();

	bool execute(int dbPos, const std::string& command);
	template<typename T>
	EnumDBOperReturnCode execQueryNoParam(int dbPos, const string& command, T& lhs, const typename BinaryPredicateType<T>::type &function) {
		boost::posix_time::ptime time_begin = boost::posix_time::microsec_clock::universal_time();
		boost::posix_time::ptime time_begin_mutex;

		ResultSet* result = nullptr;
		EnumDBOperReturnCode enumReturnCode = ENUM_DBOP_RTNCODE_DBFAILED;

		PreparedStatement* state = nullptr;
		bool bSucc = false;
		bool bExecuteSucc = false;

		for (int i = 0; i < 5; i++) {
			time_begin_mutex = boost::posix_time::microsec_clock::universal_time();
			try {
				if (nullptr == m_arConnections[dbPos])
				{
					break;
				}
				if (!m_arConnections[dbPos]->isClosed())
				{
					state = m_arConnections[dbPos]->prepareStatement(command);

					result = state->executeQuery();
					bSucc = function(result, lhs);
					if (bSucc) {
						enumReturnCode = ENUM_DBOP_RTNCODE_SUCCESS;
					}
					else {
						enumReturnCode = ENUM_DBOP_RTNCODE_RESULTNOTFOUND;
					}
					state->close();
					delete state;
					state = nullptr;

					if (result != nullptr)
					{
						result->close();
						delete result;
						result = nullptr;
					}

					bExecuteSucc = true;
				}
				else
				{
					closeMasterDB();
				}
			}
			catch (SQLException& e) {
				if (nullptr != state)
				{
					state->close();
					delete state;
					state = nullptr;
				}
				bExecuteSucc = !FuncHandleSqlException(dbPos, command, e);
			}
			catch (...) {
				if (nullptr != state)
				{
					state->close();
					delete state;
					state = nullptr;
				}
				LOGERROR("# ERR: SQLException sql[%s]", command.c_str());
			}
			if (bExecuteSucc) {
				break;
			}

		}

		boost::posix_time::ptime time_end = boost::posix_time::microsec_clock::universal_time();

		boost::posix_time::millisec_posix_time_system_config::time_duration_type time_elapse = time_end - time_begin;
		int ticks = time_elapse.ticks();
		if (ticks >= 5000) {
		}

		time_elapse = time_end - time_begin_mutex;
		ticks = time_elapse.ticks();
		if (ticks >= 5000) {
		}

		return enumReturnCode;
	}
private:
	void ping();
	void connectMasterDB(bool init);
	void closeMasterDB();
	void ReConnectDB(int iDBPos);
	ConnectPropertyVal CreateConnectPropertyVal(const string& strValue);
	ConnectPropertyVal CreateConnectPropertyVal(int iValue);
	ConnectPropertyVal CreateConnectPropertyValBool(bool bValue);
	void CreateConnectionProperties(const string& strHostName,
		const string& strUserName, const string& strPassword,
		ConnectOptionsMap& mapConnectionProperties);

	bool IsErrorCodeNeedReconnect(int iErrorCode);
	bool FuncHandleSqlException(int dbPos, const std::string& command, SQLException& e);

private:
    bool m_isDbConnected;
	//主数据库
	//16个对象，16数据库，每个库一个对象，16个锁，每个库一个锁，确保多线程访问同一个数据库时是串行操作
	mysql::MySQL_Driver *m_arDriver[MAX_DB_NUM];
	Connection *m_arConnections[MAX_DB_NUM];
    bool m_bInited;
    bool m_bClosingDB;
    bool m_bConnecttingDB;
	map<int, string> m_mapUserDBUrl;
	string m_strUserName;
	string m_strPassword;
};
