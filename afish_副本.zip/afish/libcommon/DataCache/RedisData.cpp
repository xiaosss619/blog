#include "RedisData.h"
#include "Include/RedisKey.h"
#include "Include/RedisProtoHelper.h"

bool RedisData::PassWhiteList(RedisConnection* pConnection, const string& userId) {
	int32 status = ESMS_Normal;
	pConnection->get(SYS_STATUS, status);
	switch( status ) {
	case ESMS_InMaintain:
		return false;
	case ESMS_Normal:
		return true;
	case ESMS_WhiteList:
		return pConnection->hexists(SYS_STATUS_WHITE, userId);
	}
	return true;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
uint64 RedisData::GenerateUserId(RedisConnection* pConnection) {
    vector<uint64> vec;
    if( GenerateUserId(1, vec, pConnection) ) {
        return vec[0];
    }
    return 0;
}

bool RedisData::GenerateUserId(int32 nNum, vector<uint64>& vecUserId, RedisConnection* pConnection) {
	if( nNum <= 0 ) {
		LOGERROR("Invalid num[%d]", nNum);
		return false;
	}
    string strKey = RedisKey::MakeUserUniqueKey();
	// userid 做一下处理，避免一直连号看上去很蠢
	int64 iUserId = pConnection->incrby(strKey, nNum);
	if( iUserId <= 10000 ) {
		// 没初始化
		iUserId = pConnection->incrby(strKey, GlobalUtils::GetRandNumber(10000, 10086));
	}
	else if( iUserId <= 100000 ) {
		iUserId = pConnection->incrby(strKey, GlobalUtils::GetRandNumber(16, 32));
	}
	else if( iUserId < 1000000 ) {
		iUserId = pConnection->incrby(strKey, GlobalUtils::GetRandNumber(2, 8));
	}
	else {
		// 1m以上就少浪费一点
		iUserId = pConnection->incrby(strKey, 1);
	}
	if( iUserId == 0 ) {
		LOGFATAL("USERID failed");
		return false;
	}
	for( int i = 0 ; i < nNum ; i++ ) {
		vecUserId.push_back(iUserId--);
	}
	return true;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
uint64 RedisData::GetUserIdByOpenId(const string& strOpenId, RedisConnection* pConnection) {
	string key = RedisKey::MakeOpenIdUserKey(strOpenId);
	uint64 uUserId = 0;
	pConnection->get(key, uUserId);
	return uUserId;
}

bool RedisData::SetUserIdWithOpenId(const string& strOpenId, uint64 uUserId, RedisConnection* pConnection) {
	string key = RedisKey::MakeOpenIdUserKey(strOpenId);
	return pConnection->set(key, uUserId);
}

bool RedisData::HasUser(uint64 uUserId, RedisConnection* pConnection) {
	return pConnection->exists(RedisKey::MakeUserKey(uUserId));
}

////////////////////////////////////////////////////////////////////////////////////////////////
string RedisData::GetUserDefineData(uint64 uUserId, RedisConnection* pConnection) {
	string key = RedisKey::MakeUserDefineDataKey(uUserId);
	string strData;
	pConnection->get(key, strData);
	return strData;
}

bool RedisData::SetUserDefineData(uint64 uUserId, const string& value) {
	FETCH_RETURN(false);
	string key = RedisKey::MakeUserDefineDataKey(uUserId);
	return pConnection->set(key, value);
}

int64 RedisData::GetSlotBarData(RedisConnection* pConnection, int32 serverId, int32 slotId, int32 idx) {
	int64 cur = 0;
	if( pConnection->hget(RedisKey::MakeSysSlotKey(serverId, slotId), idx, cur) ) {
		return cur;
	}
	return 0;
}

bool RedisData::SetSlotBarData(RedisConnection* pConnection, int32 serverId, int32 slotId, int32 idx, int64 cur) {
	return pConnection->hset(RedisKey::MakeSysSlotKey(serverId, slotId), idx, cur);
}

int64 RedisData::GetSlotPoolData(RedisConnection* pConnection, int32 serverId, int32 slotId) {
	int64 cur = 0;
	if( pConnection->hget(RedisKey::MakeSysSlotKey(serverId, slotId), "pool", cur) ) {
		return cur;
	}
	return 0;
}

bool RedisData::SetSlotPoolData(RedisConnection* pConnection, int32 serverId, int32 slotId, int64 cur) {
	return pConnection->hset(RedisKey::MakeSysSlotKey(serverId, slotId), "pool", cur);
}

void RedisData::ShrinkListUsingRPop(RedisConnection* pConnection, const string& strKey, int32 maxLen) {
    int32 len = 0;
    if( pConnection->llen(strKey, len) ) {
        if( len > maxLen ) {
            vector<string> vecTemp;
            pConnection->rpop(strKey, len-maxLen, vecTemp);
        }
    }
}

bool RedisData::IsApplyListFull(RedisConnection* pConnection, uint64 userId) {
	string strKey = RedisKey::MakeUserApplyKey(userId);
	int64 num = 0;
	if( pConnection->zcard(strKey, num) ) {
		return num >= JDATA->SystemConstPtr()->GetFriendApplyLimit();
	}
	// 查找失敗返回一個好友滿比較合適
	return true;
}

bool RedisData::IsFriendListFull(RedisConnection* pConnection, uint64 userId) {
	string strKey = RedisKey::MakeUserFriendKey(userId);
	return pConnection->hlen(strKey) >= JDATA->SystemConstPtr()->GetFriendNumLimit();
}

bool RedisData::SetUserTargetInfo(RedisConnection* pConnection, const TargetInfo& info) {
	string strKey = RedisKey::MakeUserTargetInfoKey(info.t_id());
	if( RedisProtoHelper::RedisSaveSET(pConnection, strKey, info) ) {
		pConnection->expire(strKey, TIME_DAY*30);
		return true;
	}
	return false;
}

bool RedisData::GetUserTargetInfo(RedisConnection* pConnection, uint64 userId, TargetInfo& lhs) {
	string strKey = RedisKey::MakeUserTargetInfoKey(userId);
	string strData;
	if( pConnection->get(strKey, strData) ) {
		pConnection->expire(strKey, TIME_DAY*30);
		return JsonProto::ProtoFromJson(strData, lhs);
	}
	return false;
}

bool RedisData::IsUserOnline(RedisConnection* pConnection, uint64 userId) {
	string strKey = RedisKey::MakeUserKey(userId);
	int64 offline = 1;	// 如果差不到对应角色, 应该显示一个离线
	pConnection->hget(strKey, "time_offline", offline);
	return offline == 0;
}

bool RedisData::IsUserBlocked(RedisConnection* pConnection, uint64 src, uint64 dst) {
	string strKey = RedisKey::MakeUserBlockKey(src);
	return pConnection->hexists(strKey, GlobalUtils::ToString(dst));
}

void RedisData::GetTableSkillLockFlag(RedisConnection* pConnection, int32 tableId, GameRoomLimit* pLimit) {
	if( pConnection->hexists(RedisKey::MakeTableSkillLockKey(tableId), "fast") ) {
		pLimit->set_fast_locked(true);
	}
	if( pConnection->hexists(RedisKey::MakeTableSkillLockKey(tableId), "fury") ) {
		pLimit->set_fury_locked(true);
	}
	if( pConnection->hexists(RedisKey::MakeTableSkillLockKey(tableId), "super") ) {
		pLimit->set_super_locked(true);
	}
}

int64 RedisData::GenerateGiftId(RedisConnection* pConnection) {
    string strKey = RedisKey::MakeGiftUniqueKey();
	int64 giftId = pConnection->incrby(strKey, 1);
	if( giftId <= 10000 ) {
		// 没初始化
		giftId = pConnection->incrby(strKey, GlobalUtils::GetRandNumber(10000, 10086));
	}
	else {
		giftId = pConnection->incrby(strKey, 1);
	}
	return giftId;
}

int64 RedisData::GenerateChatGroupId(RedisConnection* pConnection) {
	int64 uuid = pConnection->incrby(GUID_CHAT_GROUP_KEY, 1);
	if( uuid <= 10000 ) {
		// 没初始化
		uuid = pConnection->incrby(GUID_CHAT_GROUP_KEY, GlobalUtils::GetRandNumber(10000, 10086));
	}
	else {
		uuid = pConnection->incrby(GUID_CHAT_GROUP_KEY, 1);
	}
	return uuid;
}

int64 RedisData::GenerateChatMsgId(RedisConnection* pConnection) {
	return pConnection->incrby(GUID_CHAT_MSG_KEY, 1);;
}

int64 RedisData::GenerateBossGuid() {
	FETCH_RETURN(0);
	return pConnection->incrby(GUID_BOSS_KEY, 1);;
}

string RedisData::GetUserGiftCode(RedisConnection* pConnection, uint64 userId) {
    string strCode;
    pConnection->hget(RedisKey::MakeUserKey(userId), "gift_code", strCode);
    return strCode;
}

bool RedisData::IsInMuteTime(RedisConnection* pConnection, uint64 userId, int64 now) {
    int64 tmMute = 0;
    pConnection->hget(RedisKey::MakeUserKey(userId), "time_mute_end", tmMute);
    return tmMute > now;
}

int32 RedisData::GetUserPopularity(RedisConnection* pConnection, uint64 userId) {
    int32 pop = 0;
    pConnection->hget(RedisKey::MakeUserKey(userId), "popularity", pop);
    return pop;
}

string RedisData::GetUserPhone(RedisConnection* pConnection, uint64 userId) {
    string phone;
    pConnection->hget(RedisKey::MakeUserKey(userId), "user_phone", phone);
    return phone;
}

int32 RedisData::GetSysFireInterval() {
	FETCH_RETURN(250);
    int32 interval = 250;
	if( pConnection->get(SYS_FIRE_INTERVAL, interval) ) {
		if( interval >= 250 ) {
			return interval;
		}
	}
	return 250;
}

bool RedisData::GetGift(RedisConnection* pConnection, int64 guid, GiftData& lhs) {
    string strGift;
    if( !pConnection->hget(SYS_GIFT_KEY, guid, strGift) ) {
        return false;
    }
    if( !JsonProto::ProtoFromJson(strGift, lhs) ) {
		LOGERROR("gift fomat error[%s]", strGift.c_str());
        return false;
    }
    return true;
}
