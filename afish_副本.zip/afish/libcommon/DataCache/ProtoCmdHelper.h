#pragma once

#include "ServerDefine.h"

class ProtoCmdHelper
{
public:
	static void PushServerCmd(RedisConnection* pConnection, int32 serverId, const ServerProtoCmd& proto);
    static void ForEachServerCmd(RedisConnection* pConnection, int32 serverId, boost::function<void(const ServerProtoCmd&)> func);

	static void PushGmCmd(RedisConnection* pConnection, uint64 userId, int32 cmd);
	static void PushGmCmd(RedisConnection* pConnection, uint64 userId, int32 cmd, const vector<string>& params);
    static void ForEachGmCmd(RedisConnection* pConnection, uint64 userId, boost::function<void(const string&)> func);

	static void PushUserCmd(RedisConnection* pConnection, uint64 userId, const UserProtoCmd& proto);
    static void ForEachUserCmd(RedisConnection* pConnection, uint64 userId, boost::function<void(const UserProtoCmd&)> func);

	static void PushGiftCmd(RedisConnection* pConnection, const GiftChannelCmd& proto);
    static void ForEachGiftCmd(RedisConnection* pConnection, boost::function<void(const GiftChannelCmd&)> func);

	static void PushChatCmd(RedisConnection* pConnection, const ChatChannelCmd& proto);
};
