import sys, getopt
import os.path
import time, datetime
import redis
import shutil
import logging
import logging.handlers
import json

myapp = logging.getLogger()
myapp.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(levelname)s: %(asctime)s %(filename)s %(message)s')
#每 1(interval) 天(when) 重写1个文件,保留7(backupCount) 个旧文件；when还可以是Y/m/d/H/M/S
filehandler = logging.handlers.TimedRotatingFileHandler('/game/eslog/my.log', when='d', interval=1, backupCount=24)
filehandler.suffix = '%Y-%m-%d.log'#设置历史文件 后缀
filehandler.setFormatter(formatter)
myapp.addHandler(filehandler)

def TimeToString(data):
	return datetime.datetime.fromtimestamp(int(data)).strftime('%Y/%m/%d %H:%M:%S')

def PARSE_LOGACCINFO(data):
	total = data.split(',')
	js = {}
	js['event_time'] = TimeToString(total[0])
	js['acc_ip'] = total[1]
	js['acc_open_id'] = total[2]
	js['acc_user_id'] = int(total[3])
	js['acc_user_gold'] = int(total[4])
	js['acc_user_win'] = int(total[5])
	js['acc_pass_id'] = total[6]
	js['acc_pass_is_vip'] = int(total[7])
	js['acc_pass_reward_level'] = int(total[8])
	js['acc_poverty_total'] = int(total[9])
	js['acc_user_diamond'] = int(total[10])
	js['acc_total_charge'] = int(total[11])
	js['acc_total_fish_time'] = int(total[12])
	js['acc_create_time'] = int(total[13])
	return js

#记录用户设备数据
# dev_game_id 游戏id
# dev_app_id 应用id
# dev_package_name 包名
# dev_channel_id 渠道编号
# dev_idfa ios设备号
# dev_idfv ios设备相关
# dev_android_id 安卓id
# dev_google_aid 谷歌aid
# dev_oaid 安卓10以上必填
# dev_language 语言
# dev_carrier 网络环境,4G/5G/wifi
# dev_os_type ios/android
# dev_app_version 应用版本号
# dev_original_app_version 二进制包版本号
# dev_type phone/tablet
# dev_brand 设备制造商品牌
# dev_mode 设备型号
# dev_adid adid
# dev_sdk_version sdk版本号
def PARSE_USER_DEVICE(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'user_device'
	total = data.split(',')
	js['dev_game_id'] = int(total[idx + 0])
	js['dev_app_id'] = int(total[idx + 1])
	js['dev_package_name'] = total[idx + 2]
	js['dev_channel_id'] = total[idx + 3]
	js['dev_idfa'] = total[idx + 4]
	js['dev_idfv'] = total[idx + 5]
	js['dev_android_id'] = total[idx + 6]
	js['dev_google_aid'] = total[idx + 7]
	js['dev_oaid'] = total[idx + 8]
	js['dev_language'] = total[idx + 9]
	js['dev_carrier'] = total[idx + 10]
	js['dev_os_type'] = total[idx + 11]
	js['dev_app_version'] = total[idx + 12]
	js['dev_original_app_version'] = total[idx + 13]
	js['dev_type'] = total[idx + 14]
	js['dev_brand'] = total[idx + 15]
	js['dev_mode'] = total[idx + 16]
	js['dev_adid'] = total[idx + 17]
	js['dev_sdk_version'] = total[idx + 18]
	xjs = {}
	xjs['user_device'] = json.dumps(js)
	r.xadd('log_stream', xjs)

def PARSE_USER_CREATE(data, r):
	js = PARSE_LOGACCINFO(data)
	js['event_name'] = 'user_create'
	xjs = {}
	xjs['user_create'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#用户登录
# gold 金币数量
# diamond_free 免费钻石
# diamond_pay 付费钻石
# coupon 兑换券数量
# power 战力
# game_time_total 游戏总时长
# online_time_total 在线总时长
def PARSE_USER_LOGIN(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'user_login'
	total = data.split(',')
	js['gold'] = int(total[idx + 0])
	js['diamond_free'] = int(total[idx + 1])
	js['diamond_pay'] = int(total[idx + 2])
	js['coupon'] = int(total[idx + 3])
	js['power'] = int(total[idx + 4])
	js['game_time_total'] = int(total[idx + 5])
	js['online_time_total'] = int(total[idx + 6])
	xjs = {}
	xjs['user_login'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#用户离线
# gold 金币数量
# diamond_free 免费钻石
# diamond_pay 付费钻石
# coupon 兑换券数量
# power 战力
# game_time_total 游戏总时长
# online_time_total 在线总时长
# reason 原因
def PARSE_USER_LOGOUT(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'user_logout'
	total = data.split(',')
	js['gold'] = int(total[idx + 0])
	js['diamond_free'] = int(total[idx + 1])
	js['diamond_pay'] = int(total[idx + 2])
	js['coupon'] = int(total[idx + 3])
	js['power'] = int(total[idx + 4])
	js['game_time_total'] = int(total[idx + 5])
	js['online_time_total'] = int(total[idx + 6])
	js['reason'] = int(total[idx + 7])
	xjs = {}
	xjs['user_logout'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#
# level_before 升级前等级
# level_after 升级后等级
def PARSE_USER_LEVELUP(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'user_levelup'
	total = data.split(',')
	js['level_before'] = int(total[idx + 0])
	js['level_after'] = int(total[idx + 1])
	xjs = {}
	xjs['user_levelup'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#vip升级
# vip_level_before 升级前等级
# vip_level_after 升级后等级
def PARSE_USER_VIP_LEVELUP(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'user_vip_levelup'
	total = data.split(',')
	js['vip_level_before'] = int(total[idx + 0])
	js['vip_level_after'] = int(total[idx + 1])
	xjs = {}
	xjs['user_vip_levelup'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#生成新炮台
# turret_unique_id 炮台唯一id
# turret_set_id 炮台配置id
# born_type 生成类型,EnumLogTurretBornType
# turret_patk 炮台物理攻击力
# turret_matk 炮台魔法攻击力
# turret_pp 炮台物理穿透
# turret_mp 炮台魔法穿透
# turret_bullet_speed 炮台子弹速度
# turret_bullet_count 炮台子弹数量
# turret_frozen_time 炮台冰冻时间
# turret_lock_time 炮台锁定时间
# turret_rapid_time 炮台急速时间
# turret_rd 炮台真实伤害
# turret_death_rate 炮台鱼死亡几率
# turret_gold_bonus 炮台金币额外奖励
# turret_energy_collection 炮台能量累积速度
def PARSE_TURRET_BORN(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'turret_born'
	total = data.split(',')
	js['turret_unique_id'] = int(total[idx + 0])
	js['turret_set_id'] = int(total[idx + 1])
	js['born_type'] = int(total[idx + 2])
	js['turret_patk'] = int(total[idx + 3])
	js['turret_matk'] = int(total[idx + 4])
	js['turret_pp'] = int(total[idx + 5])
	js['turret_mp'] = int(total[idx + 6])
	js['turret_bullet_speed'] = int(total[idx + 7])
	js['turret_bullet_count'] = int(total[idx + 8])
	js['turret_frozen_time'] = int(total[idx + 9])
	js['turret_lock_time'] = int(total[idx + 10])
	js['turret_rapid_time'] = int(total[idx + 11])
	js['turret_rd'] = int(total[idx + 12])
	js['turret_death_rate'] = int(total[idx + 13])
	js['turret_gold_bonus'] = int(total[idx + 14])
	js['turret_energy_collection'] = int(total[idx + 15])
	xjs = {}
	xjs['turret_born'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#炮台升级
# turret_unique_id 炮台唯一id
# turret_set_id 炮台配置id
# level_before 升级前等级
# level_after 升级后等级
def PARSE_TURRET_LEVELUP(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'turret_levelup'
	total = data.split(',')
	js['turret_unique_id'] = int(total[idx + 0])
	js['turret_set_id'] = int(total[idx + 1])
	js['level_before'] = int(total[idx + 2])
	js['level_after'] = int(total[idx + 3])
	xjs = {}
	xjs['turret_levelup'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#炮台升星
# turret_unique_id 炮台唯一id
# turret_set_id 炮台配置id
# star_before 升级前星级
# star_after 升级后星级
def PARSE_TURRET_STARUPGRADE(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'turret_starupgrade'
	total = data.split(',')
	js['turret_unique_id'] = int(total[idx + 0])
	js['turret_set_id'] = int(total[idx + 1])
	js['star_before'] = int(total[idx + 2])
	js['star_after'] = int(total[idx + 3])
	xjs = {}
	xjs['turret_starupgrade'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#炮台强化
# turret_unique_id 炮台唯一id
# turret_set_id 炮台配置id
# strength_before 强化前等级
# strength_after 强化后等级
def PARSE_TURRET_STRENGTH(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'turret_strength'
	total = data.split(',')
	js['turret_unique_id'] = int(total[idx + 0])
	js['turret_set_id'] = int(total[idx + 1])
	js['strength_before'] = int(total[idx + 2])
	js['strength_after'] = int(total[idx + 3])
	xjs = {}
	xjs['turret_strength'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#炮台删除
# turret_unique_id 炮台唯一id
# turret_set_id 炮台配置id
# turret_level 等级
# turret_star 星级
# turret_strength 强化等级
def PARSE_TURRET_DELETE(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'turret_delete'
	total = data.split(',')
	js['turret_unique_id'] = int(total[idx + 0])
	js['turret_set_id'] = int(total[idx + 1])
	js['turret_level'] = int(total[idx + 2])
	js['turret_star'] = int(total[idx + 3])
	js['turret_strength'] = int(total[idx + 4])
	xjs = {}
	xjs['turret_delete'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#翅膀生成
# swing_unique_id 翅膀唯一id
# swing_index 翅膀配置id
# swing_phase 翅膀位阶
# swing_patkr 翅膀物理攻击加成
# swing_matkr 翅膀魔法攻击加成
# swing_ppr 翅膀物理穿透加成
# swing_mpr 翅膀魔法穿透加成
# swing_cr 翅膀暴击加成
# swing_ctdr 翅膀暴击伤害加成
def PARSE_SWING_BORN(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'swing_born'
	total = data.split(',')
	js['swing_unique_id'] = int(total[idx + 0])
	js['swing_index'] = int(total[idx + 1])
	js['swing_phase'] = int(total[idx + 2])
	js['swing_patkr'] = int(total[idx + 3])
	js['swing_matkr'] = int(total[idx + 4])
	js['swing_ppr'] = int(total[idx + 5])
	js['swing_mpr'] = int(total[idx + 6])
	js['swing_cr'] = int(total[idx + 7])
	js['swing_ctdr'] = int(total[idx + 8])
	xjs = {}
	xjs['swing_born'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#翅膀升阶
# swing_unique_id 翅膀唯一id
# swing_index 翅膀配置id
# level_before 升级前等级
# level_after 升级后等级
# success_rate 本次进阶的成功率
def PARSE_SWING_UPGRADE(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'swing_upgrade'
	total = data.split(',')
	js['swing_unique_id'] = int(total[idx + 0])
	js['swing_index'] = int(total[idx + 1])
	js['level_before'] = int(total[idx + 2])
	js['level_after'] = int(total[idx + 3])
	js['success_rate'] = int(total[idx + 4])
	xjs = {}
	xjs['swing_upgrade'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#翅膀消失
# swing_unique_id 翅膀唯一id
# swing_index 翅膀配置id
def PARSE_SWING_DELETE(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'swing_delete'
	total = data.split(',')
	js['swing_unique_id'] = int(total[idx + 0])
	js['swing_index'] = int(total[idx + 1])
	xjs = {}
	xjs['swing_delete'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#资源变化
# resource_type 资源类型
# resource_id 资源id,包括道具,炮台,翅膀的配置id
# resource_before 变化前
# resource_after 变化后
# count 变化量
# operation_type 类型EnumLogResourceInc/EnumLogResourceDec
def PARSE_RESOURCE_FLOW(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'resource_flow'
	total = data.split(',')
	js['resource_type'] = int(total[idx + 0])
	js['resource_id'] = int(total[idx + 1])
	js['resource_before'] = int(total[idx + 2])
	js['resource_after'] = int(total[idx + 3])
	js['count'] = int(total[idx + 4])
	js['operation_type'] = int(total[idx + 5])
	xjs = {}
	xjs['resource_flow'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#邮件
# mail_id 邮件id
# status 状态
# mail_type 邮件类型
def PARSE_USER_MAIL(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'user_mail'
	total = data.split(',')
	js['mail_id'] = int(total[idx + 0])
	js['status'] = int(total[idx + 1])
	js['mail_type'] = int(total[idx + 2])
	xjs = {}
	xjs['user_mail'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#签到
# is_make_up 是否是补签
# rmb_num 补签次数
# continuos_days 连续签到天数
# member_continuos_days 会员连续签到天数
def PARSE_SIGN_UP(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'sign_up'
	total = data.split(',')
	js['is_make_up'] = int(total[idx + 0])
	js['rmb_num'] = int(total[idx + 1])
	js['continuos_days'] = int(total[idx + 2])
	js['member_continuos_days'] = int(total[idx + 3])
	xjs = {}
	xjs['sign_up'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#任务
# quest_id 任务配置id
# quest_status 任务状态,EnumQuestStatus
def PARSE_QUEST(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'quest'
	total = data.split(',')
	js['quest_id'] = int(total[idx + 0])
	js['quest_status'] = int(total[idx + 1])
	xjs = {}
	xjs['quest'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#7日任务
# quest_id 任务配置id
# quest_status 任务状态,EnumQuestStatus
def PARSE_SEVEN_DAY(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'seven_day'
	total = data.split(',')
	js['quest_id'] = int(total[idx + 0])
	js['quest_status'] = int(total[idx + 1])
	xjs = {}
	xjs['seven_day'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#兑换商城
# product_id 商品id
def PARSE_EXCHANGE(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'exchange'
	total = data.split(',')
	js['product_id'] = total[idx + 0]
	xjs = {}
	xjs['exchange'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#付费
# sku 商品id
# order_id 游戏端订单号
# merchant_id 商户订单
# purchase_type apple/alipay/wx
# currency USD/CNY
# revenue 充值金额
def PARSE_PURCHASE(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'purchase'
	total = data.split(',')
	js['sku'] = total[idx + 0]
	js['order_id'] = total[idx + 1]
	js['merchant_id'] = total[idx + 2]
	js['purchase_type'] = total[idx + 3]
	js['currency'] = total[idx + 4]
	js['revenue'] = int(total[idx + 5])
	xjs = {}
	xjs['purchase'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#进入房间
# enter_type 进入类型EnumLogEnterTable
# gold 金币数量
# diamond_free 免费钻石
# diamond_pay 付费钻石
# coupon 兑换券数量
# power 战力
# room_id 房间id
# table_id 桌子id
def PARSE_GAME_ENTER(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'game_enter'
	total = data.split(',')
	js['enter_type'] = int(total[idx + 0])
	js['gold'] = int(total[idx + 1])
	js['diamond_free'] = int(total[idx + 2])
	js['diamond_pay'] = int(total[idx + 3])
	js['coupon'] = int(total[idx + 4])
	js['power'] = int(total[idx + 5])
	js['room_id'] = int(total[idx + 6])
	js['table_id'] = int(total[idx + 7])
	xjs = {}
	xjs['game_enter'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#离开房间
# leave_type 进入类型EnumLogLeaveTable
# gold 金币数量
# diamond_free 免费钻石
# diamond_pay 付费钻石
# coupon 兑换券数量
# power 战力
# room_id 房间id
# table_id 桌子id
def PARSE_GAME_LEAVE(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'game_leave'
	total = data.split(',')
	js['leave_type'] = int(total[idx + 0])
	js['gold'] = int(total[idx + 1])
	js['diamond_free'] = int(total[idx + 2])
	js['diamond_pay'] = int(total[idx + 3])
	js['coupon'] = int(total[idx + 4])
	js['power'] = int(total[idx + 5])
	js['room_id'] = int(total[idx + 6])
	js['table_id'] = int(total[idx + 7])
	xjs = {}
	xjs['game_leave'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#游戏记录
# event_time 事件时间
# room_id 房间id
# table_id 桌子id
# seat_id 座位
# gold_last 上次记录时金币
# gold_now 当前金币
# diamond_last 上次记录时钻石
# diamond_now 当前钻石
# user_cumulative_income 累计金币收入
# user_cumulative_expend 累计金币支出
# fish_num_type1 类型1鱼的击杀数量
# fish_num_type2 类型2鱼的击杀数量
# fish_num_type3 类型3鱼的击杀数量
# fish_num_type4 类型4鱼的击杀数量
# fish_num_type5 类型5鱼的击杀数量
# fish_num_type6 类型6鱼的击杀数量
# fish_num_type7 类型7鱼的击杀数量
# fish_num_type8 类型8鱼的击杀数量
def PARSE_GAME_STATISTIC(data, r):
	js = {}
	js['event_name'] = 'game_statistic'
	total = data.split(',')
	js['event_time'] = TimeToString(total[0])
	js['room_id'] = int(total[1])
	js['table_id'] = int(total[2])
	js['seat_id'] = int(total[3])
	js['gold_last'] = int(total[4])
	js['gold_now'] = int(total[5])
	js['diamond_last'] = int(total[6])
	js['diamond_now'] = int(total[7])
	js['user_cumulative_income'] = int(total[8])
	js['user_cumulative_expend'] = int(total[9])
	js['fish_num_type1'] = int(total[10])
	js['fish_num_type2'] = int(total[11])
	js['fish_num_type3'] = int(total[12])
	js['fish_num_type4'] = int(total[13])
	js['fish_num_type5'] = int(total[14])
	js['fish_num_type6'] = int(total[15])
	js['fish_num_type7'] = int(total[16])
	js['fish_num_type8'] = int(total[17])
	xjs = {}
	xjs['game_statistic'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#在线人数报告
# event_time 时间
# game_id 游戏id
# app_id 同一游戏下的不同应用app
# server_id 服务器id
# online_count 同时在线人数
def PARSE_ONLINE(data, r):
	js = {}
	js['event_name'] = 'online'
	total = data.split(',')
	js['event_time'] = TimeToString(total[0])
	js['game_id'] = int(total[1])
	js['app_id'] = int(total[2])
	js['server_id'] = int(total[3])
	js['online_count'] = int(total[4])
	xjs = {}
	xjs['online'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#概率击杀鱼
# event_time 事件时间
# room_id 房间id
# table_id 桌子id
# fish_id 鱼的配置id
# fish_type 鱼的类型
# user_id 击杀人
# score 鱼分
# gold 金币
# life_tick 寿命
# death_type 击杀类型
# refund_type 返奖类型,EnumLogRefundType
# death_rate_Fi 基础概率
# death_rate_BP 大boss出生时给该玩家附加的击杀概率
# death_rate_BN 返奖增加的概率
# death_rate_AT 炮台属性增加的概率
# death_rate_B 击杀时的炮倍
# death_rate_R 击杀时的房间修正
# death_rate_F 击杀时的房间友好度
# death_rate_feel 击杀时的玩家感受值
# death_real_rate 击杀时的几率
# death_expect_num 实际的期望次数
# death_hit_num 被击杀玩家击中次数
# death_hit_total_num 一共被击中了多少次
# death_gold 被击杀时消耗了多少金币
# sf_stage 是否处于短期感受值红利阶段
# player_num 房间人数
# bullet_speed 炮弹速度
# bullet_count 弹道数
# user_win 赢
# user_lose 输
# user_pool 奖池金额
# user_use_pool 奖池输出状态
# table_win 赢
# table_lose 输
# table_pool 奖池金额
# table_use_pool 奖池输出状态
# room_win 赢
# room_lose 输
# room_pool 奖池金额
# room_use_pool 奖池输出状态
# game_win 赢
# game_lose 输
# game_pool 奖池金额
# game_use_pool 奖池输出状态
def PARSE_FISH_DEATH(data, r):
	js = {}
	js['event_name'] = 'fish_death'
	total = data.split(',')
	js['event_time'] = TimeToString(total[0])
	js['room_id'] = int(total[1])
	js['table_id'] = int(total[2])
	js['fish_id'] = int(total[3])
	js['fish_type'] = int(total[4])
	js['user_id'] = int(total[5])
	js['score'] = int(total[6])
	js['gold'] = int(total[7])
	js['life_tick'] = int(total[8])
	js['death_type'] = int(total[9])
	js['refund_type'] = int(total[10])
	js['death_rate_Fi'] = int(total[11])
	js['death_rate_BP'] = int(total[12])
	js['death_rate_BN'] = int(total[13])
	js['death_rate_AT'] = int(total[14])
	js['death_rate_B'] = int(total[15])
	js['death_rate_R'] = int(total[16])
	js['death_rate_F'] = int(total[17])
	js['death_rate_feel'] = int(total[18])
	js['death_real_rate'] = int(total[19])
	js['death_expect_num'] = int(total[20])
	js['death_hit_num'] = int(total[21])
	js['death_hit_total_num'] = int(total[22])
	js['death_gold'] = int(total[23])
	js['sf_stage'] = int(total[24])
	js['player_num'] = int(total[25])
	js['bullet_speed'] = int(total[26])
	js['bullet_count'] = int(total[27])
	js['user_win'] = int(total[28])
	js['user_lose'] = int(total[29])
	js['user_pool'] = int(total[30])
	js['user_use_pool'] = int(total[31])
	js['table_win'] = int(total[32])
	js['table_lose'] = int(total[33])
	js['table_pool'] = int(total[34])
	js['table_use_pool'] = int(total[35])
	js['room_win'] = int(total[36])
	js['room_lose'] = int(total[37])
	js['room_pool'] = int(total[38])
	js['room_use_pool'] = int(total[39])
	js['game_win'] = int(total[40])
	js['game_lose'] = int(total[41])
	js['game_pool'] = int(total[42])
	js['game_use_pool'] = int(total[43])
	xjs = {}
	xjs['fish_death'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#非概率击杀鱼
# event_time 事件时间
# room_id 房间id
# table_id 桌子id
# fish_id 鱼的配置id
# fish_type 鱼的类型
# user_id 击杀人
# score 鱼分
# gold 金币
# death_hit_num 被击杀玩家击中次数
# death_gold 被击杀时消耗了多少金币
def PARSE_FISH_DEATH_NORATE(data, r):
	js = {}
	js['event_name'] = 'fish_death_norate'
	total = data.split(',')
	js['event_time'] = TimeToString(total[0])
	js['room_id'] = int(total[1])
	js['table_id'] = int(total[2])
	js['fish_id'] = int(total[3])
	js['fish_type'] = int(total[4])
	js['user_id'] = int(total[5])
	js['score'] = int(total[6])
	js['gold'] = int(total[7])
	js['death_hit_num'] = int(total[8])
	js['death_gold'] = int(total[9])
	xjs = {}
	xjs['fish_death_norate'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#桌面统计信息
# event_time 事件时间
# room_id 房间id
# table_id 桌子id
# active_time 存在时长
# table_bonus 桌面当前的奖池
# table_cumulative_income 桌面累计收入
# table_cumulative_expend 桌面累计支出
# system_fee 桌面收到的抽水
def PARSE_TABLE_STATISTIC(data, r):
	js = {}
	js['event_name'] = 'table_statistic'
	total = data.split(',')
	js['event_time'] = TimeToString(total[0])
	js['room_id'] = int(total[1])
	js['table_id'] = int(total[2])
	js['active_time'] = int(total[3])
	js['table_bonus'] = int(total[4])
	js['table_cumulative_income'] = int(total[5])
	js['table_cumulative_expend'] = int(total[6])
	js['system_fee'] = int(total[7])
	xjs = {}
	xjs['table_statistic'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#充值商品展示次数
# product_id 商品id
# count 展示次数
def PARSE_PRODUCT_REPRESENT(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'product_represent'
	total = data.split(',')
	js['product_id'] = total[idx + 0]
	js['count'] = int(total[idx + 1])
	xjs = {}
	xjs['product_represent'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#新手指引当前步数
# step 当前步数
def PARSE_GUIDE_STEP(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'guide_step'
	total = data.split(',')
	js['step'] = int(total[idx + 0])
	xjs = {}
	xjs['guide_step'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#玩家帧数
# frames 当前帧数
def PARSE_FRAME_NUM(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'frame_num'
	total = data.split(',')
	js['frames'] = int(total[idx + 0])
	xjs = {}
	xjs['frame_num'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#充值前行为记录
# act 行为列表
# step 行为的排序id
# product_name 充值商品id
def PARSE_BEFORE_CHARGE(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'before_charge'
	total = data.split(',')
	js['act'] = total[idx + 0]
	js['step'] = int(total[idx + 1])
	js['product_name'] = total[idx + 2]
	xjs = {}
	xjs['before_charge'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#充值后行为记录
# act 行为标识
def PARSE_AFTER_CHARGE(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'after_charge'
	total = data.split(',')
	js['act'] = total[idx + 0]
	xjs = {}
	xjs['after_charge'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#玩家使用转盘
# tt_id 活动id
# tt_today_num 当天累计次数
# tt_total_num 活动期间累计次数
# tt_num 本次是1或者10,10表示十连
def PARSE_USER_TURNTABLE(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'user_turntable'
	total = data.split(',')
	js['tt_id'] = int(total[idx + 0])
	js['tt_today_num'] = int(total[idx + 1])
	js['tt_total_num'] = int(total[idx + 2])
	js['tt_num'] = int(total[idx + 3])
	xjs = {}
	xjs['user_turntable'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#兑换券抽奖数据
# phone_voucher 抽奖时的话费券数量
# left_draw_times 当前剩余抽奖次数
# left_voucher_times 当前剩余抽话费次数
# current_reward_id 本次抽中的道具id
# current_reward_num 本次抽中的道具数量
# order 本轮的第几次抽奖
# reward_id1 奖励道具id
# reward_num1 奖励道具数量
# reward_id2 奖励道具id
# reward_num2 奖励道具数量
# reward_id3 奖励道具id
# reward_num3 奖励道具数量
# reward_id4 奖励道具id
# reward_num4 奖励道具数量
# reward_id5 奖励道具id
# reward_num5 奖励道具数量
def PARSE_COUPON_DRAW(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'coupon_draw'
	total = data.split(',')
	js['phone_voucher'] = int(total[idx + 0])
	js['left_draw_times'] = int(total[idx + 1])
	js['left_voucher_times'] = int(total[idx + 2])
	js['current_reward_id'] = int(total[idx + 3])
	js['current_reward_num'] = int(total[idx + 4])
	js['order'] = int(total[idx + 5])
	js['reward_id1'] = int(total[idx + 6])
	js['reward_num1'] = int(total[idx + 7])
	js['reward_id2'] = int(total[idx + 8])
	js['reward_num2'] = int(total[idx + 9])
	js['reward_id3'] = int(total[idx + 10])
	js['reward_num3'] = int(total[idx + 11])
	js['reward_id4'] = int(total[idx + 12])
	js['reward_num4'] = int(total[idx + 13])
	js['reward_id5'] = int(total[idx + 14])
	js['reward_num5'] = int(total[idx + 15])
	xjs = {}
	xjs['coupon_draw'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#金币变化
# resource_before 变化前
# resource_after 变化后
# count 变化量
# operation_type 类型EnumLogResourceInc/EnumLogResourceDec
def PARSE_GOLD_FLOW(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'gold_flow'
	total = data.split(',')
	js['resource_before'] = int(total[idx + 0])
	js['resource_after'] = int(total[idx + 1])
	js['count'] = int(total[idx + 2])
	js['operation_type'] = int(total[idx + 3])
	xjs = {}
	xjs['gold_flow'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#钻石变化
# resource_before 变化前
# resource_after 变化后
# count 变化量
# operation_type 类型EnumLogResourceInc/EnumLogResourceDec
def PARSE_DIAMOND_FLOW(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'diamond_flow'
	total = data.split(',')
	js['resource_before'] = int(total[idx + 0])
	js['resource_after'] = int(total[idx + 1])
	js['count'] = int(total[idx + 2])
	js['operation_type'] = int(total[idx + 3])
	xjs = {}
	xjs['diamond_flow'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#兑换券变化
# resource_before 变化前
# resource_after 变化后
# count 变化量
# operation_type 类型EnumLogResourceInc/EnumLogResourceDec
def PARSE_COUPON_FLOW(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'coupon_flow'
	total = data.split(',')
	js['resource_before'] = int(total[idx + 0])
	js['resource_after'] = int(total[idx + 1])
	js['count'] = int(total[idx + 2])
	js['operation_type'] = int(total[idx + 3])
	xjs = {}
	xjs['coupon_flow'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#道具变化
# resource_id 资源id,包括道具,炮台,翅膀的配置id
# resource_before 变化前
# resource_after 变化后
# count 变化量
# operation_type 类型EnumLogResourceInc/EnumLogResourceDec
def PARSE_ITEM_FLOW(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'item_flow'
	total = data.split(',')
	js['resource_id'] = int(total[idx + 0])
	js['resource_before'] = int(total[idx + 1])
	js['resource_after'] = int(total[idx + 2])
	js['count'] = int(total[idx + 3])
	js['operation_type'] = int(total[idx + 4])
	xjs = {}
	xjs['item_flow'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#玩家渔场内金币状态
# gold 当前金币数量
# feeling 当前感受值
# room_friendly 当前房间的友好度
def PARSE_GOLD_STATUS(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'gold_status'
	total = data.split(',')
	js['gold'] = int(total[idx + 0])
	js['feeling'] = int(total[idx + 1])
	js['room_friendly'] = int(total[idx + 2])
	xjs = {}
	xjs['gold_status'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#服务器玩家在线情况
# event_time 事件时间
# total_online 总在线人数
# total_fisher 总捕鱼人数
# table_101 101房间人数
# table_102 102房间人数
# table_103 103房间人数
# table_104 104房间人数
# table_105 105房间人数
def PARSE_ONLINE_NUM(data, r):
	js = {}
	js['event_name'] = 'online_num'
	total = data.split(',')
	js['event_time'] = TimeToString(total[0])
	js['total_online'] = int(total[1])
	js['total_fisher'] = int(total[2])
	js['table_101'] = int(total[3])
	js['table_102'] = int(total[4])
	js['table_103'] = int(total[5])
	js['table_104'] = int(total[6])
	js['table_105'] = int(total[7])
	xjs = {}
	xjs['online_num'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#通用任务
# task_id 任务配置id
# task_status 任务状态,EnumGeneralTaskStatus
def PARSE_GENERAL_TASK(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'general_task'
	total = data.split(',')
	js['task_id'] = int(total[idx + 0])
	js['task_status'] = int(total[idx + 1])
	xjs = {}
	xjs['general_task'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#桌面信息
# event_time 事件时间
# table_index 桌子id
# game_tick 桌子当前游戏时长(毫秒)
# fire_cost 玩家开炮消耗金币总量
# fish_win 玩家击杀鱼获得金币总量
# bomb1001 1001核弹数量
# bomb1002 1002核弹数量
# bomb1003 1003核弹数量
# bomb1004 1004核弹数量
# lock_item 瞄准道具消耗
# lock_diamond 瞄准钻石消耗
# freeze_item 冰冻道具消耗
# freeze_diamond 冰冻钻石消耗
# fast_item 急速道具消耗
# fast_diamond 急速钻石消耗
# fury_item 狂暴道具消耗
# fury_diamond 狂暴钻石消耗
# summon_item 召唤道具消耗
# summon_diamond 召唤钻石消耗
def PARSE_TABLE_DATA(data, r):
	js = {}
	js['event_name'] = 'table_data'
	total = data.split(',')
	js['event_time'] = TimeToString(total[0])
	js['table_index'] = int(total[1])
	js['game_tick'] = int(total[2])
	js['fire_cost'] = int(total[3])
	js['fish_win'] = int(total[4])
	js['bomb1001'] = int(total[5])
	js['bomb1002'] = int(total[6])
	js['bomb1003'] = int(total[7])
	js['bomb1004'] = int(total[8])
	js['lock_item'] = int(total[9])
	js['lock_diamond'] = int(total[10])
	js['freeze_item'] = int(total[11])
	js['freeze_diamond'] = int(total[12])
	js['fast_item'] = int(total[13])
	js['fast_diamond'] = int(total[14])
	js['fury_item'] = int(total[15])
	js['fury_diamond'] = int(total[16])
	js['summon_item'] = int(total[17])
	js['summon_diamond'] = int(total[18])
	xjs = {}
	xjs['table_data'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#用户离线v2
# gold 金币数量
# diamond_free 免费钻石
# diamond_pay 付费钻石
# coupon 兑换券数量
# voucher 话费券数量
# bomb1001 1001核弹数量
# bomb1002 1002核弹数量
# bomb1003 1003核弹数量
# bomb1004 1004核弹数量
# game_time_total 游戏总时长
# online_time_total 在线总时长
def PARSE_USER_LOGOUT_V2(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'user_logout_v2'
	total = data.split(',')
	js['gold'] = int(total[idx + 0])
	js['diamond_free'] = int(total[idx + 1])
	js['diamond_pay'] = int(total[idx + 2])
	js['coupon'] = int(total[idx + 3])
	js['voucher'] = int(total[idx + 4])
	js['bomb1001'] = int(total[idx + 5])
	js['bomb1002'] = int(total[idx + 6])
	js['bomb1003'] = int(total[idx + 7])
	js['bomb1004'] = int(total[idx + 8])
	js['game_time_total'] = int(total[idx + 9])
	js['online_time_total'] = int(total[idx + 10])
	xjs = {}
	xjs['user_logout_v2'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#玩家渔场内金币状态
# gold 当前金币数量
# feeling 当前感受值
# room_friendly 当前房间的友好度
# alpha 玩家的alpha
# in_bonus 是否处于红利阶段
# bonus_value 当前红利上限(充值获得)
# fish_win 捕鱼赢分
# fish_lose 捕鱼输分
# bullet_tax 开炮时加入到召唤奖池中的额外金额
# kill_tax 杀鱼时的召唤奖池抽水,填补子弹赠送
def PARSE_GOLD_STATUS_V2(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'gold_status_v2'
	total = data.split(',')
	js['gold'] = int(total[idx + 0])
	js['feeling'] = int(total[idx + 1])
	js['room_friendly'] = int(total[idx + 2])
	js['alpha'] = int(total[idx + 3])
	js['in_bonus'] = int(total[idx + 4])
	js['bonus_value'] = int(total[idx + 5])
	js['fish_win'] = int(total[idx + 6])
	js['fish_lose'] = int(total[idx + 7])
	js['bullet_tax'] = int(total[idx + 8])
	js['kill_tax'] = int(total[idx + 9])
	xjs = {}
	xjs['gold_status_v2'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#概率击杀鱼
# event_time 事件时间
# room_id 房间id
# fish_id 鱼的配置id
# fish_type 鱼的类型
# user_id 击杀人
# score 鱼分
# gold 金币
# life_tick 寿命
# death_rate_Fi 基础概率
# death_rate_BP 大boss出生时给该玩家附加的击杀概率
# death_rate_BN 返奖增加的概率
# death_rate_AT 炮台属性增加的概率
# death_rate_B 击杀时的炮倍
# death_rate_R 击杀时的房间修正
# death_rate_F 击杀时的房间友好度
# death_rate_feel 击杀时的玩家感受值
# death_real_rate 击杀时的几率
# death_expect_num 实际的期望次数
# death_by_poverty 是否被破产保护击杀
# player_num 房间人数
# turret_index 炮台id
# bullet_speed 炮弹速度
# bullet_count 弹道数
# user_win 赢
# user_lose 输
# table_win 赢
# table_lose 输
def PARSE_FISH_DEATH_V2(data, r):
	js = {}
	js['event_name'] = 'fish_death_v2'
	total = data.split(',')
	js['event_time'] = TimeToString(total[0])
	js['room_id'] = int(total[1])
	js['fish_id'] = int(total[2])
	js['fish_type'] = int(total[3])
	js['user_id'] = int(total[4])
	js['score'] = int(total[5])
	js['gold'] = int(total[6])
	js['life_tick'] = int(total[7])
	js['death_rate_Fi'] = int(total[8])
	js['death_rate_BP'] = int(total[9])
	js['death_rate_BN'] = int(total[10])
	js['death_rate_AT'] = int(total[11])
	js['death_rate_B'] = int(total[12])
	js['death_rate_R'] = int(total[13])
	js['death_rate_F'] = int(total[14])
	js['death_rate_feel'] = int(total[15])
	js['death_real_rate'] = int(total[16])
	js['death_expect_num'] = int(total[17])
	js['death_by_poverty'] = int(total[18])
	js['player_num'] = int(total[19])
	js['turret_index'] = int(total[20])
	js['bullet_speed'] = int(total[21])
	js['bullet_count'] = int(total[22])
	js['user_win'] = int(total[23])
	js['user_lose'] = int(total[24])
	js['table_win'] = int(total[25])
	js['table_lose'] = int(total[26])
	xjs = {}
	xjs['fish_death_v2'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#召唤boss被击杀
# event_time 事件时间
# room_id 当前boss净分
# fish_id 鱼的配置id
# user_id 击杀人
# fire_cost 开炮消耗的金币
# expect_num 预期击杀次数
# rate1 倍率1
# rate2 倍率2
# win 获得的总金币
# bonus 奖池分红
# bombId 获得的核弹id
# bombNum 获得的核弹数量
# reset 是否使用重置卡
def PARSE_SUMMON_BOSS_KILLED(data, r):
	js = {}
	js['event_name'] = 'summon_boss_killed'
	total = data.split(',')
	js['event_time'] = TimeToString(total[0])
	js['room_id'] = int(total[1])
	js['fish_id'] = int(total[2])
	js['user_id'] = int(total[3])
	js['fire_cost'] = int(total[4])
	js['expect_num'] = int(total[5])
	js['rate1'] = int(total[6])
	js['rate2'] = int(total[7])
	js['win'] = int(total[8])
	js['bonus'] = int(total[9])
	js['bombId'] = int(total[10])
	js['bombNum'] = int(total[11])
	js['reset'] = int(total[12])
	xjs = {}
	xjs['summon_boss_killed'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#内存信息
# event_time 事件时间
# thread_index 线程序号
# pool_name 名称
# cur_num 当前激活数量
# free_num 空闲节点数量
# used_num 使用中节点数量
def PARSE_MEMPOOL_INFO(data, r):
	js = {}
	js['event_name'] = 'mempool_info'
	total = data.split(',')
	js['event_time'] = TimeToString(total[0])
	js['thread_index'] = int(total[1])
	js['pool_name'] = total[2]
	js['cur_num'] = int(total[3])
	js['free_num'] = int(total[4])
	js['used_num'] = int(total[5])
	xjs = {}
	xjs['mempool_info'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#召唤boss被击杀
# event_time 事件时间
# room_id 房间id
# fish_id 鱼的配置id
# user_id 击杀人
# fire_cost 开炮消耗的金币
# expect_num 预期击杀次数
# rate1 倍率1
# rate2 倍率2
# win 获得的总金币
# bonus 奖池分红
# bombId 获得的核弹id
# bombNum 获得的核弹数量
# reset 是否使用重置卡
# boss_point_before 击杀前boss净分
# boss_point_after 击杀后boss净分
def PARSE_SUMMON_BOSS_KILLED_V2(data, r):
	js = {}
	js['event_name'] = 'summon_boss_killed_v2'
	total = data.split(',')
	js['event_time'] = TimeToString(total[0])
	js['room_id'] = int(total[1])
	js['fish_id'] = int(total[2])
	js['user_id'] = int(total[3])
	js['fire_cost'] = int(total[4])
	js['expect_num'] = int(total[5])
	js['rate1'] = int(total[6])
	js['rate2'] = int(total[7])
	js['win'] = int(total[8])
	js['bonus'] = int(total[9])
	js['bombId'] = int(total[10])
	js['bombNum'] = int(total[11])
	js['reset'] = int(total[12])
	js['boss_point_before'] = int(total[13])
	js['boss_point_after'] = int(total[14])
	xjs = {}
	xjs['summon_boss_killed_v2'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#核弹活动翻一次牌的结果
# num 今日的第几次开牌
# card_id 卡牌id
# relation_id 当前触发的id
def PARSE_BOMB_ACT_CARD_FLIP(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'bomb_act_card_flip'
	total = data.split(',')
	js['num'] = int(total[idx + 0])
	js['card_id'] = int(total[idx + 1])
	js['relation_id'] = int(total[idx + 2])
	xjs = {}
	xjs['bomb_act_card_flip'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#核弹场翻一次牌
# times 选择的倍率
# cards "抽到的牌组,
# relations "组成的羁绊id,
# bomb_num 获得的核弹总数
# pool_gold 获得的奖池金额
# point_before 之前控分值
# point_after 之后控分值
def PARSE_BOMB_GAME_PLAY(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'bomb_game_play'
	total = data.split(',')
	js['times'] = int(total[idx + 0])
	js['cards'] = total[idx + 1]
	js['relations'] = total[idx + 2]
	js['bomb_num'] = int(total[idx + 3])
	js['pool_gold'] = int(total[idx + 4])
	js['point_before'] = int(total[idx + 5])
	js['point_after'] = int(total[idx + 6])
	xjs = {}
	xjs['bomb_game_play'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#科技升级
# tech_id 科技id
# tech_level_before 升级前等级
# tech_level_after 升级后等级
# diamond_acc 钻石加速的秒数
# item_acc 道具加速的秒数
def PARSE_TECH_UPGRADE(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'tech_upgrade'
	total = data.split(',')
	js['tech_id'] = int(total[idx + 0])
	js['tech_level_before'] = int(total[idx + 1])
	js['tech_level_after'] = int(total[idx + 2])
	js['diamond_acc'] = int(total[idx + 3])
	js['item_acc'] = int(total[idx + 4])
	xjs = {}
	xjs['tech_upgrade'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#魔晶变化
# resource_before 变化前
# resource_after 变化后
# count 变化量
# operation_type 类型EnumLogResourceInc/EnumLogResourceDec
def PARSE_CRYSTAL_FLOW(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'crystal_flow'
	total = data.split(',')
	js['resource_before'] = int(total[idx + 0])
	js['resource_after'] = int(total[idx + 1])
	js['count'] = int(total[idx + 2])
	js['operation_type'] = int(total[idx + 3])
	xjs = {}
	xjs['crystal_flow'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#卡牌场翻一次牌的结果
# num 今日的第几次开牌
# card_id 卡牌id
# relation_id 当前触发的id
# pool_reward 奖池奖金数额
def PARSE_BOMB_TABLE_CARD_FLIP(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'bomb_table_card_flip'
	total = data.split(',')
	js['num'] = int(total[idx + 0])
	js['card_id'] = int(total[idx + 1])
	js['relation_id'] = int(total[idx + 2])
	js['pool_reward'] = int(total[idx + 3])
	xjs = {}
	xjs['bomb_table_card_flip'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#炮台升级
# hero_index 炮台配置id
# level_before 升级前等级
# level_after 升级后等级
def PARSE_HERO_LEVELUP(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'hero_levelup'
	total = data.split(',')
	js['hero_index'] = int(total[idx + 0])
	js['level_before'] = int(total[idx + 1])
	js['level_after'] = int(total[idx + 2])
	xjs = {}
	xjs['hero_levelup'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#生成新炮台
# hero_index 炮台配置id
# born_type 生成类型,EnumLogTurretBornType
def PARSE_HERO_BORN(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'hero_born'
	total = data.split(',')
	js['hero_index'] = int(total[idx + 0])
	js['born_type'] = int(total[idx + 1])
	xjs = {}
	xjs['hero_born'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#翅膀生成
# wing_index 翅膀配置id
# wing_level 翅膀位阶
def PARSE_WING_BORN(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'wing_born'
	total = data.split(',')
	js['wing_index'] = int(total[idx + 0])
	js['wing_level'] = int(total[idx + 1])
	xjs = {}
	xjs['wing_born'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#翅膀升阶
# wing_index 翅膀配置id
# level_before 升级前等级
# level_after 升级后等级
# success_rate 本次进阶的成功率
def PARSE_WING_UPGRADE(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'wing_upgrade'
	total = data.split(',')
	js['wing_index'] = int(total[idx + 0])
	js['level_before'] = int(total[idx + 1])
	js['level_after'] = int(total[idx + 2])
	js['success_rate'] = int(total[idx + 3])
	xjs = {}
	xjs['wing_upgrade'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#炮台升星
# hero_index 炮台配置id
# star_before 升级前星级
# charge_before 升级前充能数
# star_after 升级后星级
# charge_after 升级后充能数
def PARSE_HERO_STAR_CHARGE(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'hero_star_charge'
	total = data.split(',')
	js['hero_index'] = int(total[idx + 0])
	js['star_before'] = int(total[idx + 1])
	js['charge_before'] = int(total[idx + 2])
	js['star_after'] = int(total[idx + 3])
	js['charge_after'] = int(total[idx + 4])
	xjs = {}
	xjs['hero_star_charge'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#内存信息
# event_time 事件时间
# mid 聊天id
# speaker 发言方
# listener 接受方,公聊为0,私聊为接收方id,群聊为群组id
# type 0公聊,1私聊,2群聊,3礼物状态
# content 内容
def PARSE_CHAT_INFO(data, r):
	js = {}
	js['event_name'] = 'chat_info'
	total = data.split(',')
	js['event_time'] = TimeToString(total[0])
	js['mid'] = int(total[1])
	js['speaker'] = int(total[2])
	js['listener'] = int(total[3])
	js['type'] = int(total[4])
	js['content'] = total[5]
	xjs = {}
	xjs['chat_info'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#礼物信息
# event_time 事件时间
# gift_id 礼物id
# source 赠送方
# dest 接收方
# item_id 道具id
# item_num 数量
# status 状态
# fee 服务费
def PARSE_GIFT_INFO(data, r):
	js = {}
	js['event_name'] = 'gift_info'
	total = data.split(',')
	js['event_time'] = TimeToString(total[0])
	js['gift_id'] = int(total[1])
	js['source'] = int(total[2])
	js['dest'] = int(total[3])
	js['item_id'] = int(total[4])
	js['item_num'] = int(total[5])
	js['status'] = int(total[6])
	js['fee'] = int(total[7])
	xjs = {}
	xjs['gift_info'] = json.dumps(js)
	r.xadd('log_stream', xjs)

#围猎奖励相关信息
# bossid 唯一id
# index 配置id
# cost 消耗
# gold 可领奖励
# item_gold 道具可领奖励
# status 状态
def PARSE_HUNT_BOSS_INFO(data, r):
	js = PARSE_LOGACCINFO(data)
	idx = len(js)
	js['event_name'] = 'hunt_boss_info'
	total = data.split(',')
	js['bossid'] = int(total[idx + 0])
	js['index'] = int(total[idx + 1])
	js['cost'] = int(total[idx + 2])
	js['gold'] = int(total[idx + 3])
	js['item_gold'] = int(total[idx + 4])
	js['status'] = int(total[idx + 5])
	xjs = {}
	xjs['hunt_boss_info'] = json.dumps(js)
	r.xadd('log_stream', xjs)

def parse_log_file(filePath, r):
	fileName = os.path.basename(filePath)
	eventName,_ = fileName.split('.')
	file = open(filePath)
	for line in file:
		eval('PARSE_' + eventName.upper())(line, r)

def parse_base_dir(logBase, r):
# 取上一个小时的日志
	tLog = (datetime.datetime.utcnow() + datetime.timedelta(hours=7))
	filePath = logBase + '/' + tLog.strftime('%Y%m%d/%H')
	zipfile = filePath + '.zip'
	logging.info('start %s', filePath)
	try:
		if os.path.exists(zipfile) :
			shutil.unpack_archive(zipfile, filePath)
			filelist = os.listdir(filePath)
			for i in range(0, len(filelist)):
				parse_log_file(filePath+'/'+filelist[i], r)
			logging.info('success')
		else :
			logging.info('no log file')
	except Exception:
			logging.error('failed')

def parse_log_dir(logDir, r):
	logging.info('start dir %s', logDir)
	try:
		filelist = os.listdir(logDir)
		for i in range(0, len(filelist)):
			parse_log_file(logDir+'/'+filelist[i], r)
		logging.info('success')
	except Exception:
		logging.error('failed')

def main(argv):
	r = redis.Redis(host='127.0.0.1', port=6379, decode_responses=True)
	try:
		opts, args = getopt.getopt(argv, 'hb:d:f:')
	except getopt.GetopeError:
		print('log2redis.py [-b LogBaseDir] [-f GameLogFile] [-d LogBaseDir/yyyymmdd/hh]')
		sys.exit(2)
	try:
		for opt, arg in opts:
			if opt == '-h':
				print('log2redis.py [-b LogBaseDir] [-f GameLogFileFullPath] [-d LogBaseDir/yyyymmdd/hh]')
				sys.exit()
			elif opt == '-d':
				parse_log_dir(arg, r)
			elif opt == '-f':
				parse_log_file(arg, r)
			elif opt == '-b':
				parse_base_dir(arg, r)
	except Exception:
		logging.error('log2redis faild ', exc_info = True)

if __name__ == '__main__':
	main(sys.argv[1:])
