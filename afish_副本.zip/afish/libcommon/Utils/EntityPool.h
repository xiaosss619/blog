#pragma once

#include "LxObjectPool.h"
#include <map>
#include <string>
using namespace std;
// 对象池中对象需要实现以下接口
// GetKey() Update(int32 deltaMS) IsValid() Init(xxxxx)
// 在Init中需要设置key,使得GetKey可以返回正确的数值
// 在Update中,如果设置自己的Valid为false,则可以在下一帧中被删除并返回到对象池中,不需要主动删除
template<class KeyType, class ValueType>
class EntityDriver
{
private:
    map<KeyType, ValueType*> _entityMap;
    LxObjectPool<ValueType> _pool;
    string _name;
private:
    ValueType* Create() {
        auto p = _pool.alloc();
        if( _entityMap.find(p->GetKey()) != _entityMap.end() ) {
            string strKey = GlobalUtils::ToString(p->GetKey());
            LOGINFO("entity in entity map when create[%s][%s]", _name.c_str(), strKey.data());
            return nullptr;
        }
        return p;
    }
public:
    EntityDriver() {}
    ~EntityDriver() {}
    void Init(const string& name, int initNum = 200, int increaseNum = 100)
    {
        _name = name;
        _entityMap.clear();
        _pool.init(name, initNum, increaseNum);
    }

    // lstInValid中的指针仍旧有效,数据也还是有效的,但是已经返回到对象池,不再会调用Update函数
    // 调用方无需释放对应指针,但是需要对指针进行数据清理,防止脏数据产生
    void Update(int32 dt)
    {
        list<ValueType*> lstInvalid;
        for( auto it = _entityMap.begin(); it != _entityMap.end(); ) {
            if( it->second->IsValid() ) {
                it->second->Update(dt);
                ++it;
            }
            else {
                lstInvalid.push_back(it->second);
                _pool.dealloc(it->second);
                _entityMap.erase(it++);
            }
        }
        for( auto& entity : lstInvalid ) {
            entity->OnRecycled();
        }
    }

    std::tuple<string, int32, int32, int32> DebugInfo() {
        auto data = _pool.showinfo();
        return make_tuple(_name, _entityMap.size(), TUPLE0(data), TUPLE1(data));
    }

    int32 GetEntityCount() { return (int32)_entityMap.size(); }

    // 从对象池中获取一个ValueType对象, 会主动调用ValueType->Init(Args&&...args)
    // Args可以为任何形式的参数列表,只需要对应类中声明了对应形式的Init函数
    template<typename...Args>
    ValueType* CreateEntity(Args&&...args) {
        ValueType* p = Create();
        if( p == nullptr ) {
            LOGERROR("%s EntityPool empty", _name.c_str());
            return nullptr;
        }
        if( !p->Init(std::forward<Args>(args)...) ) {
            LOGERROR("%s entity init failed", _name.c_str());
            _pool.dealloc(p);
            return nullptr;
        }
        if( !p->IsValid() ) {
            LOGERROR("%s entity invalid after init", _name.c_str());
            _pool.dealloc(p);
            return nullptr;
        }
        _entityMap[p->GetKey()] = p;
        return p;
    }
    // 谨慎使用 释放一个指针,仅使用在不调用update的指针,如果是需要调用update的对象池,直接设置IsValid返回false即可
    void RemoveEntity(ValueType* p) {
        _entityMap.erase(p->GetKey());
        p->OnRecycled();
        _pool.dealloc(p);
    }
    // 根据id获取一个对象
    ValueType* GetEntity(KeyType key) {
        auto it = _entityMap.find(key);
        if( it != _entityMap.end() ) {
            return it->second;
        }
        return nullptr;
    }
    // 查找当前有效的对象列表中是否有指定对象
    bool HasEntity(KeyType key) {
        return _entityMap.find(key) != _entityMap.end();
    }
    // 获取所有有效对象
    map<KeyType, ValueType*>& GetAllEntity() { return _entityMap; }
    void ForEachEntity(boost::function<void(ValueType*)> func) {
        for( auto & it : _entityMap) {
            func(it.second);
        }
    }
    void ForEachEntityWithBreak(boost::function<bool(ValueType*)> func) {
        for( auto & it : _entityMap) {
            if( func(it.second) ) {
                break;
            }
        }
    }
    // 轮询
    void ForOtherEntity(ValueType* thisOne, std::function<void(ValueType*)> func) {
        for( auto& it : _entityMap ) {
            if( thisOne != it.second ) {
                func(it.second);
            }
        }
    }
    void RemoveAll() {
        for( auto it = _entityMap.begin(); it != _entityMap.end(); ++it ) {
            it->second->OnRecycled();
            _pool.dealloc(it->second);
        }
        _entityMap.clear();
    }
};
