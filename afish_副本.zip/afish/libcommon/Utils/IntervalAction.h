﻿#pragma once

#include "ServerDefine.h"

class IntervalAction
{
    struct Interval
    {
        int IntervalMS;
        int IntervalCountdown;
        bool EveryFrame;
        bool OnlyOnce;     //仅执行一次
        boost::function<void ()> Action;
        bool Valid;
        Interval() {
            EveryFrame = false;
            OnlyOnce = false;
            Valid = true;
        }
    };
private:
    std::list<Interval> actions;
    std::list<Interval> protectList;
public:
    void Register(int intervalMS, boost::function<void ()> action)
    {
        Interval inter;
        inter.IntervalMS = intervalMS;
        inter.IntervalCountdown = intervalMS;
        inter.Action = action;
        AddInterval(inter);
    }
    void DelayRun(int delayMS, boost::function<void ()> action)
    {
        Interval inter;
        inter.IntervalMS = delayMS;
        inter.IntervalCountdown = delayMS;
        inter.OnlyOnce = true;
        inter.Action = action;
        AddInterval(inter);
    }

    void AddInterval(Interval inter)
    {
        protectList.emplace_back(inter);
    }

    void RegFrameAction(boost::function<void ()> action)
    {
        Interval inter;
        inter.EveryFrame = true;
        inter.Action = action;
        AddInterval(inter);
    }

    void Update(int deltaMS)
    {
        if (protectList.size() > 0)
        {
            actions.merge(protectList);
            protectList.clear();
        }

        bool needClear = false;
        for( auto it = actions.begin(); it != actions.end() ;)
        {
            if (!(*it).Valid)
            {
                actions.erase(it++);
                continue;
            }

            if ((*it).EveryFrame)
            {
                (*it).Action();
            }
            else
            {
                (*it).IntervalCountdown -= deltaMS;
                if ((*it).IntervalCountdown <= 0)
                {
                    (*it).IntervalCountdown = (*it).IntervalMS;
                    (*it).Action();

                    if ((*it).OnlyOnce)
                    {
                        (*it).Valid = false;
                        needClear = true;
                    }
                }
            }
            ++it;
        }
    }
};

