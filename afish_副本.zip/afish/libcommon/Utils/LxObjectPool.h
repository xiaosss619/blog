#pragma once

#include <unordered_set>
#include <string.h>

//对象池模板类 多线程不可用
template<class T>
class LxObjectPool
{
public:
	enum
	{
		MAX_INIT_NUM = 100000,	// 初始化最大数量，暂定10万
	};
	LxObjectPool() {}
	~LxObjectPool() {}
public:
	// 初始化(初始数量，一次增长的数量)
	bool init(const string& name, int initNum = 200, int increaseNum = 100)
	{
		// 参数检测
		if (initNum <= 0 || increaseNum <= 0 )
		{
			return false;
		}
		_name = name;
		_initNum = initNum;
		_incNum	= increaseNum;
		// 参数修正
		_initNum		= _initNum>MAX_INIT_NUM ? MAX_INIT_NUM : _initNum;			// 初始个数
		_incNum	= _incNum>MAX_INIT_NUM ? MAX_INIT_NUM : _incNum;	// 一次增长的数量
		// 初始化对象
		for (int i = 0; i<_initNum; ++i)
		{
			T* pObj = new(std::nothrow)T();
			if (pObj == nullptr)
			{
				continue;
			}
			_freeList.insert(pObj);
		}

		return true;
	}

	// 分配一个新对象
	T* alloc()
	{
		T* pRet = nullptr;
		// 空闲列表中有，则取一个
		if (_freeList.size() > 0)
		{
			auto iter = _freeList.begin();
			pRet = *iter;
			_freeList.erase(iter);
			_usedList.insert(pRet);
			return pRet;
		}

		// 空闲列表中没有时，则新建一批
		for (int i = 0; i<_incNum; i++)
		{
			T* pObj = new(std::nothrow)T();
			if (pObj == nullptr)
			{
				continue;
			}
			// 没赋值的先赋值；已赋值的压入空闲列表
			if (pRet == nullptr)
			{
				pRet = pObj;
				_usedList.insert(pObj);
			}
			else
			{
				_freeList.insert(pObj);
			}
		}

		return pRet;
	}

	// 回收一个对象
	void dealloc(T* pObj)
	{
		if (pObj == nullptr)
		{
			return;
		}
		// 不存在
		auto it = _usedList.find(pObj);
		if (it == _usedList.end())
		{
			return;
		}
		_freeList.insert(pObj);
		_usedList.erase(pObj);
	}

	std::tuple<int32, int32> showinfo()
	{
		return make_tuple(_freeList.size(), _usedList.size());
	}

private:
	std::unordered_set<T*> 	_freeList;		// 空闲列表
	std::unordered_set<T*> 	_usedList;		// 使用中的列表
	int 					_initNum;		// 初始个数
	int 					_incNum;	// 一次增长的数量
	string					_name;		// 名称
};

