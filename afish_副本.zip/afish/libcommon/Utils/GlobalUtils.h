#pragma once

#include <string>
#include <sstream>
#include <map>
#include <random>
using namespace std;

#include <google/protobuf/stubs/common.h>
using namespace google::protobuf;

#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>

#include <cxxabi.h>
#include <cstdio>
#include <cstdlib>
#include <execinfo.h>

#include "ThreadLog/ThreadLog.h"
#include "fasthash.h"
#include "rapidjson/document.h"
#include "rapidjson/writer.h"
using namespace rapidjson;

#define TRYBEGIN() try {
#define TRYEND(strLog) } catch (boost::bad_lexical_cast & e) {\
    LOGERROR("CATCH cast[%s]", strLog.data());\
    return;\
}\
catch (std::exception& e) {\
    LOGERROR("CATCH std::exception[%s] format error", strLog.data());\
    return;\
}\
catch (...) {\
    LOGERROR("CATCH all[%s] format error", strLog.data());\
    return;\
}

#define TRYENDFALSE() } catch (boost::bad_lexical_cast & e) {\
    LOGERROR("CATCH cast");\
    return false;\
}\
catch (std::exception& e) {\
    LOGERROR("CATCH std");\
    return false;\
}\
catch (...) {\
    LOGERROR("CATCH all");\
    return false;\
}

enum E_TimeFormat
{
	ETF_YMDHMS	= 0,	// yyyy-mm-dd HH:MM:SS
	ETF_YMD		= 1,	// yyyy-mm-dd
	ETF_LOG		= 2,	// redis打点时间字符串格式 yyyy/mm/dd hh:mm:ss
	ETF_YMD_SHORT	= 3,	// yymmdd
};

#define TIME_REDIS_EXPIRE 86400*20
#define TIME_WEEK 604800
#define TIME_DAY 86400
#define TIME_HOUR 3600
#define TIME_MIN 60

class Roll;
class GlobalUtils
{
public:
	GlobalUtils() {};
	~GlobalUtils(void) {};
	static string MakeJson(const Document& doc)
	{
		StringBuffer sbBuffer;
		rapidjson::Writer<rapidjson::StringBuffer> jWriter(sbBuffer);
		doc.Accept(jWriter);
		return (string)sbBuffer.GetString();
	}
	static string MakeJson(const rapidjson::Value& valObj)
	{
		rapidjson::StringBuffer sbBuf;
		rapidjson::Writer<rapidjson::StringBuffer> jWriter(sbBuf);
		valObj.Accept(jWriter);
		return std::string(sbBuf.GetString());
	}
	static void Init();
public:
    static int32 GetServiceId(int32 cmd) { return (cmd >> 24); }
	static string GetStarName(const string& strName);
	static string GetWholeFileString(const string& file);
	static uint32 GenerateCRC32(const void* data, size_t size);
	static uint64 StringHash(const string& str);
	static unsigned char ToHex(unsigned char x);
	static unsigned char FromHex(unsigned char x);
	static std::string UrlEncode(const std::string& str);

	template<typename T>
	static void ShuffleVector(vector<T>& vec) {
		static thread_local std::default_random_engine generator(std::random_device{}());
		std::shuffle(vec.begin(), vec.end(), generator);
	}
	//获取范围内随机数,左右都是闭区间
	static int32 GetRandNumber(int32 iMin, int32 iMax);
	static int32 GetRandNumber2(int32 iMin, int32 iMax);
	// 获取范围内随机数,左右都是闭区间, 每位数字都不同
	static int32 GetRandDigit(int32 iMin, int32 iMax, bool seed2);
	//获取范围内随机数,左右都是闭区间
	static int64 GetRandLong(int64 iMin, int64 iMax);
	// 获得0-10000之间的随机数, stdev为方差 结果符合正态分布
	static int GetRandNumber(int32 stdev);
	// 获得iMin-iMax之间的随机数, stdev为方差 结果符合正态分布
	static int GetRandNumber(int iMin, int iMax, int32 stdev);
	static void GetStrArray(const string& str, const string& splitter, vector<string>& lhs);
	static void GetNumArray(const string& str, const string& splitter, vector<int64>& lhs);
	static void GetNumSet(const string& str, const string& splitter, set<int64>& lhs);
	template<typename T>
	static int32 SearchItem(const vector<T>& vec, T item) {
		for( size_t i = 0; i < vec.size(); ++i ) {
			if( item == vec[i] ) {
				return i;
			}
		}
		return -1;
	}
	template<typename T>
	static string JoinArray(const vector<T>& vec, const string& seperator) {
		ostringstream oss;
		for( size_t n = 0 ; n < vec.size() ; ++n ) {
			oss << vec[n];
			if( n != vec.size()-1 ) {
				oss << seperator;
			}
		}
		return oss.str();
	}
	template<typename T>
	static string JoinSet(const set<T>& datas, const string& seperator) {
		ostringstream oss;
		for( auto & it : datas ) {
			oss << it << seperator;
		}
		return oss.str();
	}
	template <typename KeyType, typename ValueType>
	static void SimpleMapAdd(map<KeyType, ValueType>& mapData, const KeyType& key, const ValueType& value) {
		auto it = mapData.find(key);
		if( it == mapData.end() ) {
			mapData[key] = value;
		}
		else {
			it->second += value;
		}
	}
	// 合并map
	template <typename KeyType, typename ValueType>
	static void SimpleMapMergeAdd(const map<KeyType, ValueType>& mp1, const map<KeyType, ValueType>& mp2, map<KeyType, ValueType>& mapFinal) {
		mapFinal = mp1;
		for(auto& item : mp2) {
			auto it = mapFinal.find(item.first);
			if( it == mapFinal.end() ) {
				mapFinal[item.first] = item.second;
			}
			else {
				it->second += item.second;
			}
		}
	}
	static bool InVector(int64 value, const vector<int64>& vec) {
		for( size_t i = 0; i < vec.size(); i++ ) {
			if( value == vec[i] ) {
				return true;
			}
		}
		return false;
	}
	// 金币转换成字符串, 大于亿的保留两位小数的亿, 大于万的保留两位小数的万
	static string GetNumberString(int64 number) {
		if( number >= 1000000000 ) {
			char szNumber[32] = {0};
			sprintf(szNumber, "%.2fB", number*1.0/1000000000.0);
			return (string)(szNumber);
		}
		else if( number >= 1000000 ) {
			char szNumber[32] = {0};
			sprintf(szNumber, "%.2fM", number*1.0/1000000.0);
			return (string)(szNumber);
		}
		else {
			return ToString(number);
		}
	}
	// 判断两个日期是否在同一天
	static bool InSameDay(int64 uDay1, int64 uDay2) { return (uDay1+8*TIME_HOUR)/TIME_DAY == (uDay2+8*TIME_HOUR)/TIME_DAY; };
	// 判断两个日期是否在同一周 +3天的原因是1970/01/01是周四
	static bool InSameWeek(int64 uDay1, int64 uDay2) { return (uDay1+3*TIME_DAY+8*TIME_HOUR)/TIME_WEEK == (uDay2+3*TIME_DAY+8*TIME_HOUR)/TIME_WEEK; }
	// 是否在00:05以内,用于判定竞技场的排名显示,前5分钟是不应该显示数据的
	static bool LessThan0005(int64 tTime);
	// 判定是否是周一
	static bool IsMonday(time_t tmNow);
	// 判断tmNow是否是周一 0点的+-5分钟时间段内
	static bool IsInMondayGL5(time_t tmNow);
	// 获取给定时间到24点的剩余秒数
	static int32 GetLeftSecondsOfDay(time_t tmNow);
	// 计算两个日期之间相差的天数,返回绝对值
	static int32 GetDayDiff(int64 t1, int64 t2) { return abs((t1+8*TIME_HOUR)/TIME_DAY - (t2+8*TIME_HOUR)/TIME_DAY); };
	//根据小时设置时间
	static int64 SetTimeToHour(const string& hour);
	static int64 SetTimeToHour(int64 iTime,const string& hour);
	//根据String设置时间
	static int64 SetTimeToString(const string& strTime);
	//判断是否在时间区间
	static bool TimeInTheInterval(const string& startTime,const string& endTime,const string& startHour,const string& endHour);
	static bool TimeInTheInterval(const string& startTime,const string& endTime);
    // yyyy-mm-dd hh:mm:ss 转换成 time_t
    static int64 MakeTime(const string& strTime);
	// 按格式输出时间字符串
	static string GetTimeByFormat(E_TimeFormat eFormat,int64 iTime);
	static int64 GetRandomMoney(int64 nTotalMoney, int64 nRemainMoney, int64 nMinimum, int32 nRemainCount);
	// 生成红包队列
	static void GenerateGrabBonus(int64 iTotal, int32 nCount, int64 nMinimum, vector<string>& vecData);
	static uint32 ConvertIpToInt(const string& strIp);

	template<class T>
	static string ToString(const T& t) {
		ostringstream os;
		os << t;
		return os.str();
	};
	//判断字符是否是中文
	static bool is_zh_ch(char p) {
		if(~(p >> 8) == 0)
		{
			return true;
		}
		return false;
	}
	// 获取字符串第一个字符
	static string GetFirstWord(const string& str)
	{
		string ret;
		if( is_zh_ch(str.at(0)) && str.size() >= 3 ) {
			ret+= str.at(0);
			ret+= str.at(1);
			ret+= str.at(2);
		}
		else {
			ret += str.at(0);
		}
		return ret;
	}

	// 获取当前系统时间的毫秒数
	static int64 GetTickCount() {
		struct timeval tv;
		gettimeofday(&tv,NULL);
		return (int64)(tv.tv_sec*1000 + tv.tv_usec/1000);
	}

	// 生成指定位数的随机数
	static string GenerateRandCode(int iSeed, int len) {
		srand(time(NULL) + iSeed);
		ostringstream osCode;
		for (int i = 0; i < len; i++) {
			osCode << (rand() % 10);
		}
		return osCode.str();
	}
	// 把分值分成三份,要全部分完,同时最大值不超过99
	static std::tuple<int32, int32, int32> SplitTortoiseScore(int32 score) {
		int32 minNum = max(1,score-198);
		int32 maxNum = min(99,score-2);
		int32 a = GetRandNumber(minNum,maxNum);
		int32 leftNum = score - a;
		minNum = max(1, leftNum - 99);
		maxNum = min(99, leftNum - 1);
		int32 b = GetRandNumber(minNum,maxNum);
		int32 c = score - a - b;
		return std::make_tuple(a, b, c);
	}
	// ver1与ver2是 xx.xx.xxx 的版本号模式 按.最少的一个字符串来进行对比 x.x.x.x 和 x.x 只会对比前两个版本号, 后几位被忽略
	// 相同返回0
	// ver1 > ver2 返回1
	// ver1 < ver2 返回-1
	static int32 VersionCompare(const string& ver1, const string& ver2);
	// 从userid计算获得db和table的索引
	// 返回 make_tuple(db,table)
	static std::tuple<int32, int32> CalculateDbTableByUserId(uint64 userid)
	{
		userid = 0x00000000000000FF & userid;
		return std::make_tuple((userid & 0xF0) >> 4, (userid & 0x0F));
	}
	// 从账号的hash计算获得db和table的索引
	// 返回 make_tuple(db,table)
	static std::tuple<int32, int32> CalculateDbTableByAccount(const std::string& account)
	{
		uint64 hash_id = fasthash64(account.c_str(), account.length(), 0);
		hash_id = 0x00000000000000FF & hash_id;
		return std::make_tuple(hash_id & 0xF0 >> 4, hash_id & 0x0F);
	}

	static string GetLimitNickName(const string& sNickName);
	static string GetLimitNickName(const string& sNickName,int iLimitWidth);
	static string GetLimitWidthString(const string& sText, int iLimitWidth);

	static string ReplaceAll(const string& str, const string& old_value, const string& new_value) {
		string strNew = str;
		while (true)
		{
			string::size_type pos(0);
			if( (pos=strNew.find(old_value))!=string::npos)
			{
				strNew.replace(pos,old_value.length(),new_value);
			}
			else
			{
				break;
			}
		}
		return strNew;
	}

	static int get_path_name(char* name, int name_size)
	{
		char path[1024] = {0};
		strcpy(path,get_current_dir_name());
		char* ptr = strrchr(path,'/');
		bzero(name, name_size);
		strncpy(name, ptr+1, name_size - 1);
		return 0;
	}
	static bool process_is_running();
private:
	static Roll _numbers;
};

class Roll {
	struct tagRoll {
		int32 _weight;
		int64 _value;
		tagRoll(int32 weight, int64 value) : _weight(weight), _value(value) { }
		tagRoll& operator=(const tagRoll& rhs) {
			_weight = rhs._weight;
			_value = rhs._value;
			return *this;
		}
	};
private:
	int32 m_nRollTimes;			// roll几次
	bool m_bNeedRemoveValue;	// roll之后是否需要移除
    int32 m_nTotalWeight;
	list<tagRoll> m_lstRoll;
	set<int64> m_setValues;
public:
	Roll() {
		clear();
	};
	~Roll() {};
	/**@brief 设置额外属性
	 * @param bNeedRemoveValue 是否在随机出一个数值后将其从库中删除
	 * @param times 部分配置中会限制本库的随机次数
	 */
	void set_extra(bool bNeedRemoveValue, int32 times) {
		m_bNeedRemoveValue = bNeedRemoveValue;
		m_nRollTimes = times;
	}
	inline int32 times() const { return m_nRollTimes; }
	Roll& operator=(const Roll& other) {
		m_nRollTimes = other.m_nRollTimes;
		m_bNeedRemoveValue = other.m_bNeedRemoveValue;
		m_nTotalWeight = other.m_nTotalWeight;
		m_lstRoll = other.m_lstRoll;
		m_setValues = other.m_setValues;
		return *this;
	}
	inline bool empty() { return m_lstRoll.empty(); }
public:
	/**@brief 增加随机数值
	 * @param weight 该数值的权重
	 * @param value 随机数值
	 */
	void push_value(int32 weight, int64 value) {
		if( weight == 0 ) {
			return;
		}
		m_lstRoll.push_back(tagRoll(weight, value));
        m_nTotalWeight += weight;
		m_setValues.insert(value);
	}
	void remove_value(int64 value) {
		for( auto it = m_lstRoll.begin(); it != m_lstRoll.end() ; ++it ) {
			if( value == (*it)._value) {
				m_nTotalWeight -= (*it)._weight;
				m_lstRoll.erase(it);
				m_setValues.erase(value);
				break;
			}
		}
	}
	bool has_value(int64 value) {
		return m_setValues.find(value) != m_setValues.end();
	}
	int64 roll() {
		if( m_lstRoll.empty() ) { return 0; }
        int32 v = GlobalUtils::GetRandNumber(0, m_nTotalWeight);
        int32 nWeightNow = 0;
		for( auto it = m_lstRoll.begin(); it != m_lstRoll.end() ; ++it ) {
            nWeightNow += (*it)._weight;
            if( v <= nWeightNow ) {
				int64 value = (*it)._value;
				if( m_bNeedRemoveValue ) {
					m_nTotalWeight -= (*it)._weight;
					m_lstRoll.erase( it );
					m_setValues.erase(value);
				}
				return value;
			}
        }
        return 0;
	}
	void clear() {
		m_nRollTimes = 0;
		m_nTotalWeight = 0;
		m_lstRoll.clear();
		m_setValues.clear();
		m_bNeedRemoveValue = false;
	}
	int32 size() { return m_lstRoll.size(); }
};

template<class T>
class Singleton
{
public:
	static T* Instance()
	{
		if (NULL == m_pInstance)
		{
			// 二次检查
			if (NULL == m_pInstance)
			{
				m_pInstance = new T;
				atexit(Destory);
			}
		}

		return m_pInstance;
	}

protected:
	Singleton() {} //防止实例
	Singleton(const Singleton&) {} //防止拷贝构造一个实例
	Singleton& operator=(const Singleton&){} //防止赋值出另一个实例

	virtual ~Singleton()
	{
	}

	static void Destory()
	{
		if (m_pInstance)
		{
			delete m_pInstance;
			m_pInstance = NULL;
		}
	}

private:
	static T* m_pInstance;
};

template<class T> T* Singleton<T>::m_pInstance = NULL;
