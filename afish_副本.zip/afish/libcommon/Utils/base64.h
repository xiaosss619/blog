#ifndef __ZBASE64_H__
#define __ZBASE64_H__

#include <string>
using namespace std;

class ZBase64
{
public:
	static string Encode(const unsigned char* Data,int DataByte);
	static string Decode(const char* Data,int DataByte,int& OutByte);
	static string Encode(const string& strSource);
	static string Decode(const string& strSource);
};

#endif
