
#ifndef MEMORY_POOL_HPP
#define MEMORY_POOL_HPP

#include <boost/pool/pool.hpp>
#include <boost/pool/singleton_pool.hpp>

using namespace std;
using namespace boost;

#define MEMORY_BUFFER_MAX_SIZE 65535

struct memorypool{};
typedef singleton_pool<memorypool, MEMORY_BUFFER_MAX_SIZE> memory_pool_64k;

#endif // MEMORY_POOL_HPP
