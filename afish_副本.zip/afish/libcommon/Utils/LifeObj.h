// 处理一些带生命周期的简单对象,到期从队列里删除,可查询
#pragma once

/**
 * ValueType
 *      key() 用于查询该对象是否存在
// 生命
 */
template<typename KeyType, typename ValueType>
class LifeObj {
public:
    LifeObj() {
        m_mapObj.clear();
    };
    ~LifeObj() {};
    struct tagLifeObj {
        KeyType _key;
        ValueType _obj;
        int64 _curTick;
        int64 _lifeTick;
    };
public:
    // 增加一个对象 lifetick为寿命
    void Add(const KeyType& key, const ValueType& obj, int64 lifeTick) {
        tagLifeObj data;
        data._key = key;
        data._obj = obj;
        data._curTick = 0;
        data._lifeTick = lifeTick;
        m_mapObj[key] = data;
    }
    // 传入当前tick时间 GlobalUtils::GetTickCount()
    void Update(int32 dt) {
        int32 loopCount = 0;
        for( auto it = m_mapObj.begin(); it != m_mapObj.end(); loopCount++ ) {
            it->second._curTick += dt;
            if( it->second._curTick < it->second._lifeTick ) {
                ++it;
            }
            else {
                m_mapObj.erase(it++);
            }
            if( loopCount >= 100 ) {
                break;
            }
        }
    }
    string GetLogData() {
        ostringstream os;
        for( auto & it : m_mapObj ) {
            os << "buffid : " << it.second._key << " curTick : " << it.second._curTick << " lifeTick : " << it.second._lifeTick << " ### ";
        }
        return os.str();
    }
    bool Contains(const KeyType& key) {
        return m_mapObj.find(key) != m_mapObj.end();
    }
    void Remove(const KeyType& key) {
        m_mapObj.erase(key);
    }
    void Clear() {
        m_mapObj.clear();
    }
    void ForEach(std::function<void(tagLifeObj*)> func) {
        for( auto & it : m_mapObj) {
            func(&it.second);
        }
    }
    void ForEachWithBreak(std::function<bool(tagLifeObj*)> func) {
        for( auto & it : m_mapObj) {
            if( func(&it.second) ) {
                break;
            }
        }
    }
    bool Get(const KeyType& key, ValueType& lhs) {
        auto it = m_mapObj.find(key);
        if( it != m_mapObj.end() ) {
            lhs = it->second._obj;
            return true;
        }
        return false;
    }
    ValueType* GetPtr(const KeyType& key) {
        auto it = m_mapObj.find(key);
        if( it != m_mapObj.end() ) {
            return &it->second._obj;
        }
        return nullptr;
    }
private:
    map<KeyType, tagLifeObj> m_mapObj;
};
