#pragma once

#include <string>
#include <sstream>
#include <map>
#include <set>
#include <vector>
using namespace std;

#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>

#include <google/protobuf/stubs/common.h>
using namespace google::protobuf;

#include "ThreadLog/ThreadLog.h"

// 对应位置是否为*
enum E_CronStar {
    ECS_Year    = 0x00000001,
    ECS_Month   = 0x00000002,
    ECS_Week    = 0x00000004,
    ECS_Day     = 0x00000008,
    ECS_Hour    = 0x00000010,
    ECS_Minute  = 0x00000020,
};

/**
 * 变异版crontab
 * 用于定时开放的活动开关
 * _start ~ _end 为总的时间范围,优先满足该时间段的任务才会被触发
 * _flags 为*标记
 *      _flags & ECS_Year == true 表示 year字段为*,任何年份均可执行
 *      _flags & ECS_Year == false 表示需要在_years中查找可执行的年份
 * lasting 必须 > 0 单位为分钟
 * _hours 不能为* 必须填写对应的时间点,遍历时,如果在时间点内,并且_this_end=0会触发一次活动开启,用于活动期间服务器重启,
 * 新配置上传后,在时间段内服务器重启,此时redis无数据,也必须由这里触发一次
 */
struct tagCronTask {
    int32 _id;              // 活动id
    int32 _flags;           // *标记位
    int64 _start;           // 开始时间 这里的开始和结束是总的开关
    int64 _end;             // 结束时间
    int32 _lasting;         // 持续时间
    int64 _this_end;        // 本次应该结束的时间
    set<int32> _years;      // *标记如果未设置,则读取以下set,判定是否可以执行该命令
    set<int32> _months;
    set<int32> _weeks;
    set<int32> _days;
    set<int32> _hours;
    set<int32> _minutes;
    tagCronTask() {
        Reset();
    }
    void Reset() {
        _id = 0;
        _flags = 0;
        _lasting = 0;
        _this_end = 0;
        _years.clear();
        _months.clear();
        _weeks.clear();
        _days.clear();
        _hours.clear();
        _minutes.clear();
    }
    tagCronTask& operator=(const tagCronTask& rhs) {
        _id = rhs._id;
        _flags = rhs._flags;
        _start = rhs._start;
        _end = rhs._end;
        _lasting = rhs._lasting;
        _this_end = rhs._this_end;
        _years = rhs._years;
        _months = rhs._months;
        _weeks = rhs._weeks;
        _days = rhs._days;
        _hours = rhs._hours;
        _minutes = rhs._minutes;
        return *this;
    }
    bool assign(int32 id, const string& start, const string& end, int32 lasting,
                const vector<string>& years,
                const vector<string>& months,
                const vector<string>& weeks,
                const vector<string>& days,
                const vector<string>& hours,
                const vector<string>& minutes) {
        // hours minutes lasting必须填具体数值
        if( lasting == 0 || hours.size() == 0 || hours[0] == "*" || minutes.size() == 0 || minutes[0] == "*") {
            return false;
        }
        _id = id;
        _lasting = lasting;
        MakeFlag(years, ECS_Year);
        MakeFlag(months, ECS_Month);
        MakeFlag(weeks, ECS_Week);
        MakeFlag(days, ECS_Day);
        MakeFlag(hours, ECS_Hour);
        MakeFlag(minutes, ECS_Minute);
        _start = MakeTime(start);
        _end = MakeTime(end);
        if( _start == 0 || _end == 0 ) {
            return false;
        }
        return true;
    }
    void MakeFlag(const vector<string>& vec, E_CronStar flag) {
        if( vec.size() == 0 || vec[0] == "*" ) {
            _flags |= flag;
        }
        else {
            for( size_t i = 0; i < vec.size(); i++ ) {
                try {
                    int32 value = boost::lexical_cast<int32>(vec[i]);
                    switch(flag) {
                    case ECS_Year:
                        _years.insert(value);
                        break;
                    case ECS_Month:
                        _months.insert(value);
                        break;
                    case ECS_Week:
                        _weeks.insert(value);
                        break;
                    case ECS_Day:
                        _days.insert(value);
                        break;
                    case ECS_Hour:
                        _hours.insert(value);
                        break;
                    case ECS_Minute:
                        _minutes.insert(value);
                        break;
                    default:
                        break;
                    }
                }
                catch(boost::bad_lexical_cast & e) {
                    LOGERROR("bad argument");
                }
            }
        }
    }
    // yyyy-mm-dd hh:mm:ss 转换成 time_t
    int64 MakeTime(const string& strTime)
    {
        try {
            vector<string> vecTime;
            boost::split(vecTime, strTime, boost::is_any_of(" "));
            if( vecTime.size() != 2 ) {
                return 0;
            }
            vector<string> ymd;
            boost::split(ymd, vecTime[0], boost::is_any_of("-"));
            if( ymd.size() != 3 ) {
                return 0;
            }
            vector<string> hms;
            boost::split(hms, vecTime[1], boost::is_any_of(":"));
            if( hms.size() != 3 ) {
                return 0;
            }

            struct tm tt;
            tt.tm_year = boost::lexical_cast<int32>(ymd[0])-1900;
            tt.tm_mon  = boost::lexical_cast<int32>(ymd[1])-1;
            tt.tm_mday = boost::lexical_cast<int32>(ymd[2]);
            tt.tm_hour = boost::lexical_cast<int32>(hms[0]);
            tt.tm_min  = boost::lexical_cast<int32>(hms[1]);
            tt.tm_sec  = boost::lexical_cast<int32>(hms[2]);
            tt.tm_isdst= -1;
            return mktime(&tt);
        }
        catch(boost::bad_lexical_cast & e) {
            LOGERROR("invalid time format");
            return 0;
        }
    }
    int64 MakeTodayTime(const struct tm& ltm, int32 hour, int32 minute) {
        struct tm tmStart = ltm;
        tmStart.tm_sec = 0;
        tmStart.tm_hour = hour;
        tmStart.tm_min = minute;
        return mktime(&tmStart);
    }
    bool CanDo(int64 tNow, const struct tm& ltm, int64& tStart, int64& tEnd) {
        if( _this_end != 0 ) {
            return false;
        }
        // _lasting == -1 表示是在_start ==> _end 期间内全天开放的类型, 所以不判定其他的时间
        if( _lasting == -1 ) {
            tStart = _start;
            tEnd = _end;
            return true;
        }
        bool bInTodayHourMinute = false;
        for( auto & hour : _hours ) {
            for( auto & minute : _minutes ) {
                // minute hour是改成今天以后按lasting算是否在时间段内
                int64 start = MakeTodayTime( ltm, hour, minute );
                int64 end = start + _lasting*60;
                if( start <= tNow && tNow <= end ) {
                    bInTodayHourMinute = true;
                    tStart = start;
                    tEnd = end;
                    break;
                }
            }
            if( bInTodayHourMinute ) {
                break;
            }
        }
        if( bInTodayHourMinute
            && Check(ECS_Day, ltm.tm_mday, _days)
            && Check(ECS_Week, ltm.tm_wday, _weeks)
            && Check(ECS_Month, ltm.tm_mon+1, _months)
            && Check(ECS_Year, ltm.tm_year+1900, _years) ) {
            return true;
        }
        return false;
    }
    bool Check(E_CronStar eFlag, int32 value, const set<int32>& setValue) {
        if( _flags & eFlag ) {
            return true;
        }
        return setValue.find(value) != setValue.end();
    }
};

class LxCrontab {
public:
    LxCrontab() {}
    ~LxCrontab() {}
public:
    void push(const tagCronTask& task) {
        auto it = m_mapTasks.find(task._id);
        if( it == m_mapTasks.end() ) {
            m_mapTasks[task._id] = task;
        }
        else {
            // 已有的任务,更新任务属性,但是保留_this_end,保证已开启的任务不会重复开启
            int64 endTime = it->second._this_end;
            it->second.Reset();
            it->second = task;
            it->second._this_end = endTime;
        }
    }
    void check(int64 tNow, std::function<void (int32, int64, int64)> func) {
        struct tm ltm;
        localtime_r(&tNow, &ltm);
        for( auto& it : m_mapTasks ) {
            // 已经开始的活动, 判断一下是否该结束了
            if( it.second._this_end != 0 ) {
                // 说明该活动已经开启,需要判定是否要结束
                if( it.second._this_end <= tNow ) {
                    // 结束了
                    it.second._this_end = 0;
                    LOGDEBUG("ACTIVITY [%d] end", it.second._id);
                    func(it.second._id, -1, -1);
                }
                continue;
            }
            if( tNow < it.second._start || tNow >= it.second._end ) {
                continue;
            }
            int64 start = 0;
            int64 end = 0;
            if( it.second.CanDo(tNow, ltm, start, end) ) {
                it.second._this_end = end;
                func(it.second._id, start, end);
                LOGDEBUG("ACTIVITY [%d] start", it.second._id);
            }
        }
    }
    void clear() {
        m_mapTasks.clear();
    }
private:
    map<int32, tagCronTask> m_mapTasks;
};
