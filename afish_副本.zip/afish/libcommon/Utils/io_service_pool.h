//
// io_service_pool.hpp
// ~~~~~~~~~~~~~~~~~~~
//
// Copyright (c) 2003-2012 Christopher M. Kohlhoff (chris at kohlhoff dot com)
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//

#ifndef _IO_SERVICE_POOL_H_
#define _IO_SERVICE_POOL_H_

#include <boost/beast/core.hpp>
#include <boost/beast/core/detail/stream_traits.hpp>
#include <boost/beast/websocket.hpp>
#include <boost/asio/dispatch.hpp>
#include <boost/asio/strand.hpp>
#include <boost/asio.hpp>
#include <boost/noncopyable.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/thread.hpp>
#include <vector>

/// A pool of io_context objects.
class io_service_pool
  : private boost::noncopyable
{
public:
	/// Construct the io_context pool.
	explicit io_service_pool(std::size_t pool_size);

	/// Run all io_context objects in the pool.
	void run();

	void join();

	/// Stop all io_context objects in the pool.
	void stop();

	boost::asio::io_context& get_io_service(int idx) { return *io_services_[idx%_max_size]; };
private:
	typedef boost::shared_ptr<boost::asio::io_context> io_context_ptr;
	typedef boost::shared_ptr<boost::asio::io_context::work> work_ptr;

	/// The pool of io_services.
	std::vector<io_context_ptr> io_services_;

	/// The work that keeps the io_services running.
	std::vector<work_ptr> work_;

	/// The next io_context to use for a connection.
	std::vector<boost::shared_ptr<boost::thread> > _threads;

	//lock, to ensure thread safe when get io service
	mutable boost::mutex m_mutex;

	int _max_size;
};

class Poolize : private boost::noncopyable
{
public:
	Poolize(int nPoolSize) : _pool(nPoolSize) {
	}
	virtual ~Poolize() {}

	boost::asio::io_context& get_io_service(int idx) { return _pool.get_io_service(idx); };

	// 启动线程 子类在执行万初始化之后再调用 Poolize::start()
	virtual void start() {
		_pool.run();
	}
	// 等待线程结束
	void wait() {
		_pool.join();
	}
protected:
	io_service_pool _pool;
};

#endif // _IO_SERVICE_POOL_H_
