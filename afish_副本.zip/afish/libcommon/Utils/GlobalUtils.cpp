#include "GlobalUtils.h"
#include "Utils/base64.h"
#include <dirent.h>

#include <boost/algorithm/string.hpp>
#include <boost/crc.hpp>
#include <boost/random.hpp>
#include <boost/random/random_device.hpp>
using namespace boost::algorithm;
#include <boost/exception/diagnostic_information.hpp>
#include <boost/system/system_error.hpp>

#include "ThreadLog/ThreadLog.h"

Roll GlobalUtils::_numbers;
void GlobalUtils::Init()
{
    for( int i = 0 ; i < 10 ; ++i ) {
        _numbers.push_value(100, i);
    }
    _numbers.set_extra(true, 1);
}

int inet_aton(const char * cp, struct in_addr * inp) {
	inp->s_addr = inet_addr(cp);
	return (inp->s_addr == INADDR_NONE) ? 0 : 1;
}

uint32 GlobalUtils::ConvertIpToInt(const string& strIp) {
	in_addr address;
	uint32 uIp = 0;
	if (inet_aton(strIp.c_str(), &address) != 0) {
		uIp = ntohl(address.s_addr);
	}
	return uIp;
}

//生成CRC32
uint32 GlobalUtils::GenerateCRC32(const void* data, size_t size) {
	boost::crc_32_type crc32;
	crc32.process_bytes(data, size);
	return crc32();
}

//字符串转hex
unsigned char GlobalUtils::ToHex(unsigned char x)
{
	return  x > 9 ? x + 55 : x + 48;
}

//hex转字符串
unsigned char GlobalUtils::FromHex(unsigned char x)
{
	unsigned char y = x;
	if (x >= 'A' && x <= 'Z') y = x - 'A' + 10;
	else if (x >= 'a' && x <= 'z') y = x - 'a' + 10;
	else if (x >= '0' && x <= '9') y = x - '0';
	else assert(0);
	return y;
}

//url encode
std::string GlobalUtils::UrlEncode(const std::string& str)
{
	std::string strTemp = "";
	size_t length = str.length();
	for (size_t i = 0; i < length; i++)
	{
		if (isalnum((unsigned char)str[i]) ||
			(str[i] == '-') ||
			(str[i] == '_') ||
			(str[i] == '.') ||
			(str[i] == '~'))
			strTemp += str[i];
		else if (str[i] == ' ')
			strTemp += "+";
		else {
			strTemp += '%';
			strTemp += ToHex((unsigned char)str[i] >> 4);
			strTemp += ToHex((unsigned char)str[i] % 16);
		}
	}
	return strTemp;
}

//获取范围内随机数,左右都是闭区间
int32 GlobalUtils::GetRandNumber(int32 iMin, int32 iMax) {
    if (iMin == iMax) {
        return iMin;
    }
    int32 mi = iMin;
    int32 ma = iMax;
    if( iMin > iMax ) {
        mi = iMax;
        ma = iMin;
    }
    static thread_local std::default_random_engine gen(std::random_device{}());
    std::uniform_int_distribution<int32> dist( mi, ma );
    return dist(gen);
}

//获取范围内随机数,左右都是闭区间
int32 GlobalUtils::GetRandNumber2(int32 iMin, int32 iMax) {
    if (iMin >= iMax) {
        return iMin;
    }
    static thread_local std::default_random_engine gen2(std::random_device{}());
    std::uniform_int_distribution<int32> dist( iMin, iMax );
    return dist(gen2);
}

int32 GlobalUtils::GetRandDigit(int32 iMin, int32 iMax, bool seed2) {
    // 先拿一个数字, 后续要保持位数不变
    int32 value = seed2?GetRandNumber2(iMin, iMax):GetRandNumber(iMin, iMax);
    Roll dice = _numbers;
    list<int32> lstDigit;
    int32 tmpValue = value;
    for( int i = 1 ; ; i *= 10 ) {
        if( value / i == 0 ) {
            break;
        }
        lstDigit.push_front(tmpValue%10);
        tmpValue /= 10;
    }
    int32 changedValue = 0;
    while( !lstDigit.empty() ) {
        int32 digit = lstDigit.front();
        if( dice.has_value(digit) ) {
            dice.remove_value(digit);
            changedValue += digit*pow(10, lstDigit.size()-1);
        }
        else {
            // 说明已经出现过了, 重新随一个
            changedValue += dice.roll()*pow(10, lstDigit.size()-1);
        }
        lstDigit.pop_front();
    }
    return changedValue;
}

//获取范围内随机数,左右都是闭区间
int64 GlobalUtils::GetRandLong(int64 iMin, int64 iMax) {
    if (iMin >= iMax) {
        return iMin;
    }
    static thread_local std::default_random_engine gen(std::random_device{}());
    std::uniform_int_distribution<int64> dist( iMin, iMax );
    return dist(gen);
}

int32 GlobalUtils::GetRandNumber(int32 stdev) {
    static thread_local std::default_random_engine generator(std::random_device{}());
    std::normal_distribution<double> distribution( 5000, stdev );
    while (true) {
        int32 number = distribution(generator);
        if (number >= 0 && number <= 10000)
            return number;
    }
    return GetRandNumber(0,10000);
}

int32 GlobalUtils::GetRandNumber(int iMin, int iMax, int32 stdev) {
    if( iMax == iMin ) {
        return iMin;
    }
    static thread_local std::default_random_engine generator(std::random_device{}());
    std::normal_distribution<double> distribution( (iMin+iMax)/2, stdev );
    while (true) {
        int32 number = distribution(generator);
        if (number >= iMin && number <= iMax)
            return number;
    }
    return GetRandNumber(iMin, iMax);
}

void GlobalUtils::GetNumArray(const string& str, const string& splitter, vector<int64>& lhs) {
    if( str.empty() ) {
        lhs.clear();
        return;
    }
    vector<string> vec;
    boost::split(vec, str, boost::is_any_of(splitter), boost::token_compress_off);
    for( size_t i=0; i < vec.size(); ++i ) {
        if( !vec[i].empty() ) {
            lhs.push_back(boost::lexical_cast<int64>(vec[i]));
        }
    }
}

void GlobalUtils::GetNumSet(const string& str, const string& splitter, set<int64>& lhs) {
    if( str.empty() ) {
        lhs.clear();
        return;
    }
    vector<string> vec;
    boost::split(vec, str, boost::is_any_of(splitter), boost::token_compress_off);
    for( size_t i=0; i < vec.size(); ++i ) {
        if( !vec[i].empty() ) {
            lhs.insert(boost::lexical_cast<int64>(vec[i]));
        }
    }
}

void GlobalUtils::GetStrArray(const string& str, const string& splitter, vector<string>& lhs) {
    if( str.empty() ) {
        lhs.clear();
        return;
    }
    vector<string> vec;
    boost::split(vec, str, boost::is_any_of(splitter), boost::token_compress_off);
    for( size_t i=0; i < vec.size(); ++i ) {
        if( !vec[i].empty() ) {
            lhs.push_back(vec[i]);
        }
    }
}

int32 GlobalUtils::GetLeftSecondsOfDay(int64 tmNow) {
    time_t t1 = tmNow;
    time_t t2 = t1 + 24*3600;
    struct tm lt2;
    localtime_r(&t2, &lt2);
    lt2.tm_hour = 0;
    lt2.tm_min = 0;
    lt2.tm_sec = 0;
    return mktime(&lt2) - t1;
}

bool GlobalUtils::IsMonday(int64 tmNow) {
    struct tm lt;
    localtime_r(&tmNow, &lt);
    return lt.tm_wday == 1;
}

bool GlobalUtils::IsInMondayGL5(time_t tmNow) {
    struct tm lt;
    localtime_r(&tmNow, &lt);
    if( lt.tm_wday == 1 && lt.tm_hour == 0 && lt.tm_min < 5 ) {
        return true;
    }
    else if( lt.tm_wday == 0 && lt.tm_hour == 23 && lt.tm_min >= 55 ) {
        return true;
    }
    return false;
}

bool GlobalUtils::LessThan0005(int64 tTime) {
    struct tm lt;
    localtime_r(&tTime, &lt);
    return lt.tm_hour == 0 && lt.tm_min < 5;
}

//根据string设置时间
//商品上架时间，格式为年-月-日-时-分-秒，例如：2020-06-07-05-30-00
int64 GlobalUtils::SetTimeToString(const string& strTime)
{
    vector<string> vecTime;
	boost::split(vecTime, strTime, boost::is_any_of("-"));
    if( vecTime.size() != 6 ) {
        return 0;
    }
    struct tm strTm;

    strTm.tm_year = boost::lexical_cast<int>(vecTime[0])-1900;
    strTm.tm_mon  = boost::lexical_cast<int>(vecTime[1])-1;
    strTm.tm_mday = boost::lexical_cast<int>(vecTime[2]);
    strTm.tm_hour = boost::lexical_cast<int>(vecTime[3]);
    strTm.tm_min  = boost::lexical_cast<int>(vecTime[4]);
    strTm.tm_sec  = boost::lexical_cast<int>(vecTime[5]);
    strTm.tm_isdst= -1;
    time_t strTT = mktime(&strTm);
    return strTT;
}

//根据小时设置时间
int64 GlobalUtils::SetTimeToHour(const string& hour)
{
    time_t nowTime = time(NULL);
    vector<string> vecHour;
    boost::split(vecHour, hour, boost::is_any_of("-"));
    if( vecHour.size() != 3 ) {
        return 0;
    }
    struct tm hTm;
    localtime_r(&nowTime, &hTm);
    hTm.tm_hour = boost::lexical_cast<int>(vecHour[0]);
    hTm.tm_min = boost::lexical_cast<int>(vecHour[1]);
    hTm.tm_sec = boost::lexical_cast<int>(vecHour[2]);
    time_t hourTime = mktime(&hTm);
    return hourTime;
}

//根据时间戳和小时设置时间
int64 GlobalUtils::SetTimeToHour(int64 iTime,const string& hour)
{
    time_t nowTime = iTime;
    vector<string> vecHour;
    boost::split(vecHour, hour, boost::is_any_of("-"));
    if( vecHour.size() != 3 ) {
        return 0;
    }
    struct tm hTm;
    localtime_r(&nowTime, &hTm);
    hTm.tm_hour = boost::lexical_cast<int>(vecHour[0]);
    hTm.tm_min = boost::lexical_cast<int>(vecHour[1]);
    hTm.tm_sec = boost::lexical_cast<int>(vecHour[2]);
    time_t hourTime = mktime(&hTm);
    return hourTime;
}

/*
    string _startTime;  //活动周期开始时间，格式为年-月-日-时-分-秒，例如：2020-06-07-05-30-00
	string _endTime;  //活动周期结束时间，格式为年-月-日-时-分-秒，例如：2020-06-07-05-30-01
	string _startHour;  //活动开始时间，格式为时-分-秒，例如07-30-00
	string _endHour;  //活动结束时间，格式为时-分-秒，例如07-30-00
*/

bool GlobalUtils::TimeInTheInterval(const string& startTime, const string& endTime, const string& startHour, const string& endHour)
{
    if ( TimeInTheInterval(startTime, endTime) )
    {
        int64 nStart = SetTimeToHour(startHour);
        int64 nEnd = SetTimeToHour(endHour);
        if( nStart == 0 || nEnd == 0 ) {
            LOGINFO("TimeInTheInterval format error[%s][%s]", startHour.data(), endHour.data());
            return false;
        }
        int64 nowTime = time(nullptr);
        return nowTime > nStart && nowTime < nEnd;
    }
    return false;
}

/*
    string _startTime;  //活动周期开始时间，格式为年-月-日-时-分-秒，例如：2020-06-07-05-30-00
	string _endTime;  //活动周期结束时间，格式为年-月-日-时-分-秒，例如：2020-06-07-05-30-01
*/
bool GlobalUtils::TimeInTheInterval(const string& startTime, const string& endTime)
{
    int64 startTT = SetTimeToString(startTime);
    if( startTT == 0 ) {
        LOGINFO("TimeInTheInterval startTime[%s] failed", startTime.c_str());
        return false;
    }
    int64 endTT = SetTimeToString(endTime);
    if( endTT == 0 ) {
        LOGINFO("TimeInTheInterval endTime[%s] failed", endTime.c_str());
        return false;
    }
    int64 nowTime = time(NULL);
    return nowTime > startTT && nowTime < endTT;
}

// yyyy-mm-dd hh:mm:ss 转换成 time_t
int64 GlobalUtils::MakeTime(const string& strTime)
{
    try {
        vector<string> vecTime;
        boost::split(vecTime, strTime, boost::is_any_of(" "));
        if( vecTime.size() != 2 ) {
            return 0;
        }
        vector<string> ymd;
        boost::split(ymd, vecTime[0], boost::is_any_of("-"));
        if( ymd.size() != 3 ) {
            return 0;
        }
        vector<string> hms;
        boost::split(hms, vecTime[1], boost::is_any_of(":"));
        if( hms.size() != 3 ) {
            return 0;
        }

        struct tm tt;
        tt.tm_year = boost::lexical_cast<int32>(ymd[0])-1900;
        tt.tm_mon  = boost::lexical_cast<int32>(ymd[1])-1;
        tt.tm_mday = boost::lexical_cast<int32>(ymd[2]);
        tt.tm_hour = boost::lexical_cast<int32>(hms[0]);
        tt.tm_min  = boost::lexical_cast<int32>(hms[1]);
        tt.tm_sec  = boost::lexical_cast<int32>(hms[2]);
        tt.tm_isdst= -1;
        return mktime(&tt);
    }
    catch(boost::bad_lexical_cast & e) {
        LOGERROR("invalid time format");
        return 0;
    }
}

int64 GlobalUtils::GetRandomMoney(int64 nTotalMoney, int64 nRemainMoney, int64 nMinimum, int32 nRemainCount) {
	if( nRemainCount <= 1 ) {
		return nRemainMoney;
	}

	int64 nMax = nRemainMoney / nRemainCount * 2;
	int64 nMoney = nMax * GetRandNumber(0,99) / 100;
	if( nMoney < nMinimum ) {
		nMoney = nMinimum;
	}
	return nMoney;
}

void GlobalUtils::GenerateGrabBonus(int64 iTotal, int32 nCount, int64 nMinimum, vector<string>& vecData) {
    int64 lMoney = 0;
    int64 lRemain = iTotal;
    while( lRemain >= 0 ) {
        lMoney = GetRandomMoney(iTotal, lRemain, nMinimum, nCount--);
		if( lMoney > 0 ) {
	        vecData.push_back(ToString(lMoney));
		}
        if( nCount < 0 )
            break;
        lRemain = lRemain - lMoney;
        if( lMoney <= 0 )
            break;
    }
}

string GlobalUtils::GetTimeByFormat(E_TimeFormat eFormat,int64 iTime) {
	struct tm tmTime;
    localtime_r(&iTime, &tmTime);
	ostringstream osTime;
	switch( eFormat ) {
	case ETF_YMDHMS:
		{
			char szTime[64] = {0};
			sprintf( szTime, "%d-%02d-%02d %02d:%02d:%02d", tmTime.tm_year+1900, tmTime.tm_mon+1, tmTime.tm_mday, tmTime.tm_hour, tmTime.tm_min, tmTime.tm_sec);
			osTime << szTime;
		}
		break;
	case ETF_YMD:
		{
			char szTime[64] = {0};
			sprintf( szTime, "%d-%02d-%02d", tmTime.tm_year+1900, tmTime.tm_mon+1, tmTime.tm_mday);
			osTime << szTime;
		}
		break;
    case ETF_LOG:
		{
			char szTime[64] = {0};
			sprintf( szTime, "%d/%02d/%02d %02d:%02d:%02d", tmTime.tm_year+1900, tmTime.tm_mon+1, tmTime.tm_mday, tmTime.tm_hour, tmTime.tm_min, tmTime.tm_sec);
			osTime << szTime;
		}
        break;
	case ETF_YMD_SHORT:
		{
			char szTime[64] = {0};
			sprintf( szTime, "%02d%02d%02d", tmTime.tm_year+1900, tmTime.tm_mon+1, tmTime.tm_mday);
			osTime << szTime;
		}
		break;
	}
	return osTime.str();
}

static const int g_iNickNameLimitWidth = 12;
string GlobalUtils::GetLimitNickName(const string& sNickName) {
	return GetLimitWidthString(sNickName, g_iNickNameLimitWidth);
}

string GlobalUtils::GetLimitNickName(const string& sNickName,int iLimitWidth) {
	return GetLimitWidthString(sNickName, iLimitWidth);
}

string GlobalUtils::GetLimitWidthString(const string& sText, int iLimitWidth) {
	const char* p = sText.c_str();
	int iLength = sText.size();
	int i = 0;
	ostringstream os;
	int iTotalWidth = 0;
	int iCharWidth = 0;
	int iByteNumber = 0;
	while (i < iLength) {
		char b = *(p + i);
		if (b > 0) {
			iCharWidth = 1;
			iByteNumber = 1;
		} else if (((b ^ (char)0xc0) >> 4) == 0) {
			iCharWidth = 1;
			iByteNumber = 2;
		} else if (((b ^ (char)0xe0) >> 4) == 0) {
			iCharWidth = 2;
			iByteNumber = 3;
		} else if (((b ^ (char)0xf0) >> 4) == 0) {
			i += 4;
			continue;
		} else {
			break;
		}

		if (iTotalWidth + iCharWidth <= iLimitWidth) {
			for (int j = 0; j < iByteNumber && i < iLength; j++) {
				os << p[i++];
			}

			iTotalWidth += iCharWidth;
		} else {
			break;
		}
	}
	return os.str();
}

// 检测进程是否在运行
bool GlobalUtils::process_is_running()
{
    long pid;
    char full_name[1024] = {0};
    char proc_name[1024] = {0};
    pid = getpid();
    sprintf(full_name, "/proc/%ld/cmdline", pid);
    if (access(full_name, F_OK) == 0)
    {
        int fd = open (full_name, O_RDONLY);
        if (fd == -1)
            return false;
        read (fd, proc_name, 1024);
        close (fd);
    }
    else
        return false;

    char self_proc_name[512] = {0};
    char * p = proc_name;
    int pt = 0;
    while (*p != ' ' && *p != '\0')
    {
        self_proc_name[pt] = *p;
        p++;
        pt++;
    }
    string self_final_name = basename(self_proc_name);
    DIR *dir;
    struct dirent * result;
    dir = opendir ("/proc");
    while ((result = readdir (dir)) != NULL)
    {
        if (! strcmp(result->d_name, ".") || ! strcmp (result->d_name, "..") || ! strcmp (result->d_name, "thread-self")
                || ! strcmp (result->d_name, "self") || atol (result->d_name) == pid)
            continue;
        memset(full_name, 0, sizeof(full_name));
        memset(proc_name, 0, sizeof(proc_name));
        sprintf(full_name, "/proc/%s/cmdline", result->d_name);
        if (access(full_name, F_OK) == 0)
        {
            int fd = open (full_name, O_RDONLY);
            if (fd == -1)
                continue;
            read (fd, proc_name, 1024);
            close (fd);
            char *q = proc_name;
            pt = 0;
            memset(self_proc_name, 0, sizeof (self_proc_name));
            while (*q != ' ' && *q != '\0')
            {
                self_proc_name[pt] = *q;
                q++;
                pt++;
            }
            string other_final_name = basename(self_proc_name);
            if (self_final_name == other_final_name)
            {
                return true;
            }
        }
    }
    return false;
}

uint64 GlobalUtils::StringHash(const string& str) {
	uint64 uHashValue = 0;
	for (size_t i = 0; i < str.size(); i++) {
		uHashValue = uHashValue * 131 + str.c_str()[i];
	}
	return uHashValue;
}

string GlobalUtils::GetWholeFileString(const string& file) {
    FILE* fp = fopen(file.c_str(), "r");
    fseek(fp, 0, SEEK_END);
    size_t filesize = (size_t)ftell(fp);
    fseek(fp, 0, SEEK_SET);
    char* buffer = (char*)malloc(filesize + 1);
    size_t readLength = fread(buffer, 1, filesize, fp);
    buffer[readLength] = '\0';
    fclose(fp);
    string strData = buffer;
    delete buffer;
    return strData;
}

int32 GlobalUtils::VersionCompare(const string& ver1, const string& ver2) {
	// ver1与ver2是 xx.xx.xxx 的版本号模式
	// 相同返回0
	// ver1 > ver2 返回1
	// ver1 < ver2 返回-1

    vector<string> vec1;
	boost::split(vec1, ver1, boost::is_any_of("."));

    vector<string> vec2;
	boost::split(vec2, ver2, boost::is_any_of("."));

    int32 loop = (int32)min(vec1.size(), vec2.size());
    for( int32 i = 0; i < loop ; ++i ) {
        if( atoi(vec1[i].data()) != atoi(vec2[i].data()) ) {
            return atoi(vec1[i].data()) > atoi(vec2[i].data()) ? 1 : -1;
        }
    }
    return 0;
}

string GlobalUtils::GetStarName(const string& strName) {
    return strName;
}
