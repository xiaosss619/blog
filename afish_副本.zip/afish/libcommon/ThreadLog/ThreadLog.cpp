#include "ThreadLog.h"
#include <stdarg.h>
#include <boost/algorithm/string.hpp>
#include <iostream>
#include <string>
#include <sstream>
#include <iomanip>
using namespace std;

typedef boost::shared_lock<boost::shared_mutex> readLock;
typedef boost::unique_lock<boost::shared_mutex> writeLock;

ThreadLog* ThreadLog::static_logger_ = nullptr;

ThreadLog::ThreadLog(int level):
	default_level_(level),
    work_(new boost::asio::io_service::work(work_io_service_)),
    work_thread_(new boost::thread(boost::bind(&boost::asio::io_service::run, &work_io_service_))),
	m_strLogFileName("")
{
}

ThreadLog::~ThreadLog()
{
    work_.reset();
    if (work_thread_)
    {
        work_thread_->join();
    }
    if( ofstream_.is_open() ) {
        ofstream_.close();
    }
}

#define BUFFER_SIZE 8192
void ThreadLog::log(EnumLogLevel level,const char * pszFormat, ...) {
	{
		readLock lock(_log_level_mutex);
		if( level < default_level_ ) {
			return;
		}
	}
	if (strlen(pszFormat) > BUFFER_SIZE - 100) {
		return;
	}
	char buffer[BUFFER_SIZE] = {0};
	va_list ap;
	va_start(ap, pszFormat);
	vsnprintf(buffer, sizeof(buffer), pszFormat, ap);
	va_end(ap);
    string strContent = buffer;
    boost::erase_all(strContent, "\n");
	work_io_service_.post(boost::bind(&ThreadLog::log_impl, this, strContent));
}

void ThreadLog::set_level(int level) {
	writeLock lock(_log_level_mutex);
	default_level_ = level;
}

void ThreadLog::log_impl(const std::string& content)
{
    time_t tNow = time(nullptr);
    struct tm lt;
    localtime_r(&tNow, &lt);
	char szTime[32] = {0};
	sprintf(szTime, "[%02d:%02d:%02d]", lt.tm_hour, lt.tm_min, lt.tm_sec);

	string strLogFileName = make_log_file_name(lt);
    if( m_strLogFileName != strLogFileName ) {
        if( ofstream_.is_open() ) {
            ofstream_.close();
        }
        m_strLogFileName = strLogFileName;
        ofstream_.open(m_strLogFileName, ios::app);
    }
	ofstream_ << szTime << content << std::endl;
}

string ThreadLog::make_log_file_name(const tm& lt)
{
    ostringstream osDir;
    osDir << "./log";
    mkdir(osDir.str().c_str(),0775);

    // ./log/20200801
    char szYearMonDay[32] = {0};
    sprintf(szYearMonDay, "%04d%02d%02d", lt.tm_year + 1900, lt.tm_mon+1, lt.tm_mday);
    osDir << "/" << szYearMonDay;
    mkdir(osDir.str().c_str(),0775);

    // ./log/20200801/14_20200801.log
    char szYearMonDayHourFile[32] = {0};
    sprintf(szYearMonDayHourFile, "%02d.log", lt.tm_hour);
    osDir << "/" << szYearMonDayHourFile;
    return osDir.str();
}
