#ifndef _THREAD_LOG_H_
#define _THREAD_LOG_H_

#include <boost/asio.hpp>
#include <boost/thread/thread.hpp>
#include <boost/noncopyable.hpp>
#include <boost/scoped_ptr.hpp>
#include <boost/asio/ip/tcp.hpp>
#include <boost/lexical_cast.hpp>
#include <map>
#include <string>
#include <fstream>
#include <time.h>
#include <string.h>
using namespace std;

#define FILENAME(x) (strrchr(x,'/')?strrchr(x,'/')+1:x)

#define INIT_LOG(lv) ThreadLog::get_instance(lv)
#define SET_LOG_LEVEL(lv) ThreadLog::get_instance(lv)->set_level(lv)
#define LOGDEBUG(format, ...) ThreadLog::get_instance()->log(LOG_DEBUG, "[DEBUG][%s:%d] " format, FILENAME(__FILE__), __LINE__, ##__VA_ARGS__)
#define LOGINFO(format, ...) ThreadLog::get_instance()->log(LOG_INFO, "[INFO][%s:%d] " format, FILENAME(__FILE__), __LINE__, ##__VA_ARGS__)
#define LOGERROR(format, ...) ThreadLog::get_instance()->log(LOG_ERROR, "[ERROR][%s:%d] " format, FILENAME(__FILE__), __LINE__, ##__VA_ARGS__)
#define LOGFATAL(format, ...) ThreadLog::get_instance()->log(LOG_FATAL, "[FATAL][%s:%d] " format, FILENAME(__FILE__), __LINE__, ##__VA_ARGS__)

enum EnumLogLevel {
	LOG_DEBUG = 0,
    LOG_INFO = 1,
    LOG_ERROR = 2,
    LOG_FATAL = 3,
};

class ThreadLog : private boost::noncopyable
{
public:
	ThreadLog(int level=LOG_INFO);
    virtual ~ThreadLog();
    static ThreadLog* get_instance(int level=LOG_INFO) {
        if (static_logger_ == nullptr)
        {
            static_logger_ = new ThreadLog(level);
        }
        return static_logger_;
    }
	void set_level(int level);
	void log(EnumLogLevel level,const char * pszFormat, ...);

    boost::asio::io_service& get_io_service() {
		return work_io_service_;
	}
protected:
    void log_impl(const std::string& content);
    string make_log_file_name(const tm& lt);
protected:
    int default_level_;
    boost::asio::io_service work_io_service_;
    boost::scoped_ptr<boost::asio::io_service::work> work_;
    boost::scoped_ptr<boost::thread> work_thread_;

    static ThreadLog* static_logger_;
	boost::shared_mutex _log_level_mutex;
    string m_strLogFileName;
    std::ofstream ofstream_;
};

#endif // LOGGER_H
