#pragma once

#include "TrieTreeNode.h"
#include <vector>
#include <set>

class FilterWordHelper
{
public:
	FilterWordHelper(void);
	~FilterWordHelper(void);

	bool IsWordContainsFilterWords(const std::string& strWord);
	std::string ToValidWord(const std::string& strWord);
	int GetWordWidth(const std::string& strWord);

	void InsertFilterWord(const std::string& strFilterWord);
protected:
	size_t GetWordLength(char firstByte);
	void SplitWordIntoCharactor(const std::string& strWord, std::vector<std::string>& vecCharactor);

	std::string& ReplaceAll(std::string& str, const std::string& old_value, const std::string& new_value);
protected:
	TrieTreeNode* m_pTreeRoot;
};
