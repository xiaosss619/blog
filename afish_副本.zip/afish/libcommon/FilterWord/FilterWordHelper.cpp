﻿#include "FilterWordHelper.h"
#include <stdio.h>
#include <string.h>

#include <boost/date_time/posix_time/posix_time.hpp>
using namespace boost::posix_time;

//#include <boost/random/random_device.hpp>
//#include "boost/random.hpp"
//#include "boost/generator_iterator.hpp"

#include "ThreadLog/ThreadLog.h"

using namespace std;

//#define OLD_LOGIC

//g++ -o filterword *.cpp -O2 -lboost_random

FilterWordHelper::FilterWordHelper(void)
{
	m_pTreeRoot = new TrieTreeNode();
}

FilterWordHelper::~FilterWordHelper(void)
{
}

bool FilterWordHelper::IsWordContainsFilterWords(const std::string& strWord) {
	//按照utf-8编码格式,寻找每一个独立的字符
	vector<string> vecCharactor;
	SplitWordIntoCharactor(strWord, vecCharactor);
	//printf("char size[%lu]\n", vecCharactor.size());

	//对每个字符,寻找从它开始的序列是不是能找到一个屏蔽词
	for (size_t i = 0; i < vecCharactor.size(); i++) {
		//挨个往后找节点,一直到NULL(说明不符合),或者是叶子节点(说明这是一个完整的词)
		TrieTreeNode* pNode = m_pTreeRoot;
		for (size_t j = i; j < vecCharactor.size(); j++) {
			string strLower = vecCharactor[j];
			boost::to_lower(strLower);
			pNode = pNode->FindChild(strLower);
			if (pNode != nullptr) {
				//printf("find [%s]\n", vecCharactor[j].c_str());
				if (pNode->FindChild(g_strEndChar) != nullptr) {
					return true;
				}
			} else {
				break;
			}
		}
	}
	return false;
}

string FilterWordHelper::ToValidWord(const std::string& strWord) {
	//LOGDEBUG("%s", strWord.c_str());
	//按照utf-8编码格式,寻找每一个独立的字符
	vector<string> vecCharactor;
	SplitWordIntoCharactor(strWord, vecCharactor);
	//printf("char size[%lu]\n", vecCharactor.size());
	//LOGDEBUG("size %lu", vecCharactor.size());

	string strResult = "";
	//对每个字符,寻找从它开始的序列是不是能找到一个屏蔽词
	for (size_t i = 0; i < vecCharactor.size(); i++) {
		//挨个往后找节点,一直到NULL(说明不符合),或者是叶子节点(说明这是一个完整的词)
		bool bMatch = false;
		//LOGDEBUG("begin index[%lu], size[%lu]", i, vecCharactor.size());
		TrieTreeNode* pNode = m_pTreeRoot;
		for (size_t j = i; j < vecCharactor.size(); j++) {
			string strLower = vecCharactor[j];
			boost::to_lower(strLower);
			pNode = pNode->FindChild(strLower);
			if (pNode != nullptr) {
				//LOGDEBUG("find [%s]", strLower.c_str());
				if (pNode->FindChild(g_strEndChar) != nullptr) {
					bMatch = true;
					i = j;
					//LOGDEBUG("match, update begin index to[%lu]", i);
					//break;
				}
			} else {
				break;
			}
		}

		if (bMatch) {
			strResult += "***";
		} else {
			strResult += vecCharactor[i];
		}
	}

	return strResult;
}

int FilterWordHelper::GetWordWidth(const std::string& strWord) {
	const char* p = strWord.c_str();
	int iLength = strWord.size();
	int i = 0;
	int iTotalWidth = 0;
	int iCharWidth = 0;
	while (i < iLength) {
		char b = *(p + i);
		if (b > 0) {
			iCharWidth = 1;
			i += 1;
		} else if (((b ^ (char)0xc0) >> 4) == 0) {
			iCharWidth = 1;
			i += 2;
		} else if (((b ^ (char)0xe0) >> 4) == 0) {
			iCharWidth = 2;
			i += 3;
		} else if (((b ^ (char)0xf0) >> 4) == 0) {
			iCharWidth = 2;
			i += 4;
		} else {
			break;
		}

		iTotalWidth += iCharWidth;
	}

	return iTotalWidth;
}

size_t FilterWordHelper::GetWordLength(char firstByte) {
	if (firstByte > 0) {
		return 1;
	} else if (((firstByte ^ (char)0xc0) >> 4) == 0) {
		return 2;
	} else if (((firstByte ^ (char)0xe0) >> 4) == 0) {
		return 3;
	} else if (((firstByte ^ (char)0xf0) >> 4) == 0) {
		return 4;
	} else if (((firstByte ^ (char)0xf8) >> 4) == 0) {
		return 5;
	} else if (((firstByte ^ (char)0xfc) >> 4) == 0) {
		return 6;
	}

	return 0;
}

void FilterWordHelper::InsertFilterWord(const std::string& strFilterWord) {
	vector<string> vecCharactor;
	SplitWordIntoCharactor(strFilterWord, vecCharactor);
	TrieTreeNode* pNode = m_pTreeRoot;
	for (size_t i = 0; i < vecCharactor.size(); i++) {
		pNode = pNode->InsertChild(vecCharactor[i]);
	}
	pNode->InsertChild(g_strEndChar);
}

void FilterWordHelper::SplitWordIntoCharactor(const std::string& strWord, std::vector<std::string>& vecCharactor) {
	for (size_t i = 0; i < strWord.size(); ) {
		char firstByte = strWord.c_str()[i];
		size_t wordLength = GetWordLength(firstByte);
		//printf("%x,%lu\n", firstByte, wordLength);
		if (wordLength == 0) {
			return;
		}

		string strCharactor = "";
		for (size_t offset = 0; offset < wordLength; offset++) {
			strCharactor += strWord.c_str()[i + offset];
		}
		vecCharactor.push_back(strCharactor);
		i += wordLength;
	}
}

string& FilterWordHelper::ReplaceAll(string& str, const string& old_value, const string& new_value)
{
	while(true)
	{
		string::size_type pos(0);
		if( (pos = str.find(old_value)) != string::npos)
		{
			str.replace(pos, old_value.length(), new_value);
		}
		else
		{
			break;
		}
	}

	return str;
}
