#ifndef TRIE_TREE_NODE_H
#define TRIE_TREE_NODE_H

#include <string>
#include <map>

static const std::string g_strEndChar = "\n";

class TrieTreeNode
{
public:
	TrieTreeNode(void);
	~TrieTreeNode(void);
	
	TrieTreeNode* FindChild(const std::string& strCharactor);
	TrieTreeNode* InsertChild(const std::string& strCharactor);

protected:
	std::map<std::string, TrieTreeNode*> m_mapChildren; 
};

#endif