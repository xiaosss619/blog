#include "TrieTreeNode.h"

TrieTreeNode::TrieTreeNode(void)
{
}

TrieTreeNode::~TrieTreeNode(void)
{
	std::map<std::string, TrieTreeNode*>::iterator iter = m_mapChildren.begin();
	for (; iter != m_mapChildren.end(); iter++) {
		delete iter->second;
		iter->second= nullptr;
	}

	m_mapChildren.clear();
}

TrieTreeNode* TrieTreeNode::FindChild(const std::string& strCharactor) {
	std::map<std::string, TrieTreeNode*>::const_iterator iter = m_mapChildren.find(strCharactor);
	if (iter != m_mapChildren.end()) {
		return iter->second;
	}

	return nullptr;
}

TrieTreeNode* TrieTreeNode::InsertChild(const std::string& strCharactor) {
	std::map<std::string, TrieTreeNode*>::const_iterator iter = m_mapChildren.find(strCharactor);
	if (iter != m_mapChildren.end()) {
		return iter->second;
	}

	TrieTreeNode* pChild = new TrieTreeNode();
	m_mapChildren[strCharactor] = pChild;
	return pChild;
}