#pragma once

#include "RedisConnectionPool.h"
#include <google/protobuf/message.h>
#include "RedisConnection.h"
#include <map>

enum EnumRedisServerType
{
	enumRedisServerTypeData = 1,
};

class RedisConnectionIdGetter {
public:
	RedisConnectionIdGetter(int id);
	~RedisConnectionIdGetter();

	RedisConnection* GetConnection() const;
protected:
	int m_id;
	RedisConnection* m_pConnection;
};

class RedisManager : protected boost::noncopyable
{
	friend class RedisConnectionIdGetter;

public:
	RedisManager(void);
	virtual ~RedisManager(void);

	void Init(const string& conf);

	static RedisManager* GetInstance();
protected:
	RedisConnection* GetConnectionById(int id);
	void ReturnConnectionById(int id, RedisConnection* pConnection);


protected:
	static RedisManager* m_pInstance;
	std::map<int, RedisConnectionPool*> m_mapIdConnectionPool;
};
