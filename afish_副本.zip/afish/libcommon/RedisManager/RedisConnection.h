#pragma once

#include <google/protobuf/stubs/common.h>

#include "hiredis/hiredis.h"
#include "r3c/r3c.h"
#include <mutex>
#include <functional>
#include <boost/lexical_cast.hpp>
#include "ThreadLog/ThreadLog.h"

class RedisConnection
{
public:
	RedisConnection(const std::string& sHostName, const std::string& sPassword);
	virtual ~RedisConnection(void);

	//virtual void ping();
	template<class T>
	bool get(const std::string& strKey, T& value) {
		std::unique_lock<std::mutex> lock(m_mutexRedisClient);
		try {
			std::string strValue;
			bool bResult = rc.get(strKey, &strValue);
			if (bResult) {
				value = boost::lexical_cast<T>(strValue);
				return true;
			}
		}
		catch (boost::bad_lexical_cast & e) {
			LOGINFO("redis lexical cast exception[%s], get[%s]", e.what(), strKey.c_str());
		}
		catch (std::exception& e) {
			LOGINFO("redis exception[%s], get[%s]", e.what(), strKey.c_str());
		}

		return false;
	}

	template<class T>
	bool set(const std::string& strKey, const T& value) {
		std::unique_lock<std::mutex> lock(m_mutexRedisClient);
		std::string strValue;
		try {
			strValue = boost::lexical_cast<std::string>(value);
			rc.set(strKey, strValue);
			return true;
		}
		catch (boost::bad_lexical_cast & e) {
			LOGINFO("redis lexical cast exception[%s], set[%s][%s]", e.what(), strKey.c_str(), strValue.c_str());
		}
		catch (std::exception& e) {
			LOGINFO("redis exception[%s], set[%s][%s]", e.what(), strKey.c_str(), strValue.c_str());
		}

		return false;
	}

	template<class T>
	bool setex(const std::string& strKey, const T& value, uint32_t expireSeconds) {
		std::unique_lock<std::mutex> lock(m_mutexRedisClient);
		std::string strValue;
		try {
			strValue = boost::lexical_cast<std::string>(value);
			rc.setex(strKey, strValue, expireSeconds);
			return true;
		}
		catch (boost::bad_lexical_cast & e) {
			LOGINFO("redis lexical cast exception[%s], set[%s][%s]", e.what(), strKey.c_str(), strValue.c_str());
		}
		catch (std::exception& e) {
			LOGINFO("redis exception[%s], set[%s][%s]", e.what(), strKey.c_str(), strValue.c_str());
		}

		return false;
	}

	int mget(const std::vector<std::string>& keys, std::vector<std::string>& values) {
		std::unique_lock<std::mutex> lock(m_mutexRedisClient);
		try {
			return rc.mget(keys, &values);
		}
		catch (std::exception& e) {
			LOGINFO("redis exception[%s], mget", e.what());
			return 0;
		}
	}

	virtual bool del(const std::string& sKey);
	virtual bool expire(const std::string& sKey, int iSeconds);
	virtual bool exists(const std::string& strKey);

	// incrby
	long incrby(const std::string& strName, long iIncreaseNum) {
		std::unique_lock<std::mutex> lock(m_mutexRedisClient);
		try {
			return rc.incrby(strName, iIncreaseNum);
		}
		catch (std::exception& e) {
			LOGINFO("redis exception[%s], incrby[%s][%ld]", e.what(), strName.c_str(), iIncreaseNum);
		}
		return 0;
	}
	//> hset ok
	//> hincrby ok
	template<class T1, class T2>
	bool hset(const std::string& strHashName, const T1& key, const T2& value) {
		std::unique_lock<std::mutex> lock(m_mutexRedisClient);
		std::string strKey;
		std::string strValue;
		try {
			strKey = boost::lexical_cast<std::string>(key);
			strValue = boost::lexical_cast<std::string>(value);
			return rc.hset(strHashName, strKey, strValue);
		}
		catch (boost::bad_lexical_cast & e) {
			LOGINFO("redis lexical cast exception[%s], hset[%s][%s][%s]", e.what(), strHashName.c_str(), strKey.c_str(), strValue.c_str());
		}
		catch (std::exception& e) {
			LOGINFO("redis exception[%s], hset[%s][%s][%s]", e.what(), strHashName.c_str(), strKey.c_str(), strValue.c_str());
		}

		return false;
	}

	template<class T1, class T2>
	int64_t hincrby(const std::string& strHashName, const T1& key, const T2& value) {
		std::unique_lock<std::mutex> lock(m_mutexRedisClient);
		std::string strKey;
		google::protobuf::int64 iValue = 0;
		try {
			strKey = boost::lexical_cast<std::string>(key);
			iValue = boost::lexical_cast<google::protobuf::int64>(value);
			return rc.hincrby(strHashName, strKey, iValue);
		}
		catch (boost::bad_lexical_cast & e) {
			LOGINFO("redis lexical cast exception[%s], hincrby[%s][%s][%ld]", e.what(), strHashName.c_str(), strKey.c_str(), iValue);
		}
		catch (std::exception& e) {
			LOGINFO("redis exception[%s], hincrby[%s][%s][%ld]", e.what(), strHashName.c_str(), strKey.c_str(), iValue);
		}

		return false;
	}

	template<class T1, class T2>
	bool hget(const std::string& strHashName, const T1& key, T2& value) {
		std::unique_lock<std::mutex> lock(m_mutexRedisClient);
		std::string strKey;
		try {
			std::string strValue;
			strKey = boost::lexical_cast<std::string>(key);
			bool bResult = rc.hget(strHashName, strKey, &strValue);
			if (bResult) {
				value = boost::lexical_cast<T2>(strValue);
				return true;
			}
		}
		catch (boost::bad_lexical_cast & e) {
			LOGINFO("redis lexical cast exception[%s], hget[%s][%s]", e.what(), strHashName.c_str(), strKey.c_str());
		}
		catch (std::exception& e) {
			LOGINFO("redis exception[%s], hget[%s][%s]", e.what(), strHashName.c_str(), strKey.c_str());
		}
		return false;
	}

	template<class T1, class T2>
	bool hgetall(const std::string& strHashName, std::map<T1, T2>& mapResult) {
		std::unique_lock<std::mutex> lock(m_mutexRedisClient);
		std::map<std::string, std::string > mapTempResult;
		try {
			rc.hgetall(strHashName, &mapTempResult);
			for (auto& value : mapTempResult) {
				auto resultKey = boost::lexical_cast<T1>(value.first);
				auto resultValue = boost::lexical_cast<T2>(value.second);
				mapResult[resultKey] = resultValue;
			}
			return true;
		}
		catch (boost::bad_lexical_cast & e) {
			LOGINFO("redis lexical cast exception[%s], hgetall[%s]", e.what(), strHashName.c_str());
		}
		catch (std::exception& e) {
			LOGINFO("redis exception[%s], hgetall[%s]", e.what(), strHashName.c_str());
		}
		return false;
	}

	template<class T1, class T2>
	bool hgetall(const std::string& strHashName, std::vector<std::pair<T1, T2> >& vecResult) {
		std::unique_lock<std::mutex> lock(m_mutexRedisClient);
		std::map<std::string, std::string > mapResult;
		try {
			rc.hgetall(strHashName, &mapResult);
			for (auto& value : mapResult) {
				auto resultKey = boost::lexical_cast<T1>(value.first);
				auto resultValue = boost::lexical_cast<T2>(value.second);
				vecResult.push_back(std::pair<T1, T2>(resultKey, resultValue));
			}
			return true;
		}
		catch (boost::bad_lexical_cast & e) {
			LOGINFO("redis lexical cast exception[%s], hgetall[%s]", e.what(), strHashName.c_str());
		}
		catch (std::exception& e) {
			LOGINFO("redis exception[%s], hgetall[%s]", e.what(), strHashName.c_str());
		}
		return false;
	}

	//>hmset ok
	bool hmget(const std::string& strHashName, const std::vector<std::string>& vecKey, std::map<std::string, std::string>& mapData) {
		std::unique_lock<std::mutex> lock(m_mutexRedisClient);
		try {
			return rc.hmget(strHashName, vecKey, &mapData);
		}
		catch (boost::bad_lexical_cast & e) {
			LOGINFO("redis lexical cast exception[%s], hmset[%s]", e.what(), strHashName.c_str());
		}
		catch (std::exception& e) {
			LOGINFO("redis exception[%s], hmset[%s]", e.what(), strHashName.c_str());
		}
		return false;
	}

	//>hmset ok
	template<class T1, class T2>
	bool hmset(const std::string& strHashName, const std::map<T1, T2>& mapParam) {
		std::unique_lock<std::mutex> lock(m_mutexRedisClient);
		std::map<std::string, std::string > mapTempParam;
		try {
			for (auto& param : mapParam) {
				mapTempParam[boost::lexical_cast<std::string>(param.first)] = boost::lexical_cast<std::string>(param.second);
			}

			rc.hmset(strHashName, mapTempParam);
			return true;
		}
		catch (boost::bad_lexical_cast & e) {
			LOGINFO("redis lexical cast exception[%s], hmset[%s]", e.what(), strHashName.c_str());
		}
		catch (std::exception& e) {
			LOGINFO("redis exception[%s], hmset[%s]", e.what(), strHashName.c_str());
		}
		return false;
	}
	int hlen(const std::string& strHashName) {
		try {
			return rc.hlen(strHashName);
		}
		catch (boost::bad_lexical_cast & e) {
			LOGINFO("redis lexical cast exception[%s], hmset[%s]", e.what(), strHashName.c_str());
		}
		catch (std::exception& e) {
			LOGINFO("redis exception[%s], hmset[%s]", e.what(), strHashName.c_str());
		}
		return 0;
	}
	virtual bool hmset(const std::string& sHashName, const std::vector<std::string>& vParam);
	//>hdel ok
	virtual bool hdel(const std::string& sHashName, const std::string& sKey);
	virtual bool hdel(const std::string& sHashName, const std::vector<std::string>& vKey);
	//>hexists ok
	virtual bool hexists(const std::string& sHashName, const std::string& sKey);

	virtual bool zcard(const std::string& sSetName, google::protobuf::int64& iResult);

	template<class T1>
	bool zincrby(const std::string& strSetName, const T1& key, google::protobuf::int64 iValue) {
		std::unique_lock<std::mutex> lock(m_mutexRedisClient);
		std::string strKey;
		try {
			strKey = boost::lexical_cast<std::string>(key);
			return rc.zincrby(strSetName, strKey, iValue);
		}
		catch (boost::bad_lexical_cast & e) {
			LOGERROR("lexical failed[%s][%s][%ld]", strSetName.c_str(), strKey.c_str(), iValue);
		}
		catch (std::exception& e) {
			LOGERROR("redis failed[%s][%s][%ld]", strSetName.c_str(), strKey.c_str(), iValue);
		}

		return false;
	}

	template<class T>
	google::protobuf::int64 zscore(const std::string& strSetName, const T& key) {
		std::unique_lock<std::mutex> lock(m_mutexRedisClient);
		std::string strKey;
		try {
			strKey = boost::lexical_cast<std::string>(key);
			return rc.zscore(strSetName, strKey);
		}
		catch (boost::bad_lexical_cast & e) {
			LOGINFO("redis lexical cast exception[%s], zscore[%s][%s]", e.what(), strSetName.c_str(), strKey.c_str());
		}
		catch (std::exception& e) {
			LOGINFO("redis exception[%s], zscore[%s][%s]", e.what(), strSetName.c_str(), strKey.c_str());
		}
		return -1;
	}

	template<class T1, class T2>
	bool zrangebyscore(const std::string& strSetName, T1 begin, T1 end, std::vector<T2>& vecResult) {
		std::unique_lock<std::mutex> lock(m_mutexRedisClient);
		std::vector<std::pair<std::string, google::protobuf::int64 > > values;
		google::protobuf::int64 iBegin = 0;
		google::protobuf::int64 iEnd = 0;
		try {
			iBegin = boost::lexical_cast<google::protobuf::int64>(begin);
			iEnd = boost::lexical_cast<google::protobuf::int64>(end);
			rc.zrangebyscore(strSetName, iBegin, iEnd, false, &values);
			for (auto& value : values) {
				auto resultValue = boost::lexical_cast<T2>(value.first);
				vecResult.push_back(resultValue);
			}

			return true;
		}
		catch (boost::bad_lexical_cast & e) {
			LOGINFO("redis lexical cast exception[%s], zrangebyscore[%s][%ld][%ld]", e.what(), strSetName.c_str(), iBegin, iEnd);
		}
		catch (std::exception& e) {
			LOGINFO("redis exception[%s], zrangebyscore[%s][%ld][%ld]", e.what(), strSetName.c_str(), iBegin, iEnd);
		}

		return false;
	}

	template<class T1, class T2, class T3>
	bool zrangebyscore(const std::string& strSetName, T3 begin, T3 end, std::vector<std::pair<T1, T2> >& vecResult) {
		std::unique_lock<std::mutex> lock(m_mutexRedisClient);
		std::vector<std::pair<std::string, google::protobuf::int64 > > values;
		google::protobuf::int64 iBegin = 0;
		google::protobuf::int64 iEnd = 0;
		try {
			iBegin = boost::lexical_cast<google::protobuf::int64>(begin);
			iEnd = boost::lexical_cast<google::protobuf::int64>(end);
			rc.zrangebyscore(strSetName, iBegin, iEnd, true, &values);
			for (auto& value : values) {
				auto resultKey = boost::lexical_cast<T1>(value.first);
				auto resultScore = boost::lexical_cast<T2>(value.second);
				vecResult.push_back(std::pair<T1, T2>(resultKey, resultScore));
			}

			return true;
		}
		catch (boost::bad_lexical_cast & e) {
			LOGINFO("redis lexical cast exception[%s], zrangebyscore_withvalue[%s][%ld][%ld]", e.what(), strSetName.c_str(), iBegin, iEnd);
		}
		catch (std::exception& e) {
			LOGINFO("redis exception[%s], zrangebyscore_withvalue[%s][%ld][%ld]", e.what(), strSetName.c_str(), iBegin, iEnd);
		}

		return false;
	}

	template<class T1>
	bool zadd(const std::string& strSetName, const T1& key, google::protobuf::int64 iValue) {
		std::unique_lock<std::mutex> lock(m_mutexRedisClient);
		std::string strKey;
		try {
			strKey = boost::lexical_cast<std::string>(key);
			rc.zadd(strSetName, strKey, iValue);
			return true;
		}
		catch (boost::bad_lexical_cast & e) {
			LOGINFO("redis lexical cast exception[%s], zrangebyscore_withvalue[%s][%s][%ld]", e.what(), strSetName.c_str(), strKey.c_str(), iValue);
		}
		catch (std::exception& e) {
			LOGINFO("redis exception[%s], zrangebyscore_withvalue[%s][%s][%ld]", e.what(), strSetName.c_str(), strKey.c_str(), iValue);
		}
		return false;
	}

	template<class T1>
	int zrem(const std::string& strSetName, const T1& key) {
		std::unique_lock<std::mutex> lock(m_mutexRedisClient);
		std::string strKey;
		try {
			strKey = boost::lexical_cast<std::string>(key);
			return rc.zrem(strSetName, strKey);
		}
		catch (boost::bad_lexical_cast & e) {
			LOGINFO("redis lexical cast exception[%s], zrem[%s][%s]", e.what(), strSetName.c_str(), strKey.c_str());
		}
		catch (std::exception& e) {
			LOGINFO("redis exception[%s], zrem[%s][%s]", e.what(), strSetName.c_str(), strKey.c_str());
		}
		return 0;
	}

	template<class T>
	bool zrevrange(const std::string& strSetName, google::protobuf::int64 iBegin, google::protobuf::int64 iEnd, std::vector<T>& vecResult) {
		std::unique_lock<std::mutex> lock(m_mutexRedisClient);
		std::vector<std::pair<std::string, google::protobuf::int64 > > values;
		try {
			rc.zrevrange(strSetName, iBegin, iEnd, false, &values);
			for (auto& value : values) {
				auto resultValue = boost::lexical_cast<T>(value.first);
				vecResult.push_back(resultValue);
			}

			return true;
		}
		catch (boost::bad_lexical_cast & e) {
			LOGINFO("redis lexical cast exception[%s], zrevrange[%s][%ld][%ld]", e.what(), strSetName.c_str(), iBegin, iEnd);
		}
		catch (std::exception& e) {
			LOGINFO("redis exception[%s], zrevrange[%s][%ld][%ld]", e.what(), strSetName.c_str(), iBegin, iEnd);
		}

		return false;
	}

	template<class T1, class T2>
	bool zrevrange(const std::string& strSetName, google::protobuf::int64 iBegin, google::protobuf::int64 iEnd, std::vector<std::pair<T1, T2> >& vecResult) {
		std::unique_lock<std::mutex> lock(m_mutexRedisClient);
		std::vector<std::pair<std::string, google::protobuf::int64 > > values;

		try {
			rc.zrevrange(strSetName, iBegin, iEnd, true, &values);
			for (auto& value : values) {
				auto resultKey = boost::lexical_cast<T1>(value.first);
				auto resultScore = boost::lexical_cast<T2>(value.second);
				vecResult.push_back(std::pair<T1, T2>(resultKey, resultScore));
			}
			return true;
		}
		catch (boost::bad_lexical_cast & e) {
			LOGINFO("redis lexical cast exception[%s], zrevrange_withvalue[%s][%ld][%ld]", e.what(), strSetName.c_str(), iBegin, iEnd);
		}
		catch (std::exception& e) {
			LOGINFO("redis exception[%s], zrevrange_withvalue[%s][%ld][%ld]", e.what(), strSetName.c_str(), iBegin, iEnd);
		}
		return false;
	}

	template<class T>
	int zrevrank(const std::string& sSetName, const T& key) {
		std::unique_lock<std::mutex> lock(m_mutexRedisClient);
		string sKey;
		try {
			sKey = boost::lexical_cast<string>(key);
			return rc.zrevrank(sSetName, sKey);
		}
		catch (std::exception& e) {
			LOGINFO("redis exception[%s], zrevrank[%s][%s]", e.what(), sSetName.c_str(), sKey.c_str());
		}
		return -1;
	}

	template<class T>
	bool sadd(const std::string& strSetName, const T& value) {
		std::unique_lock<std::mutex> lock(m_mutexRedisClient);
		std::string strValue;
		try {
			strValue = boost::lexical_cast<std::string>(value);
			return rc.sadd(strSetName, strValue);
		}
		catch (boost::bad_lexical_cast & e) {
			LOGINFO("redis lexical cast exception[%s], sadd[%s][%s]", e.what(), strSetName.c_str(), strValue.c_str());
		}
		catch (std::exception& e) {
			LOGINFO("redis exception[%s], sadd[%s][%s]", e.what(), strSetName.c_str(), strValue.c_str());
		}
		return false;
	}

	string xadd(const std::string& keyName, const string& field, const string& value) {
		std::unique_lock<std::mutex> lock(m_mutexRedisClient);
		std::string strValue;
		try {
			r3c::FVPair pair;
			pair.field = field;
			pair.value = value;
			vector<r3c::FVPair> vec;
			vec.push_back(pair);
			return rc.xadd(keyName, "*", vec);
		}
		catch (std::exception& e) {
			LOGINFO("redis exception[%s], xadd[%s][%s]", e.what(), keyName.c_str(), field.c_str(), value.c_str());
		}
		return "";
	}
    int xdel(const std::string& keyName, const string& id) {
		std::unique_lock<std::mutex> lock(m_mutexRedisClient);
		try {
			return rc.xdel(keyName, id);
		}
		catch (std::exception& e) {
			LOGINFO("redis exception[%s], xdel[%s][%s]", e.what(), keyName.c_str(), id.c_str());
		}
		return 0;
    }
    int xdel(const std::string& keyName, const vector<string>& ids) {
		std::unique_lock<std::mutex> lock(m_mutexRedisClient);
		try {
			return rc.xdel(keyName, ids);
		}
		catch (std::exception& e) {
			LOGINFO("redis exception[%s], xdel[%s] size[%d]", e.what(), keyName.c_str(), ids.size());
		}
		return 0;
    }
    void xread(const std::string& keyName, google::protobuf::int64 count, google::protobuf::int64 blockms, std::vector<r3c::StreamEntry>& vec) {
		std::unique_lock<std::mutex> lock(m_mutexRedisClient);
		std::string strValue;
		try {
            vector<string> ids;
            ids.push_back("0-0");
            rc.xread(keyName, ids, count, blockms, &vec);
		}
		catch (boost::bad_lexical_cast & e) {
			LOGINFO("redis lexical cast exception[%s], xadd[%s] [%%ld][%ld]", e.what(), keyName.c_str(), count, blockms);
		}
		catch (std::exception& e) {
			LOGINFO("redis lexical cast exception[%s], xadd[%s] [%%ld][%ld]", e.what(), keyName.c_str(), count, blockms);
		}
    }
	//>setnxex ok
	template<class T>
	bool setnxex(const std::string& strKeyName, const T& value, uint32_t expireTime) {
		std::unique_lock<std::mutex> lock(m_mutexRedisClient);
		std::map<std::string, std::string > mapTempParam;
		try {
			std::string strValue;
			strValue = boost::lexical_cast<std::string>(value);
			return rc.setnxex(strKeyName, strValue, expireTime);
		}
		catch (boost::bad_lexical_cast & e) {
			LOGINFO("redis lexical cast exception[%s], hmset[%s]", e.what(), strKeyName.c_str());
		}
		catch (std::exception& e) {
			LOGINFO("redis exception[%s], hmset[%s]", e.what(), strKeyName.c_str());
		}
		return false;
	}

	//>setnx ok
	template<class T>
	bool setnx(const std::string& strKeyName, const T& value) {
		std::unique_lock<std::mutex> lock(m_mutexRedisClient);
		std::map<std::string, std::string > mapTempParam;
		try {
			std::string strValue;
			strValue = boost::lexical_cast<std::string>(value);
			rc.setnx(strKeyName, strValue);
			return true;
		}
		catch (boost::bad_lexical_cast & e) {
			LOGINFO("redis lexical cast exception[%s], hmset[%s]", e.what(), strKeyName.c_str());
		}
		catch (std::exception& e) {
			LOGINFO("redis exception[%s], hmset[%s]", e.what(), strKeyName.c_str());
		}
		return false;
	}


	virtual bool srem(const std::string& sSetName, const std::string& sValue);
	virtual bool smembers(const std::string& sSetName, std::vector<std::string>& vResult);
	virtual bool sismember(const std::string& strSetName, const std::string& strValue, bool& bIsMember);

	virtual bool lpush(const std::string& sListName, const std::string& sValue);
	virtual bool lpush(const std::string& sListName, const std::vector<std::string>& vValue);
	virtual bool lpop(const std::string& sListName, std::string& sValue);
	virtual bool lrange(const std::string& sListName, int iStart, int iEnd, std::vector<std::string>& vResult);
	virtual bool lindex(const std::string& sListName,  int index, std::string& sValue);
	virtual int lrem(const std::string& sListName,  int count, const std::string& sValue);
	virtual bool ltrim(const std::string& sListName, int iBegin, int iEnd);

	virtual bool rpush(const std::string& sListName, const std::string& sValue);
	virtual bool rpop(const std::string& sListName, std::string& sValue);
	virtual bool rpop(const std::string& sListName, int count, std::vector<std::string>& vecValues);
	virtual bool llen(const std::string& sListName, google::protobuf::int32& lLength);

protected:
	bool redisCommand(std::function<bool()> function);

protected:
	r3c::CRedisClient rc;
	std::mutex m_mutexRedisClient;
};
