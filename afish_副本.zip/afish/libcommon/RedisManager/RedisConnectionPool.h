#ifndef _REDIS_CONNECTION_POOL_H_
#define _REDIS_CONNECTION_POOL_H_

#include <vector>
#include <boost/noncopyable.hpp>
#include <mutex>
#include <condition_variable>

#include "RedisConnection.h"


class RedisConnectionPool : private boost::noncopyable
{
public:
	RedisConnectionPool(const std::vector<RedisConnection*>& vecConnection);
	~RedisConnectionPool(void);

	RedisConnection* GetConnection();
	void ReturnConnection(RedisConnection* pConnection);

protected:
	std::vector<RedisConnection*> m_vecConnection;
	int m_iValidConnectionCount;

	std::mutex m_mutexConnection;
	std::condition_variable m_cvConnection;
};

#endif