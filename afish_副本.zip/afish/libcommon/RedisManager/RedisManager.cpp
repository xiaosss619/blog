#include "RedisManager.h"

#include "ThreadLog/ThreadLog.h"
#include "Utils/GlobalUtils.h"
#include "rapidjson/document.h"
#include "rapidjson/error/en.h"

#include "RedisConnection.h"
#include <google/protobuf/descriptor.h>
#include "ConfReader/ConfReader.h"

#include <iostream>

using namespace std;
using namespace google::protobuf;

RedisManager* RedisManager::m_pInstance = nullptr;

RedisConnectionIdGetter::RedisConnectionIdGetter(int id) {
	m_id = id;
	m_pConnection = RedisManager::GetInstance()->GetConnectionById(id);

}

RedisConnectionIdGetter::~RedisConnectionIdGetter() {
	RedisManager::GetInstance()->ReturnConnectionById(m_id, m_pConnection);
}

RedisConnection* RedisConnectionIdGetter::GetConnection() const {
	return m_pConnection;
}

RedisManager::RedisManager() {
}

RedisManager::~RedisManager() {
}

RedisManager* RedisManager::GetInstance() {
	if (m_pInstance == nullptr) {
		m_pInstance = new RedisManager();
	}
	return m_pInstance;
}

void RedisManager::Init(const string& conf) {
	ConfReader cfg;
	try{
		// read cfg file, if possible
		if(!cfg.read(conf)){
			LOGERROR("Could not open config file!");
			return;
		}
	}
	catch(std::invalid_argument& e){
		LOGERROR("Error reading config file![%s]", e.what());
	}

	auto all = cfg["redis"];
	for( size_t i = 0; i < all.size(); i++){
		string strName = all.getString(i);
		int32 type = cfg[strName].getInt(0);
		int32 poolSize = cfg[strName].getInt(1);
		string address = cfg[strName].getString(2);
		string password = cfg[strName].getString(3);
		vector<RedisConnection*> vecConnection;
		for (int i = 0; i < poolSize; i++) {
			auto pConnection = new RedisConnection(address, password);
			vecConnection.push_back(pConnection);
		}
		auto pConnectionPool = new RedisConnectionPool(vecConnection);
		m_mapIdConnectionPool[type] = pConnectionPool;
	}
}

RedisConnection* RedisManager::GetConnectionById(int id) {
	//std::shared_lock<std::shared_mutex> lock(m_mutexPool);
	std::map<int, RedisConnectionPool*>::const_iterator iter = m_mapIdConnectionPool.find(id);
	if (iter != m_mapIdConnectionPool.end()) {
		if (iter->second != nullptr) {
			return iter->second->GetConnection();
		}
	}

	return nullptr;
}

void RedisManager::ReturnConnectionById(int id, RedisConnection* pConnection) {
	//std::unique_lock<std::shared_mutex> lock(m_mutexPool);
	std::map<int, RedisConnectionPool*>::const_iterator iter = m_mapIdConnectionPool.find(id);
	if (iter != m_mapIdConnectionPool.end()) {
		if (iter->second != nullptr) {
			iter->second->ReturnConnection(pConnection);
		}
	}
}
