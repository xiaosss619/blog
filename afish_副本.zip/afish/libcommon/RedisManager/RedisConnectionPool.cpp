#include "RedisConnectionPool.h"

#include "ThreadLog/ThreadLog.h"

using namespace std;

RedisConnectionPool::RedisConnectionPool(const std::vector<RedisConnection*>& vecConnection) :
m_vecConnection(vecConnection)
{
	m_iValidConnectionCount = int(m_vecConnection.size());
}

RedisConnectionPool::~RedisConnectionPool(void)
{
	for (size_t i = 0; i < m_vecConnection.size(); i++) {
		if (m_vecConnection[i] != nullptr) {
			delete m_vecConnection[i];
			m_vecConnection[i] = nullptr;
		}
	}
}

RedisConnection* RedisConnectionPool::GetConnection() {
	unique_lock<mutex> lock(m_mutexConnection);
	if (--m_iValidConnectionCount < 0) {
		m_cvConnection.wait(lock);
	}

	auto pConnection = m_vecConnection.back();
	m_vecConnection.pop_back();
	return pConnection;
}

void RedisConnectionPool::ReturnConnection(RedisConnection* pConnection) {
	unique_lock<mutex> lock(m_mutexConnection);

	m_vecConnection.push_back(pConnection);
	if (++m_iValidConnectionCount <= 0) {
		m_cvConnection.notify_one();
	}
}