#include "RedisConnection.h"

using namespace std;
using namespace google::protobuf;

RedisConnection::RedisConnection(const std::string& sHostName, const std::string& sPassword) :
	rc(sHostName, sPassword) {
}

RedisConnection::~RedisConnection(void) {
}

bool RedisConnection::redisCommand(std::function<bool()> function) {
	try {
		return function();
	}
	catch (std::exception& e) {
		LOGINFO("redis exception[%s]", e.what());
	}
	return false;
}

//*lock
bool RedisConnection::del(const std::string& strKey) {
	if (strKey.empty()) {
		return false;
	}
	unique_lock<mutex> lock(m_mutexRedisClient);
	try {
		return rc.del(strKey);
	}
	catch (std::exception& e) {
		LOGINFO("redis exception[%s], del[%s]", e.what(), strKey.c_str());
	}

	return false;
}

bool RedisConnection::expire(const std::string& strKey, int iSeconds) {
	unsigned int utime = (unsigned int)iSeconds;
	unique_lock<mutex> lock(m_mutexRedisClient);
	try {
		return rc.expire(strKey, utime);
	}
	catch (std::exception& e) {
		LOGINFO("redis exception[%s], expire[%s]", e.what(), strKey.c_str());
	}
	return false;
}

bool RedisConnection::exists(const std::string& strKey) {
	unique_lock<mutex> lock(m_mutexRedisClient);
	try {
		return rc.exists(strKey);
	}
	catch (std::exception& e) {
		LOGINFO("redis exception[%s], exists[%s]", e.what(), strKey.c_str());
	}
	return false;
}

//r3c hmset 无返回值
bool RedisConnection::hmset(const std::string& strHashName, const vector<string>& vParam) {
	if (vParam.size() < 2) {
		return false;
	}

	if (vParam.size() % 2 != 0) {
		return false;
	}

	unique_lock<mutex> lock(m_mutexRedisClient);
	std::map<std::string, std::string> r3ckeymap;
	std::string hashkey;

	for (size_t i = 0; i < vParam.size(); i++) {
		if (i % 2 == 0) {//key
			hashkey = vParam[i];
		}
		else {//value
			r3ckeymap.insert(make_pair(hashkey, vParam[i]));
		}
	}
	try {
		rc.hmset(strHashName, r3ckeymap);
		return true;
	}
	catch (std::exception& e) {
		LOGINFO("redis exception[%s], hmset[%s]", e.what(), strHashName.c_str());
	}

	return false;
}

bool RedisConnection::hdel(const std::string& strHashName, const std::string& strKey) {
	unique_lock<mutex> lock(m_mutexRedisClient);

	try {
		return rc.hdel(strHashName, strKey);
	}
	catch (std::exception& e) {
		LOGINFO("redis exception[%s], hdel[%s]", e.what(), strHashName.c_str());
	}

	return false;
}

bool RedisConnection::hdel(const std::string& strHashName, const vector<string>& vKey) {
	bool flag = true;
	if (vKey.size() <= 0) {
		return false;
	}
	unique_lock<mutex> lock(m_mutexRedisClient);

	try {
		for (size_t i = 0; i < vKey.size(); i++) {
			if (!rc.hdel(strHashName, vKey[i])) {
				flag = false;
				continue;
			}
		}

		return flag;
	}
	catch (std::exception& e) {
		LOGINFO("redis exception[%s], hdel[%s]", e.what(), strHashName.c_str());
	}
	return false;
}

bool RedisConnection::hexists(const std::string& strHashName, const std::string& strKey) {
	unique_lock<mutex> lock(m_mutexRedisClient);

	try {
		return rc.hexists(strHashName, strKey);
	}
	catch (std::exception& e) {
		LOGINFO("redis exception[%s], hexists[%s][%s]", e.what(), strHashName.c_str(), strKey.c_str());
	}

	return false;
}

bool RedisConnection::zcard(const std::string& sSetName, int64& iResult) {
	unique_lock<mutex> lock(m_mutexRedisClient);
	try {
		iResult = rc.zcard(sSetName);
		return true;
	}
	catch (std::exception& e) {
		LOGINFO("redis exception[%s], zcard[%s]", e.what(), sSetName.c_str());
	}

	return false;
}

bool RedisConnection::srem(const std::string& sSetName, const std::string& sValue) {
	unique_lock<mutex> lock(m_mutexRedisClient);
	try {
		return rc.srem(sSetName, sValue) > 0;
	}
	catch (std::exception& e) {
		LOGINFO("redis exception[%s], srem[%s][%s]", e.what(), sSetName.c_str(), sValue.c_str());
	}

	return false;
}

bool RedisConnection::smembers(const std::string& sSetName, vector<string>& vResult) {
	unique_lock<mutex> lock(m_mutexRedisClient);

	try {
		return rc.smembers(sSetName, &vResult) > 0;
	}
	catch (std::exception& e) {
		LOGINFO("redis exception[%s], smembers[%s]", e.what(), sSetName.c_str());
	}

	return false;
}


bool RedisConnection::sismember(const std::string& strSetName, const std::string& strValue, bool& bIsMember) {
	unique_lock<mutex> lock(m_mutexRedisClient);

	try {
		bIsMember = rc.sismember(strSetName, strValue);
		return true;
	}
	catch (std::exception& e) {
		LOGINFO("redis exception[%s], sismember[%s][%s]", e.what(), strSetName.c_str(), strValue.c_str());
	}

	return false;
}

bool RedisConnection::lpush(const std::string& sListName, const std::string& sValue) {
	unique_lock<mutex> lock(m_mutexRedisClient);

	try {
		return rc.lpush(sListName, sValue) > 0;
	}
	catch (std::exception& e) {
		LOGINFO("redis exception[%s], lpush[%s][%s]", e.what(), sListName.c_str(), sValue.c_str());
	}

	return false;
}

bool RedisConnection::lpush(const std::string& sListName, const vector<string>& vValue) {
	unique_lock<mutex> lock(m_mutexRedisClient);
	bool flag = true;

	try {
		for (auto& value : vValue) {
			if (!rc.lpush(sListName, value)) {
				flag = false;
				continue;
			}
		}
		return flag;
	}
	catch (std::exception& e) {
		LOGINFO("redis exception[%s], lpush[%s]", e.what(), sListName.c_str());
	}

	return false;
}


bool RedisConnection::lpop(const std::string& sListName, std::string& sValue) {
	unique_lock<mutex> lock(m_mutexRedisClient);

	try {
		return rc.lpop(sListName, &sValue);
	}
	catch (std::exception& e) {
		LOGINFO("redis exception[%s], lpop[%s]", e.what(), sListName.c_str());
	}

	return false;
}

bool RedisConnection::lindex(const std::string& sListName, int index, std::string& sValue) {
	unique_lock<mutex> lock(m_mutexRedisClient);

	try {
		return rc.lindex(sListName,index,&sValue);
	}
	catch (std::exception& e) {
		LOGINFO("redis exception[%s], lindex[%s]", e.what(), sListName.c_str());
	}

	return false;
}

int RedisConnection::lrem(const std::string& sListName,  int count, const std::string& sValue) {
	unique_lock<mutex> lock(m_mutexRedisClient);

	try {
		return rc.lrem(sListName,count,sValue);
	}
	catch (std::exception& e) {
		LOGINFO("redis exception[%s], lindex[%s]", e.what(), sListName.c_str());
	}

	return 0;
}

bool RedisConnection::lrange(const std::string& sListName, int iBegin, int iEnd, vector<string>& vResult) {
	unique_lock<mutex> lock(m_mutexRedisClient);

	try {
		return rc.lrange(sListName, iBegin, iEnd, &vResult) > 0;
	}
	catch (std::exception& e) {
		LOGINFO("redis exception[%s], lrange[%s][%d][%d]", e.what(), sListName.c_str(), iBegin, iEnd);
	}

	return false;
}

bool RedisConnection::ltrim(const std::string& sListName, int iBegin, int iEnd) {
	unique_lock<mutex> lock(m_mutexRedisClient);

	try {
		rc.ltrim(sListName, iBegin, iEnd);
		return true;
	}
	catch (std::exception& e) {
		LOGINFO("redis exception[%s], lrange[%s][%d][%d]", e.what(), sListName.c_str(), iBegin, iEnd);
	}

	return false;
}


bool RedisConnection::rpush(const std::string& sListName, const std::string& sValue) {
	unique_lock<mutex> lock(m_mutexRedisClient);

	try {
		return rc.rpush(sListName, sValue) > 0;
	}
	catch (std::exception& e) {
		LOGINFO("redis exception[%s], rpush[%s][%s]", e.what(), sListName.c_str(), sValue.c_str());
	}

	return false;
}

bool RedisConnection::rpop(const std::string& sListName, std::string& sValue) {
	unique_lock<mutex> lock(m_mutexRedisClient);

	try {
		return rc.rpop(sListName, &sValue);
	}
	catch (std::exception& e) {
		LOGINFO("redis exception[%s], rpop[%s]", e.what(), sListName.c_str());
	}

	return false;
}

bool RedisConnection::rpop(const std::string& sListName, int count, std::vector<std::string>& vecValues) {
	unique_lock<mutex> lock(m_mutexRedisClient);

	try {
		return rc.rpop(sListName, &vecValues, count);
	}
	catch (std::exception& e) {
		LOGINFO("redis exception[%s], rpop[%s]", e.what(), sListName.c_str());
	}

	return false;
}

bool RedisConnection::llen(const std::string& sListName, int32& lLength) {
	unique_lock<mutex> lock(m_mutexRedisClient);

	try {
		lLength = rc.llen(sListName);
		return true;
	}
	catch (std::exception& e) {
		LOGINFO("redis exception[%s], llen[%s]", e.what(), sListName.c_str());
	}
	return false;
}
