#pragma once

#include <boost/asio.hpp>
#include <boost/noncopyable.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/thread.hpp>
#include <boost/noncopyable.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/asio/deadline_timer.hpp>
#include <boost/thread.hpp>
#include <boost/date_time.hpp>

#include <boost/bind/bind.hpp>
using namespace boost::placeholders;

#include <boost/typeof/typeof.hpp>
#include <boost/algorithm/string.hpp>
#include <boost/date_time/gregorian/gregorian.hpp>
using boost::asio::ip::tcp;
using namespace boost::gregorian;
using namespace boost::posix_time;
using timer_callback = boost::function<void (const boost::system::error_code&)>;

#include <google/protobuf/stubs/common.h>
using namespace google::protobuf;

#include <boost/beast.hpp>
#include <boost/asio/dispatch.hpp>
#include <boost/asio/strand.hpp>

#include <math.h>
#include <string>
#include <vector>
#include <set>
#include <iostream>
#include <unordered_map>
#include <unordered_set>
#include <random>
using namespace std;

#include "protocol/LxGameHelper.h"

#include "ThreadLog/ThreadLog.h"
#include "RedisManager/RedisManager.h"
#include "Utils/GlobalUtils.h"
#include "Utils/Vec2.h"
#include "Utils/fasthash.h"
#include "Utils/LxObjectPool.h"
#include "Utils/io_service_pool.h"
#include "Utils/LxCrontab.h"
#include "rapidjson/rapidjson.h"
#include "libjsons/JsonConfig.h"
#include "Utils/LifeObj.h"
#include "FilterWord/FilterWordHelper.h"
#include "Include/pbjson.h"

#define MAX_CHAT_GROUP_NAME_LEN 64
#define MAX_NAME_LEN 32
#define ROOM_MAX_PLAYER 4
#define MAX_ACCOUNT_LENGTH 64
#define MAX_SIGN_LEN 180
// 用户最大等级
#define MAX_USER_LEVEL 255
// vip最大等级
#define MAX_VIP_LEVEL 99
// 炮台最大等级
#define MAX_TURRET_LEVEL 99
// 最大强化等级
#define MAX_TURRET_PLUS 6
// 炮台最大16星...
#define MAX_TURRET_STAR 16
// 狂暴默认4倍
#define DEFAULT_FURY_RATE 4
// 核弹场获奖记录最大数量
#define BOMB_GAME_REWARD_LIST_MAX_NUM 50

struct tagSystemMail {
	int64 _mailid;
    int64 _timestamp;
	string _title;
	string _content;
	map<int32, int64> _mapItem;
	tagSystemMail() {
		_mailid = 0;
        _timestamp = 0;
		_title.clear();
		_content.clear();
		_mapItem.clear();
	}
	tagSystemMail& operator=(const tagSystemMail &rhs) {
		_mailid = rhs._mailid;
        _timestamp = rhs._timestamp;
		_title = rhs._title;
		_content = rhs._content;
		_mapItem = rhs._mapItem;
		return *this;
	}
};

struct tagSS {
	int32 _update_time;
    map<string, int32> _ss;
	tagSS() {
		_update_time = 0;
        _ss.clear();
	}
    tagSS& operator=(const tagSS& rhs) {
        _update_time = rhs._update_time;
        _ss = rhs._ss;
        return *this;
    }
};

union U_RankScore {
	int64 _value;
	struct
	{
        int64 _seconds : 21; // 今天还剩余的秒数 最多使用不会超过20位,
        int64 _score : 31; // 分值
        uint64 _reserved : 12; // 保留12位,防止redis的int64溢出
	};
    static int32 GetScore(int64 sc) {
        if( sc >= 0 ) {
            U_RankScore score;
            score._value = sc;
            return score._score;
        }
        return -1;
    }
    static int64 MakeScore(int64 tNow, int32 score) {
        U_RankScore u;
        u._value = 0;
        u._score = score;
        u._seconds = GlobalUtils::GetLeftSecondsOfDay(tNow);
        return u._value;
    }
};

typedef boost::shared_lock<boost::shared_mutex> readLock;
typedef boost::unique_lock<boost::shared_mutex> writeLock;

class PerformanceCheck {
public:
	uint64 _time;
	uint32 _cmd;
	string _tag;
public:
	PerformanceCheck(const string& tag, uint32 cmd) {
		_tag = tag;
		_cmd = cmd;
		_time = GlobalUtils::GetTickCount();
	}

	~PerformanceCheck() {
		LOGINFO("[%s] = [%lu] CMD[%u]", _tag.c_str(), GlobalUtils::GetTickCount() - _time, _cmd);
	}
};

// msg为消息名,data为实际数据
#define CALL_CLIENT_SIMPLE(pUser, MsgName) {\
    WrapPacket packet;\
    packet.set_userid(pUser->GetKey());\
    packet.set_connectionid(pUser->GetConnectionId());\
    packet.set_packtype(EPT_Sync);\
    LxGameHelper::Make##MsgName(packet);\
    sDispatcher->call_client(packet);\
}

// msg为消息名,data为实际数据
#define CALL_CLIENT(pUser, MsgName, MsgData) {\
    WrapPacket packet;\
    packet.set_userid(pUser->GetKey());\
    packet.set_connectionid(pUser->GetConnectionId());\
    packet.set_packtype(EPT_Sync);\
    LxGameHelper::Make##MsgName(packet, MsgData);\
    sDispatcher->call_client(packet);\
}

// resp中无任何数据的
#define RESPONSE_EMPTY(pUser, reqId, error, MsgName) {\
    WrapPacket packet;\
    packet.set_userid(pUser->GetKey());\
    packet.set_connectionid(pUser->GetConnectionId());\
    packet.set_requestid(reqId);\
    packet.set_errorcode(error);\
    packet.set_packtype(EPT_Request);\
    LxGameHelper::Make##MsgName(packet);\
    sDispatcher->call_client(packet);\
}

// resp中有response, errorcode不为0时, 需要一个空结构构造resp包
#define RESPONSE_WITH_CODE(pUser, reqId, error, MsgName) {\
    WrapPacket packet;\
    packet.set_userid(pUser->GetKey());\
    packet.set_connectionid(pUser->GetConnectionId());\
    packet.set_requestid(reqId);\
    packet.set_errorcode(error);\
    packet.set_packtype(EPT_Request);\
    MsgName data;\
    LxGameHelper::Make##MsgName(packet, data);\
    sDispatcher->call_client(packet);\
}

// resp中有response, errorcode为0, 需要一个构造对应的数据
#define RESPONSE_WITH_DATA(pUser, reqId, MsgName, MsgData) {\
    WrapPacket packet;\
    packet.set_userid(pUser->GetKey());\
    packet.set_connectionid(pUser->GetConnectionId());\
    packet.set_requestid(reqId);\
    packet.set_packtype(EPT_Request);\
    LxGameHelper::Make##MsgName(packet, MsgData);\
    sDispatcher->call_client(packet);\
}

// msg为消息名,data为实际数据
#define CALL_CLIENT_ID(userid, MsgName, MsgData) {\
    WrapPacket packet;\
    packet.set_userid(userid);\
    packet.set_packtype(EPT_Sync);\
    LxGameHelper::Make##MsgName(packet, MsgData);\
    sDispatcher->call_client(packet);\
}

// msg为消息名,data为实际数据
#define CALL_THREAD(pUser, MsgName, MsgData) {\
    WrapPacket packet;\
    packet.set_userid(pUser->GetKey());\
    packet.set_connectionid(pUser->GetConnectionId());\
    LxGameHelper::Make##MsgName(packet, MsgData);\
    sDispatcher->dispatch(packet);\
}

// msg为消息名,data为实际数据
#define CALL_USER_THREAD(userId, MsgName, MsgData) {\
    WrapPacket packet;\
    packet.set_userid(userId);\
    packet.set_connectionid(0);\
    LxGameHelper::Make##MsgName(packet, MsgData);\
    sDispatcher->dispatch(packet);\
}

// msg为消息名
#define CALL_THREAD_SIMPLE(pUser, MsgName) {\
    WrapPacket packet;\
    packet.set_userid(pUser->GetKey());\
    packet.set_connectionid(pUser->GetConnectionId());\
    LxGameHelper::Make##MsgName(packet);\
    sDispatcher->dispatch(packet);\
}

#define GETSET_BOOL(name) \
public:\
        bool Is##name() { return m_##name; }\
        void Set##name(bool _##name) { m_##name = _##name; };\
protected:\
        bool m_##name;

#define GETSET_PTR(type, name) \
public:\
        type* Get##name() { return m_p##name; }\
        void Set##name(type* _##name) { m_p##name = _##name; };\
protected:\
        type* m_p##name;

#define GETSET(type, name) \
public:\
        const type& Get##name() { return m_##name; }\
        void Set##name(const type& _##name) { m_##name = _##name; };\
protected:\
        type m_##name;

#define GETSETCHG(type, name) \
public:\
        const type& Get##name() { return m_##name; }\
        void Set##name(const type& _##name) { m_##name = _##name; };\
        void Change##name(const type& _##name, type vMin=0) { m_##name += _##name; if( m_##name < vMin ) {m_##name = vMin;} };\
protected:\
        type m_##name;

#define GETSET_PTR(type, name) \
public:\
        type* Get##name() { return m_p##name; }\
        void Set##name(type* _##name) { m_p##name = _##name; };\
protected:\
        type* m_p##name;

#define TUPLE0(data) std::get<0>(data)
#define TUPLE1(data) std::get<1>(data)
#define TUPLE2(data) std::get<2>(data)
#define TUPLE3(data) std::get<3>(data)
#define TUPLE4(data) std::get<4>(data)
#define TUPLE5(data) std::get<5>(data)


#define FETCH_VOID() \
    RedisConnectionIdGetter idGetter(enumRedisServerTypeData);\
    auto pConnection = idGetter.GetConnection();\
    if( pConnection == nullptr ) {\
        LOGERROR("NOREDIS");\
        return;\
    }

#define FETCH_RETURN(ret) \
    RedisConnectionIdGetter idGetter(enumRedisServerTypeData);\
    auto pConnection = idGetter.GetConnection();\
    if( pConnection == nullptr ) {\
        LOGERROR("NOREDIS");\
        return ret;\
    }

#define FETCH_RESPONSE_BREAK(response) \
    RedisConnectionIdGetter idGetter(enumRedisServerTypeData);\
    auto pConnection = idGetter.GetConnection();\
    if( pConnection == nullptr ) {\
        LOGERROR("NOREDIS");\
        response.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());\
        break;\
    }

struct tagMemoryId {
	int32 _id;
	tagMemoryId() {
		_id = 1000;
	}
	int32 incryby(int32 count) {
        int32 startId = _id;
        if( startId >= 2147483648 || startId <= 0 ) {
            startId = 1000;
			_id = 1000;
        }
        _id += count;
        return startId;
	}
	tagMemoryId& operator=(const tagMemoryId& rhs)
    {
        _id = rhs._id;
        return *this;
    }
	void reset() { _id = 1000; }
};

struct tagGoldPool {
public:
    // 奖池归属
    uint64 _owner;
    // 累计收入
    int64 _win;
    // 累计产出
    int64 _lose;
    // 奖池累计奖金
    int64 _pool;
    // 抽水率
    float _rate;
    int64 _pool_start;
    int64 _pool_end;
    bool _in_use;
    // 用于客户端界面显示的百分比值
    int32 _show_rate;
    tagGoldPool() {
        reset();
    }
    void reset() {
        _owner = 0;
        _win = 0;
        _lose = 0;
        _pool = 0;
        _rate = 0.0f;
        _pool_start = 0;
        _pool_end = 0;
        _show_rate = 0;
        _in_use = false;
    }
    tagGoldPool& operator=(const tagGoldPool& rhs) {
        _owner = rhs._owner;
        _win = rhs._win;
        _lose = rhs._lose;
        _pool = rhs._pool;
        _rate = rhs._rate;
        _pool_start = rhs._pool_start;
        _pool_end = rhs._pool_end;
        _in_use = rhs._in_use;
        _show_rate = rhs._show_rate;
        return *this;
    }
    void CheckUsePool() {
        if( _pool < _pool_end ) {
            _in_use = false;
        }
        if( _pool >= _pool_start ) {
            _in_use = true;
        }
    }
};

struct tagFishHitParam {
    int64 B; // 炮倍
    int64 f; // 个人感受值
    int64 F; // 房间友好度
    int64 C; // 房间抽水率
    int64 R; // 房间的R值
    int64 Fi;
    int64 BN;
    int64 AT;
    int64 BP;
    double hitNum;
    int64 totalGold;    // 开炮消耗的总金币
    int64 expectNum;
    int64 rate;
    int32 score;
    int64 bossPointParam;
    bool isBonusBoss;
    tagFishHitParam() {
        memset( this, 0, sizeof(tagFishHitParam) );
    }
    tagFishHitParam& operator=(const tagFishHitParam& rhs) {
        memcpy(this, &rhs, sizeof(tagFishHitParam));
        return *this;
    }
    int32 GetRate(float alpha) {
        return BP + BN + AT + alpha * (Fi + B/R)*pow(1.1, F/100+f/100);
    }
};

#define LOG_POOL(obj, idx)  \
{\
	auto data = obj.DebugInfo();\
	LOG_MEMPOOL_INFO(time(nullptr),idx,std::get<0>(data),std::get<1>(data),std::get<2>(data),std::get<3>(data));\
}

#define LOG_GIFT(gift) \
{\
    LOG_GIFT_INFO(time(nullptr), gift.gid(), gift.sender().t_id(), gift.receiver().t_id(), gift.item().item_id(), gift.item().item_num(), gift.status(), gift.fee());\
}

class JsonProto {
public:
    static std::string ProtoToJson(const Message& msg) {
        Document encoded;
        ProtobufToJson::encode_to_json_doc(msg, &encoded);
        StringBuffer output;
        rapidjson::Writer<rapidjson::StringBuffer> writer(output);
        encoded.Accept(writer);
        return std::string(output.GetString());
    }

    static bool ProtoFromJson(const std::string& json, Message& msg) {
        Document doc;
        if( doc.Parse(json.data()).HasParseError() ) {
            LOGERROR("parse error: %s", json.data());
            return false;
        }
        std::string error;
        if(!ProtobufToJson::decode_from_json_value(doc, &msg, &error)) {
            LOGERROR("decode error: [%s] [%s]", json.data(), error.data());
            return false;
        }
        return true;
    }
};

enum E_RedisCmd
{
	EIC_Null		= 0,
	EIC_Gold		= 1,	// 增减金币数值可以有正负 10000
	EIC_Diamond		= 2,	// 增减钻石数值可以有正负 10000
	EIC_Item 		= 3,	// 给道具 itemid,itemnum
	EIC_Exp			= 4,	// 给经验 1000
	EIC_Reload		= 5,	// 重新加载配置 xmlItem.xml
	EIC_Yell		= 6,	// 系统跑马灯发送 content
	EIC_Time		= 7,	// 0 重置 time 查询 设置yyyy-mm-dd-hh-mm-ss
	EIC_Lv1			= 8,	// 重置等级经验
	EIC_Vip0		= 9,	// 重置vip等级经验
	EIC_Gt0			= 10,	// 重置游戏时长领取标记
	EIC_RewardCode	= 11,	// 兑换码
	EIC_GMMail		= 12,	// GM后台发个人邮件 mail jsonstring
	EIC_Charge		= 13,	// 后台充值指令 product,自己的订单号,第三方订单号
	EIC_Room0		= 14,	// 重置休闲模式每日次数
	EIC_ResetQuest	= 15,	// 重置任务
	EIC_CouponResult= 16, 	// 礼券兑换结果
	EIC_BindPhone	= 17,	// 绑定手机号 138xxxxxxxx
	EIC_BindIdCard	= 18, 	// 绑定身份证号 310xxxxx
	EIC_FriendNewApply	= 19, // 新的好友申請提示
	EIC_FriendApplyAccepted	= 21, // 好友申請被通過, userid
	EIC_FriendForceRemoved = 22,	// 對方刪除了好友, 靜默刪除自己的
	EIC_FriendUpdate = 23,	// 好友更新數據 userid
	EIC_BindFBID	= 24,	// 绑定facebookid facebookid
	EIC_GiftCode	= 25,	// 礼物赠送系统密码设置 xxxxxxx
	EIC_GiftWithdraw	= 26, // 礼物取消, 发送方回滚当日计数  itemid|itemnum
	EIC_SetPopularity	= 27,	// 设置玩家人气值 数值
	EIC_Mute		= 28,	//	设置禁言结束时间,0表示解除禁言, 时间戳
	EIC_UpdateField	= 29,	// 更新属性 field|value
	EIC_KickUser	= 30, 	// 踢人
    EIC_GiftRecv    = 31,       // 接受礼物, itemid|itemnum
    EIC_KickRelogin = 32,   // 跨服重复登录踢人
};

union SeverIdAndLinkId {
    int64 _data;
    struct {
        int64 _serverId : 32; // 服务器id
        int64 _linkId : 32;     // 连接的connectionId
    };
};
