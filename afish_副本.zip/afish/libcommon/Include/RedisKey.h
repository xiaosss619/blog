#pragma once

#include "ServerDefine.h"

enum E_SystemMaintainanceStatus {
	ESMS_InMaintain	= 0,	// 维护中
	ESMS_Normal		= 1,	// 正常开放
	ESMS_WhiteList	= 2,	// 白名单开放
};

#define GM_CHANNEL_VERSION	"gm:server:"
#define GM_CHANNEL	"gm:channel:"
#define LOG_USER_DEVICE_KEY "log:dvc:"			// 用户设备信息

#define SYS_NEW_GIFT_FEE_KEY "gift:fee:new"	// 费率数据修改标记, 1表示有修改
#define SYS_GIFT_FEE_KEY "gift:fee"			// 礼物费率数据
#define SYS_CONST_KEY "sys:const"
#define SYS_CONST_DYN_KEY "sys:dyn:const"
#define SYS_STATUS			"sys:stat"			// 当前系统状态 E_SystemMaintainanceStatus 0-维护 1正常 2白名单状态
#define SYS_STATUS_KICK		"sys:stat:kick"		// 转换到维护中后, 是否已经全服踢人下线了
#define SYS_STATUS_WHITE	"sys:stat:white"	// 系统白名单列表 hset
#define SYS_TABLE_SKILL_LOCK	"sys:lock:"		// 桌面技能锁
#define SYS_BLOCK_USERS_KEY	"sys:user:block"	// 系统封停名单
#define SYS_SYSTEM_NOTICE_KEY "sys:notice"		// 系统通知
#define SYS_SYSTEM_MAIL_KEY "sys:mail"			// 系统邮件
#define SYS_SYSTEM_MAIL_ID_KEY "sys:mail:id"	// 系统邮件的自增id
#define SYS_TURNTABLE	"sys:tt:"				// 转盘奖金池
#define SYS_SLOT_FISH_TABLE_KEY "sys:slot:fish:table:"		// 桌面型奖池鱼存储key
#define SYS_RELOAD	"sys:reload"	// 重新加载配置指令
#define SYS_RELOAD_ALL	"sys:reload:all"	// 重新加载所有配置指令
#define SYS_SLOT_DRAW_KEY	"sys:slot:draw:"	// 奖池型抽奖
#define SYS_CHANNEL_GIFT_KEY "sys:chn:gift"
#define SYS_CHANNEL_CHAT_KEY "sys:chn:chat"
#define SYS_SERVER_CMD_KEY	"sys:server:cmd:"	// 给每个服务器发送的广播消息
#define SYS_SUMMON_POOL_KEY "sys:smn:pool:"		// 召唤boss奖金池数据
#define SYS_SUMMON_KILLER_KEY "sys:smn:killer:"	// 召唤boss击杀名单
#define SYS_BOMB_GAME_POOL_KEY "sys:bomb:game:pool" // 核弹场奖池金额
#define SYS_BOMB_GAME_POOL_LIST_KEY "sys:bomb:game:pool:list" // 核弹场奖池名单
#define SYS_GIFT_KEY	"sys:gift"
#define SYS_GIFT_CLOSE_KEY	"sys:gift:close"
#define SYS_FIRE_INTERVAL	"sys:fire"
#define SYS_SUMMON_POOL_LOCK "sys:pool:lock:"
#define SYS_BOMB_GAME_POOL_LOCK "sys:bomb:lock:"
#define SYS_CHATS_KEY	"sys:chats"
#define SYS_CHAT_MSG_KEY "sys:chat:msg:"	// 聊天信息存储

#define ARENA_CROSSDAY_TIME "sys:arena:0"	// 上次计算竞技场跨天的时间
#define ARENA_USER_INFO_KEY "sys:arena:user"	// 竞技场用户数据
#define ARENA_DAY_RANK "sys:arena:day"		// 竞技场每日排名数据
#define ARENA_WEEK_RANK "sys:arena:week"	// 竞技场每周排名数据
#define ARENA_LAST_WEEK_RANK "sys:arena:week:last"	// 竞技场上周前三数据

#define BOARD_CROSSDAY_TIME "board:0"	// 上次排行榜跨天計算時間
#define BOARD_USER_INFO_KEY "board:user" // 排行榜用户数据存储
#define BOARD_DATA_KEY	"board:data:"	// 排行榜数据

#define BULLETIN_CROSSDAY_TIME "sys:blt:0"	// 上次计算boss排行跨天的时间
#define BULLETIN_HORN_KEY	"blt:horn:"	// 号角boss prefix

#define GUID_USER_KEY	"guid:user"		// 用户唯一id
#define GUID_GIFT_KEY	"guid:gift"		// 礼物唯一id
#define GUID_CHAT_GROUP_KEY	"guid:gid"	// 聊天组唯一id
#define GUID_CHAT_MSG_KEY	"guid:mid"	// 聊天信息唯一id
#define GUID_BOSS_KEY	"guid:boss"	// boss唯一id

#define USER_RMB_KEY	"u:rmb:"	// 充值数据
#define USER_INFO_KEY	"u:info:"	// 基础信息
#define USER_MAIL_KEY	"u:mail:"	// 邮件
#define USER_ITEM_KEY	"u:item:"	// 道具
#define USER_HERO_KEY	"u:herov2:"	// 炮台
#define USER_WING_KEY	"u:wing:"	// 翅膀
#define USER_QUEST_KEY 	"u:qst:"	// 任务
#define USER_DAY7_KEY 	"u:day7:"	// 7日任务
#define USER_OPENID_KEY "u:oid:"	// 用户openid对照userid pub:oid:xxxxxxxxx => 12345(userid)
#define USER_CMD_KEY 	"u:cmd:"	// 用户gm命令
#define USER_DEFINE_KEY	"u:def:" 	// 用户自定义数据
#define USER_MARKET_KEY "u:mkt:"	// 用户个人黑店数据
#define USER_EXCHANGE_KEY "u:exg:"	// 用户兑换商城数据
#define USER_OFFLINE_MAIL_KEY "u:offmail:"	// 用户离线邮件
#define USER_DRAW_RMB_KEY "u:drawrmb:"	// 兑换券抽话费活动
#define USER_GENERAL_TASK_KEY 	"u:gtsk:"	// 通用任务
#define USER_TURNTABLE_KEY 	"u:tt:"	// 转盘
#define USER_BOMB_ACT_KEY "u:bomb:act:"	// 核弹活动-翻牌
#define USER_BOMB_GAME_KEY	"u:bomb:game:"	// 核弹场中奖记录
#define USER_TECH_KEY	"u:tech:"	// 科技数据
#define USER_BUFF_KEY	"u:buff:"	// 增益数据
#define USER_TREASURE_KEY	"u:treasure:"	// 宝藏数据
#define USER_COUNTER_KEY	"u:counter:"	// 计数器数据
#define USER_FRIEND_KEY	"u:frd:"	// 好友数据
#define USER_APPLY_KEY	"u:apply:"	// 好友申請列表
#define USER_BLOCK_KEY	"u:blk:"	// 黑名单数据
#define USER_TARGET_INFO_KEY	"u:tinfo:"	// 用戶基礎信息key
#define USER_FROZEN_ASSETS_KEY	"u:frozen:"	// 用户冻结资产明细
#define USER_GIFT_COUNTER_KEY	"u:gcounter:"	// 用户当日送礼道具统计
#define USER_HUNT_BOSS_INFO_KEY "u:hunt:"
#define USER_BOSS_INFO_KEY "u:boss:"
#define USER_LOGIN_LOCK_KEY "u:login:lock:" // 用户的登录锁
#define USER_PROTO_CMD_KEY "u:pcmd:" // 用户与聊天和礼物部分的redis通信
#define USER_GIFT_LIST_KEY "u:gifts:"   // 用户礼物列表
#define USER_GROUP_CHAT_MSG_KEY "u:gtalk:"	// 用户聊天组清空消息记录 记录gid=>清除掉的最大id
#define USER_KICKED_GROUP_KEY	"u:cg:kicked:"	// 用户被这些群组踢出

// 以下是与go服务器通信使用的消息队列的key

// 兑换码key {"uid":"", "code":""}
#define GO_RK_REWARD_CODE "redeem_stream"
#define GO_J_FMT_REWARD_CODE "{\"uid\":\"<T1>\", \"code\":\"<T2>\"}"

class RedisKey {
public:
	static std::tuple<std::string, std::string> MakeKeyUserDataTableId(uint64 uUserId) {
		ostringstream os;
		os << "u:" << uUserId;
		return std::make_tuple(os.str(), std::string("table"));
	}
	static string MakeUserDefineDataKey(uint64 uUserId) {
		ostringstream os;
		os << USER_DEFINE_KEY << uUserId;
		return os.str();
	}
	static string MakeUserChargeKey(uint64 uUserId) {
		ostringstream os;
		os << USER_RMB_KEY << uUserId;
		return os.str();
	}
	static string MakeUserBombGameKey(uint64 uUserId) {
		ostringstream os;
		os << USER_BOMB_GAME_KEY << uUserId;
		return os.str();
	}
	static string MakeUserItemKey(uint64 uUserId) {
		ostringstream os;
		os << USER_ITEM_KEY << uUserId;
		return os.str();
	}
	static string MakeUserHeroKey(uint64 uUserId) {
		ostringstream os;
		os << USER_HERO_KEY << uUserId;
		return os.str();
	}
	static string MakeUserWingKey(uint64 uUserId) {
		ostringstream os;
		os << USER_WING_KEY << uUserId;
		return os.str();
	}
	static string MakeUserQuestKey(uint64 uUserId) {
		ostringstream os;
		os << USER_QUEST_KEY << uUserId;
		return os.str();
	}
	static string MakeUserDay7Key(uint64 uUserId) {
		ostringstream os;
		os << USER_DAY7_KEY << uUserId;
		return os.str();
	}
	static string MakeUserGTaskKey(uint64 uUserId) {
		ostringstream os;
		os << USER_GENERAL_TASK_KEY << uUserId;
		return os.str();
	}
	static string MakeUserTurnTableKey(uint64 uUserId) {
		ostringstream os;
		os << USER_TURNTABLE_KEY << uUserId;
		return os.str();
	}
	static string MakeUserMailKey(uint64 uUserId) {
		ostringstream os;
		os << USER_MAIL_KEY << uUserId;
		return os.str();
	}
	static string MakeUserDrawRmbKey(uint64 uUserId) {
		ostringstream os;
		os << USER_DRAW_RMB_KEY << uUserId;
		return os.str();
	}
	static string MakeUserOfflineMailKey(uint64 uUserId) {
		ostringstream os;
		os << USER_OFFLINE_MAIL_KEY << uUserId;
		return os.str();
	}
	static string MakeUserMarketKey(uint64 uUserId) {
		ostringstream os;
		os << USER_MARKET_KEY << uUserId;
		return os.str();
	}
	static string MakeUserExchangeKey(uint64 uUserId) {
		ostringstream os;
		os << USER_EXCHANGE_KEY << uUserId;
		return os.str();
	}
	static string MakeOpenIdUserKey(const string& strOpenId) {
		ostringstream os;
		os << USER_OPENID_KEY << strOpenId;
		return os.str();
	}
	static string MakeUserUniqueKey() {
		return GUID_USER_KEY;
	}
	static string MakeGiftUniqueKey() {
		return GUID_GIFT_KEY;
	}
	static string MakeSystemConstKey() {
		return SYS_CONST_KEY;
	}
	static string MakeSystemConstDynKey() {
		return SYS_CONST_DYN_KEY;
	}
	static string MakeSystemMailKey() {
		return SYS_SYSTEM_MAIL_KEY;
	}
	static string MakeSystemNoticeKey() {
		return SYS_SYSTEM_NOTICE_KEY;
	}
	static string MakeUserKey(uint64 uUserId) {
		ostringstream osKey;
		osKey << USER_INFO_KEY << uUserId;
		return osKey.str();
	}
	static string MakeUserFrozensKey(uint64 uUserId) {
		ostringstream osKey;
		osKey << USER_FROZEN_ASSETS_KEY << uUserId;
		return osKey.str();
	}

	static string MakeUserGiftCounterKey(uint64 uUserId) {
		ostringstream osKey;
		osKey << USER_GIFT_COUNTER_KEY << uUserId;
		return osKey.str();
	}

	static string MakeUserHuntBossInfoKey(uint64 uUserId) {
		ostringstream osKey;
		osKey << USER_HUNT_BOSS_INFO_KEY << uUserId;
		return osKey.str();
	}

	static string MakeUserBossInfoKey(uint64 uUserId) {
		ostringstream osKey;
		osKey << USER_BOSS_INFO_KEY << uUserId;
		return osKey.str();
	}

	static string MakeUserGmCmdKey(uint64 uUserId) {
		ostringstream osKey;
		osKey << USER_CMD_KEY << uUserId;
		return osKey.str();
	}
	static string MakeBulletinCrossDayKey() {
		return BULLETIN_CROSSDAY_TIME;
	}
	static string MakeArenaUserKey() {
		return ARENA_USER_INFO_KEY;
	}
	static string MakeArenaCrossDayKey() {
		return ARENA_CROSSDAY_TIME;
	}
	static string MakeArenaDayKey() {
		return ARENA_DAY_RANK;
	}
	static string MakeArenaWeekKey() {
		return ARENA_WEEK_RANK;
	}
	static string MakeArenaLastWeekKey() {
		return ARENA_LAST_WEEK_RANK;
	}

	static string MakeGoKeyRewardCode() {
		return GO_RK_REWARD_CODE;
	}
	static string MakeSystemUserBlockKey() {
		return SYS_BLOCK_USERS_KEY;
	}
	// hType EnumBossBulletinBoardType EBBBT_UserBase+EnumBossBulletinBoardType表示查找对应的用户数据
	static string MakeBulletinHornKey(int32 bossIndex, int32 hType, const string& strDate) {
		ostringstream os;
		os << BULLETIN_HORN_KEY << strDate << ":" << bossIndex << ":" << hType;
		return os.str();
	}
	static string MakeGoDataRewardCode(uint64 userId, const string& code) {
		string strData = GO_J_FMT_REWARD_CODE;
		strData = GlobalUtils::ReplaceAll(strData, "<T1>", GlobalUtils::ToString(userId));
		strData = GlobalUtils::ReplaceAll(strData, "<T2>", code);
		return strData;
	}
	static string MakeServerCmdKey(int32 serverId) {
		ostringstream oss;
		oss << SYS_SERVER_CMD_KEY << serverId;
		return oss.str();
	}
	static string MakeChannelVersionKey(const string& channel) {
		ostringstream oss;
		oss << GM_CHANNEL_VERSION << channel;
		return oss.str();
	}
	static string MakeChannelKey(const string& channel) {
		ostringstream oss;
		oss << GM_CHANNEL << channel;
		return oss.str();
	}
	static string MakeSysTurntableKey(int32 serverId, int32 ttid, int32 idx) {
		ostringstream osKey;
		osKey << SYS_TURNTABLE << serverId << ":" << ttid << ":" << idx;
		return osKey.str();
	}
	static string MakeSysSlotKey(int32 serverId, int32 slotId) {
		ostringstream osKey;
		osKey << SYS_SLOT_DRAW_KEY << serverId << ":" << slotId;
		return osKey.str();
	}
	static string MakeSysSlotTableFishKey(int32 idx) {
		ostringstream osKey;
		osKey << SYS_SLOT_FISH_TABLE_KEY << idx;
		return osKey.str();
	}
	static string MakeSysSummonPoolKey(int32 idx) {
		ostringstream osKey;
		osKey << SYS_SUMMON_POOL_KEY << idx;
		return osKey.str();
	}
	static string MakeSysSummonKillerKey(int32 idx) {
		ostringstream osKey;
		osKey << SYS_SUMMON_KILLER_KEY << idx;
		return osKey.str();
	}
	static string MakeTableSkillLockKey(int32 tableId) {
		ostringstream osKey;
		osKey << SYS_TABLE_SKILL_LOCK << tableId;
		return osKey.str();
	}
	static string MakeUserBombActKey(uint64 uUserId) {
		ostringstream osKey;
		osKey << USER_BOMB_ACT_KEY << uUserId;
		return osKey.str();
	}
	static string MakeSysBombGamePoolKey() {
		return SYS_BOMB_GAME_POOL_KEY;
	}
	static string MakeSysBombGamePoolListKey() {
		return SYS_BOMB_GAME_POOL_LIST_KEY;
	}
	static string MakeUserTechKey(uint64 userId) {
		ostringstream osKey;
		osKey << USER_TECH_KEY << userId;
		return osKey.str();
	}
	static string MakeUserBuffKey(uint64 userId) {
		ostringstream osKey;
		osKey << USER_BUFF_KEY << userId;
		return osKey.str();
	}
	static string MakeUserTreasureKey(uint64 userId) {
		ostringstream osKey;
		osKey << USER_TREASURE_KEY << userId;
		return osKey.str();
	}
	static string MakeUserCounterKey(uint64 userId) {
		ostringstream osKey;
		osKey << USER_COUNTER_KEY << userId;
		return osKey.str();
	}
	static string MakeUserBlockKey(uint64 userId) {
		ostringstream osKey;
		osKey << USER_BLOCK_KEY << userId;
		return osKey.str();
	}
	static string MakeUserFriendKey(uint64 userId) {
		ostringstream osKey;
		osKey << USER_FRIEND_KEY << userId;
		return osKey.str();
	}
	static string MakeUserApplyKey(uint64 userId) {
		ostringstream osKey;
		osKey << USER_APPLY_KEY << userId;
		return osKey.str();
	}
	static string MakeUserTargetInfoKey(uint64 userId) {
		ostringstream osKey;
		osKey << USER_TARGET_INFO_KEY << userId;
		return osKey.str();
	}
	static string MakeUserGroupChatMsgKey(uint64 userId) {
		ostringstream osKey;
		osKey << USER_GROUP_CHAT_MSG_KEY << userId;
		return osKey.str();
	}
	static string MakeBoardDataKey(int32 boardType) {
		ostringstream osKey;
		osKey << BOARD_DATA_KEY << boardType;
		return osKey.str();
	}
	static string MakeSysChatMsgKey(int64 msgId) {
		ostringstream osKey;
		osKey << SYS_CHAT_MSG_KEY << msgId;
		return osKey.str();
	}
	static string MakeUserKickedChatGroupKey(uint64 userId) {
		ostringstream osKey;
		osKey << USER_KICKED_GROUP_KEY << userId;
		return osKey.str();
	}
    static string MakeUserLoginLockKey(uint64 userId) {
        ostringstream ss;
        ss << USER_LOGIN_LOCK_KEY << userId;
        return ss.str();
    }
    static string MakeUserProtoCmdKey(uint64 userId) {
        ostringstream ss;
        ss << USER_PROTO_CMD_KEY << userId;
        return ss.str();
    }
    static string MakeUserGiftListKey(uint64 userId) {
        ostringstream ss;
        ss << USER_GIFT_LIST_KEY << userId;
        return ss.str();
    }
};
