#!/bin/sh

# json生成
mkdir -p ./xlsx
mkdir -p ./output
mkdir -p ./client
mkdir -p ./json
rm -f ./xlsx/*
rm -f ./output/*
rm -f ./client/*
rm -f ./json/*
rm -f ~/svn/FishServer/trunk/afish/libjsons/*
svn up ~/svn/FishDocs/AFExcel/
svn up ~/svn/FishClient/ClientAutoFileAF/json/
svn up ~/svn/FishClient/ClientAutoFileAF/ConfigTs/
rm ~/svn/FishClient/ClientAutoFileAF/ConfigTs/*
cp ~/svn/FishDocs/AFExcel/*.xlsx ./xlsx/
./gen_json ./xlsx/
mv ./client/SystemConst.ts ~/svn/FishClient/ClientAutoFileAF/proto/
mv ./client/ErrorCode.ts ~/svn/FishClient/ClientAutoFileAF/proto/
mv ./client/*.ts ~/svn/FishClient/ClientAutoFileAF/ConfigTs/
cp ./json/*.json ~/svn/FishDocs/AFExcel/json/
cp ./json/*.json ~/svn/FishServer/trunk/afish/misc/json/
mv ./json/*.json ~/svn/FishClient/ClientAutoFileAF/json/
mv ./output/*.h ~/svn/FishServer/trunk/afish/libjsons/
mv ./output/*.cpp ~/svn/FishServer/trunk/afish/libjsons/
svn ci ~/svn/FishClient/ClientAutoFileAF/json/ -m ""
svn ci ~/svn/FishClient/ClientAutoFileAF/ConfigTs/ -m ""
svn ci ~/svn/FishServer/trunk/afish/misc/json/ -m ""
svn ci ~/svn/FishDocs/AFExcel/json/ -m ""
rm -rf ./xlsx
rm -rf ./output
rm -rf ./client
rm -rf ./json
# proto生成
mkdir -p ./client
mkdir -p ./output
rm -rf ./client/*
rm -rf ./output/*
svn up ~/svn/FishServer/trunk/afish/misc/excel/
./gen_pkt ~/svn/FishServer/trunk/afish/misc/excel/packet.xlsx
protoc ./output/*.proto --cpp_out=./output/ -I./output/
mv ./client/* ~/svn/FishClient/ClientAutoFileAF/proto/
svn ci ~/svn/FishClient/ClientAutoFileAF/proto/ -m ""
mv ./output/RedisProtoHelper.h ~/svn/FishServer/trunk/afish/libcommon/Include/
mv ./output/MySQLProtoHelper.h ~/svn/FishServer/trunk/afish/libcommon/Include/
mv ./output/* ~/svn/FishServer/trunk/afish/libcommon/protocol/
rm -rf ./client
rm -rf ./output
rm temp.csv
mv test.go ./misc/
svn ci ~/svn/FishServer/trunk/afish/misc/ -m ""
rm ~/svn/FishClient/ClientAutoFileAF/ConfigTs/FishRouteCFG.ts
rm ~/svn/FishClient/ClientAutoFileAF/ConfigTs/DirtyWordsCFG.ts
rm ~/svn/FishClient/ClientAutoFileAF/ConfigTs/LotteryCFG.ts
rm ~/svn/FishClient/ClientAutoFileAF/json/BossFix.json
rm ~/svn/FishClient/ClientAutoFileAF/json/Coupon.json
rm ~/svn/FishClient/ClientAutoFileAF/json/Difficulty.json
rm ~/svn/FishClient/ClientAutoFileAF/json/FishRoute.json
rm ~/svn/FishClient/ClientAutoFileAF/json/ItemRecycle.json
rm ~/svn/FishClient/ClientAutoFileAF/json/KillTax.json
rm ~/svn/FishClient/ClientAutoFileAF/json/NickName.json
rm ~/svn/FishClient/ClientAutoFileAF/json/NuclearFix.json
rm ~/svn/FishClient/ClientAutoFileAF/json/QuestRouter.json
rm ~/svn/FishClient/ClientAutoFileAF/json/Lottery.json
rm ~/svn/FishClient/ClientAutoFileAF/json/Robot.json
rm ~/svn/FishClient/ClientAutoFileAF/json/RobotArenaRank.json
rm ~/svn/FishClient/ClientAutoFileAF/json/RobotNickName.json
rm ~/svn/FishClient/ClientAutoFileAF/json/ServerFix.json
rm ~/svn/FishClient/ClientAutoFileAF/json/VoucherFix.json
rm ~/svn/FishClient/ClientAutoFileAF/json/DirtyWords.json
