## **针对用户执行GM指令**

redis保存的key `u:cmd:[userid]`

支持的指令格式为json

json 格式说明:

```json
{
    "userid" : 1234545,
    "cmd" : 12, // 命令id
    "param" : "", // 命令数据字符串
}
```
## 对应的命令与格式如下:
### 增减金币,可以有正负
`cmd = 1	param = 10000`
### 增减钻石,可以有正负
`cmd = 2	param = 10000`
### 赠送道具
`cmd = 3    param = "itemid,itemnum"`
### 加经验
`cmd = 4    param = 12345`
### 重新加载配置
`cmd = 5`
### 系统发送跑马灯
`cmd = 6    param = "content"`
### 系统时间重置
`cmd = 7    param = "0"`
### 系统时间查询
`cmd = 7`
### 系统时间设置
`cmd = 7    param = "yyyy-mm-dd-hh-mm-ss"`
### 重置用户等级经验
`cmd = 8`
### 重置vip等级经验,月卡用户相关信息
`cmd = 9`
### 重置游戏时长领取标记
`cmd = 10`
### 兑换码
`cmd = 11 param="json格式的兑换码数据"`
```json
{
    "gold" : 1000000,
	"diamond" : 5000,
    "items" :
	[
		{"item":10501001, "num":50},
		{"item":10501001, "num":50}
	]
}
```
### GM后台个人邮件
`cmd = 12 param="json格式的邮件数据"`
```json
{
    "title" : "标题",
	"content" : "正文内容",
    "items" :
	[
		{"item":10501001, "num":50},
		{"item":10501001, "num":50}
	]
}
```
