type UserInfo struct {
	UserId uint64 `json:"user_id"`
	UserOpenId string `json:"user_open_id"`
	UserName string `json:"user_name"`
	UserGold int64 `json:"user_gold"`
	UserDiamond int64 `json:"user_diamond"`
	UserCrystal int64 `json:"user_crystal"`
	UserGender int32 `json:"user_gender"`
	UserPower int32 `json:"user_power"`
	UserCurEnergy int32 `json:"user_cur_energy"`
	UserEnergyTime int64 `json:"user_energy_time"`
	UserPortrait int32 `json:"user_portrait"`
	UserSweapon int32 `json:"user_sweapon"`
	UserLevel int32 `json:"user_level"`
	UserExp int64 `json:"user_exp"`
	UserFrame int32 `json:"user_frame"`
	UserSign string `json:"user_sign"`
	UserVip int32 `json:"user_vip"`
	UserLevelReward int32 `json:"user_level_reward"`
	UserGrowthFlag uint32 `json:"user_growth_flag"`
	UserGrowthFund int32 `json:"user_growth_fund"`
	UserGrowthFundVersion int32 `json:"user_growth_fund_version"`
	UserHeroIndex int32 `json:"user_hero_index"`
	UserLastTide int32 `json:"user_last_tide"`
	UserCurTide int32 `json:"user_cur_tide"`
	UserTideTime int64 `json:"user_tide_time"`
	UserChargeLoot int32 `json:"user_charge_loot"`
	UserPhone string `json:"user_phone"`
	UserIdcard string `json:"user_idcard"`
	UserFbid string `json:"user_fbid"`
	UserArenaNum int32 `json:"user_arena_num"`
	VipExp int64 `json:"vip_exp"`
	VipGiftFlag uint32 `json:"vip_gift_flag"`
	SignedToday int32 `json:"signed_today"`
	SignDayNum int32 `json:"sign_day_num"`
	TodayPovertyNum int32 `json:"today_poverty_num"`
	TimeVideoReward int64 `json:"time_video_reward"`
	TimeRegister int64 `json:"time_register"`
	TimeLastLogin int64 `json:"time_last_login"`
	TimeOffline int64 `json:"time_offline"`
	TimeGame int64 `json:"time_game"`
	TimeOnline int64 `json:"time_online"`
	TotalCharge int64 `json:"total_charge"`
	TotalSpent uint64 `json:"total_spent"`
	TotalCoupon int64 `json:"total_coupon"`
	LastSysMailid int64 `json:"last_sys_mailid"`
	FishTableId int32 `json:"fish_table_id"`
	FishTableIndex int32 `json:"fish_table_index"`
	FishTableEndTime int64 `json:"fish_table_end_time"`
	FishCostGold int64 `json:"fish_cost_gold"`
	FishWinGold int64 `json:"fish_win_gold"`
	FishPoolGold int64 `json:"fish_pool_gold"`
	DiamondFree int64 `json:"diamond_free"`
	DiamondRmb int64 `json:"diamond_rmb"`
	ClientVersion string `json:"client_version"`
	ClientChannel string `json:"client_channel"`
	LoginNum int32 `json:"login_num"`
	TodayCoupon int32 `json:"today_coupon"`
	TodayDiamond int32 `json:"today_diamond"`
	MarketRandNum int32 `json:"market_rand_num"`
	Autoid uint64 `json:"autoid"`
	TodayOnlineTime int32 `json:"today_online_time"`
	TodayFishTime int32 `json:"today_fish_time"`
	BuyEnergyNum int32 `json:"buy_energy_num"`
	SevenDayExp int32 `json:"seven_day_exp"`
	SevenDayRewarded int32 `json:"seven_day_rewarded"`
	MaxGold int64 `json:"max_gold"`
	TotalPoverty int32 `json:"total_poverty"`
	ServerFlag uint64 `json:"server_flag"`
	NeedNewbieGift int32 `json:"need_newbie_gift"`
	NewbieFeeId int32 `json:"newbie_fee_id"`
	NewbieFeeEnd int64 `json:"newbie_fee_end"`
	NewbieFeeGold int64 `json:"newbie_fee_gold"`
	NewbieFeeCoupon int32 `json:"newbie_fee_coupon"`
	NewbieFeeDraw int32 `json:"newbie_fee_draw"`
	DrawRmbId int32 `json:"draw_rmb_id"`
	SlotFishDrawCurNum int32 `json:"slot_fish_draw_cur_num"`
	SlotFishDrawCurGold int64 `json:"slot_fish_draw_cur_gold"`
	McardEnd int64 `json:"mcard_end"`
	McardToday int32 `json:"mcard_today"`
	TodayFlag uint32 `json:"today_flag"`
	UserValue int32 `json:"user_value"`
	TotalBrokenBonus int64 `json:"total_broken_bonus"`
	TodayBrokenBonus int64 `json:"today_broken_bonus"`
	TotalChargeBonus int64 `json:"total_charge_bonus"`
	TodayChargeBonus int64 `json:"today_charge_bonus"`
	BattlePassExp int64 `json:"battle_pass_exp"`
	BattlePassVipNow int32 `json:"battle_pass_vip_now"`
	BattlePassNow int32 `json:"battle_pass_now"`
	UserChargeBonusFlag int32 `json:"user_charge_bonus_flag"`
	UserChargeBonus int64 `json:"user_charge_bonus"`
	FishPoolRate int64 `json:"fish_pool_rate"`
	FishPoolStart int64 `json:"fish_pool_start"`
	FishPoolEnd int64 `json:"fish_pool_end"`
	FishPoolInUse int32 `json:"fish_pool_in_use"`
	TodayCharge int32 `json:"today_charge"`
	FixId int32 `json:"fix_id"`
	UserProperty int32 `json:"user_property"`
	SensitiveFlag int32 `json:"sensitive_flag"`
	TotalBombValue int64 `json:"total_bomb_value"`
	PassportId int32 `json:"passport_id"`
	PassportExp int64 `json:"passport_exp"`
	PassportVipNow int32 `json:"passport_vip_now"`
	PassportNow int32 `json:"passport_now"`
	PassportExpire int64 `json:"passport_expire"`
	SummonBossPoint int64 `json:"summon_boss_point"`
	TimeWeek int64 `json:"time_week"`
	TimeMonth int64 `json:"time_month"`
	TimeMonthSuper int64 `json:"time_month_super"`
	BombActCardNum int32 `json:"bomb_act_card_num"`
	BombGamePoint int64 `json:"bomb_game_point"`
	BombTableCardNum int32 `json:"bomb_table_card_num"`
	WeekGoldWin int64 `json:"week_gold_win"`
	WeekGoldCost int64 `json:"week_gold_cost"`
	WeekBombWin int64 `json:"week_bomb_win"`
	WeekBombCost int64 `json:"week_bomb_cost"`
	WeekCrystalWin int64 `json:"week_crystal_win"`
	WeekCrystalCost int64 `json:"week_crystal_cost"`
	WeekVipScore int64 `json:"week_vip_score"`
	BossBonus string `json:"boss_bonus"`
	VoucherControl int32 `json:"voucher_control"`
	TreasureHuntId int32 `json:"treasure_hunt_id"`
	TreasureHuntNum int32 `json:"treasure_hunt_num"`
	TimeTax int64 `json:"time_tax"`
	CurFishTax int32 `json:"cur_fish_tax"`
	DrawTenNum int32 `json:"draw_ten_num"`
	DrawTenNextBig int32 `json:"draw_ten_next_big"`
	DrawTenPeriodIdx int32 `json:"draw_ten_period_idx"`
	DrawTenPeriodMax int32 `json:"draw_ten_period_max"`
	DrawTenPeriodNum int32 `json:"draw_ten_period_num"`
	DrawTenPeriodLoot int32 `json:"draw_ten_period_loot"`
	ShowLog int32 `json:"show_log"`
	GiftCode string `json:"gift_code"`
	Popularity int32 `json:"popularity"`
	TimeMuteEnd int64 `json:"time_mute_end"`
	DoubleDiamond int32 `json:"double_diamond"`
	CurBossId int32 `json:"cur_boss_id"`
	CurBossIndex int32 `json:"cur_boss_index"`
	SlotLevel int32 `json:"slot_level"`
	SlotExp int64 `json:"slot_exp"`
	SlotChip int32 `json:"slot_chip"`
}

//GetPlayerInfo get player info from redis
func (d *Dao) GetPlayerInfo(id string) (*model.PlayerInfo, error) {
	conn := d.Pool.Get()
	defer conn.Close()

	uid := "uinfo:" + id
	kv, err := redis.Values(conn.Do("HGETALL", uid))
	if err != nil {
		return nil, err
	}
	playerInfo := new(model.PlayerInfo)

	kvLen := len(kv)
	for i := 0; i < kvLen; i += 2 {
		switch kv[i].(string) {
		case "user_id":
			val, _ := strconv.ParseUint(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.UserId = uint64(val)
		case "user_open_id":
			playerInfo.UserOpenId = string(kv[i+1].([]uint8))
		case "user_name":
			playerInfo.UserName = string(kv[i+1].([]uint8))
		case "user_gold":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.UserGold = int64(val)
		case "user_diamond":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.UserDiamond = int64(val)
		case "user_crystal":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.UserCrystal = int64(val)
		case "user_gender":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.UserGender = int32(val)
		case "user_power":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.UserPower = int32(val)
		case "user_cur_energy":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.UserCurEnergy = int32(val)
		case "user_energy_time":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.UserEnergyTime = int64(val)
		case "user_portrait":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.UserPortrait = int32(val)
		case "user_sweapon":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.UserSweapon = int32(val)
		case "user_level":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.UserLevel = int32(val)
		case "user_exp":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.UserExp = int64(val)
		case "user_frame":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.UserFrame = int32(val)
		case "user_sign":
			playerInfo.UserSign = string(kv[i+1].([]uint8))
		case "user_vip":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.UserVip = int32(val)
		case "user_level_reward":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.UserLevelReward = int32(val)
		case "user_growth_flag":
			val, _ := strconv.ParseUint(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.UserGrowthFlag = uint32(val)
		case "user_growth_fund":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.UserGrowthFund = int32(val)
		case "user_growth_fund_version":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.UserGrowthFundVersion = int32(val)
		case "user_hero_index":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.UserHeroIndex = int32(val)
		case "user_last_tide":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.UserLastTide = int32(val)
		case "user_cur_tide":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.UserCurTide = int32(val)
		case "user_tide_time":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.UserTideTime = int64(val)
		case "user_charge_loot":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.UserChargeLoot = int32(val)
		case "user_phone":
			playerInfo.UserPhone = string(kv[i+1].([]uint8))
		case "user_idcard":
			playerInfo.UserIdcard = string(kv[i+1].([]uint8))
		case "user_fbid":
			playerInfo.UserFbid = string(kv[i+1].([]uint8))
		case "user_arena_num":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.UserArenaNum = int32(val)
		case "vip_exp":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.VipExp = int64(val)
		case "vip_gift_flag":
			val, _ := strconv.ParseUint(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.VipGiftFlag = uint32(val)
		case "signed_today":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.SignedToday = int32(val)
		case "sign_day_num":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.SignDayNum = int32(val)
		case "today_poverty_num":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.TodayPovertyNum = int32(val)
		case "time_video_reward":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.TimeVideoReward = int64(val)
		case "time_register":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.TimeRegister = int64(val)
		case "time_last_login":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.TimeLastLogin = int64(val)
		case "time_offline":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.TimeOffline = int64(val)
		case "time_game":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.TimeGame = int64(val)
		case "time_online":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.TimeOnline = int64(val)
		case "total_charge":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.TotalCharge = int64(val)
		case "total_spent":
			val, _ := strconv.ParseUint(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.TotalSpent = uint64(val)
		case "total_coupon":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.TotalCoupon = int64(val)
		case "last_sys_mailid":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.LastSysMailid = int64(val)
		case "fish_table_id":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.FishTableId = int32(val)
		case "fish_table_index":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.FishTableIndex = int32(val)
		case "fish_table_end_time":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.FishTableEndTime = int64(val)
		case "fish_cost_gold":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.FishCostGold = int64(val)
		case "fish_win_gold":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.FishWinGold = int64(val)
		case "fish_pool_gold":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.FishPoolGold = int64(val)
		case "diamond_free":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.DiamondFree = int64(val)
		case "diamond_rmb":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.DiamondRmb = int64(val)
		case "client_version":
			playerInfo.ClientVersion = string(kv[i+1].([]uint8))
		case "client_channel":
			playerInfo.ClientChannel = string(kv[i+1].([]uint8))
		case "login_num":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.LoginNum = int32(val)
		case "today_coupon":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.TodayCoupon = int32(val)
		case "today_diamond":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.TodayDiamond = int32(val)
		case "market_rand_num":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.MarketRandNum = int32(val)
		case "autoid":
			val, _ := strconv.ParseUint(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.Autoid = uint64(val)
		case "today_online_time":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.TodayOnlineTime = int32(val)
		case "today_fish_time":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.TodayFishTime = int32(val)
		case "buy_energy_num":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.BuyEnergyNum = int32(val)
		case "seven_day_exp":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.SevenDayExp = int32(val)
		case "seven_day_rewarded":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.SevenDayRewarded = int32(val)
		case "max_gold":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.MaxGold = int64(val)
		case "total_poverty":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.TotalPoverty = int32(val)
		case "server_flag":
			val, _ := strconv.ParseUint(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.ServerFlag = uint64(val)
		case "need_newbie_gift":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.NeedNewbieGift = int32(val)
		case "newbie_fee_id":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.NewbieFeeId = int32(val)
		case "newbie_fee_end":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.NewbieFeeEnd = int64(val)
		case "newbie_fee_gold":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.NewbieFeeGold = int64(val)
		case "newbie_fee_coupon":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.NewbieFeeCoupon = int32(val)
		case "newbie_fee_draw":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.NewbieFeeDraw = int32(val)
		case "draw_rmb_id":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.DrawRmbId = int32(val)
		case "slot_fish_draw_cur_num":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.SlotFishDrawCurNum = int32(val)
		case "slot_fish_draw_cur_gold":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.SlotFishDrawCurGold = int64(val)
		case "mcard_end":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.McardEnd = int64(val)
		case "mcard_today":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.McardToday = int32(val)
		case "today_flag":
			val, _ := strconv.ParseUint(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.TodayFlag = uint32(val)
		case "user_value":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.UserValue = int32(val)
		case "total_broken_bonus":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.TotalBrokenBonus = int64(val)
		case "today_broken_bonus":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.TodayBrokenBonus = int64(val)
		case "total_charge_bonus":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.TotalChargeBonus = int64(val)
		case "today_charge_bonus":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.TodayChargeBonus = int64(val)
		case "battle_pass_exp":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.BattlePassExp = int64(val)
		case "battle_pass_vip_now":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.BattlePassVipNow = int32(val)
		case "battle_pass_now":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.BattlePassNow = int32(val)
		case "user_charge_bonus_flag":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.UserChargeBonusFlag = int32(val)
		case "user_charge_bonus":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.UserChargeBonus = int64(val)
		case "fish_pool_rate":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.FishPoolRate = int64(val)
		case "fish_pool_start":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.FishPoolStart = int64(val)
		case "fish_pool_end":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.FishPoolEnd = int64(val)
		case "fish_pool_in_use":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.FishPoolInUse = int32(val)
		case "today_charge":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.TodayCharge = int32(val)
		case "fix_id":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.FixId = int32(val)
		case "user_property":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.UserProperty = int32(val)
		case "sensitive_flag":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.SensitiveFlag = int32(val)
		case "total_bomb_value":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.TotalBombValue = int64(val)
		case "passport_id":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.PassportId = int32(val)
		case "passport_exp":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.PassportExp = int64(val)
		case "passport_vip_now":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.PassportVipNow = int32(val)
		case "passport_now":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.PassportNow = int32(val)
		case "passport_expire":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.PassportExpire = int64(val)
		case "summon_boss_point":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.SummonBossPoint = int64(val)
		case "time_week":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.TimeWeek = int64(val)
		case "time_month":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.TimeMonth = int64(val)
		case "time_month_super":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.TimeMonthSuper = int64(val)
		case "bomb_act_card_num":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.BombActCardNum = int32(val)
		case "bomb_game_point":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.BombGamePoint = int64(val)
		case "bomb_table_card_num":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.BombTableCardNum = int32(val)
		case "week_gold_win":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.WeekGoldWin = int64(val)
		case "week_gold_cost":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.WeekGoldCost = int64(val)
		case "week_bomb_win":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.WeekBombWin = int64(val)
		case "week_bomb_cost":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.WeekBombCost = int64(val)
		case "week_crystal_win":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.WeekCrystalWin = int64(val)
		case "week_crystal_cost":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.WeekCrystalCost = int64(val)
		case "week_vip_score":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.WeekVipScore = int64(val)
		case "boss_bonus":
			playerInfo.BossBonus = string(kv[i+1].([]uint8))
		case "voucher_control":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.VoucherControl = int32(val)
		case "treasure_hunt_id":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.TreasureHuntId = int32(val)
		case "treasure_hunt_num":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.TreasureHuntNum = int32(val)
		case "time_tax":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.TimeTax = int64(val)
		case "cur_fish_tax":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.CurFishTax = int32(val)
		case "draw_ten_num":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.DrawTenNum = int32(val)
		case "draw_ten_next_big":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.DrawTenNextBig = int32(val)
		case "draw_ten_period_idx":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.DrawTenPeriodIdx = int32(val)
		case "draw_ten_period_max":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.DrawTenPeriodMax = int32(val)
		case "draw_ten_period_num":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.DrawTenPeriodNum = int32(val)
		case "draw_ten_period_loot":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.DrawTenPeriodLoot = int32(val)
		case "show_log":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.ShowLog = int32(val)
		case "gift_code":
			playerInfo.GiftCode = string(kv[i+1].([]uint8))
		case "popularity":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.Popularity = int32(val)
		case "time_mute_end":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.TimeMuteEnd = int64(val)
		case "double_diamond":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.DoubleDiamond = int32(val)
		case "cur_boss_id":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.CurBossId = int32(val)
		case "cur_boss_index":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.CurBossIndex = int32(val)
		case "slot_level":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.SlotLevel = int32(val)
		case "slot_exp":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.SlotExp = int64(val)
		case "slot_chip":
			val, _ := strconv.ParseInt(string(kv[i+1].([]uint8)), 10, 64)
			playerInfo.SlotChip = int32(val)
		}
	}
	return playerInfo, nil
}

<a-descriptions-item label="用户id">{{ userInfo.user_id }}</a-descriptions-item>
<a-descriptions-item label="用户openid">{{ userInfo.user_open_id }}</a-descriptions-item>
<a-descriptions-item label="昵称">{{ userInfo.user_name }}</a-descriptions-item>
<a-descriptions-item label="当前金币数量">{{ userInfo.user_gold }}</a-descriptions-item>
<a-descriptions-item label="当前钻石数量">{{ userInfo.user_diamond }}</a-descriptions-item>
<a-descriptions-item label="当前魔晶数量">{{ userInfo.user_crystal }}</a-descriptions-item>
<a-descriptions-item label="性别">{{ userInfo.user_gender }}</a-descriptions-item>
<a-descriptions-item label="当前战力">{{ userInfo.user_power }}</a-descriptions-item>
<a-descriptions-item label="当前能量值,用于休闲场">{{ userInfo.user_cur_energy }}</a-descriptions-item>
<a-descriptions-item label="上次增加能量值的时间点">{{ userInfo.user_energy_time }}</a-descriptions-item>
<a-descriptions-item label="头像">{{ userInfo.user_portrait }}</a-descriptions-item>
<a-descriptions-item label="当前使用的超级武器皮肤">{{ userInfo.user_sweapon }}</a-descriptions-item>
<a-descriptions-item label="用户当前等级">{{ userInfo.user_level }}</a-descriptions-item>
<a-descriptions-item label="用户当前经验">{{ userInfo.user_exp }}</a-descriptions-item>
<a-descriptions-item label="头像框对应的道具id">{{ userInfo.user_frame }}</a-descriptions-item>
<a-descriptions-item label="用户签名">{{ userInfo.user_sign }}</a-descriptions-item>
<a-descriptions-item label="vip等级">{{ userInfo.user_vip }}</a-descriptions-item>
<a-descriptions-item label="当前等级礼包领取到的等级">{{ userInfo.user_level_reward }}</a-descriptions-item>
<a-descriptions-item label="领取成长基金标记">{{ userInfo.user_growth_flag }}</a-descriptions-item>
<a-descriptions-item label="是否购买过成长基金商品">{{ userInfo.user_growth_fund }}</a-descriptions-item>
<a-descriptions-item label="成长基金当前版本">{{ userInfo.user_growth_fund_version }}</a-descriptions-item>
<a-descriptions-item label="当前使用的英雄id">{{ userInfo.user_hero_index }}</a-descriptions-item>
<a-descriptions-item label="玩家昨日鱼潮关卡">{{ userInfo.user_last_tide }}</a-descriptions-item>
<a-descriptions-item label="玩家今日鱼潮关卡">{{ userInfo.user_cur_tide }}</a-descriptions-item>
<a-descriptions-item label="玩家上次鱼潮关卡通关时间">{{ userInfo.user_tide_time }}</a-descriptions-item>
<a-descriptions-item label="玩家是否获得过首充奖励">{{ userInfo.user_charge_loot }}</a-descriptions-item>
<a-descriptions-item label="玩家绑定的手机号">{{ userInfo.user_phone }}</a-descriptions-item>
<a-descriptions-item label="玩家绑定的身份证">{{ userInfo.user_idcard }}</a-descriptions-item>
<a-descriptions-item label="玩家绑定的facebook账号">{{ userInfo.user_fbid }}</a-descriptions-item>
<a-descriptions-item label="今日竞技场次数">{{ userInfo.user_arena_num }}</a-descriptions-item>
<a-descriptions-item label="当前vip经验">{{ userInfo.vip_exp }}</a-descriptions-item>
<a-descriptions-item label="vip特权礼包购买标记">{{ userInfo.vip_gift_flag }}</a-descriptions-item>
<a-descriptions-item label="今日是否进行过7日累计签到">{{ userInfo.signed_today }}</a-descriptions-item>
<a-descriptions-item label="7日签到累计次数">{{ userInfo.sign_day_num }}</a-descriptions-item>
<a-descriptions-item label="今日破产次数">{{ userInfo.today_poverty_num }}</a-descriptions-item>
<a-descriptions-item label="上次领取看视频奖励时间">{{ userInfo.time_video_reward }}</a-descriptions-item>
<a-descriptions-item label="注册时间">{{ userInfo.time_register }}</a-descriptions-item>
<a-descriptions-item label="上次登录时间">{{ userInfo.time_last_login }}</a-descriptions-item>
<a-descriptions-item label="上次离线时间">{{ userInfo.time_offline }}</a-descriptions-item>
<a-descriptions-item label="用户累计游戏时长">{{ userInfo.time_game }}</a-descriptions-item>
<a-descriptions-item label="用户累计在线时长">{{ userInfo.time_online }}</a-descriptions-item>
<a-descriptions-item label="总充值数量">{{ userInfo.total_charge }}</a-descriptions-item>
<a-descriptions-item label="用户消耗总钻石">{{ userInfo.total_spent }}</a-descriptions-item>
<a-descriptions-item label="礼券累计总值">{{ userInfo.total_coupon }}</a-descriptions-item>
<a-descriptions-item label="上次发送过的系统邮件id">{{ userInfo.last_sys_mailid }}</a-descriptions-item>
<a-descriptions-item label="渔场唯一id">{{ userInfo.fish_table_id }}</a-descriptions-item>
<a-descriptions-item label="渔场配置id">{{ userInfo.fish_table_index }}</a-descriptions-item>
<a-descriptions-item label="当前渔场结束时间(无结束时间时为-1)">{{ userInfo.fish_table_end_time }}</a-descriptions-item>
<a-descriptions-item label="渔场中消耗的金币">{{ userInfo.fish_cost_gold }}</a-descriptions-item>
<a-descriptions-item label="渔场中赚取的金币">{{ userInfo.fish_win_gold }}</a-descriptions-item>
<a-descriptions-item label="玩家自身累计奖池">{{ userInfo.fish_pool_gold }}</a-descriptions-item>
<a-descriptions-item label="免费钻石">{{ userInfo.diamond_free }}</a-descriptions-item>
<a-descriptions-item label="付费钻石">{{ userInfo.diamond_rmb }}</a-descriptions-item>
<a-descriptions-item label="客户端版本号">{{ userInfo.client_version }}</a-descriptions-item>
<a-descriptions-item label="客户端渠道号">{{ userInfo.client_channel }}</a-descriptions-item>
<a-descriptions-item label="累计登录次数">{{ userInfo.login_num }}</a-descriptions-item>
<a-descriptions-item label="当日累计获得奖券数量">{{ userInfo.today_coupon }}</a-descriptions-item>
<a-descriptions-item label="当日累计获得钻石数量">{{ userInfo.today_diamond }}</a-descriptions-item>
<a-descriptions-item label="今日宝库刷新次数">{{ userInfo.market_rand_num }}</a-descriptions-item>
<a-descriptions-item label="用户自身id">{{ userInfo.autoid }}</a-descriptions-item>
<a-descriptions-item label="今日累计在线时长">{{ userInfo.today_online_time }}</a-descriptions-item>
<a-descriptions-item label="今日累计捕鱼时长">{{ userInfo.today_fish_time }}</a-descriptions-item>
<a-descriptions-item label="今日购买休闲场钥匙次数">{{ userInfo.buy_energy_num }}</a-descriptions-item>
<a-descriptions-item label="7日任务累计经验">{{ userInfo.seven_day_exp }}</a-descriptions-item>
<a-descriptions-item label="7日任务累计礼包是否领取">{{ userInfo.seven_day_rewarded }}</a-descriptions-item>
<a-descriptions-item label="用户持有过的金币峰值">{{ userInfo.max_gold }}</a-descriptions-item>
<a-descriptions-item label="用户破产次数">{{ userInfo.total_poverty }}</a-descriptions-item>
<a-descriptions-item label="用户服务器标记">{{ userInfo.server_flag }}</a-descriptions-item>
<a-descriptions-item label="是否可以领取起航礼包">{{ userInfo.need_newbie_gift }}</a-descriptions-item>
<a-descriptions-item label="新手话费红包活动id">{{ userInfo.newbie_fee_id }}</a-descriptions-item>
<a-descriptions-item label="新手话费红包结束时间">{{ userInfo.newbie_fee_end }}</a-descriptions-item>
<a-descriptions-item label="新手话费红包活动当前累计消耗金币">{{ userInfo.newbie_fee_gold }}</a-descriptions-item>
<a-descriptions-item label="新手话费红包活动已经领取的话费券数量">{{ userInfo.newbie_fee_coupon }}</a-descriptions-item>
<a-descriptions-item label="新手话费红包阶段奖励领取次数">{{ userInfo.newbie_fee_draw }}</a-descriptions-item>
<a-descriptions-item label="兑换券抽话费活动id">{{ userInfo.draw_rmb_id }}</a-descriptions-item>
<a-descriptions-item label="累计捕鱼奖池抽奖条件1当前数量">{{ userInfo.slot_fish_draw_cur_num }}</a-descriptions-item>
<a-descriptions-item label="累计捕鱼奖池抽奖当前累计金币">{{ userInfo.slot_fish_draw_cur_gold }}</a-descriptions-item>
<a-descriptions-item label="月卡到期时间">{{ userInfo.mcard_end }}</a-descriptions-item>
<a-descriptions-item label="今日是否领取过月卡奖励">{{ userInfo.mcard_today }}</a-descriptions-item>
<a-descriptions-item label="日标记,跨天清空">{{ userInfo.today_flag }}</a-descriptions-item>
<a-descriptions-item label="用户价值">{{ userInfo.user_value }}</a-descriptions-item>
<a-descriptions-item label="破产保护机制获得的金币总值">{{ userInfo.total_broken_bonus }}</a-descriptions-item>
<a-descriptions-item label="今日破产保护机制获得的金币总值">{{ userInfo.today_broken_bonus }}</a-descriptions-item>
<a-descriptions-item label="充值带来的破产保护累计额度">{{ userInfo.total_charge_bonus }}</a-descriptions-item>
<a-descriptions-item label="今日充值带来的破产保护累计额度">{{ userInfo.today_charge_bonus }}</a-descriptions-item>
<a-descriptions-item label="通行证经验">{{ userInfo.battle_pass_exp }}</a-descriptions-item>
<a-descriptions-item label="通行证vip领取到的等级,-1表示未购买vip通行证">{{ userInfo.battle_pass_vip_now }}</a-descriptions-item>
<a-descriptions-item label="通行证普通领取到的等级">{{ userInfo.battle_pass_now }}</a-descriptions-item>
<a-descriptions-item label="充值福利标记,true使用区间控分,false使用感受值控分">{{ userInfo.user_charge_bonus_flag }}</a-descriptions-item>
<a-descriptions-item label="充值获得的p值">{{ userInfo.user_charge_bonus }}</a-descriptions-item>
<a-descriptions-item label="奖池抽水率,需要/100">{{ userInfo.fish_pool_rate }}</a-descriptions-item>
<a-descriptions-item label="奖池释放基准点">{{ userInfo.fish_pool_start }}</a-descriptions-item>
<a-descriptions-item label="奖池释放结束点">{{ userInfo.fish_pool_end }}</a-descriptions-item>
<a-descriptions-item label="奖池是否正在释放">{{ userInfo.fish_pool_in_use }}</a-descriptions-item>
<a-descriptions-item label="当日累计充值">{{ userInfo.today_charge }}</a-descriptions-item>
<a-descriptions-item label="修正id">{{ userInfo.fix_id }}</a-descriptions-item>
<a-descriptions-item label="玩家资产面板">{{ userInfo.user_property }}</a-descriptions-item>
<a-descriptions-item label="敏感系统关闭标记">{{ userInfo.sensitive_flag }}</a-descriptions-item>
<a-descriptions-item label="核弹价值">{{ userInfo.total_bomb_value }}</a-descriptions-item>
<a-descriptions-item label="月度通行证编号">{{ userInfo.passport_id }}</a-descriptions-item>
<a-descriptions-item label="月度通行证当前经验">{{ userInfo.passport_exp }}</a-descriptions-item>
<a-descriptions-item label="月度通行证vip领取到的等级,-1表示未购买vip通行证">{{ userInfo.passport_vip_now }}</a-descriptions-item>
<a-descriptions-item label="月度通行证免费领取到的等级">{{ userInfo.passport_now }}</a-descriptions-item>
<a-descriptions-item label="月度通行证过期时间">{{ userInfo.passport_expire }}</a-descriptions-item>
<a-descriptions-item label="召唤boss当前净分">{{ userInfo.summon_boss_point }}</a-descriptions-item>
<a-descriptions-item label="周卡到期时间">{{ userInfo.time_week }}</a-descriptions-item>
<a-descriptions-item label="月卡到期时间">{{ userInfo.time_month }}</a-descriptions-item>
<a-descriptions-item label="超值月卡到期时间">{{ userInfo.time_month_super }}</a-descriptions-item>
<a-descriptions-item label="当日剩余核弹翻牌活动次数">{{ userInfo.bomb_act_card_num }}</a-descriptions-item>
<a-descriptions-item label="核弹场净分">{{ userInfo.bomb_game_point }}</a-descriptions-item>
<a-descriptions-item label="三国卡牌场翻牌次数">{{ userInfo.bomb_table_card_num }}</a-descriptions-item>
<a-descriptions-item label="金币获得">{{ userInfo.week_gold_win }}</a-descriptions-item>
<a-descriptions-item label="金币消耗">{{ userInfo.week_gold_cost }}</a-descriptions-item>
<a-descriptions-item label="核弹获得">{{ userInfo.week_bomb_win }}</a-descriptions-item>
<a-descriptions-item label="核弹消耗">{{ userInfo.week_bomb_cost }}</a-descriptions-item>
<a-descriptions-item label="魔晶获得">{{ userInfo.week_crystal_win }}</a-descriptions-item>
<a-descriptions-item label="魔晶消耗">{{ userInfo.week_crystal_cost }}</a-descriptions-item>
<a-descriptions-item label="vip积分">{{ userInfo.week_vip_score }}</a-descriptions-item>
<a-descriptions-item label="用竖线分隔的boss福利">{{ userInfo.boss_bonus }}</a-descriptions-item>
<a-descriptions-item label="话费控制">{{ userInfo.voucher_control }}</a-descriptions-item>
<a-descriptions-item label="宝藏活动id">{{ userInfo.treasure_hunt_id }}</a-descriptions-item>
<a-descriptions-item label="本轮次内寻宝次数">{{ userInfo.treasure_hunt_num }}</a-descriptions-item>
<a-descriptions-item label="下次税率随机时间">{{ userInfo.time_tax }}</a-descriptions-item>
<a-descriptions-item label="当前捕鱼税率,需要除以10000">{{ userInfo.cur_fish_tax }}</a-descriptions-item>
<a-descriptions-item label="十连抽次数">{{ userInfo.draw_ten_num }}</a-descriptions-item>
<a-descriptions-item label="下次特殊奖池需要的次数">{{ userInfo.draw_ten_next_big }}</a-descriptions-item>
<a-descriptions-item label="十连抽次数奖励当前索引">{{ userInfo.draw_ten_period_idx }}</a-descriptions-item>
<a-descriptions-item label="十连抽次数奖励需求总数">{{ userInfo.draw_ten_period_max }}</a-descriptions-item>
<a-descriptions-item label="十连抽次数奖励当前总数">{{ userInfo.draw_ten_period_num }}</a-descriptions-item>
<a-descriptions-item label="十连抽次数奖励内容">{{ userInfo.draw_ten_period_loot }}</a-descriptions-item>
<a-descriptions-item label="显示日志">{{ userInfo.show_log }}</a-descriptions-item>
<a-descriptions-item label="礼物系统密码">{{ userInfo.gift_code }}</a-descriptions-item>
<a-descriptions-item label="人气">{{ userInfo.popularity }}</a-descriptions-item>
<a-descriptions-item label="禁言结束时间,0表示未禁言">{{ userInfo.time_mute_end }}</a-descriptions-item>
<a-descriptions-item label="钻石充值赠送双倍的次数">{{ userInfo.double_diamond }}</a-descriptions-item>
<a-descriptions-item label="渔场中召唤的bossid">{{ userInfo.cur_boss_id }}</a-descriptions-item>
<a-descriptions-item label="渔场中召唤的boss编号">{{ userInfo.cur_boss_index }}</a-descriptions-item>
<a-descriptions-item label="聚宝盆等级">{{ userInfo.slot_level }}</a-descriptions-item>
<a-descriptions-item label="聚宝盆当前经验">{{ userInfo.slot_exp }}</a-descriptions-item>
<a-descriptions-item label="单注筹码">{{ userInfo.slot_chip }}</a-descriptions-item>
