#pragma once

#include "JsonSystemConst.h"
#include "JsonErrorCode.h"
#include "JsonCardRelation.h"
#include "JsonCouponDraw.h"
#include "JsonQuest.h"
#include "JsonLoot.h"
#include "JsonQuickPlay.h"
#include "JsonVIP.h"
#include "JsonSystemEntrance.h"
#include "JsonHeroStar.h"
#include "JsonVoucherFix.h"
#include "JsonFishData.h"
#include "JsonSummonRankReward.h"
#include "JsonServerFix.h"
#include "JsonLevel.h"
#include "JsonPeriodPass.h"
#include "JsonItemRecycle.h"
#include "JsonGamePlay.h"
#include "JsonSkill.h"
#include "JsonInstituteLevel.h"
#include "JsonRedEnvelope.h"
#include "JsonWingData.h"
#include "JsonChannelConfig.h"
#include "JsonTurnTable.h"
#include "JsonBattlePass.h"
#include "JsonRankReward.h"
#include "JsonExchange.h"
#include "JsonKillTax.h"
#include "JsonFishPool.h"
#include "JsonHeroLevel.h"
#include "JsonDifficulty.h"
#include "JsonLocalization.h"
#include "JsonMarket.h"
#include "JsonCard.h"
#include "JsonHeroRelation.h"
#include "JsonDiamondTimes.h"
#include "JsonMonthCard.h"
#include "JsonArenaReward.h"
#include "JsonFishModel.h"
#include "JsonRobotArenaRank.h"
#include "JsonFishGroup.h"
#include "JsonAnnouncement.h"
#include "JsonCharge.h"
#include "JsonNickName.h"
#include "JsonSlotDraw.h"
#include "JsonGeneralTask.h"
#include "JsonWingAttribute.h"
#include "JsonCoupon.h"
#include "JsonSignReward.h"
#include "JsonLottery.h"
#include "JsonMenghuoBattle.h"
#include "JsonQuestRouter.h"
#include "JsonDirtyWords.h"
#include "JsonRobot.h"
#include "JsonNewBieCarnival.h"
#include "JsonFishRoute.h"
#include "JsonNuclearFix.h"
#include "JsonHeroAttribute.h"
#include "JsonHeroSet.h"
#include "JsonActivities.h"
#include "JsonFishShoal.h"
#include "JsonItem.h"
#include "JsonRobotNickName.h"
#include "JsonTurretModel.h"
#include "JsonPeriodPassControl.h"
#include "JsonInstitute.h"
#include "JsonBossFix.h"
#include "JsonBuff.h"
#include "JsonTreasureHunt.h"
#include "JsonFishGenerator.h"
#include "JsonMail.h"
#include "JsonFishBullet.h"
#include "JsonFishFunction.h"
#include "JsonSwingModel.h"

class JsonConfig {
public:
	JsonCardRelation* CardRelationPtr() { return &_CardRelation; }
	JsonCouponDraw* CouponDrawPtr() { return &_CouponDraw; }
	JsonQuest* QuestPtr() { return &_Quest; }
	JsonLoot* LootPtr() { return &_Loot; }
	JsonQuickPlay* QuickPlayPtr() { return &_QuickPlay; }
	JsonVIP* VIPPtr() { return &_VIP; }
	JsonSystemEntrance* SystemEntrancePtr() { return &_SystemEntrance; }
	JsonHeroStar* HeroStarPtr() { return &_HeroStar; }
	JsonVoucherFix* VoucherFixPtr() { return &_VoucherFix; }
	JsonFishData* FishDataPtr() { return &_FishData; }
	JsonSummonRankReward* SummonRankRewardPtr() { return &_SummonRankReward; }
	JsonServerFix* ServerFixPtr() { return &_ServerFix; }
	JsonLevel* LevelPtr() { return &_Level; }
	JsonPeriodPass* PeriodPassPtr() { return &_PeriodPass; }
	JsonItemRecycle* ItemRecyclePtr() { return &_ItemRecycle; }
	JsonGamePlay* GamePlayPtr() { return &_GamePlay; }
	JsonSkill* SkillPtr() { return &_Skill; }
	JsonInstituteLevel* InstituteLevelPtr() { return &_InstituteLevel; }
	JsonRedEnvelope* RedEnvelopePtr() { return &_RedEnvelope; }
	JsonWingData* WingDataPtr() { return &_WingData; }
	JsonChannelConfig* ChannelConfigPtr() { return &_ChannelConfig; }
	JsonTurnTable* TurnTablePtr() { return &_TurnTable; }
	JsonBattlePass* BattlePassPtr() { return &_BattlePass; }
	JsonRankReward* RankRewardPtr() { return &_RankReward; }
	JsonExchange* ExchangePtr() { return &_Exchange; }
	JsonKillTax* KillTaxPtr() { return &_KillTax; }
	JsonFishPool* FishPoolPtr() { return &_FishPool; }
	JsonHeroLevel* HeroLevelPtr() { return &_HeroLevel; }
	JsonDifficulty* DifficultyPtr() { return &_Difficulty; }
	JsonLocalization* LocalizationPtr() { return &_Localization; }
	JsonMarket* MarketPtr() { return &_Market; }
	JsonCard* CardPtr() { return &_Card; }
	JsonHeroRelation* HeroRelationPtr() { return &_HeroRelation; }
	JsonDiamondTimes* DiamondTimesPtr() { return &_DiamondTimes; }
	JsonMonthCard* MonthCardPtr() { return &_MonthCard; }
	JsonArenaReward* ArenaRewardPtr() { return &_ArenaReward; }
	JsonFishModel* FishModelPtr() { return &_FishModel; }
	JsonRobotArenaRank* RobotArenaRankPtr() { return &_RobotArenaRank; }
	JsonFishGroup* FishGroupPtr() { return &_FishGroup; }
	JsonAnnouncement* AnnouncementPtr() { return &_Announcement; }
	JsonCharge* ChargePtr() { return &_Charge; }
	JsonNickName* NickNamePtr() { return &_NickName; }
	JsonSlotDraw* SlotDrawPtr() { return &_SlotDraw; }
	JsonGeneralTask* GeneralTaskPtr() { return &_GeneralTask; }
	JsonWingAttribute* WingAttributePtr() { return &_WingAttribute; }
	JsonCoupon* CouponPtr() { return &_Coupon; }
	JsonSignReward* SignRewardPtr() { return &_SignReward; }
	JsonLottery* LotteryPtr() { return &_Lottery; }
	JsonMenghuoBattle* MenghuoBattlePtr() { return &_MenghuoBattle; }
	JsonQuestRouter* QuestRouterPtr() { return &_QuestRouter; }
	JsonDirtyWords* DirtyWordsPtr() { return &_DirtyWords; }
	JsonRobot* RobotPtr() { return &_Robot; }
	JsonNewBieCarnival* NewBieCarnivalPtr() { return &_NewBieCarnival; }
	JsonFishRoute* FishRoutePtr() { return &_FishRoute; }
	JsonNuclearFix* NuclearFixPtr() { return &_NuclearFix; }
	JsonHeroAttribute* HeroAttributePtr() { return &_HeroAttribute; }
	JsonHeroSet* HeroSetPtr() { return &_HeroSet; }
	JsonActivities* ActivitiesPtr() { return &_Activities; }
	JsonFishShoal* FishShoalPtr() { return &_FishShoal; }
	JsonItem* ItemPtr() { return &_Item; }
	JsonRobotNickName* RobotNickNamePtr() { return &_RobotNickName; }
	JsonTurretModel* TurretModelPtr() { return &_TurretModel; }
	JsonPeriodPassControl* PeriodPassControlPtr() { return &_PeriodPassControl; }
	JsonInstitute* InstitutePtr() { return &_Institute; }
	JsonBossFix* BossFixPtr() { return &_BossFix; }
	JsonBuff* BuffPtr() { return &_Buff; }
	JsonTreasureHunt* TreasureHuntPtr() { return &_TreasureHunt; }
	JsonFishGenerator* FishGeneratorPtr() { return &_FishGenerator; }
	JsonMail* MailPtr() { return &_Mail; }
	JsonFishBullet* FishBulletPtr() { return &_FishBullet; }
	JsonFishFunction* FishFunctionPtr() { return &_FishFunction; }
	JsonSwingModel* SwingModelPtr() { return &_SwingModel; }
	JsonSystemConst* SystemConstPtr() { return &_SystemConst; }
	JsonErrorCode* ErrorCodePtr() { return &_ErrorCode; }
private:
	JsonCardRelation _CardRelation;
	JsonCouponDraw _CouponDraw;
	JsonQuest _Quest;
	JsonLoot _Loot;
	JsonQuickPlay _QuickPlay;
	JsonVIP _VIP;
	JsonSystemEntrance _SystemEntrance;
	JsonHeroStar _HeroStar;
	JsonVoucherFix _VoucherFix;
	JsonFishData _FishData;
	JsonSummonRankReward _SummonRankReward;
	JsonServerFix _ServerFix;
	JsonLevel _Level;
	JsonPeriodPass _PeriodPass;
	JsonItemRecycle _ItemRecycle;
	JsonGamePlay _GamePlay;
	JsonSkill _Skill;
	JsonInstituteLevel _InstituteLevel;
	JsonRedEnvelope _RedEnvelope;
	JsonWingData _WingData;
	JsonChannelConfig _ChannelConfig;
	JsonTurnTable _TurnTable;
	JsonBattlePass _BattlePass;
	JsonRankReward _RankReward;
	JsonExchange _Exchange;
	JsonKillTax _KillTax;
	JsonFishPool _FishPool;
	JsonHeroLevel _HeroLevel;
	JsonDifficulty _Difficulty;
	JsonLocalization _Localization;
	JsonMarket _Market;
	JsonCard _Card;
	JsonHeroRelation _HeroRelation;
	JsonDiamondTimes _DiamondTimes;
	JsonMonthCard _MonthCard;
	JsonArenaReward _ArenaReward;
	JsonFishModel _FishModel;
	JsonRobotArenaRank _RobotArenaRank;
	JsonFishGroup _FishGroup;
	JsonAnnouncement _Announcement;
	JsonCharge _Charge;
	JsonNickName _NickName;
	JsonSlotDraw _SlotDraw;
	JsonGeneralTask _GeneralTask;
	JsonWingAttribute _WingAttribute;
	JsonCoupon _Coupon;
	JsonSignReward _SignReward;
	JsonLottery _Lottery;
	JsonMenghuoBattle _MenghuoBattle;
	JsonQuestRouter _QuestRouter;
	JsonDirtyWords _DirtyWords;
	JsonRobot _Robot;
	JsonNewBieCarnival _NewBieCarnival;
	JsonFishRoute _FishRoute;
	JsonNuclearFix _NuclearFix;
	JsonHeroAttribute _HeroAttribute;
	JsonHeroSet _HeroSet;
	JsonActivities _Activities;
	JsonFishShoal _FishShoal;
	JsonItem _Item;
	JsonRobotNickName _RobotNickName;
	JsonTurretModel _TurretModel;
	JsonPeriodPassControl _PeriodPassControl;
	JsonInstitute _Institute;
	JsonBossFix _BossFix;
	JsonBuff _Buff;
	JsonTreasureHunt _TreasureHunt;
	JsonFishGenerator _FishGenerator;
	JsonMail _Mail;
	JsonFishBullet _FishBullet;
	JsonFishFunction _FishFunction;
	JsonSwingModel _SwingModel;
	JsonSystemConst _SystemConst;
	JsonErrorCode _ErrorCode;
public:
	bool LoadAll(const string& path) {
		if( !LoadOne(path, "CardRelation") ) { return false; }
		if( !LoadOne(path, "CouponDraw") ) { return false; }
		if( !LoadOne(path, "Quest") ) { return false; }
		if( !LoadOne(path, "Loot") ) { return false; }
		if( !LoadOne(path, "QuickPlay") ) { return false; }
		if( !LoadOne(path, "VIP") ) { return false; }
		if( !LoadOne(path, "SystemEntrance") ) { return false; }
		if( !LoadOne(path, "HeroStar") ) { return false; }
		if( !LoadOne(path, "VoucherFix") ) { return false; }
		if( !LoadOne(path, "FishData") ) { return false; }
		if( !LoadOne(path, "SummonRankReward") ) { return false; }
		if( !LoadOne(path, "ServerFix") ) { return false; }
		if( !LoadOne(path, "Level") ) { return false; }
		if( !LoadOne(path, "PeriodPass") ) { return false; }
		if( !LoadOne(path, "ItemRecycle") ) { return false; }
		if( !LoadOne(path, "GamePlay") ) { return false; }
		if( !LoadOne(path, "Skill") ) { return false; }
		if( !LoadOne(path, "InstituteLevel") ) { return false; }
		if( !LoadOne(path, "RedEnvelope") ) { return false; }
		if( !LoadOne(path, "WingData") ) { return false; }
		if( !LoadOne(path, "ChannelConfig") ) { return false; }
		if( !LoadOne(path, "TurnTable") ) { return false; }
		if( !LoadOne(path, "BattlePass") ) { return false; }
		if( !LoadOne(path, "RankReward") ) { return false; }
		if( !LoadOne(path, "Exchange") ) { return false; }
		if( !LoadOne(path, "KillTax") ) { return false; }
		if( !LoadOne(path, "FishPool") ) { return false; }
		if( !LoadOne(path, "HeroLevel") ) { return false; }
		if( !LoadOne(path, "Difficulty") ) { return false; }
		if( !LoadOne(path, "Localization") ) { return false; }
		if( !LoadOne(path, "Market") ) { return false; }
		if( !LoadOne(path, "Card") ) { return false; }
		if( !LoadOne(path, "HeroRelation") ) { return false; }
		if( !LoadOne(path, "DiamondTimes") ) { return false; }
		if( !LoadOne(path, "MonthCard") ) { return false; }
		if( !LoadOne(path, "ArenaReward") ) { return false; }
		if( !LoadOne(path, "FishModel") ) { return false; }
		if( !LoadOne(path, "RobotArenaRank") ) { return false; }
		if( !LoadOne(path, "FishGroup") ) { return false; }
		if( !LoadOne(path, "Announcement") ) { return false; }
		if( !LoadOne(path, "Charge") ) { return false; }
		if( !LoadOne(path, "NickName") ) { return false; }
		if( !LoadOne(path, "SlotDraw") ) { return false; }
		if( !LoadOne(path, "GeneralTask") ) { return false; }
		if( !LoadOne(path, "WingAttribute") ) { return false; }
		if( !LoadOne(path, "Coupon") ) { return false; }
		if( !LoadOne(path, "SignReward") ) { return false; }
		if( !LoadOne(path, "Lottery") ) { return false; }
		if( !LoadOne(path, "MenghuoBattle") ) { return false; }
		if( !LoadOne(path, "QuestRouter") ) { return false; }
		if( !LoadOne(path, "DirtyWords") ) { return false; }
		if( !LoadOne(path, "Robot") ) { return false; }
		if( !LoadOne(path, "NewBieCarnival") ) { return false; }
		if( !LoadOne(path, "FishRoute") ) { return false; }
		if( !LoadOne(path, "NuclearFix") ) { return false; }
		if( !LoadOne(path, "HeroAttribute") ) { return false; }
		if( !LoadOne(path, "HeroSet") ) { return false; }
		if( !LoadOne(path, "Activities") ) { return false; }
		if( !LoadOne(path, "FishShoal") ) { return false; }
		if( !LoadOne(path, "Item") ) { return false; }
		if( !LoadOne(path, "RobotNickName") ) { return false; }
		if( !LoadOne(path, "TurretModel") ) { return false; }
		if( !LoadOne(path, "PeriodPassControl") ) { return false; }
		if( !LoadOne(path, "Institute") ) { return false; }
		if( !LoadOne(path, "BossFix") ) { return false; }
		if( !LoadOne(path, "Buff") ) { return false; }
		if( !LoadOne(path, "TreasureHunt") ) { return false; }
		if( !LoadOne(path, "FishGenerator") ) { return false; }
		if( !LoadOne(path, "Mail") ) { return false; }
		if( !LoadOne(path, "FishBullet") ) { return false; }
		if( !LoadOne(path, "FishFunction") ) { return false; }
		if( !LoadOne(path, "SwingModel") ) { return false; }
		return true;
	}
	bool LoadOne(const string& path, const string& fileName) {
		if( fileName == "CardRelation") { return _CardRelation.Load(path+fileName+".json"); }
		if( fileName == "CouponDraw") { return _CouponDraw.Load(path+fileName+".json"); }
		if( fileName == "Quest") { return _Quest.Load(path+fileName+".json"); }
		if( fileName == "Loot") { return _Loot.Load(path+fileName+".json"); }
		if( fileName == "QuickPlay") { return _QuickPlay.Load(path+fileName+".json"); }
		if( fileName == "VIP") { return _VIP.Load(path+fileName+".json"); }
		if( fileName == "SystemEntrance") { return _SystemEntrance.Load(path+fileName+".json"); }
		if( fileName == "HeroStar") { return _HeroStar.Load(path+fileName+".json"); }
		if( fileName == "VoucherFix") { return _VoucherFix.Load(path+fileName+".json"); }
		if( fileName == "FishData") { return _FishData.Load(path+fileName+".json"); }
		if( fileName == "SummonRankReward") { return _SummonRankReward.Load(path+fileName+".json"); }
		if( fileName == "ServerFix") { return _ServerFix.Load(path+fileName+".json"); }
		if( fileName == "Level") { return _Level.Load(path+fileName+".json"); }
		if( fileName == "PeriodPass") { return _PeriodPass.Load(path+fileName+".json"); }
		if( fileName == "ItemRecycle") { return _ItemRecycle.Load(path+fileName+".json"); }
		if( fileName == "GamePlay") { return _GamePlay.Load(path+fileName+".json"); }
		if( fileName == "Skill") { return _Skill.Load(path+fileName+".json"); }
		if( fileName == "InstituteLevel") { return _InstituteLevel.Load(path+fileName+".json"); }
		if( fileName == "RedEnvelope") { return _RedEnvelope.Load(path+fileName+".json"); }
		if( fileName == "WingData") { return _WingData.Load(path+fileName+".json"); }
		if( fileName == "ChannelConfig") { return _ChannelConfig.Load(path+fileName+".json"); }
		if( fileName == "TurnTable") { return _TurnTable.Load(path+fileName+".json"); }
		if( fileName == "BattlePass") { return _BattlePass.Load(path+fileName+".json"); }
		if( fileName == "RankReward") { return _RankReward.Load(path+fileName+".json"); }
		if( fileName == "Exchange") { return _Exchange.Load(path+fileName+".json"); }
		if( fileName == "KillTax") { return _KillTax.Load(path+fileName+".json"); }
		if( fileName == "FishPool") { return _FishPool.Load(path+fileName+".json"); }
		if( fileName == "HeroLevel") { return _HeroLevel.Load(path+fileName+".json"); }
		if( fileName == "Difficulty") { return _Difficulty.Load(path+fileName+".json"); }
		if( fileName == "Localization") { return _Localization.Load(path+fileName+".json"); }
		if( fileName == "Market") { return _Market.Load(path+fileName+".json"); }
		if( fileName == "Card") { return _Card.Load(path+fileName+".json"); }
		if( fileName == "HeroRelation") { return _HeroRelation.Load(path+fileName+".json"); }
		if( fileName == "DiamondTimes") { return _DiamondTimes.Load(path+fileName+".json"); }
		if( fileName == "MonthCard") { return _MonthCard.Load(path+fileName+".json"); }
		if( fileName == "ArenaReward") { return _ArenaReward.Load(path+fileName+".json"); }
		if( fileName == "FishModel") { return _FishModel.Load(path+fileName+".json"); }
		if( fileName == "RobotArenaRank") { return _RobotArenaRank.Load(path+fileName+".json"); }
		if( fileName == "FishGroup") { return _FishGroup.Load(path+fileName+".json"); }
		if( fileName == "Announcement") { return _Announcement.Load(path+fileName+".json"); }
		if( fileName == "Charge") { return _Charge.Load(path+fileName+".json"); }
		if( fileName == "NickName") { return _NickName.Load(path+fileName+".json"); }
		if( fileName == "SlotDraw") { return _SlotDraw.Load(path+fileName+".json"); }
		if( fileName == "GeneralTask") { return _GeneralTask.Load(path+fileName+".json"); }
		if( fileName == "WingAttribute") { return _WingAttribute.Load(path+fileName+".json"); }
		if( fileName == "Coupon") { return _Coupon.Load(path+fileName+".json"); }
		if( fileName == "SignReward") { return _SignReward.Load(path+fileName+".json"); }
		if( fileName == "Lottery") { return _Lottery.Load(path+fileName+".json"); }
		if( fileName == "MenghuoBattle") { return _MenghuoBattle.Load(path+fileName+".json"); }
		if( fileName == "QuestRouter") { return _QuestRouter.Load(path+fileName+".json"); }
		if( fileName == "DirtyWords") { return _DirtyWords.Load(path+fileName+".json"); }
		if( fileName == "Robot") { return _Robot.Load(path+fileName+".json"); }
		if( fileName == "NewBieCarnival") { return _NewBieCarnival.Load(path+fileName+".json"); }
		if( fileName == "FishRoute") { return _FishRoute.Load(path+fileName+".json"); }
		if( fileName == "NuclearFix") { return _NuclearFix.Load(path+fileName+".json"); }
		if( fileName == "HeroAttribute") { return _HeroAttribute.Load(path+fileName+".json"); }
		if( fileName == "HeroSet") { return _HeroSet.Load(path+fileName+".json"); }
		if( fileName == "Activities") { return _Activities.Load(path+fileName+".json"); }
		if( fileName == "FishShoal") { return _FishShoal.Load(path+fileName+".json"); }
		if( fileName == "Item") { return _Item.Load(path+fileName+".json"); }
		if( fileName == "RobotNickName") { return _RobotNickName.Load(path+fileName+".json"); }
		if( fileName == "TurretModel") { return _TurretModel.Load(path+fileName+".json"); }
		if( fileName == "PeriodPassControl") { return _PeriodPassControl.Load(path+fileName+".json"); }
		if( fileName == "Institute") { return _Institute.Load(path+fileName+".json"); }
		if( fileName == "BossFix") { return _BossFix.Load(path+fileName+".json"); }
		if( fileName == "Buff") { return _Buff.Load(path+fileName+".json"); }
		if( fileName == "TreasureHunt") { return _TreasureHunt.Load(path+fileName+".json"); }
		if( fileName == "FishGenerator") { return _FishGenerator.Load(path+fileName+".json"); }
		if( fileName == "Mail") { return _Mail.Load(path+fileName+".json"); }
		if( fileName == "FishBullet") { return _FishBullet.Load(path+fileName+".json"); }
		if( fileName == "FishFunction") { return _FishFunction.Load(path+fileName+".json"); }
		if( fileName == "SwingModel") { return _SwingModel.Load(path+fileName+".json"); }
		return false;
	}
};

#define JDATA Singleton<JsonConfig>::Instance()

