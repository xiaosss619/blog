#include "JsonSystemConst.h"

void JsonSystemConst::SetByName(const string& name, int64 v) {
	if( name =="firstLoot" ) {
		SetfirstLoot(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Gold" ) {
		SetGold(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="VideoAdCd" ) {
		SetVideoAdCd(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="VideoAdReward" ) {
		SetVideoAdReward(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="GameTimeRewardDefault" ) {
		SetGameTimeRewardDefault(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="GameTimeRewardUnit" ) {
		SetGameTimeRewardUnit(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="GameTimeRewardUnitValue" ) {
		SetGameTimeRewardUnitValue(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="maxMail" ) {
		SetmaxMail(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Diamond" ) {
		SetDiamond(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="povertyLine" ) {
		SetpovertyLine(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="maxLevel" ) {
		SetmaxLevel(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="maxVIPLevel" ) {
		SetmaxVIPLevel(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="rewardInfo" ) {
		SetrewardInfo(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="maxDailyDiscount" ) {
		SetmaxDailyDiscount(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="maxLuckBag" ) {
		SetmaxLuckBag(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="redEnvelopeRate" ) {
		SetredEnvelopeRate(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="redEnvelopeNum" ) {
		SetredEnvelopeNum(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="speakerItemID" ) {
		SetspeakerItemID(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="speakerItemDiamond" ) {
		SetspeakerItemDiamond(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="speakerIntervalTime" ) {
		SetspeakerIntervalTime(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="renameCD" ) {
		SetrenameCD(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="updateReward" ) {
		SetupdateReward(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="PersonalRefundRate" ) {
		SetPersonalRefundRate(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="TableRefundRate" ) {
		SetTableRefundRate(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="RoomRefundRate" ) {
		SetRoomRefundRate(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="GameRefundRate" ) {
		SetGameRefundRate(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="RefundDeathRateMin" ) {
		SetRefundDeathRateMin(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="RefundDeathRateMax" ) {
		SetRefundDeathRateMax(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="BigSurprise_SmallWeight" ) {
		SetBigSurprise_SmallWeight(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="BigSurprise_MiddleWeight" ) {
		SetBigSurprise_MiddleWeight(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="BigSurprise_BigWeight" ) {
		SetBigSurprise_BigWeight(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="BigSurprise_HugeWeight" ) {
		SetBigSurprise_HugeWeight(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="AutoFireLevel" ) {
		SetAutoFireLevel(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="AutoFireTime" ) {
		SetAutoFireTime(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="FirstTurretID" ) {
		SetFirstTurretID(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="DefenseConst" ) {
		SetDefenseConst(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="BasicCritical" ) {
		SetBasicCritical(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="BasicCriticalDamage" ) {
		SetBasicCriticalDamage(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="NewbieGuideFirst" ) {
		SetNewbieGuideFirst(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="NewbieGuideEnd" ) {
		SetNewbieGuideEnd(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="TurretMaxSpeed" ) {
		SetTurretMaxSpeed(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="NameChangeItem" ) {
		SetNameChangeItem(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="OfficialInitialLoot" ) {
		SetOfficialInitialLoot(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="OtherInitialLoot" ) {
		SetOtherInitialLoot(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ChannelInitialLoot" ) {
		SetChannelInitialLoot(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="BigSurprise_EffectID" ) {
		SetBigSurprise_EffectID(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="BPDeathRateMin" ) {
		SetBPDeathRateMin(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="BPDeathRateMax" ) {
		SetBPDeathRateMax(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Coupon" ) {
		SetCoupon(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="BigSurprise_TipStyle" ) {
		SetBigSurprise_TipStyle(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ArenaRankCritical" ) {
		SetArenaRankCritical(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="FishPoolSwitchTime" ) {
		SetFishPoolSwitchTime(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="DefaultFishPoolExistedTime" ) {
		SetDefaultFishPoolExistedTime(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ArenaCountDownTime" ) {
		SetArenaCountDownTime(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ArenaDoubleStartTime" ) {
		SetArenaDoubleStartTime(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ArenaDoubleLasting" ) {
		SetArenaDoubleLasting(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ArenaTripleStartTime" ) {
		SetArenaTripleStartTime(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ArenaTripleLasting" ) {
		SetArenaTripleLasting(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="CommodityExchangeItem" ) {
		SetCommodityExchangeItem(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ExchangeFailedMail" ) {
		SetExchangeFailedMail(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="KickCost" ) {
		SetKickCost(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="BeKickedReward" ) {
		SetBeKickedReward(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="FishKillSTDEV" ) {
		SetFishKillSTDEV(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="SwingSkill_TipStyle" ) {
		SetSwingSkill_TipStyle(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="CouponControlParam" ) {
		SetCouponControlParam(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="MarketGoodsNum" ) {
		SetMarketGoodsNum(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="SwingStrengthMaxLevel" ) {
		SetSwingStrengthMaxLevel(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="VIPPrivilegeMail" ) {
		SetVIPPrivilegeMail(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="EnergyRecoveryTime" ) {
		SetEnergyRecoveryTime(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="InitialEnergyMax" ) {
		SetInitialEnergyMax(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="TurretFirstReward" ) {
		SetTurretFirstReward(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="MinOutFish" ) {
		SetMinOutFish(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="MaxOutFish" ) {
		SetMaxOutFish(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="OutFishInterval" ) {
		SetOutFishInterval(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="OutFishCount" ) {
		SetOutFishCount(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="NormalOutFishTime" ) {
		SetNormalOutFishTime(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ChangeSceneTime" ) {
		SetChangeSceneTime(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Fixedhits" ) {
		SetFixedhits(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ChangeSceneWaitTime" ) {
		SetChangeSceneWaitTime(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="LaserHitCount" ) {
		SetLaserHitCount(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="PearlPerHit" ) {
		SetPearlPerHit(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="PearlHitCount" ) {
		SetPearlHitCount(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="FirstTicket" ) {
		SetFirstTicket(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="MinBroadcast" ) {
		SetMinBroadcast(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="MinTicketTime" ) {
		SetMinTicketTime(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="MaxTicketTime" ) {
		SetMaxTicketTime(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="MaxEverydayTicket" ) {
		SetMaxEverydayTicket(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="defaultlevel" ) {
		Setdefaultlevel(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="protectTime" ) {
		SetprotectTime(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="protectLine" ) {
		SetprotectLine(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="protectMin" ) {
		SetprotectMin(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="protectMax" ) {
		SetprotectMax(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="isopen" ) {
		Setisopen(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="MissileHitCount" ) {
		SetMissileHitCount(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="DiscountVIP" ) {
		SetDiscountVIP(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="DiscountValue" ) {
		SetDiscountValue(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="MonthCardTurret" ) {
		SetMonthCardTurret(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="StarRate" ) {
		SetStarRate(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="CloseNet" ) {
		SetCloseNet(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="IsDebug" ) {
		SetIsDebug(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="DefaultTurret" ) {
		SetDefaultTurret(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="CloseSkill" ) {
		SetCloseSkill(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="game_state1" ) {
		Setgame_state1(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="game_state2" ) {
		Setgame_state2(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="game_state3" ) {
		Setgame_state3(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="EndExperienceTime" ) {
		SetEndExperienceTime(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="FixLine" ) {
		SetFixLine(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="fixRate" ) {
		SetfixRate(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="FishDeathMiuParam" ) {
		SetFishDeathMiuParam(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="FishDeathSigmaParam" ) {
		SetFishDeathSigmaParam(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ArenaWarrior" ) {
		SetArenaWarrior(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="TowerChallenger" ) {
		SetTowerChallenger(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="BindIdentityMailID" ) {
		SetBindIdentityMailID(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="BindIdentityLootID" ) {
		SetBindIdentityLootID(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="BindPhoneMailID" ) {
		SetBindPhoneMailID(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="BindPhoneLootID" ) {
		SetBindPhoneLootID(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="GameExpectationTime" ) {
		SetGameExpectationTime(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="FriendChangeFrequency" ) {
		SetFriendChangeFrequency(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="FriendChangeRange" ) {
		SetFriendChangeRange(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="PovertyReward" ) {
		SetPovertyReward(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="PovertyRewardTimes" ) {
		SetPovertyRewardTimes(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="TurretStarUpgradeGoldRate" ) {
		SetTurretStarUpgradeGoldRate(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="NewBieCarnivalExp" ) {
		SetNewBieCarnivalExp(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="NewBieCarnivalLoot" ) {
		SetNewBieCarnivalLoot(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="NewBieCarnivalLottery" ) {
		SetNewBieCarnivalLottery(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="NewBieCarnivalItem" ) {
		SetNewBieCarnivalItem(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="NewBieCarnivalMail" ) {
		SetNewBieCarnivalMail(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="QuestAcceptTips" ) {
		SetQuestAcceptTips(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="FishSoundFrequent" ) {
		SetFishSoundFrequent(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="CouponExchangeRate" ) {
		SetCouponExchangeRate(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="CouponDrawCount" ) {
		SetCouponDrawCount(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="PhoneVoucherItemID" ) {
		SetPhoneVoucherItemID(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="RedEnvelopeMaxShow" ) {
		SetRedEnvelopeMaxShow(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="UserTotalGoldValue" ) {
		SetUserTotalGoldValue(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="PovertyResetRate" ) {
		SetPovertyResetRate(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="UserValueInitial" ) {
		SetUserValueInitial(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="UserValueMinusForVIP" ) {
		SetUserValueMinusForVIP(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="UserValueMinusForFree" ) {
		SetUserValueMinusForFree(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="UserValueMin" ) {
		SetUserValueMin(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="UserValueAddForPovertyRate" ) {
		SetUserValueAddForPovertyRate(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="UserValueAddForPoverty" ) {
		SetUserValueAddForPoverty(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="PovertyProtectTurretLeft" ) {
		SetPovertyProtectTurretLeft(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="PovertyProtectFishPoint" ) {
		SetPovertyProtectFishPoint(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="PovertyProtectRate" ) {
		SetPovertyProtectRate(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="PovertyProtectHistoryTotal" ) {
		SetPovertyProtectHistoryTotal(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="SlotBossMailID" ) {
		SetSlotBossMailID(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="SlotResetItemID" ) {
		SetSlotResetItemID(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="HunterRefundItemID" ) {
		SetHunterRefundItemID(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="HunterContinueItemID" ) {
		SetHunterContinueItemID(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="HunterRefundMin" ) {
		SetHunterRefundMin(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="HunterRefundMax" ) {
		SetHunterRefundMax(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="HunterRefundDivider" ) {
		SetHunterRefundDivider(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="NewBieRedEnvelope" ) {
		SetNewBieRedEnvelope(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="NewBieRedEnvelopeTime" ) {
		SetNewBieRedEnvelopeTime(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="NewBieNetScoreRange" ) {
		SetNewBieNetScoreRange(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="RegularNetScoreRange" ) {
		SetRegularNetScoreRange(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="InitialHeadIcon" ) {
		SetInitialHeadIcon(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="InitialHeadFrame" ) {
		SetInitialHeadFrame(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="InitialPropertyBG" ) {
		SetInitialPropertyBG(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="SummonNetScoreRate" ) {
		SetSummonNetScoreRate(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="SummonNetScoreRangeMax" ) {
		SetSummonNetScoreRangeMax(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="SummonNetScoreRangeMin" ) {
		SetSummonNetScoreRangeMin(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="MonthCardEffectMin" ) {
		SetMonthCardEffectMin(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="CardDrawNuclearID" ) {
		SetCardDrawNuclearID(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="PeriodPassID" ) {
		SetPeriodPassID(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="TimesPerDiamond" ) {
		SetTimesPerDiamond(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="AdditionLootParamK" ) {
		SetAdditionLootParamK(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="AdditionLootParamM" ) {
		SetAdditionLootParamM(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="NuclearDrawRankFishID" ) {
		SetNuclearDrawRankFishID(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="NuclearDrawFee" ) {
		SetNuclearDrawFee(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="NuclearDrawScoreParamM1" ) {
		SetNuclearDrawScoreParamM1(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="NuclearDrawScoreParamM2" ) {
		SetNuclearDrawScoreParamM2(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="NuclearDrawAverageScore" ) {
		SetNuclearDrawAverageScore(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="NuclearDrawGuaranteeRate" ) {
		SetNuclearDrawGuaranteeRate(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="CollectionCardItemID" ) {
		SetCollectionCardItemID(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="CardFishKillSigmaParam" ) {
		SetCardFishKillSigmaParam(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="CardFishLootMin" ) {
		SetCardFishLootMin(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="CardFishLootMax" ) {
		SetCardFishLootMax(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="GrownFundItemID" ) {
		SetGrownFundItemID(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="FriendNumLimit" ) {
		SetFriendNumLimit(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="FriendApplyLimit" ) {
		SetFriendApplyLimit(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="FriendBlockListLimit" ) {
		SetFriendBlockListLimit(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="MonthCard_DailyReward" ) {
		SetMonthCard_DailyReward(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="TreasureBoxVoucherInitial" ) {
		SetTreasureBoxVoucherInitial(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="TreasureBoxVoucherInitialRate" ) {
		SetTreasureBoxVoucherInitialRate(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="TreasureBoxVoucherChargeRate" ) {
		SetTreasureBoxVoucherChargeRate(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="TreasureBoxVoucherMax" ) {
		SetTreasureBoxVoucherMax(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="SuperWeaponInitialSkinItemID" ) {
		SetSuperWeaponInitialSkinItemID(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="SunquanBossID" ) {
		SetSunquanBossID(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="CaocaoBossID" ) {
		SetCaocaoBossID(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="LvbuBossID" ) {
		SetLvbuBossID(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="MenghuoBossID" ) {
		SetMenghuoBossID(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="SuperWeaponWidthBasic" ) {
		SetSuperWeaponWidthBasic(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="FishTaxRange" ) {
		SetFishTaxRange(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="FishTaxChangeIntervalMin" ) {
		SetFishTaxChangeIntervalMin(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="FishTaxChangeIntervalMax" ) {
		SetFishTaxChangeIntervalMax(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="RechargeFrozenTime" ) {
		SetRechargeFrozenTime(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ReceiveGiftsTime" ) {
		SetReceiveGiftsTime(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="SendGiftsTime" ) {
		SetSendGiftsTime(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Crystal" ) {
		SetCrystal(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="VIPRankResourceID" ) {
		SetVIPRankResourceID(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="AcceptCancelOrderMail" ) {
		SetAcceptCancelOrderMail(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="AcceptExpiredOrderMail" ) {
		SetAcceptExpiredOrderMail(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="SendCancelOrderMail" ) {
		SetSendCancelOrderMail(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="SendExpiredOrderMail" ) {
		SetSendExpiredOrderMail(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="RecieveGiftsMail" ) {
		SetRecieveGiftsMail(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="GiftForceCloseMail" ) {
		SetGiftForceCloseMail(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ChatWordLimit" ) {
		SetChatWordLimit(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ChatCD" ) {
		SetChatCD(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="PrivateChatMessageNum" ) {
		SetPrivateChatMessageNum(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="GroupChatMessageNum" ) {
		SetGroupChatMessageNum(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="BindPhoneAddPopularity" ) {
		SetBindPhoneAddPopularity(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="SendGiftsNeedPopularity" ) {
		SetSendGiftsNeedPopularity(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="GroupChatMemberMax" ) {
		SetGroupChatMemberMax(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="GiftRecordKeepTime" ) {
		SetGiftRecordKeepTime(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="HunterRefundTime" ) {
		SetHunterRefundTime(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Sound_Button" ) {
		SetSound_Button(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Sound_DiamondDrop" ) {
		SetSound_DiamondDrop(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Sound_Gold" ) {
		SetSound_Gold(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Sound_HallBG" ) {
		SetSound_HallBG(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Sound_LevelUP" ) {
		SetSound_LevelUP(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Sound_QuestFinish" ) {
		SetSound_QuestFinish(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Sound_StarUP" ) {
		SetSound_StarUP(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Sound_GoldTurnTable1" ) {
		SetSound_GoldTurnTable1(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Sound_GoldTurnTable2" ) {
		SetSound_GoldTurnTable2(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Sound_RewardGet" ) {
		SetSound_RewardGet(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Sound_TurnTableReward" ) {
		SetSound_TurnTableReward(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Sound_TurnTableDada" ) {
		SetSound_TurnTableDada(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Sound_TurnTableStart" ) {
		SetSound_TurnTableStart(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Sound_GoldCombo" ) {
		SetSound_GoldCombo(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Sound_HighNotice" ) {
		SetSound_HighNotice(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Sound_CountDown" ) {
		SetSound_CountDown(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Sound_Success" ) {
		SetSound_Success(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Sound_Failed" ) {
		SetSound_Failed(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Sound_signup" ) {
		SetSound_signup(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Sound_monthcard" ) {
		SetSound_monthcard(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Sound_guide_1" ) {
		SetSound_guide_1(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Sound_guide_2" ) {
		SetSound_guide_2(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Sound_guide_3" ) {
		SetSound_guide_3(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Sound_guide_4" ) {
		SetSound_guide_4(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Sound_guide_5" ) {
		SetSound_guide_5(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Sound_guide_6" ) {
		SetSound_guide_6(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Sound_guide_7" ) {
		SetSound_guide_7(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Sound_guide_8" ) {
		SetSound_guide_8(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Sound_guide_9" ) {
		SetSound_guide_9(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Sound_guide_10" ) {
		SetSound_guide_10(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Sound_Strength" ) {
		SetSound_Strength(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Sound_Upgrade" ) {
		SetSound_Upgrade(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Sound_Turntable" ) {
		SetSound_Turntable(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Sound_TurntableBingo" ) {
		SetSound_TurntableBingo(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Sound_PhoneVoucher" ) {
		SetSound_PhoneVoucher(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Sound_Shuffle" ) {
		SetSound_Shuffle(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Sound_nuclear_relation" ) {
		SetSound_nuclear_relation(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Sound_nuclear_open" ) {
		SetSound_nuclear_open(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Sound_nuclear_open_auto" ) {
		SetSound_nuclear_open_auto(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Sound_treasure_turning" ) {
		SetSound_treasure_turning(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="Sound_treasure_stop" ) {
		SetSound_treasure_stop(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	LOGERROR("SetByName failed[%s] [%ld]", name.c_str(), v);
}
void JsonSystemConst::init() {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_firstLoot = 10000002;
	_Gold = 10101001;
	_VideoAdCd = 21600;
	_VideoAdReward = 5000000;
	_GameTimeRewardDefault = 100000;
	_GameTimeRewardUnit = 600;
	_GameTimeRewardUnitValue = 10000;
	_maxMail = 200;
	_Diamond = 10101050;
	_povertyLine = 0;
	_maxLevel = 100;
	_maxVIPLevel = 10;
	_rewardInfo = 10101005;
	_maxDailyDiscount = 2;
	_maxLuckBag = 3;
	_redEnvelopeRate = 10;
	_redEnvelopeNum = 20;
	_speakerItemID = 10501001;
	_speakerItemDiamond = 6000000;
	_speakerIntervalTime = 8;
	_renameCD = 604800;
	_updateReward = 10000000;
	_PersonalRefundRate = 100;
	_TableRefundRate = 105;
	_RoomRefundRate = 105;
	_GameRefundRate = 100;
	_RefundDeathRateMin = 100000;
	_RefundDeathRateMax = 200000;
	_BigSurprise_SmallWeight = 8500;
	_BigSurprise_MiddleWeight = 1500;
	_BigSurprise_BigWeight = 20;
	_BigSurprise_HugeWeight = 1;
	_AutoFireLevel = 0;
	_AutoFireTime = 600;
	_FirstTurretID = 1;
	_DefenseConst = 50;
	_BasicCritical = 10;
	_BasicCriticalDamage = 150;
	_NewbieGuideFirst = 65;
	_NewbieGuideEnd = 52;
	_TurretMaxSpeed = 12;
	_NameChangeItem = 10601001;
	_OfficialInitialLoot = 10000003;
	_OtherInitialLoot = 10000004;
	_ChannelInitialLoot = 10000005;
	_BigSurprise_EffectID = 2000;
	_BPDeathRateMin = 0;
	_BPDeathRateMax = 0;
	_Coupon = 10101060;
	_BigSurprise_TipStyle = 10;
	_ArenaRankCritical = 30;
	_FishPoolSwitchTime = 5000;
	_DefaultFishPoolExistedTime = 60000;
	_ArenaCountDownTime = 10000;
	_ArenaDoubleStartTime = 240000;
	_ArenaDoubleLasting = 60000;
	_ArenaTripleStartTime = 60000;
	_ArenaTripleLasting = 60000;
	_CommodityExchangeItem = 10101060;
	_ExchangeFailedMail = 34;
	_KickCost = 50;
	_BeKickedReward = 50000;
	_FishKillSTDEV = 4041;
	_SwingSkill_TipStyle = 3;
	_CouponControlParam = 30;
	_MarketGoodsNum = 8;
	_SwingStrengthMaxLevel = 9;
	_VIPPrivilegeMail = 35;
	_EnergyRecoveryTime = 600;
	_InitialEnergyMax = 18;
	_TurretFirstReward = 20;
	_MinOutFish = 0;
	_MaxOutFish = 45;
	_OutFishInterval = 500;
	_OutFishCount = 3;
	_NormalOutFishTime = 300;
	_ChangeSceneTime = 5;
	_Fixedhits = 0;
	_ChangeSceneWaitTime = 5;
	_LaserHitCount = 100;
	_PearlPerHit = 5;
	_PearlHitCount = 10;
	_FirstTicket = 0;
	_MinBroadcast = 500000;
	_MinTicketTime = 300;
	_MaxTicketTime = 600;
	_MaxEverydayTicket = 0;
	_defaultlevel = 1;
	_protectTime = 604800;
	_protectLine = 2000;
	_protectMin = 5000;
	_protectMax = 10000;
	_isopen = 0;
	_MissileHitCount = 200;
	_DiscountVIP = 999;
	_DiscountValue = 30;
	_MonthCardTurret = 33;
	_StarRate = 10;
	_CloseNet = 0;
	_IsDebug = 0;
	_DefaultTurret = 13;
	_CloseSkill = 1;
	_game_state1 = 0;
	_game_state2 = 2;
	_game_state3 = 10;
	_EndExperienceTime = 300;
	_FixLine = 0;
	_fixRate = 100;
	_FishDeathMiuParam = 1000;
	_FishDeathSigmaParam = 333;
	_ArenaWarrior = 10101061;
	_TowerChallenger = 10101062;
	_BindIdentityMailID = 36;
	_BindIdentityLootID = 10000101;
	_BindPhoneMailID = 37;
	_BindPhoneLootID = 10000102;
	_GameExpectationTime = 3600;
	_FriendChangeFrequency = 180;
	_FriendChangeRange = -50;
	_PovertyReward = 0;
	_PovertyRewardTimes = 2;
	_TurretStarUpgradeGoldRate = 500;
	_NewBieCarnivalExp = 63;
	_NewBieCarnivalLoot = 10000350;
	_NewBieCarnivalLottery = 112;
	_NewBieCarnivalItem = 10301014;
	_NewBieCarnivalMail = 40;
	_QuestAcceptTips = 8;
	_FishSoundFrequent = 12000;
	_CouponExchangeRate = 1000;
	_CouponDrawCount = 500;
	_PhoneVoucherItemID = 10101064;
	_RedEnvelopeMaxShow = 1000000;
	_UserTotalGoldValue = 10000000000;
	_PovertyResetRate = 10000;
	_UserValueInitial = 100;
	_UserValueMinusForVIP = -5;
	_UserValueMinusForFree = -10;
	_UserValueMin = 0;
	_UserValueAddForPovertyRate = 10;
	_UserValueAddForPoverty = 5;
	_PovertyProtectTurretLeft = 50;
	_PovertyProtectFishPoint = 999;
	_PovertyProtectRate = 2000;
	_PovertyProtectHistoryTotal = 100000000000000;
	_SlotBossMailID = 44;
	_SlotResetItemID = 11601002;
	_HunterRefundItemID = 11601003;
	_HunterContinueItemID = 11601008;
	_HunterRefundMin = 300000000;
	_HunterRefundMax = 100000000000;
	_HunterRefundDivider = 3;
	_NewBieRedEnvelope = 4;
	_NewBieRedEnvelopeTime = 604800;
	_NewBieNetScoreRange = 5000000000;
	_RegularNetScoreRange = 3500000000;
	_InitialHeadIcon = 10202001;
	_InitialHeadFrame = 10201000;
	_InitialPropertyBG = 10203001;
	_SummonNetScoreRate = 60;
	_SummonNetScoreRangeMax = 20000000000;
	_SummonNetScoreRangeMin = -20000000000;
	_MonthCardEffectMin = 50;
	_CardDrawNuclearID = 11901004;
	_PeriodPassID = 1;
	_TimesPerDiamond = 2;
	_AdditionLootParamK = 300;
	_AdditionLootParamM = 50;
	_NuclearDrawRankFishID = 100000;
	_NuclearDrawFee = 90;
	_NuclearDrawScoreParamM1 = -10;
	_NuclearDrawScoreParamM2 = 10;
	_NuclearDrawAverageScore = 7;
	_NuclearDrawGuaranteeRate = 750;
	_CollectionCardItemID = 10101075;
	_CardFishKillSigmaParam = 8;
	_CardFishLootMin = 1;
	_CardFishLootMax = 9;
	_GrownFundItemID = 10101078;
	_FriendNumLimit = 20;
	_FriendApplyLimit = 20;
	_FriendBlockListLimit = 20;
	_MonthCard_DailyReward = 10122050;
	_TreasureBoxVoucherInitial = 50;
	_TreasureBoxVoucherInitialRate = 2500;
	_TreasureBoxVoucherChargeRate = 5000;
	_TreasureBoxVoucherMax = 5000;
	_SuperWeaponInitialSkinItemID = 11303001;
	_SunquanBossID = 312;
	_CaocaoBossID = 313;
	_LvbuBossID = 311;
	_MenghuoBossID = 314;
	_SuperWeaponWidthBasic = 100;
	_FishTaxRange = 500;
	_FishTaxChangeIntervalMin = 600;
	_FishTaxChangeIntervalMax = 1200;
	_RechargeFrozenTime = 7;
	_ReceiveGiftsTime = 60;
	_SendGiftsTime = 60;
	_Crystal = 10101001;
	_VIPRankResourceID = 12001003;
	_AcceptCancelOrderMail = 1050;
	_AcceptExpiredOrderMail = 1051;
	_SendCancelOrderMail = 1052;
	_SendExpiredOrderMail = 1053;
	_RecieveGiftsMail = 1054;
	_GiftForceCloseMail = 1055;
	_ChatWordLimit = 20;
	_ChatCD = 5;
	_PrivateChatMessageNum = 100;
	_GroupChatMessageNum = 100;
	_BindPhoneAddPopularity = 60;
	_SendGiftsNeedPopularity = 60;
	_GroupChatMemberMax = 200;
	_GiftRecordKeepTime = 15;
	_HunterRefundTime = 3600;
	_Sound_Button = 1;
	_Sound_DiamondDrop = 2;
	_Sound_Gold = 18;
	_Sound_HallBG = 19;
	_Sound_LevelUP = 20;
	_Sound_QuestFinish = 22;
	_Sound_StarUP = 56;
	_Sound_GoldTurnTable1 = 67;
	_Sound_GoldTurnTable2 = 66;
	_Sound_RewardGet = 68;
	_Sound_TurnTableReward = 69;
	_Sound_TurnTableDada = 70;
	_Sound_TurnTableStart = 71;
	_Sound_GoldCombo = 72;
	_Sound_HighNotice = 73;
	_Sound_CountDown = 74;
	_Sound_Success = 75;
	_Sound_Failed = 76;
	_Sound_signup = 115;
	_Sound_monthcard = 116;
	_Sound_guide_1 = 117;
	_Sound_guide_2 = 118;
	_Sound_guide_3 = 119;
	_Sound_guide_4 = 120;
	_Sound_guide_5 = 121;
	_Sound_guide_6 = 122;
	_Sound_guide_7 = 123;
	_Sound_guide_8 = 124;
	_Sound_guide_9 = 125;
	_Sound_guide_10 = 126;
	_Sound_Strength = 56;
	_Sound_Upgrade = 56;
	_Sound_Turntable = 130;
	_Sound_TurntableBingo = 131;
	_Sound_PhoneVoucher = 132;
	_Sound_Shuffle = 133;
	_Sound_nuclear_relation = 139;
	_Sound_nuclear_open = 140;
	_Sound_nuclear_open_auto = 141;
	_Sound_treasure_turning = 142;
	_Sound_treasure_stop = 143;
}
int32 JsonSystemConst::GetfirstLoot() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _firstLoot;
}
void JsonSystemConst::SetfirstLoot(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_firstLoot = v;
}
int32 JsonSystemConst::GetGold() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Gold;
}
void JsonSystemConst::SetGold(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Gold = v;
}
int32 JsonSystemConst::GetVideoAdCd() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _VideoAdCd;
}
void JsonSystemConst::SetVideoAdCd(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_VideoAdCd = v;
}
int32 JsonSystemConst::GetVideoAdReward() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _VideoAdReward;
}
void JsonSystemConst::SetVideoAdReward(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_VideoAdReward = v;
}
int32 JsonSystemConst::GetGameTimeRewardDefault() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _GameTimeRewardDefault;
}
void JsonSystemConst::SetGameTimeRewardDefault(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_GameTimeRewardDefault = v;
}
int32 JsonSystemConst::GetGameTimeRewardUnit() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _GameTimeRewardUnit;
}
void JsonSystemConst::SetGameTimeRewardUnit(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_GameTimeRewardUnit = v;
}
int32 JsonSystemConst::GetGameTimeRewardUnitValue() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _GameTimeRewardUnitValue;
}
void JsonSystemConst::SetGameTimeRewardUnitValue(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_GameTimeRewardUnitValue = v;
}
int32 JsonSystemConst::GetmaxMail() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _maxMail;
}
void JsonSystemConst::SetmaxMail(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_maxMail = v;
}
int32 JsonSystemConst::GetDiamond() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Diamond;
}
void JsonSystemConst::SetDiamond(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Diamond = v;
}
int32 JsonSystemConst::GetpovertyLine() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _povertyLine;
}
void JsonSystemConst::SetpovertyLine(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_povertyLine = v;
}
int32 JsonSystemConst::GetmaxLevel() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _maxLevel;
}
void JsonSystemConst::SetmaxLevel(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_maxLevel = v;
}
int32 JsonSystemConst::GetmaxVIPLevel() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _maxVIPLevel;
}
void JsonSystemConst::SetmaxVIPLevel(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_maxVIPLevel = v;
}
int32 JsonSystemConst::GetrewardInfo() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _rewardInfo;
}
void JsonSystemConst::SetrewardInfo(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_rewardInfo = v;
}
int32 JsonSystemConst::GetmaxDailyDiscount() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _maxDailyDiscount;
}
void JsonSystemConst::SetmaxDailyDiscount(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_maxDailyDiscount = v;
}
int32 JsonSystemConst::GetmaxLuckBag() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _maxLuckBag;
}
void JsonSystemConst::SetmaxLuckBag(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_maxLuckBag = v;
}
int32 JsonSystemConst::GetredEnvelopeRate() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _redEnvelopeRate;
}
void JsonSystemConst::SetredEnvelopeRate(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_redEnvelopeRate = v;
}
int32 JsonSystemConst::GetredEnvelopeNum() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _redEnvelopeNum;
}
void JsonSystemConst::SetredEnvelopeNum(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_redEnvelopeNum = v;
}
int32 JsonSystemConst::GetspeakerItemID() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _speakerItemID;
}
void JsonSystemConst::SetspeakerItemID(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_speakerItemID = v;
}
int32 JsonSystemConst::GetspeakerItemDiamond() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _speakerItemDiamond;
}
void JsonSystemConst::SetspeakerItemDiamond(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_speakerItemDiamond = v;
}
int32 JsonSystemConst::GetspeakerIntervalTime() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _speakerIntervalTime;
}
void JsonSystemConst::SetspeakerIntervalTime(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_speakerIntervalTime = v;
}
int32 JsonSystemConst::GetrenameCD() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _renameCD;
}
void JsonSystemConst::SetrenameCD(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_renameCD = v;
}
int32 JsonSystemConst::GetupdateReward() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _updateReward;
}
void JsonSystemConst::SetupdateReward(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_updateReward = v;
}
int32 JsonSystemConst::GetPersonalRefundRate() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _PersonalRefundRate;
}
void JsonSystemConst::SetPersonalRefundRate(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_PersonalRefundRate = v;
}
int32 JsonSystemConst::GetTableRefundRate() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _TableRefundRate;
}
void JsonSystemConst::SetTableRefundRate(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_TableRefundRate = v;
}
int32 JsonSystemConst::GetRoomRefundRate() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _RoomRefundRate;
}
void JsonSystemConst::SetRoomRefundRate(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_RoomRefundRate = v;
}
int32 JsonSystemConst::GetGameRefundRate() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _GameRefundRate;
}
void JsonSystemConst::SetGameRefundRate(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_GameRefundRate = v;
}
int32 JsonSystemConst::GetRefundDeathRateMin() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _RefundDeathRateMin;
}
void JsonSystemConst::SetRefundDeathRateMin(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_RefundDeathRateMin = v;
}
int32 JsonSystemConst::GetRefundDeathRateMax() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _RefundDeathRateMax;
}
void JsonSystemConst::SetRefundDeathRateMax(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_RefundDeathRateMax = v;
}
int32 JsonSystemConst::GetBigSurprise_SmallWeight() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _BigSurprise_SmallWeight;
}
void JsonSystemConst::SetBigSurprise_SmallWeight(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_BigSurprise_SmallWeight = v;
}
int32 JsonSystemConst::GetBigSurprise_MiddleWeight() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _BigSurprise_MiddleWeight;
}
void JsonSystemConst::SetBigSurprise_MiddleWeight(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_BigSurprise_MiddleWeight = v;
}
int32 JsonSystemConst::GetBigSurprise_BigWeight() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _BigSurprise_BigWeight;
}
void JsonSystemConst::SetBigSurprise_BigWeight(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_BigSurprise_BigWeight = v;
}
int32 JsonSystemConst::GetBigSurprise_HugeWeight() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _BigSurprise_HugeWeight;
}
void JsonSystemConst::SetBigSurprise_HugeWeight(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_BigSurprise_HugeWeight = v;
}
int32 JsonSystemConst::GetAutoFireLevel() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _AutoFireLevel;
}
void JsonSystemConst::SetAutoFireLevel(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_AutoFireLevel = v;
}
int32 JsonSystemConst::GetAutoFireTime() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _AutoFireTime;
}
void JsonSystemConst::SetAutoFireTime(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_AutoFireTime = v;
}
int32 JsonSystemConst::GetFirstTurretID() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _FirstTurretID;
}
void JsonSystemConst::SetFirstTurretID(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_FirstTurretID = v;
}
int32 JsonSystemConst::GetDefenseConst() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _DefenseConst;
}
void JsonSystemConst::SetDefenseConst(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_DefenseConst = v;
}
int32 JsonSystemConst::GetBasicCritical() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _BasicCritical;
}
void JsonSystemConst::SetBasicCritical(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_BasicCritical = v;
}
int32 JsonSystemConst::GetBasicCriticalDamage() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _BasicCriticalDamage;
}
void JsonSystemConst::SetBasicCriticalDamage(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_BasicCriticalDamage = v;
}
int32 JsonSystemConst::GetNewbieGuideFirst() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _NewbieGuideFirst;
}
void JsonSystemConst::SetNewbieGuideFirst(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_NewbieGuideFirst = v;
}
int32 JsonSystemConst::GetNewbieGuideEnd() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _NewbieGuideEnd;
}
void JsonSystemConst::SetNewbieGuideEnd(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_NewbieGuideEnd = v;
}
int32 JsonSystemConst::GetTurretMaxSpeed() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _TurretMaxSpeed;
}
void JsonSystemConst::SetTurretMaxSpeed(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_TurretMaxSpeed = v;
}
int32 JsonSystemConst::GetNameChangeItem() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _NameChangeItem;
}
void JsonSystemConst::SetNameChangeItem(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_NameChangeItem = v;
}
int32 JsonSystemConst::GetOfficialInitialLoot() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _OfficialInitialLoot;
}
void JsonSystemConst::SetOfficialInitialLoot(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_OfficialInitialLoot = v;
}
int32 JsonSystemConst::GetOtherInitialLoot() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _OtherInitialLoot;
}
void JsonSystemConst::SetOtherInitialLoot(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_OtherInitialLoot = v;
}
int32 JsonSystemConst::GetChannelInitialLoot() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ChannelInitialLoot;
}
void JsonSystemConst::SetChannelInitialLoot(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ChannelInitialLoot = v;
}
int32 JsonSystemConst::GetBigSurprise_EffectID() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _BigSurprise_EffectID;
}
void JsonSystemConst::SetBigSurprise_EffectID(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_BigSurprise_EffectID = v;
}
int32 JsonSystemConst::GetBPDeathRateMin() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _BPDeathRateMin;
}
void JsonSystemConst::SetBPDeathRateMin(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_BPDeathRateMin = v;
}
int32 JsonSystemConst::GetBPDeathRateMax() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _BPDeathRateMax;
}
void JsonSystemConst::SetBPDeathRateMax(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_BPDeathRateMax = v;
}
int32 JsonSystemConst::GetCoupon() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Coupon;
}
void JsonSystemConst::SetCoupon(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Coupon = v;
}
int32 JsonSystemConst::GetBigSurprise_TipStyle() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _BigSurprise_TipStyle;
}
void JsonSystemConst::SetBigSurprise_TipStyle(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_BigSurprise_TipStyle = v;
}
int32 JsonSystemConst::GetArenaRankCritical() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ArenaRankCritical;
}
void JsonSystemConst::SetArenaRankCritical(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ArenaRankCritical = v;
}
int32 JsonSystemConst::GetFishPoolSwitchTime() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _FishPoolSwitchTime;
}
void JsonSystemConst::SetFishPoolSwitchTime(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_FishPoolSwitchTime = v;
}
int32 JsonSystemConst::GetDefaultFishPoolExistedTime() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _DefaultFishPoolExistedTime;
}
void JsonSystemConst::SetDefaultFishPoolExistedTime(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_DefaultFishPoolExistedTime = v;
}
int32 JsonSystemConst::GetArenaCountDownTime() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ArenaCountDownTime;
}
void JsonSystemConst::SetArenaCountDownTime(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ArenaCountDownTime = v;
}
int32 JsonSystemConst::GetArenaDoubleStartTime() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ArenaDoubleStartTime;
}
void JsonSystemConst::SetArenaDoubleStartTime(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ArenaDoubleStartTime = v;
}
int32 JsonSystemConst::GetArenaDoubleLasting() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ArenaDoubleLasting;
}
void JsonSystemConst::SetArenaDoubleLasting(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ArenaDoubleLasting = v;
}
int32 JsonSystemConst::GetArenaTripleStartTime() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ArenaTripleStartTime;
}
void JsonSystemConst::SetArenaTripleStartTime(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ArenaTripleStartTime = v;
}
int32 JsonSystemConst::GetArenaTripleLasting() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ArenaTripleLasting;
}
void JsonSystemConst::SetArenaTripleLasting(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ArenaTripleLasting = v;
}
int32 JsonSystemConst::GetCommodityExchangeItem() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _CommodityExchangeItem;
}
void JsonSystemConst::SetCommodityExchangeItem(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_CommodityExchangeItem = v;
}
int32 JsonSystemConst::GetExchangeFailedMail() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ExchangeFailedMail;
}
void JsonSystemConst::SetExchangeFailedMail(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ExchangeFailedMail = v;
}
int32 JsonSystemConst::GetKickCost() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _KickCost;
}
void JsonSystemConst::SetKickCost(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_KickCost = v;
}
int32 JsonSystemConst::GetBeKickedReward() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _BeKickedReward;
}
void JsonSystemConst::SetBeKickedReward(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_BeKickedReward = v;
}
int32 JsonSystemConst::GetFishKillSTDEV() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _FishKillSTDEV;
}
void JsonSystemConst::SetFishKillSTDEV(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_FishKillSTDEV = v;
}
int32 JsonSystemConst::GetSwingSkill_TipStyle() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _SwingSkill_TipStyle;
}
void JsonSystemConst::SetSwingSkill_TipStyle(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_SwingSkill_TipStyle = v;
}
int32 JsonSystemConst::GetCouponControlParam() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _CouponControlParam;
}
void JsonSystemConst::SetCouponControlParam(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_CouponControlParam = v;
}
int32 JsonSystemConst::GetMarketGoodsNum() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _MarketGoodsNum;
}
void JsonSystemConst::SetMarketGoodsNum(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_MarketGoodsNum = v;
}
int32 JsonSystemConst::GetSwingStrengthMaxLevel() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _SwingStrengthMaxLevel;
}
void JsonSystemConst::SetSwingStrengthMaxLevel(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_SwingStrengthMaxLevel = v;
}
int32 JsonSystemConst::GetVIPPrivilegeMail() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _VIPPrivilegeMail;
}
void JsonSystemConst::SetVIPPrivilegeMail(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_VIPPrivilegeMail = v;
}
int32 JsonSystemConst::GetEnergyRecoveryTime() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _EnergyRecoveryTime;
}
void JsonSystemConst::SetEnergyRecoveryTime(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_EnergyRecoveryTime = v;
}
int32 JsonSystemConst::GetInitialEnergyMax() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _InitialEnergyMax;
}
void JsonSystemConst::SetInitialEnergyMax(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_InitialEnergyMax = v;
}
int32 JsonSystemConst::GetTurretFirstReward() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _TurretFirstReward;
}
void JsonSystemConst::SetTurretFirstReward(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_TurretFirstReward = v;
}
int32 JsonSystemConst::GetMinOutFish() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _MinOutFish;
}
void JsonSystemConst::SetMinOutFish(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_MinOutFish = v;
}
int32 JsonSystemConst::GetMaxOutFish() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _MaxOutFish;
}
void JsonSystemConst::SetMaxOutFish(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_MaxOutFish = v;
}
int32 JsonSystemConst::GetOutFishInterval() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _OutFishInterval;
}
void JsonSystemConst::SetOutFishInterval(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_OutFishInterval = v;
}
int32 JsonSystemConst::GetOutFishCount() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _OutFishCount;
}
void JsonSystemConst::SetOutFishCount(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_OutFishCount = v;
}
int32 JsonSystemConst::GetNormalOutFishTime() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _NormalOutFishTime;
}
void JsonSystemConst::SetNormalOutFishTime(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_NormalOutFishTime = v;
}
int32 JsonSystemConst::GetChangeSceneTime() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ChangeSceneTime;
}
void JsonSystemConst::SetChangeSceneTime(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ChangeSceneTime = v;
}
int32 JsonSystemConst::GetFixedhits() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Fixedhits;
}
void JsonSystemConst::SetFixedhits(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Fixedhits = v;
}
int32 JsonSystemConst::GetChangeSceneWaitTime() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ChangeSceneWaitTime;
}
void JsonSystemConst::SetChangeSceneWaitTime(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ChangeSceneWaitTime = v;
}
int32 JsonSystemConst::GetLaserHitCount() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _LaserHitCount;
}
void JsonSystemConst::SetLaserHitCount(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_LaserHitCount = v;
}
int32 JsonSystemConst::GetPearlPerHit() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _PearlPerHit;
}
void JsonSystemConst::SetPearlPerHit(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_PearlPerHit = v;
}
int32 JsonSystemConst::GetPearlHitCount() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _PearlHitCount;
}
void JsonSystemConst::SetPearlHitCount(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_PearlHitCount = v;
}
int32 JsonSystemConst::GetFirstTicket() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _FirstTicket;
}
void JsonSystemConst::SetFirstTicket(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_FirstTicket = v;
}
int32 JsonSystemConst::GetMinBroadcast() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _MinBroadcast;
}
void JsonSystemConst::SetMinBroadcast(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_MinBroadcast = v;
}
int32 JsonSystemConst::GetMinTicketTime() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _MinTicketTime;
}
void JsonSystemConst::SetMinTicketTime(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_MinTicketTime = v;
}
int32 JsonSystemConst::GetMaxTicketTime() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _MaxTicketTime;
}
void JsonSystemConst::SetMaxTicketTime(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_MaxTicketTime = v;
}
int32 JsonSystemConst::GetMaxEverydayTicket() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _MaxEverydayTicket;
}
void JsonSystemConst::SetMaxEverydayTicket(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_MaxEverydayTicket = v;
}
int32 JsonSystemConst::Getdefaultlevel() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _defaultlevel;
}
void JsonSystemConst::Setdefaultlevel(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_defaultlevel = v;
}
int32 JsonSystemConst::GetprotectTime() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _protectTime;
}
void JsonSystemConst::SetprotectTime(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_protectTime = v;
}
int32 JsonSystemConst::GetprotectLine() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _protectLine;
}
void JsonSystemConst::SetprotectLine(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_protectLine = v;
}
int32 JsonSystemConst::GetprotectMin() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _protectMin;
}
void JsonSystemConst::SetprotectMin(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_protectMin = v;
}
int32 JsonSystemConst::GetprotectMax() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _protectMax;
}
void JsonSystemConst::SetprotectMax(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_protectMax = v;
}
int32 JsonSystemConst::Getisopen() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _isopen;
}
void JsonSystemConst::Setisopen(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_isopen = v;
}
int32 JsonSystemConst::GetMissileHitCount() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _MissileHitCount;
}
void JsonSystemConst::SetMissileHitCount(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_MissileHitCount = v;
}
int32 JsonSystemConst::GetDiscountVIP() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _DiscountVIP;
}
void JsonSystemConst::SetDiscountVIP(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_DiscountVIP = v;
}
int32 JsonSystemConst::GetDiscountValue() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _DiscountValue;
}
void JsonSystemConst::SetDiscountValue(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_DiscountValue = v;
}
int32 JsonSystemConst::GetMonthCardTurret() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _MonthCardTurret;
}
void JsonSystemConst::SetMonthCardTurret(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_MonthCardTurret = v;
}
int32 JsonSystemConst::GetStarRate() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _StarRate;
}
void JsonSystemConst::SetStarRate(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_StarRate = v;
}
int32 JsonSystemConst::GetCloseNet() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _CloseNet;
}
void JsonSystemConst::SetCloseNet(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_CloseNet = v;
}
int32 JsonSystemConst::GetIsDebug() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _IsDebug;
}
void JsonSystemConst::SetIsDebug(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_IsDebug = v;
}
int32 JsonSystemConst::GetDefaultTurret() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _DefaultTurret;
}
void JsonSystemConst::SetDefaultTurret(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_DefaultTurret = v;
}
int32 JsonSystemConst::GetCloseSkill() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _CloseSkill;
}
void JsonSystemConst::SetCloseSkill(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_CloseSkill = v;
}
int32 JsonSystemConst::Getgame_state1() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _game_state1;
}
void JsonSystemConst::Setgame_state1(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_game_state1 = v;
}
int32 JsonSystemConst::Getgame_state2() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _game_state2;
}
void JsonSystemConst::Setgame_state2(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_game_state2 = v;
}
int32 JsonSystemConst::Getgame_state3() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _game_state3;
}
void JsonSystemConst::Setgame_state3(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_game_state3 = v;
}
int32 JsonSystemConst::GetEndExperienceTime() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _EndExperienceTime;
}
void JsonSystemConst::SetEndExperienceTime(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_EndExperienceTime = v;
}
int32 JsonSystemConst::GetFixLine() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _FixLine;
}
void JsonSystemConst::SetFixLine(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_FixLine = v;
}
int32 JsonSystemConst::GetfixRate() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _fixRate;
}
void JsonSystemConst::SetfixRate(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_fixRate = v;
}
int32 JsonSystemConst::GetFishDeathMiuParam() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _FishDeathMiuParam;
}
void JsonSystemConst::SetFishDeathMiuParam(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_FishDeathMiuParam = v;
}
int32 JsonSystemConst::GetFishDeathSigmaParam() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _FishDeathSigmaParam;
}
void JsonSystemConst::SetFishDeathSigmaParam(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_FishDeathSigmaParam = v;
}
int32 JsonSystemConst::GetArenaWarrior() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ArenaWarrior;
}
void JsonSystemConst::SetArenaWarrior(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ArenaWarrior = v;
}
int32 JsonSystemConst::GetTowerChallenger() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _TowerChallenger;
}
void JsonSystemConst::SetTowerChallenger(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_TowerChallenger = v;
}
int32 JsonSystemConst::GetBindIdentityMailID() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _BindIdentityMailID;
}
void JsonSystemConst::SetBindIdentityMailID(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_BindIdentityMailID = v;
}
int32 JsonSystemConst::GetBindIdentityLootID() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _BindIdentityLootID;
}
void JsonSystemConst::SetBindIdentityLootID(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_BindIdentityLootID = v;
}
int32 JsonSystemConst::GetBindPhoneMailID() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _BindPhoneMailID;
}
void JsonSystemConst::SetBindPhoneMailID(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_BindPhoneMailID = v;
}
int32 JsonSystemConst::GetBindPhoneLootID() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _BindPhoneLootID;
}
void JsonSystemConst::SetBindPhoneLootID(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_BindPhoneLootID = v;
}
int32 JsonSystemConst::GetGameExpectationTime() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _GameExpectationTime;
}
void JsonSystemConst::SetGameExpectationTime(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_GameExpectationTime = v;
}
int32 JsonSystemConst::GetFriendChangeFrequency() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _FriendChangeFrequency;
}
void JsonSystemConst::SetFriendChangeFrequency(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_FriendChangeFrequency = v;
}
int32 JsonSystemConst::GetFriendChangeRange() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _FriendChangeRange;
}
void JsonSystemConst::SetFriendChangeRange(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_FriendChangeRange = v;
}
int32 JsonSystemConst::GetPovertyReward() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _PovertyReward;
}
void JsonSystemConst::SetPovertyReward(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_PovertyReward = v;
}
int32 JsonSystemConst::GetPovertyRewardTimes() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _PovertyRewardTimes;
}
void JsonSystemConst::SetPovertyRewardTimes(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_PovertyRewardTimes = v;
}
int32 JsonSystemConst::GetTurretStarUpgradeGoldRate() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _TurretStarUpgradeGoldRate;
}
void JsonSystemConst::SetTurretStarUpgradeGoldRate(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_TurretStarUpgradeGoldRate = v;
}
int32 JsonSystemConst::GetNewBieCarnivalExp() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _NewBieCarnivalExp;
}
void JsonSystemConst::SetNewBieCarnivalExp(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_NewBieCarnivalExp = v;
}
int32 JsonSystemConst::GetNewBieCarnivalLoot() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _NewBieCarnivalLoot;
}
void JsonSystemConst::SetNewBieCarnivalLoot(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_NewBieCarnivalLoot = v;
}
int32 JsonSystemConst::GetNewBieCarnivalLottery() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _NewBieCarnivalLottery;
}
void JsonSystemConst::SetNewBieCarnivalLottery(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_NewBieCarnivalLottery = v;
}
int32 JsonSystemConst::GetNewBieCarnivalItem() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _NewBieCarnivalItem;
}
void JsonSystemConst::SetNewBieCarnivalItem(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_NewBieCarnivalItem = v;
}
int32 JsonSystemConst::GetNewBieCarnivalMail() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _NewBieCarnivalMail;
}
void JsonSystemConst::SetNewBieCarnivalMail(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_NewBieCarnivalMail = v;
}
int32 JsonSystemConst::GetQuestAcceptTips() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _QuestAcceptTips;
}
void JsonSystemConst::SetQuestAcceptTips(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_QuestAcceptTips = v;
}
int32 JsonSystemConst::GetFishSoundFrequent() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _FishSoundFrequent;
}
void JsonSystemConst::SetFishSoundFrequent(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_FishSoundFrequent = v;
}
int32 JsonSystemConst::GetCouponExchangeRate() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _CouponExchangeRate;
}
void JsonSystemConst::SetCouponExchangeRate(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_CouponExchangeRate = v;
}
int32 JsonSystemConst::GetCouponDrawCount() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _CouponDrawCount;
}
void JsonSystemConst::SetCouponDrawCount(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_CouponDrawCount = v;
}
int32 JsonSystemConst::GetPhoneVoucherItemID() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _PhoneVoucherItemID;
}
void JsonSystemConst::SetPhoneVoucherItemID(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_PhoneVoucherItemID = v;
}
int32 JsonSystemConst::GetRedEnvelopeMaxShow() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _RedEnvelopeMaxShow;
}
void JsonSystemConst::SetRedEnvelopeMaxShow(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_RedEnvelopeMaxShow = v;
}
int64 JsonSystemConst::GetUserTotalGoldValue() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _UserTotalGoldValue;
}
void JsonSystemConst::SetUserTotalGoldValue(int64 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_UserTotalGoldValue = v;
}
int32 JsonSystemConst::GetPovertyResetRate() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _PovertyResetRate;
}
void JsonSystemConst::SetPovertyResetRate(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_PovertyResetRate = v;
}
int32 JsonSystemConst::GetUserValueInitial() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _UserValueInitial;
}
void JsonSystemConst::SetUserValueInitial(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_UserValueInitial = v;
}
int32 JsonSystemConst::GetUserValueMinusForVIP() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _UserValueMinusForVIP;
}
void JsonSystemConst::SetUserValueMinusForVIP(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_UserValueMinusForVIP = v;
}
int32 JsonSystemConst::GetUserValueMinusForFree() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _UserValueMinusForFree;
}
void JsonSystemConst::SetUserValueMinusForFree(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_UserValueMinusForFree = v;
}
int32 JsonSystemConst::GetUserValueMin() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _UserValueMin;
}
void JsonSystemConst::SetUserValueMin(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_UserValueMin = v;
}
int32 JsonSystemConst::GetUserValueAddForPovertyRate() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _UserValueAddForPovertyRate;
}
void JsonSystemConst::SetUserValueAddForPovertyRate(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_UserValueAddForPovertyRate = v;
}
int32 JsonSystemConst::GetUserValueAddForPoverty() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _UserValueAddForPoverty;
}
void JsonSystemConst::SetUserValueAddForPoverty(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_UserValueAddForPoverty = v;
}
int32 JsonSystemConst::GetPovertyProtectTurretLeft() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _PovertyProtectTurretLeft;
}
void JsonSystemConst::SetPovertyProtectTurretLeft(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_PovertyProtectTurretLeft = v;
}
int32 JsonSystemConst::GetPovertyProtectFishPoint() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _PovertyProtectFishPoint;
}
void JsonSystemConst::SetPovertyProtectFishPoint(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_PovertyProtectFishPoint = v;
}
int32 JsonSystemConst::GetPovertyProtectRate() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _PovertyProtectRate;
}
void JsonSystemConst::SetPovertyProtectRate(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_PovertyProtectRate = v;
}
int64 JsonSystemConst::GetPovertyProtectHistoryTotal() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _PovertyProtectHistoryTotal;
}
void JsonSystemConst::SetPovertyProtectHistoryTotal(int64 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_PovertyProtectHistoryTotal = v;
}
int32 JsonSystemConst::GetSlotBossMailID() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _SlotBossMailID;
}
void JsonSystemConst::SetSlotBossMailID(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_SlotBossMailID = v;
}
int32 JsonSystemConst::GetSlotResetItemID() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _SlotResetItemID;
}
void JsonSystemConst::SetSlotResetItemID(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_SlotResetItemID = v;
}
int32 JsonSystemConst::GetHunterRefundItemID() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _HunterRefundItemID;
}
void JsonSystemConst::SetHunterRefundItemID(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_HunterRefundItemID = v;
}
int32 JsonSystemConst::GetHunterContinueItemID() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _HunterContinueItemID;
}
void JsonSystemConst::SetHunterContinueItemID(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_HunterContinueItemID = v;
}
int32 JsonSystemConst::GetHunterRefundMin() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _HunterRefundMin;
}
void JsonSystemConst::SetHunterRefundMin(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_HunterRefundMin = v;
}
int64 JsonSystemConst::GetHunterRefundMax() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _HunterRefundMax;
}
void JsonSystemConst::SetHunterRefundMax(int64 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_HunterRefundMax = v;
}
int32 JsonSystemConst::GetHunterRefundDivider() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _HunterRefundDivider;
}
void JsonSystemConst::SetHunterRefundDivider(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_HunterRefundDivider = v;
}
int32 JsonSystemConst::GetNewBieRedEnvelope() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _NewBieRedEnvelope;
}
void JsonSystemConst::SetNewBieRedEnvelope(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_NewBieRedEnvelope = v;
}
int32 JsonSystemConst::GetNewBieRedEnvelopeTime() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _NewBieRedEnvelopeTime;
}
void JsonSystemConst::SetNewBieRedEnvelopeTime(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_NewBieRedEnvelopeTime = v;
}
int64 JsonSystemConst::GetNewBieNetScoreRange() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _NewBieNetScoreRange;
}
void JsonSystemConst::SetNewBieNetScoreRange(int64 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_NewBieNetScoreRange = v;
}
int64 JsonSystemConst::GetRegularNetScoreRange() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _RegularNetScoreRange;
}
void JsonSystemConst::SetRegularNetScoreRange(int64 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_RegularNetScoreRange = v;
}
int32 JsonSystemConst::GetInitialHeadIcon() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _InitialHeadIcon;
}
void JsonSystemConst::SetInitialHeadIcon(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_InitialHeadIcon = v;
}
int32 JsonSystemConst::GetInitialHeadFrame() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _InitialHeadFrame;
}
void JsonSystemConst::SetInitialHeadFrame(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_InitialHeadFrame = v;
}
int32 JsonSystemConst::GetInitialPropertyBG() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _InitialPropertyBG;
}
void JsonSystemConst::SetInitialPropertyBG(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_InitialPropertyBG = v;
}
int32 JsonSystemConst::GetSummonNetScoreRate() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _SummonNetScoreRate;
}
void JsonSystemConst::SetSummonNetScoreRate(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_SummonNetScoreRate = v;
}
int64 JsonSystemConst::GetSummonNetScoreRangeMax() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _SummonNetScoreRangeMax;
}
void JsonSystemConst::SetSummonNetScoreRangeMax(int64 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_SummonNetScoreRangeMax = v;
}
int64 JsonSystemConst::GetSummonNetScoreRangeMin() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _SummonNetScoreRangeMin;
}
void JsonSystemConst::SetSummonNetScoreRangeMin(int64 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_SummonNetScoreRangeMin = v;
}
int32 JsonSystemConst::GetMonthCardEffectMin() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _MonthCardEffectMin;
}
void JsonSystemConst::SetMonthCardEffectMin(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_MonthCardEffectMin = v;
}
int32 JsonSystemConst::GetCardDrawNuclearID() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _CardDrawNuclearID;
}
void JsonSystemConst::SetCardDrawNuclearID(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_CardDrawNuclearID = v;
}
int32 JsonSystemConst::GetPeriodPassID() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _PeriodPassID;
}
void JsonSystemConst::SetPeriodPassID(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_PeriodPassID = v;
}
int32 JsonSystemConst::GetTimesPerDiamond() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _TimesPerDiamond;
}
void JsonSystemConst::SetTimesPerDiamond(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_TimesPerDiamond = v;
}
int32 JsonSystemConst::GetAdditionLootParamK() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _AdditionLootParamK;
}
void JsonSystemConst::SetAdditionLootParamK(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_AdditionLootParamK = v;
}
int32 JsonSystemConst::GetAdditionLootParamM() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _AdditionLootParamM;
}
void JsonSystemConst::SetAdditionLootParamM(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_AdditionLootParamM = v;
}
int32 JsonSystemConst::GetNuclearDrawRankFishID() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _NuclearDrawRankFishID;
}
void JsonSystemConst::SetNuclearDrawRankFishID(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_NuclearDrawRankFishID = v;
}
int32 JsonSystemConst::GetNuclearDrawFee() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _NuclearDrawFee;
}
void JsonSystemConst::SetNuclearDrawFee(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_NuclearDrawFee = v;
}
int32 JsonSystemConst::GetNuclearDrawScoreParamM1() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _NuclearDrawScoreParamM1;
}
void JsonSystemConst::SetNuclearDrawScoreParamM1(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_NuclearDrawScoreParamM1 = v;
}
int32 JsonSystemConst::GetNuclearDrawScoreParamM2() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _NuclearDrawScoreParamM2;
}
void JsonSystemConst::SetNuclearDrawScoreParamM2(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_NuclearDrawScoreParamM2 = v;
}
int32 JsonSystemConst::GetNuclearDrawAverageScore() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _NuclearDrawAverageScore;
}
void JsonSystemConst::SetNuclearDrawAverageScore(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_NuclearDrawAverageScore = v;
}
int32 JsonSystemConst::GetNuclearDrawGuaranteeRate() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _NuclearDrawGuaranteeRate;
}
void JsonSystemConst::SetNuclearDrawGuaranteeRate(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_NuclearDrawGuaranteeRate = v;
}
int32 JsonSystemConst::GetCollectionCardItemID() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _CollectionCardItemID;
}
void JsonSystemConst::SetCollectionCardItemID(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_CollectionCardItemID = v;
}
int32 JsonSystemConst::GetCardFishKillSigmaParam() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _CardFishKillSigmaParam;
}
void JsonSystemConst::SetCardFishKillSigmaParam(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_CardFishKillSigmaParam = v;
}
int32 JsonSystemConst::GetCardFishLootMin() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _CardFishLootMin;
}
void JsonSystemConst::SetCardFishLootMin(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_CardFishLootMin = v;
}
int32 JsonSystemConst::GetCardFishLootMax() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _CardFishLootMax;
}
void JsonSystemConst::SetCardFishLootMax(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_CardFishLootMax = v;
}
int32 JsonSystemConst::GetGrownFundItemID() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _GrownFundItemID;
}
void JsonSystemConst::SetGrownFundItemID(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_GrownFundItemID = v;
}
int32 JsonSystemConst::GetFriendNumLimit() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _FriendNumLimit;
}
void JsonSystemConst::SetFriendNumLimit(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_FriendNumLimit = v;
}
int32 JsonSystemConst::GetFriendApplyLimit() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _FriendApplyLimit;
}
void JsonSystemConst::SetFriendApplyLimit(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_FriendApplyLimit = v;
}
int32 JsonSystemConst::GetFriendBlockListLimit() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _FriendBlockListLimit;
}
void JsonSystemConst::SetFriendBlockListLimit(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_FriendBlockListLimit = v;
}
int32 JsonSystemConst::GetMonthCard_DailyReward() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _MonthCard_DailyReward;
}
void JsonSystemConst::SetMonthCard_DailyReward(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_MonthCard_DailyReward = v;
}
int32 JsonSystemConst::GetTreasureBoxVoucherInitial() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _TreasureBoxVoucherInitial;
}
void JsonSystemConst::SetTreasureBoxVoucherInitial(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_TreasureBoxVoucherInitial = v;
}
int32 JsonSystemConst::GetTreasureBoxVoucherInitialRate() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _TreasureBoxVoucherInitialRate;
}
void JsonSystemConst::SetTreasureBoxVoucherInitialRate(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_TreasureBoxVoucherInitialRate = v;
}
int32 JsonSystemConst::GetTreasureBoxVoucherChargeRate() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _TreasureBoxVoucherChargeRate;
}
void JsonSystemConst::SetTreasureBoxVoucherChargeRate(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_TreasureBoxVoucherChargeRate = v;
}
int32 JsonSystemConst::GetTreasureBoxVoucherMax() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _TreasureBoxVoucherMax;
}
void JsonSystemConst::SetTreasureBoxVoucherMax(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_TreasureBoxVoucherMax = v;
}
int32 JsonSystemConst::GetSuperWeaponInitialSkinItemID() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _SuperWeaponInitialSkinItemID;
}
void JsonSystemConst::SetSuperWeaponInitialSkinItemID(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_SuperWeaponInitialSkinItemID = v;
}
int32 JsonSystemConst::GetSunquanBossID() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _SunquanBossID;
}
void JsonSystemConst::SetSunquanBossID(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_SunquanBossID = v;
}
int32 JsonSystemConst::GetCaocaoBossID() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _CaocaoBossID;
}
void JsonSystemConst::SetCaocaoBossID(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_CaocaoBossID = v;
}
int32 JsonSystemConst::GetLvbuBossID() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _LvbuBossID;
}
void JsonSystemConst::SetLvbuBossID(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_LvbuBossID = v;
}
int32 JsonSystemConst::GetMenghuoBossID() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _MenghuoBossID;
}
void JsonSystemConst::SetMenghuoBossID(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_MenghuoBossID = v;
}
int32 JsonSystemConst::GetSuperWeaponWidthBasic() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _SuperWeaponWidthBasic;
}
void JsonSystemConst::SetSuperWeaponWidthBasic(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_SuperWeaponWidthBasic = v;
}
int32 JsonSystemConst::GetFishTaxRange() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _FishTaxRange;
}
void JsonSystemConst::SetFishTaxRange(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_FishTaxRange = v;
}
int32 JsonSystemConst::GetFishTaxChangeIntervalMin() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _FishTaxChangeIntervalMin;
}
void JsonSystemConst::SetFishTaxChangeIntervalMin(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_FishTaxChangeIntervalMin = v;
}
int32 JsonSystemConst::GetFishTaxChangeIntervalMax() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _FishTaxChangeIntervalMax;
}
void JsonSystemConst::SetFishTaxChangeIntervalMax(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_FishTaxChangeIntervalMax = v;
}
int32 JsonSystemConst::GetRechargeFrozenTime() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _RechargeFrozenTime;
}
void JsonSystemConst::SetRechargeFrozenTime(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_RechargeFrozenTime = v;
}
int32 JsonSystemConst::GetReceiveGiftsTime() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ReceiveGiftsTime;
}
void JsonSystemConst::SetReceiveGiftsTime(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ReceiveGiftsTime = v;
}
int32 JsonSystemConst::GetSendGiftsTime() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _SendGiftsTime;
}
void JsonSystemConst::SetSendGiftsTime(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_SendGiftsTime = v;
}
int32 JsonSystemConst::GetCrystal() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Crystal;
}
void JsonSystemConst::SetCrystal(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Crystal = v;
}
int32 JsonSystemConst::GetVIPRankResourceID() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _VIPRankResourceID;
}
void JsonSystemConst::SetVIPRankResourceID(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_VIPRankResourceID = v;
}
int32 JsonSystemConst::GetAcceptCancelOrderMail() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _AcceptCancelOrderMail;
}
void JsonSystemConst::SetAcceptCancelOrderMail(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_AcceptCancelOrderMail = v;
}
int32 JsonSystemConst::GetAcceptExpiredOrderMail() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _AcceptExpiredOrderMail;
}
void JsonSystemConst::SetAcceptExpiredOrderMail(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_AcceptExpiredOrderMail = v;
}
int32 JsonSystemConst::GetSendCancelOrderMail() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _SendCancelOrderMail;
}
void JsonSystemConst::SetSendCancelOrderMail(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_SendCancelOrderMail = v;
}
int32 JsonSystemConst::GetSendExpiredOrderMail() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _SendExpiredOrderMail;
}
void JsonSystemConst::SetSendExpiredOrderMail(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_SendExpiredOrderMail = v;
}
int32 JsonSystemConst::GetRecieveGiftsMail() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _RecieveGiftsMail;
}
void JsonSystemConst::SetRecieveGiftsMail(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_RecieveGiftsMail = v;
}
int32 JsonSystemConst::GetGiftForceCloseMail() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _GiftForceCloseMail;
}
void JsonSystemConst::SetGiftForceCloseMail(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_GiftForceCloseMail = v;
}
int32 JsonSystemConst::GetChatWordLimit() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ChatWordLimit;
}
void JsonSystemConst::SetChatWordLimit(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ChatWordLimit = v;
}
int32 JsonSystemConst::GetChatCD() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ChatCD;
}
void JsonSystemConst::SetChatCD(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ChatCD = v;
}
int32 JsonSystemConst::GetPrivateChatMessageNum() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _PrivateChatMessageNum;
}
void JsonSystemConst::SetPrivateChatMessageNum(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_PrivateChatMessageNum = v;
}
int32 JsonSystemConst::GetGroupChatMessageNum() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _GroupChatMessageNum;
}
void JsonSystemConst::SetGroupChatMessageNum(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_GroupChatMessageNum = v;
}
int32 JsonSystemConst::GetBindPhoneAddPopularity() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _BindPhoneAddPopularity;
}
void JsonSystemConst::SetBindPhoneAddPopularity(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_BindPhoneAddPopularity = v;
}
int32 JsonSystemConst::GetSendGiftsNeedPopularity() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _SendGiftsNeedPopularity;
}
void JsonSystemConst::SetSendGiftsNeedPopularity(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_SendGiftsNeedPopularity = v;
}
int32 JsonSystemConst::GetGroupChatMemberMax() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _GroupChatMemberMax;
}
void JsonSystemConst::SetGroupChatMemberMax(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_GroupChatMemberMax = v;
}
int32 JsonSystemConst::GetGiftRecordKeepTime() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _GiftRecordKeepTime;
}
void JsonSystemConst::SetGiftRecordKeepTime(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_GiftRecordKeepTime = v;
}
int32 JsonSystemConst::GetHunterRefundTime() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _HunterRefundTime;
}
void JsonSystemConst::SetHunterRefundTime(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_HunterRefundTime = v;
}
int32 JsonSystemConst::GetSound_Button() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Sound_Button;
}
void JsonSystemConst::SetSound_Button(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Sound_Button = v;
}
int32 JsonSystemConst::GetSound_DiamondDrop() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Sound_DiamondDrop;
}
void JsonSystemConst::SetSound_DiamondDrop(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Sound_DiamondDrop = v;
}
int32 JsonSystemConst::GetSound_Gold() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Sound_Gold;
}
void JsonSystemConst::SetSound_Gold(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Sound_Gold = v;
}
int32 JsonSystemConst::GetSound_HallBG() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Sound_HallBG;
}
void JsonSystemConst::SetSound_HallBG(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Sound_HallBG = v;
}
int32 JsonSystemConst::GetSound_LevelUP() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Sound_LevelUP;
}
void JsonSystemConst::SetSound_LevelUP(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Sound_LevelUP = v;
}
int32 JsonSystemConst::GetSound_QuestFinish() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Sound_QuestFinish;
}
void JsonSystemConst::SetSound_QuestFinish(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Sound_QuestFinish = v;
}
int32 JsonSystemConst::GetSound_StarUP() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Sound_StarUP;
}
void JsonSystemConst::SetSound_StarUP(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Sound_StarUP = v;
}
int32 JsonSystemConst::GetSound_GoldTurnTable1() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Sound_GoldTurnTable1;
}
void JsonSystemConst::SetSound_GoldTurnTable1(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Sound_GoldTurnTable1 = v;
}
int32 JsonSystemConst::GetSound_GoldTurnTable2() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Sound_GoldTurnTable2;
}
void JsonSystemConst::SetSound_GoldTurnTable2(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Sound_GoldTurnTable2 = v;
}
int32 JsonSystemConst::GetSound_RewardGet() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Sound_RewardGet;
}
void JsonSystemConst::SetSound_RewardGet(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Sound_RewardGet = v;
}
int32 JsonSystemConst::GetSound_TurnTableReward() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Sound_TurnTableReward;
}
void JsonSystemConst::SetSound_TurnTableReward(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Sound_TurnTableReward = v;
}
int32 JsonSystemConst::GetSound_TurnTableDada() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Sound_TurnTableDada;
}
void JsonSystemConst::SetSound_TurnTableDada(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Sound_TurnTableDada = v;
}
int32 JsonSystemConst::GetSound_TurnTableStart() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Sound_TurnTableStart;
}
void JsonSystemConst::SetSound_TurnTableStart(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Sound_TurnTableStart = v;
}
int32 JsonSystemConst::GetSound_GoldCombo() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Sound_GoldCombo;
}
void JsonSystemConst::SetSound_GoldCombo(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Sound_GoldCombo = v;
}
int32 JsonSystemConst::GetSound_HighNotice() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Sound_HighNotice;
}
void JsonSystemConst::SetSound_HighNotice(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Sound_HighNotice = v;
}
int32 JsonSystemConst::GetSound_CountDown() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Sound_CountDown;
}
void JsonSystemConst::SetSound_CountDown(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Sound_CountDown = v;
}
int32 JsonSystemConst::GetSound_Success() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Sound_Success;
}
void JsonSystemConst::SetSound_Success(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Sound_Success = v;
}
int32 JsonSystemConst::GetSound_Failed() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Sound_Failed;
}
void JsonSystemConst::SetSound_Failed(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Sound_Failed = v;
}
int32 JsonSystemConst::GetSound_signup() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Sound_signup;
}
void JsonSystemConst::SetSound_signup(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Sound_signup = v;
}
int32 JsonSystemConst::GetSound_monthcard() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Sound_monthcard;
}
void JsonSystemConst::SetSound_monthcard(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Sound_monthcard = v;
}
int32 JsonSystemConst::GetSound_guide_1() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Sound_guide_1;
}
void JsonSystemConst::SetSound_guide_1(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Sound_guide_1 = v;
}
int32 JsonSystemConst::GetSound_guide_2() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Sound_guide_2;
}
void JsonSystemConst::SetSound_guide_2(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Sound_guide_2 = v;
}
int32 JsonSystemConst::GetSound_guide_3() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Sound_guide_3;
}
void JsonSystemConst::SetSound_guide_3(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Sound_guide_3 = v;
}
int32 JsonSystemConst::GetSound_guide_4() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Sound_guide_4;
}
void JsonSystemConst::SetSound_guide_4(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Sound_guide_4 = v;
}
int32 JsonSystemConst::GetSound_guide_5() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Sound_guide_5;
}
void JsonSystemConst::SetSound_guide_5(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Sound_guide_5 = v;
}
int32 JsonSystemConst::GetSound_guide_6() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Sound_guide_6;
}
void JsonSystemConst::SetSound_guide_6(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Sound_guide_6 = v;
}
int32 JsonSystemConst::GetSound_guide_7() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Sound_guide_7;
}
void JsonSystemConst::SetSound_guide_7(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Sound_guide_7 = v;
}
int32 JsonSystemConst::GetSound_guide_8() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Sound_guide_8;
}
void JsonSystemConst::SetSound_guide_8(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Sound_guide_8 = v;
}
int32 JsonSystemConst::GetSound_guide_9() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Sound_guide_9;
}
void JsonSystemConst::SetSound_guide_9(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Sound_guide_9 = v;
}
int32 JsonSystemConst::GetSound_guide_10() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Sound_guide_10;
}
void JsonSystemConst::SetSound_guide_10(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Sound_guide_10 = v;
}
int32 JsonSystemConst::GetSound_Strength() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Sound_Strength;
}
void JsonSystemConst::SetSound_Strength(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Sound_Strength = v;
}
int32 JsonSystemConst::GetSound_Upgrade() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Sound_Upgrade;
}
void JsonSystemConst::SetSound_Upgrade(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Sound_Upgrade = v;
}
int32 JsonSystemConst::GetSound_Turntable() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Sound_Turntable;
}
void JsonSystemConst::SetSound_Turntable(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Sound_Turntable = v;
}
int32 JsonSystemConst::GetSound_TurntableBingo() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Sound_TurntableBingo;
}
void JsonSystemConst::SetSound_TurntableBingo(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Sound_TurntableBingo = v;
}
int32 JsonSystemConst::GetSound_PhoneVoucher() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Sound_PhoneVoucher;
}
void JsonSystemConst::SetSound_PhoneVoucher(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Sound_PhoneVoucher = v;
}
int32 JsonSystemConst::GetSound_Shuffle() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Sound_Shuffle;
}
void JsonSystemConst::SetSound_Shuffle(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Sound_Shuffle = v;
}
int32 JsonSystemConst::GetSound_nuclear_relation() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Sound_nuclear_relation;
}
void JsonSystemConst::SetSound_nuclear_relation(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Sound_nuclear_relation = v;
}
int32 JsonSystemConst::GetSound_nuclear_open() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Sound_nuclear_open;
}
void JsonSystemConst::SetSound_nuclear_open(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Sound_nuclear_open = v;
}
int32 JsonSystemConst::GetSound_nuclear_open_auto() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Sound_nuclear_open_auto;
}
void JsonSystemConst::SetSound_nuclear_open_auto(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Sound_nuclear_open_auto = v;
}
int32 JsonSystemConst::GetSound_treasure_turning() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Sound_treasure_turning;
}
void JsonSystemConst::SetSound_treasure_turning(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Sound_treasure_turning = v;
}
int32 JsonSystemConst::GetSound_treasure_stop() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Sound_treasure_stop;
}
void JsonSystemConst::SetSound_treasure_stop(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Sound_treasure_stop = v;
}
