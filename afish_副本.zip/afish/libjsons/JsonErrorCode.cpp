#include "JsonErrorCode.h"

void JsonErrorCode::SetByName(const string& name, int64 v) {
	if( name =="Success" ) {
		SetSuccess(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="SystemError" ) {
		SetSystemError(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="GoldLow" ) {
		SetGoldLow(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="DiamondLow" ) {
		SetDiamondLow(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="LuckBagBought" ) {
		SetLuckBagBought(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="InvalidLuckBag" ) {
		SetInvalidLuckBag(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="DailyDiscountBought" ) {
		SetDailyDiscountBought(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="InvalidDailyDiscount" ) {
		SetInvalidDailyDiscount(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="NoGameTimeReward" ) {
		SetNoGameTimeReward(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="PovertyNumLow" ) {
		SetPovertyNumLow(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="PovertyFake" ) {
		SetPovertyFake(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="VideoRewardTimeFail" ) {
		SetVideoRewardTimeFail(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="NoLevelReward" ) {
		SetNoLevelReward(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="NoGrowthReward" ) {
		SetNoGrowthReward(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="GrowthRewarded" ) {
		SetGrowthRewarded(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="GrabBonusNull" ) {
		SetGrabBonusNull(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="SystemInChecking" ) {
		SetSystemInChecking(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="AccountBanned" ) {
		SetAccountBanned(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="LoginDatabaseFailed" ) {
		SetLoginDatabaseFailed(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="LoginGenUserIdFailed" ) {
		SetLoginGenUserIdFailed(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="LoginUserTokenAccFailed" ) {
		SetLoginUserTokenAccFailed(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="LoginTokenNoUser" ) {
		SetLoginTokenNoUser(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="LoginTooQuick" ) {
		SetLoginTooQuick(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="LoginInvalidToken" ) {
		SetLoginInvalidToken(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="LoginAccountAlreadyBound" ) {
		SetLoginAccountAlreadyBound(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="LoginInvalidType" ) {
		SetLoginInvalidType(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="LoginTokenExpired" ) {
		SetLoginTokenExpired(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="MailNotEmpty" ) {
		SetMailNotEmpty(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="MailNoReward" ) {
		SetMailNoReward(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="MailRewarded" ) {
		SetMailRewarded(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="MailNotFound" ) {
		SetMailNotFound(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="MailCanDo" ) {
		SetMailCanDo(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ChargeProductNotFound" ) {
		SetChargeProductNotFound(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ChangeNameNoItem" ) {
		SetChangeNameNoItem(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ChangeNameInvalidName" ) {
		SetChangeNameInvalidName(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ChangeSignTooLong" ) {
		SetChangeSignTooLong(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ChangeSignInvalid" ) {
		SetChangeSignInvalid(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ItemUseNumFail" ) {
		SetItemUseNumFail(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ItemUseNoItem" ) {
		SetItemUseNoItem(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ItemUseNumLow" ) {
		SetItemUseNumLow(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ItemUseTypeFail" ) {
		SetItemUseTypeFail(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ItemUseTurretNumLow" ) {
		SetItemUseTurretNumLow(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ItemUseTurretFailed" ) {
		SetItemUseTurretFailed(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ItemUseSwingNumLow" ) {
		SetItemUseSwingNumLow(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ItemUseSwingFailed" ) {
		SetItemUseSwingFailed(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="SignDayAlready" ) {
		SetSignDayAlready(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="SignDayTypeFail" ) {
		SetSignDayTypeFail(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="TurretIdError" ) {
		SetTurretIdError(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="TurretExpItemError" ) {
		SetTurretExpItemError(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="TurretExpMax" ) {
		SetTurretExpMax(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="TurretStarExpItemError" ) {
		SetTurretStarExpItemError(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="TurretStarExpMax" ) {
		SetTurretStarExpMax(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="TurretNoPlus" ) {
		SetTurretNoPlus(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="TurretPlusMax" ) {
		SetTurretPlusMax(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="TurretPlusItemLow" ) {
		SetTurretPlusItemLow(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="TurretPlusLevelLow" ) {
		SetTurretPlusLevelLow(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="TurretPlusStarLow" ) {
		SetTurretPlusStarLow(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="TurretEquipNoTurret" ) {
		SetTurretEquipNoTurret(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="TurretEquipNoSwingToPuton" ) {
		SetTurretEquipNoSwingToPuton(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="TurretEquipNoSwingToTakeoff" ) {
		SetTurretEquipNoSwingToTakeoff(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="TurretEquipSameSwing" ) {
		SetTurretEquipSameSwing(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="TurretEquipInArena" ) {
		SetTurretEquipInArena(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="TurretFireHasSwing" ) {
		SetTurretFireHasSwing(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="TurretFireInUse" ) {
		SetTurretFireInUse(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="TurretTransformHasSwing" ) {
		SetTurretTransformHasSwing(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="TurretTransformNotReady" ) {
		SetTurretTransformNotReady(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="TurretTransformWrongId" ) {
		SetTurretTransformWrongId(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="TurretChangeBulletTypeFail" ) {
		SetTurretChangeBulletTypeFail(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="SwingUpgradeIdError" ) {
		SetSwingUpgradeIdError(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="SwingUpgradeMax" ) {
		SetSwingUpgradeMax(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="SwingUpgradeRateItemFailed" ) {
		SetSwingUpgradeRateItemFailed(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="SwingUpgradeItemFailed" ) {
		SetSwingUpgradeItemFailed(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="SwingUpgradeSwingFailed" ) {
		SetSwingUpgradeSwingFailed(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="SwingUpgradeRateFailed" ) {
		SetSwingUpgradeRateFailed(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="QuestRewardUnknown" ) {
		SetQuestRewardUnknown(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="QuestRewardNoQuest" ) {
		SetQuestRewardNoQuest(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="QuestRewardStatusFailed" ) {
		SetQuestRewardStatusFailed(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="BuyTideNoLastTide" ) {
		SetBuyTideNoLastTide(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="BuyTideNoNeed" ) {
		SetBuyTideNoNeed(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ExchangeNoProduct" ) {
		SetExchangeNoProduct(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ExchangeItemLow" ) {
		SetExchangeItemLow(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ExchangeDiamondLow" ) {
		SetExchangeDiamondLow(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="FishSkillIdError" ) {
		SetFishSkillIdError(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="FishSkillEnergyLow" ) {
		SetFishSkillEnergyLow(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="FishSkillDiamondLow" ) {
		SetFishSkillDiamondLow(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="FishEnterLowEnergy" ) {
		SetFishEnterLowEnergy(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="FishEnterGoldLow" ) {
		SetFishEnterGoldLow(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="FishEnterGoldHigh" ) {
		SetFishEnterGoldHigh(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="FishEnterWrongTower" ) {
		SetFishEnterWrongTower(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="FishEnterTurretFail" ) {
		SetFishEnterTurretFail(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="FishEnterLowPower" ) {
		SetFishEnterLowPower(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="FishEnterHighPower" ) {
		SetFishEnterHighPower(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="FishEnterArenaNumLow" ) {
		SetFishEnterArenaNumLow(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="VipKickDenied" ) {
		SetVipKickDenied(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="VipKickTargetLeave" ) {
		SetVipKickTargetLeave(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="VipKickLowVip" ) {
		SetVipKickLowVip(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="VipGiftLowVip" ) {
		SetVipGiftLowVip(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="VipGiftBought" ) {
		SetVipGiftBought(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="VipGiftIllegal" ) {
		SetVipGiftIllegal(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="BuyMarketIllegal" ) {
		SetBuyMarketIllegal(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="BuyMarketBought" ) {
		SetBuyMarketBought(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ActivityTimeError" ) {
		SetActivityTimeError(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ActivityRewarded" ) {
		SetActivityRewarded(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ExchangeCodeNull" ) {
		SetExchangeCodeNull(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ExchangeCodeExpired" ) {
		SetExchangeCodeExpired(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ExchangeCodeUsed" ) {
		SetExchangeCodeUsed(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ExchangeCodeOneTime" ) {
		SetExchangeCodeOneTime(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ExchangeCodeSystem" ) {
		SetExchangeCodeSystem(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="SevenDayExpRewarded" ) {
		SetSevenDayExpRewarded(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="SevenDayExpLow" ) {
		SetSevenDayExpLow(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="SevenDayRewarded" ) {
		SetSevenDayRewarded(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="SevenDayNotFinished" ) {
		SetSevenDayNotFinished(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="SevenDayNotToday" ) {
		SetSevenDayNotToday(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="TurntableExpired" ) {
		SetTurntableExpired(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="TurntableBonusRewarded" ) {
		SetTurntableBonusRewarded(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="TurntableBonusNumLow" ) {
		SetTurntableBonusNumLow(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="TurntableNumLow" ) {
		SetTurntableNumLow(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="InsuranceEmpty" ) {
		SetInsuranceEmpty(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="InsuranceInvalidId" ) {
		SetInsuranceInvalidId(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="InsuranceInUsing" ) {
		SetInsuranceInUsing(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="InsuranceMaxBuy" ) {
		SetInsuranceMaxBuy(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="InsuranceSettleGoldHigh" ) {
		SetInsuranceSettleGoldHigh(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="NewbieFeeEmpty" ) {
		SetNewbieFeeEmpty(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="NewbieFeeDone" ) {
		SetNewbieFeeDone(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="NewbieFeeNoDraw" ) {
		SetNewbieFeeNoDraw(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="DrawRmbOpened" ) {
		SetDrawRmbOpened(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="DrawRmbLowCoupon" ) {
		SetDrawRmbLowCoupon(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="DrawRmbNotValid" ) {
		SetDrawRmbNotValid(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="DrawRmbPosRewarded" ) {
		SetDrawRmbPosRewarded(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="DrawRmbRewarded" ) {
		SetDrawRmbRewarded(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="SlotFishDrawCondError" ) {
		SetSlotFishDrawCondError(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="GeneralTaskRewarded" ) {
		SetGeneralTaskRewarded(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="GeneralTaskNotFinished" ) {
		SetGeneralTaskNotFinished(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="GeneralTaskVipFailed" ) {
		SetGeneralTaskVipFailed(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="MonthCardInvalid" ) {
		SetMonthCardInvalid(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="WeekCardInvalid" ) {
		SetWeekCardInvalid(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="SuperMonthCardInvalid" ) {
		SetSuperMonthCardInvalid(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="RmbCardRewarded" ) {
		SetRmbCardRewarded(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="BombActCardNumZero" ) {
		SetBombActCardNumZero(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="BombGameVipLow" ) {
		SetBombGameVipLow(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="TechMaxLevel" ) {
		SetTechMaxLevel(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="TechItemLow" ) {
		SetTechItemLow(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="TechUpgradeWhenProducing" ) {
		SetTechUpgradeWhenProducing(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="TechProduceWhenUpgrading" ) {
		SetTechProduceWhenUpgrading(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="TechProduceNumExceed" ) {
		SetTechProduceNumExceed(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="KillBossNotFound" ) {
		SetKillBossNotFound(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="TargetNotFound" ) {
		SetTargetNotFound(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="TargetNotFriend" ) {
		SetTargetNotFriend(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="FriendApplyListFull" ) {
		SetFriendApplyListFull(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="FriendListFulll" ) {
		SetFriendListFulll(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="FriendTargetListFull" ) {
		SetFriendTargetListFull(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="FriendAlreadyFriend" ) {
		SetFriendAlreadyFriend(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="FriendChatNotFriend" ) {
		SetFriendChatNotFriend(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ChatPrivateUserOffline" ) {
		SetChatPrivateUserOffline(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ChatPrivateInBlock" ) {
		SetChatPrivateInBlock(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ChatPrivateBlocked" ) {
		SetChatPrivateBlocked(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ChatPrivateTargetInvalid" ) {
		SetChatPrivateTargetInvalid(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ChatPublicMute" ) {
		SetChatPublicMute(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ChatGroupNotFound" ) {
		SetChatGroupNotFound(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ChatGroupNotOwner" ) {
		SetChatGroupNotOwner(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ChatGroupCreateInvalidName" ) {
		SetChatGroupCreateInvalidName(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ChatGroupInvitationInvalid" ) {
		SetChatGroupInvitationInvalid(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ChatGroupPasswdFailed" ) {
		SetChatGroupPasswdFailed(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="ChatGroupFull" ) {
		SetChatGroupFull(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="GiftCodeNotSet" ) {
		SetGiftCodeNotSet(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="GiftTargetNoPhone" ) {
		SetGiftTargetNoPhone(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	if( name =="SystemNoted" ) {
		SetSystemNoted(v);
		LOGINFO("SetByName ok [%s] = [%ld]", name.c_str(), v);
		return;
	}
	LOGERROR("SetByName failed[%s] [%ld]", name.c_str(), v);
}
void JsonErrorCode::init() {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Success = 0;
	_SystemError = 1;
	_GoldLow = 2;
	_DiamondLow = 3;
	_LuckBagBought = 4;
	_InvalidLuckBag = 5;
	_DailyDiscountBought = 6;
	_InvalidDailyDiscount = 7;
	_NoGameTimeReward = 8;
	_PovertyNumLow = 9;
	_PovertyFake = 10;
	_VideoRewardTimeFail = 11;
	_NoLevelReward = 12;
	_NoGrowthReward = 13;
	_GrowthRewarded = 14;
	_GrabBonusNull = 15;
	_SystemInChecking = 16;
	_AccountBanned = 17;
	_LoginDatabaseFailed = 1001;
	_LoginGenUserIdFailed = 1002;
	_LoginUserTokenAccFailed = 1003;
	_LoginTokenNoUser = 1004;
	_LoginTooQuick = 1005;
	_LoginInvalidToken = 1006;
	_LoginAccountAlreadyBound = 1007;
	_LoginInvalidType = 1008;
	_LoginTokenExpired = 1009;
	_MailNotEmpty = 1101;
	_MailNoReward = 1102;
	_MailRewarded = 1103;
	_MailNotFound = 1104;
	_MailCanDo = 1105;
	_ChargeProductNotFound = 1201;
	_ChangeNameNoItem = 1202;
	_ChangeNameInvalidName = 1203;
	_ChangeSignTooLong = 1210;
	_ChangeSignInvalid = 1211;
	_ItemUseNumFail = 1301;
	_ItemUseNoItem = 1302;
	_ItemUseNumLow = 1303;
	_ItemUseTypeFail = 1304;
	_ItemUseTurretNumLow = 1305;
	_ItemUseTurretFailed = 1306;
	_ItemUseSwingNumLow = 1307;
	_ItemUseSwingFailed = 1308;
	_SignDayAlready = 1401;
	_SignDayTypeFail = 1402;
	_TurretIdError = 1501;
	_TurretExpItemError = 1502;
	_TurretExpMax = 1503;
	_TurretStarExpItemError = 1601;
	_TurretStarExpMax = 1602;
	_TurretNoPlus = 1701;
	_TurretPlusMax = 1702;
	_TurretPlusItemLow = 1703;
	_TurretPlusLevelLow = 1704;
	_TurretPlusStarLow = 1705;
	_TurretEquipNoTurret = 1801;
	_TurretEquipNoSwingToPuton = 1802;
	_TurretEquipNoSwingToTakeoff = 1803;
	_TurretEquipSameSwing = 1804;
	_TurretEquipInArena = 1805;
	_TurretFireHasSwing = 1901;
	_TurretFireInUse = 1902;
	_TurretTransformHasSwing = 1910;
	_TurretTransformNotReady = 1911;
	_TurretTransformWrongId = 1912;
	_TurretChangeBulletTypeFail = 1913;
	_SwingUpgradeIdError = 2001;
	_SwingUpgradeMax = 2002;
	_SwingUpgradeRateItemFailed = 2003;
	_SwingUpgradeItemFailed = 2004;
	_SwingUpgradeSwingFailed = 2005;
	_SwingUpgradeRateFailed = 2006;
	_QuestRewardUnknown = 2101;
	_QuestRewardNoQuest = 2102;
	_QuestRewardStatusFailed = 2103;
	_BuyTideNoLastTide = 2201;
	_BuyTideNoNeed = 2202;
	_ExchangeNoProduct = 2301;
	_ExchangeItemLow = 2302;
	_ExchangeDiamondLow = 2303;
	_FishSkillIdError = 2401;
	_FishSkillEnergyLow = 2402;
	_FishSkillDiamondLow = 2403;
	_FishEnterLowEnergy = 2501;
	_FishEnterGoldLow = 2502;
	_FishEnterGoldHigh = 2503;
	_FishEnterWrongTower = 2504;
	_FishEnterTurretFail = 2505;
	_FishEnterLowPower = 2506;
	_FishEnterHighPower = 2507;
	_FishEnterArenaNumLow = 2508;
	_VipKickDenied = 2601;
	_VipKickTargetLeave = 2602;
	_VipKickLowVip = 2603;
	_VipGiftLowVip = 2701;
	_VipGiftBought = 2702;
	_VipGiftIllegal = 2703;
	_BuyMarketIllegal = 2801;
	_BuyMarketBought = 2802;
	_ActivityTimeError = 2821;
	_ActivityRewarded = 2822;
	_ExchangeCodeNull = 3001;
	_ExchangeCodeExpired = 3002;
	_ExchangeCodeUsed = 3003;
	_ExchangeCodeOneTime = 3004;
	_ExchangeCodeSystem = 3005;
	_SevenDayExpRewarded = 3101;
	_SevenDayExpLow = 3102;
	_SevenDayRewarded = 3121;
	_SevenDayNotFinished = 3122;
	_SevenDayNotToday = 3123;
	_TurntableExpired = 3201;
	_TurntableBonusRewarded = 3202;
	_TurntableBonusNumLow = 3203;
	_TurntableNumLow = 3204;
	_InsuranceEmpty = 3220;
	_InsuranceInvalidId = 3221;
	_InsuranceInUsing = 3222;
	_InsuranceMaxBuy = 3223;
	_InsuranceSettleGoldHigh = 3224;
	_NewbieFeeEmpty = 3240;
	_NewbieFeeDone = 3241;
	_NewbieFeeNoDraw = 3242;
	_DrawRmbOpened = 3301;
	_DrawRmbLowCoupon = 3302;
	_DrawRmbNotValid = 3303;
	_DrawRmbPosRewarded = 3304;
	_DrawRmbRewarded = 3305;
	_SlotFishDrawCondError = 3320;
	_GeneralTaskRewarded = 3330;
	_GeneralTaskNotFinished = 3331;
	_GeneralTaskVipFailed = 3332;
	_MonthCardInvalid = 3340;
	_WeekCardInvalid = 3341;
	_SuperMonthCardInvalid = 3342;
	_RmbCardRewarded = 3343;
	_BombActCardNumZero = 3350;
	_BombGameVipLow = 3355;
	_TechMaxLevel = 3361;
	_TechItemLow = 3362;
	_TechUpgradeWhenProducing = 3363;
	_TechProduceWhenUpgrading = 3364;
	_TechProduceNumExceed = 3365;
	_KillBossNotFound = 3380;
	_TargetNotFound = 3400;
	_TargetNotFriend = 3401;
	_FriendApplyListFull = 3410;
	_FriendListFulll = 3411;
	_FriendTargetListFull = 3412;
	_FriendAlreadyFriend = 3413;
	_FriendChatNotFriend = 3414;
	_ChatPrivateUserOffline = 3420;
	_ChatPrivateInBlock = 3421;
	_ChatPrivateBlocked = 3422;
	_ChatPrivateTargetInvalid = 3423;
	_ChatPublicMute = 3424;
	_ChatGroupNotFound = 3430;
	_ChatGroupNotOwner = 3431;
	_ChatGroupCreateInvalidName = 3432;
	_ChatGroupInvitationInvalid = 3433;
	_ChatGroupPasswdFailed = 3434;
	_ChatGroupFull = 3435;
	_GiftCodeNotSet = 3500;
	_GiftTargetNoPhone = 3501;
	_SystemNoted = 99999999;
}
int32 JsonErrorCode::GetSuccess() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _Success;
}
void JsonErrorCode::SetSuccess(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_Success = v;
}
int32 JsonErrorCode::GetSystemError() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _SystemError;
}
void JsonErrorCode::SetSystemError(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_SystemError = v;
}
int32 JsonErrorCode::GetGoldLow() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _GoldLow;
}
void JsonErrorCode::SetGoldLow(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_GoldLow = v;
}
int32 JsonErrorCode::GetDiamondLow() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _DiamondLow;
}
void JsonErrorCode::SetDiamondLow(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_DiamondLow = v;
}
int32 JsonErrorCode::GetLuckBagBought() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _LuckBagBought;
}
void JsonErrorCode::SetLuckBagBought(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_LuckBagBought = v;
}
int32 JsonErrorCode::GetInvalidLuckBag() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _InvalidLuckBag;
}
void JsonErrorCode::SetInvalidLuckBag(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_InvalidLuckBag = v;
}
int32 JsonErrorCode::GetDailyDiscountBought() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _DailyDiscountBought;
}
void JsonErrorCode::SetDailyDiscountBought(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_DailyDiscountBought = v;
}
int32 JsonErrorCode::GetInvalidDailyDiscount() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _InvalidDailyDiscount;
}
void JsonErrorCode::SetInvalidDailyDiscount(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_InvalidDailyDiscount = v;
}
int32 JsonErrorCode::GetNoGameTimeReward() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _NoGameTimeReward;
}
void JsonErrorCode::SetNoGameTimeReward(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_NoGameTimeReward = v;
}
int32 JsonErrorCode::GetPovertyNumLow() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _PovertyNumLow;
}
void JsonErrorCode::SetPovertyNumLow(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_PovertyNumLow = v;
}
int32 JsonErrorCode::GetPovertyFake() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _PovertyFake;
}
void JsonErrorCode::SetPovertyFake(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_PovertyFake = v;
}
int32 JsonErrorCode::GetVideoRewardTimeFail() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _VideoRewardTimeFail;
}
void JsonErrorCode::SetVideoRewardTimeFail(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_VideoRewardTimeFail = v;
}
int32 JsonErrorCode::GetNoLevelReward() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _NoLevelReward;
}
void JsonErrorCode::SetNoLevelReward(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_NoLevelReward = v;
}
int32 JsonErrorCode::GetNoGrowthReward() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _NoGrowthReward;
}
void JsonErrorCode::SetNoGrowthReward(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_NoGrowthReward = v;
}
int32 JsonErrorCode::GetGrowthRewarded() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _GrowthRewarded;
}
void JsonErrorCode::SetGrowthRewarded(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_GrowthRewarded = v;
}
int32 JsonErrorCode::GetGrabBonusNull() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _GrabBonusNull;
}
void JsonErrorCode::SetGrabBonusNull(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_GrabBonusNull = v;
}
int32 JsonErrorCode::GetSystemInChecking() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _SystemInChecking;
}
void JsonErrorCode::SetSystemInChecking(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_SystemInChecking = v;
}
int32 JsonErrorCode::GetAccountBanned() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _AccountBanned;
}
void JsonErrorCode::SetAccountBanned(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_AccountBanned = v;
}
int32 JsonErrorCode::GetLoginDatabaseFailed() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _LoginDatabaseFailed;
}
void JsonErrorCode::SetLoginDatabaseFailed(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_LoginDatabaseFailed = v;
}
int32 JsonErrorCode::GetLoginGenUserIdFailed() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _LoginGenUserIdFailed;
}
void JsonErrorCode::SetLoginGenUserIdFailed(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_LoginGenUserIdFailed = v;
}
int32 JsonErrorCode::GetLoginUserTokenAccFailed() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _LoginUserTokenAccFailed;
}
void JsonErrorCode::SetLoginUserTokenAccFailed(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_LoginUserTokenAccFailed = v;
}
int32 JsonErrorCode::GetLoginTokenNoUser() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _LoginTokenNoUser;
}
void JsonErrorCode::SetLoginTokenNoUser(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_LoginTokenNoUser = v;
}
int32 JsonErrorCode::GetLoginTooQuick() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _LoginTooQuick;
}
void JsonErrorCode::SetLoginTooQuick(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_LoginTooQuick = v;
}
int32 JsonErrorCode::GetLoginInvalidToken() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _LoginInvalidToken;
}
void JsonErrorCode::SetLoginInvalidToken(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_LoginInvalidToken = v;
}
int32 JsonErrorCode::GetLoginAccountAlreadyBound() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _LoginAccountAlreadyBound;
}
void JsonErrorCode::SetLoginAccountAlreadyBound(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_LoginAccountAlreadyBound = v;
}
int32 JsonErrorCode::GetLoginInvalidType() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _LoginInvalidType;
}
void JsonErrorCode::SetLoginInvalidType(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_LoginInvalidType = v;
}
int32 JsonErrorCode::GetLoginTokenExpired() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _LoginTokenExpired;
}
void JsonErrorCode::SetLoginTokenExpired(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_LoginTokenExpired = v;
}
int32 JsonErrorCode::GetMailNotEmpty() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _MailNotEmpty;
}
void JsonErrorCode::SetMailNotEmpty(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_MailNotEmpty = v;
}
int32 JsonErrorCode::GetMailNoReward() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _MailNoReward;
}
void JsonErrorCode::SetMailNoReward(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_MailNoReward = v;
}
int32 JsonErrorCode::GetMailRewarded() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _MailRewarded;
}
void JsonErrorCode::SetMailRewarded(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_MailRewarded = v;
}
int32 JsonErrorCode::GetMailNotFound() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _MailNotFound;
}
void JsonErrorCode::SetMailNotFound(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_MailNotFound = v;
}
int32 JsonErrorCode::GetMailCanDo() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _MailCanDo;
}
void JsonErrorCode::SetMailCanDo(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_MailCanDo = v;
}
int32 JsonErrorCode::GetChargeProductNotFound() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ChargeProductNotFound;
}
void JsonErrorCode::SetChargeProductNotFound(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ChargeProductNotFound = v;
}
int32 JsonErrorCode::GetChangeNameNoItem() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ChangeNameNoItem;
}
void JsonErrorCode::SetChangeNameNoItem(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ChangeNameNoItem = v;
}
int32 JsonErrorCode::GetChangeNameInvalidName() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ChangeNameInvalidName;
}
void JsonErrorCode::SetChangeNameInvalidName(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ChangeNameInvalidName = v;
}
int32 JsonErrorCode::GetChangeSignTooLong() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ChangeSignTooLong;
}
void JsonErrorCode::SetChangeSignTooLong(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ChangeSignTooLong = v;
}
int32 JsonErrorCode::GetChangeSignInvalid() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ChangeSignInvalid;
}
void JsonErrorCode::SetChangeSignInvalid(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ChangeSignInvalid = v;
}
int32 JsonErrorCode::GetItemUseNumFail() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ItemUseNumFail;
}
void JsonErrorCode::SetItemUseNumFail(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ItemUseNumFail = v;
}
int32 JsonErrorCode::GetItemUseNoItem() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ItemUseNoItem;
}
void JsonErrorCode::SetItemUseNoItem(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ItemUseNoItem = v;
}
int32 JsonErrorCode::GetItemUseNumLow() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ItemUseNumLow;
}
void JsonErrorCode::SetItemUseNumLow(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ItemUseNumLow = v;
}
int32 JsonErrorCode::GetItemUseTypeFail() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ItemUseTypeFail;
}
void JsonErrorCode::SetItemUseTypeFail(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ItemUseTypeFail = v;
}
int32 JsonErrorCode::GetItemUseTurretNumLow() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ItemUseTurretNumLow;
}
void JsonErrorCode::SetItemUseTurretNumLow(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ItemUseTurretNumLow = v;
}
int32 JsonErrorCode::GetItemUseTurretFailed() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ItemUseTurretFailed;
}
void JsonErrorCode::SetItemUseTurretFailed(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ItemUseTurretFailed = v;
}
int32 JsonErrorCode::GetItemUseSwingNumLow() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ItemUseSwingNumLow;
}
void JsonErrorCode::SetItemUseSwingNumLow(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ItemUseSwingNumLow = v;
}
int32 JsonErrorCode::GetItemUseSwingFailed() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ItemUseSwingFailed;
}
void JsonErrorCode::SetItemUseSwingFailed(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ItemUseSwingFailed = v;
}
int32 JsonErrorCode::GetSignDayAlready() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _SignDayAlready;
}
void JsonErrorCode::SetSignDayAlready(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_SignDayAlready = v;
}
int32 JsonErrorCode::GetSignDayTypeFail() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _SignDayTypeFail;
}
void JsonErrorCode::SetSignDayTypeFail(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_SignDayTypeFail = v;
}
int32 JsonErrorCode::GetTurretIdError() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _TurretIdError;
}
void JsonErrorCode::SetTurretIdError(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_TurretIdError = v;
}
int32 JsonErrorCode::GetTurretExpItemError() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _TurretExpItemError;
}
void JsonErrorCode::SetTurretExpItemError(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_TurretExpItemError = v;
}
int32 JsonErrorCode::GetTurretExpMax() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _TurretExpMax;
}
void JsonErrorCode::SetTurretExpMax(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_TurretExpMax = v;
}
int32 JsonErrorCode::GetTurretStarExpItemError() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _TurretStarExpItemError;
}
void JsonErrorCode::SetTurretStarExpItemError(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_TurretStarExpItemError = v;
}
int32 JsonErrorCode::GetTurretStarExpMax() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _TurretStarExpMax;
}
void JsonErrorCode::SetTurretStarExpMax(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_TurretStarExpMax = v;
}
int32 JsonErrorCode::GetTurretNoPlus() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _TurretNoPlus;
}
void JsonErrorCode::SetTurretNoPlus(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_TurretNoPlus = v;
}
int32 JsonErrorCode::GetTurretPlusMax() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _TurretPlusMax;
}
void JsonErrorCode::SetTurretPlusMax(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_TurretPlusMax = v;
}
int32 JsonErrorCode::GetTurretPlusItemLow() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _TurretPlusItemLow;
}
void JsonErrorCode::SetTurretPlusItemLow(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_TurretPlusItemLow = v;
}
int32 JsonErrorCode::GetTurretPlusLevelLow() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _TurretPlusLevelLow;
}
void JsonErrorCode::SetTurretPlusLevelLow(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_TurretPlusLevelLow = v;
}
int32 JsonErrorCode::GetTurretPlusStarLow() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _TurretPlusStarLow;
}
void JsonErrorCode::SetTurretPlusStarLow(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_TurretPlusStarLow = v;
}
int32 JsonErrorCode::GetTurretEquipNoTurret() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _TurretEquipNoTurret;
}
void JsonErrorCode::SetTurretEquipNoTurret(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_TurretEquipNoTurret = v;
}
int32 JsonErrorCode::GetTurretEquipNoSwingToPuton() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _TurretEquipNoSwingToPuton;
}
void JsonErrorCode::SetTurretEquipNoSwingToPuton(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_TurretEquipNoSwingToPuton = v;
}
int32 JsonErrorCode::GetTurretEquipNoSwingToTakeoff() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _TurretEquipNoSwingToTakeoff;
}
void JsonErrorCode::SetTurretEquipNoSwingToTakeoff(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_TurretEquipNoSwingToTakeoff = v;
}
int32 JsonErrorCode::GetTurretEquipSameSwing() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _TurretEquipSameSwing;
}
void JsonErrorCode::SetTurretEquipSameSwing(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_TurretEquipSameSwing = v;
}
int32 JsonErrorCode::GetTurretEquipInArena() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _TurretEquipInArena;
}
void JsonErrorCode::SetTurretEquipInArena(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_TurretEquipInArena = v;
}
int32 JsonErrorCode::GetTurretFireHasSwing() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _TurretFireHasSwing;
}
void JsonErrorCode::SetTurretFireHasSwing(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_TurretFireHasSwing = v;
}
int32 JsonErrorCode::GetTurretFireInUse() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _TurretFireInUse;
}
void JsonErrorCode::SetTurretFireInUse(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_TurretFireInUse = v;
}
int32 JsonErrorCode::GetTurretTransformHasSwing() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _TurretTransformHasSwing;
}
void JsonErrorCode::SetTurretTransformHasSwing(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_TurretTransformHasSwing = v;
}
int32 JsonErrorCode::GetTurretTransformNotReady() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _TurretTransformNotReady;
}
void JsonErrorCode::SetTurretTransformNotReady(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_TurretTransformNotReady = v;
}
int32 JsonErrorCode::GetTurretTransformWrongId() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _TurretTransformWrongId;
}
void JsonErrorCode::SetTurretTransformWrongId(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_TurretTransformWrongId = v;
}
int32 JsonErrorCode::GetTurretChangeBulletTypeFail() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _TurretChangeBulletTypeFail;
}
void JsonErrorCode::SetTurretChangeBulletTypeFail(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_TurretChangeBulletTypeFail = v;
}
int32 JsonErrorCode::GetSwingUpgradeIdError() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _SwingUpgradeIdError;
}
void JsonErrorCode::SetSwingUpgradeIdError(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_SwingUpgradeIdError = v;
}
int32 JsonErrorCode::GetSwingUpgradeMax() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _SwingUpgradeMax;
}
void JsonErrorCode::SetSwingUpgradeMax(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_SwingUpgradeMax = v;
}
int32 JsonErrorCode::GetSwingUpgradeRateItemFailed() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _SwingUpgradeRateItemFailed;
}
void JsonErrorCode::SetSwingUpgradeRateItemFailed(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_SwingUpgradeRateItemFailed = v;
}
int32 JsonErrorCode::GetSwingUpgradeItemFailed() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _SwingUpgradeItemFailed;
}
void JsonErrorCode::SetSwingUpgradeItemFailed(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_SwingUpgradeItemFailed = v;
}
int32 JsonErrorCode::GetSwingUpgradeSwingFailed() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _SwingUpgradeSwingFailed;
}
void JsonErrorCode::SetSwingUpgradeSwingFailed(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_SwingUpgradeSwingFailed = v;
}
int32 JsonErrorCode::GetSwingUpgradeRateFailed() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _SwingUpgradeRateFailed;
}
void JsonErrorCode::SetSwingUpgradeRateFailed(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_SwingUpgradeRateFailed = v;
}
int32 JsonErrorCode::GetQuestRewardUnknown() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _QuestRewardUnknown;
}
void JsonErrorCode::SetQuestRewardUnknown(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_QuestRewardUnknown = v;
}
int32 JsonErrorCode::GetQuestRewardNoQuest() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _QuestRewardNoQuest;
}
void JsonErrorCode::SetQuestRewardNoQuest(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_QuestRewardNoQuest = v;
}
int32 JsonErrorCode::GetQuestRewardStatusFailed() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _QuestRewardStatusFailed;
}
void JsonErrorCode::SetQuestRewardStatusFailed(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_QuestRewardStatusFailed = v;
}
int32 JsonErrorCode::GetBuyTideNoLastTide() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _BuyTideNoLastTide;
}
void JsonErrorCode::SetBuyTideNoLastTide(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_BuyTideNoLastTide = v;
}
int32 JsonErrorCode::GetBuyTideNoNeed() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _BuyTideNoNeed;
}
void JsonErrorCode::SetBuyTideNoNeed(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_BuyTideNoNeed = v;
}
int32 JsonErrorCode::GetExchangeNoProduct() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ExchangeNoProduct;
}
void JsonErrorCode::SetExchangeNoProduct(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ExchangeNoProduct = v;
}
int32 JsonErrorCode::GetExchangeItemLow() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ExchangeItemLow;
}
void JsonErrorCode::SetExchangeItemLow(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ExchangeItemLow = v;
}
int32 JsonErrorCode::GetExchangeDiamondLow() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ExchangeDiamondLow;
}
void JsonErrorCode::SetExchangeDiamondLow(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ExchangeDiamondLow = v;
}
int32 JsonErrorCode::GetFishSkillIdError() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _FishSkillIdError;
}
void JsonErrorCode::SetFishSkillIdError(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_FishSkillIdError = v;
}
int32 JsonErrorCode::GetFishSkillEnergyLow() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _FishSkillEnergyLow;
}
void JsonErrorCode::SetFishSkillEnergyLow(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_FishSkillEnergyLow = v;
}
int32 JsonErrorCode::GetFishSkillDiamondLow() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _FishSkillDiamondLow;
}
void JsonErrorCode::SetFishSkillDiamondLow(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_FishSkillDiamondLow = v;
}
int32 JsonErrorCode::GetFishEnterLowEnergy() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _FishEnterLowEnergy;
}
void JsonErrorCode::SetFishEnterLowEnergy(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_FishEnterLowEnergy = v;
}
int32 JsonErrorCode::GetFishEnterGoldLow() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _FishEnterGoldLow;
}
void JsonErrorCode::SetFishEnterGoldLow(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_FishEnterGoldLow = v;
}
int32 JsonErrorCode::GetFishEnterGoldHigh() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _FishEnterGoldHigh;
}
void JsonErrorCode::SetFishEnterGoldHigh(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_FishEnterGoldHigh = v;
}
int32 JsonErrorCode::GetFishEnterWrongTower() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _FishEnterWrongTower;
}
void JsonErrorCode::SetFishEnterWrongTower(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_FishEnterWrongTower = v;
}
int32 JsonErrorCode::GetFishEnterTurretFail() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _FishEnterTurretFail;
}
void JsonErrorCode::SetFishEnterTurretFail(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_FishEnterTurretFail = v;
}
int32 JsonErrorCode::GetFishEnterLowPower() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _FishEnterLowPower;
}
void JsonErrorCode::SetFishEnterLowPower(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_FishEnterLowPower = v;
}
int32 JsonErrorCode::GetFishEnterHighPower() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _FishEnterHighPower;
}
void JsonErrorCode::SetFishEnterHighPower(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_FishEnterHighPower = v;
}
int32 JsonErrorCode::GetFishEnterArenaNumLow() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _FishEnterArenaNumLow;
}
void JsonErrorCode::SetFishEnterArenaNumLow(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_FishEnterArenaNumLow = v;
}
int32 JsonErrorCode::GetVipKickDenied() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _VipKickDenied;
}
void JsonErrorCode::SetVipKickDenied(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_VipKickDenied = v;
}
int32 JsonErrorCode::GetVipKickTargetLeave() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _VipKickTargetLeave;
}
void JsonErrorCode::SetVipKickTargetLeave(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_VipKickTargetLeave = v;
}
int32 JsonErrorCode::GetVipKickLowVip() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _VipKickLowVip;
}
void JsonErrorCode::SetVipKickLowVip(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_VipKickLowVip = v;
}
int32 JsonErrorCode::GetVipGiftLowVip() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _VipGiftLowVip;
}
void JsonErrorCode::SetVipGiftLowVip(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_VipGiftLowVip = v;
}
int32 JsonErrorCode::GetVipGiftBought() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _VipGiftBought;
}
void JsonErrorCode::SetVipGiftBought(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_VipGiftBought = v;
}
int32 JsonErrorCode::GetVipGiftIllegal() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _VipGiftIllegal;
}
void JsonErrorCode::SetVipGiftIllegal(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_VipGiftIllegal = v;
}
int32 JsonErrorCode::GetBuyMarketIllegal() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _BuyMarketIllegal;
}
void JsonErrorCode::SetBuyMarketIllegal(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_BuyMarketIllegal = v;
}
int32 JsonErrorCode::GetBuyMarketBought() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _BuyMarketBought;
}
void JsonErrorCode::SetBuyMarketBought(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_BuyMarketBought = v;
}
int32 JsonErrorCode::GetActivityTimeError() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ActivityTimeError;
}
void JsonErrorCode::SetActivityTimeError(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ActivityTimeError = v;
}
int32 JsonErrorCode::GetActivityRewarded() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ActivityRewarded;
}
void JsonErrorCode::SetActivityRewarded(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ActivityRewarded = v;
}
int32 JsonErrorCode::GetExchangeCodeNull() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ExchangeCodeNull;
}
void JsonErrorCode::SetExchangeCodeNull(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ExchangeCodeNull = v;
}
int32 JsonErrorCode::GetExchangeCodeExpired() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ExchangeCodeExpired;
}
void JsonErrorCode::SetExchangeCodeExpired(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ExchangeCodeExpired = v;
}
int32 JsonErrorCode::GetExchangeCodeUsed() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ExchangeCodeUsed;
}
void JsonErrorCode::SetExchangeCodeUsed(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ExchangeCodeUsed = v;
}
int32 JsonErrorCode::GetExchangeCodeOneTime() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ExchangeCodeOneTime;
}
void JsonErrorCode::SetExchangeCodeOneTime(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ExchangeCodeOneTime = v;
}
int32 JsonErrorCode::GetExchangeCodeSystem() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ExchangeCodeSystem;
}
void JsonErrorCode::SetExchangeCodeSystem(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ExchangeCodeSystem = v;
}
int32 JsonErrorCode::GetSevenDayExpRewarded() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _SevenDayExpRewarded;
}
void JsonErrorCode::SetSevenDayExpRewarded(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_SevenDayExpRewarded = v;
}
int32 JsonErrorCode::GetSevenDayExpLow() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _SevenDayExpLow;
}
void JsonErrorCode::SetSevenDayExpLow(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_SevenDayExpLow = v;
}
int32 JsonErrorCode::GetSevenDayRewarded() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _SevenDayRewarded;
}
void JsonErrorCode::SetSevenDayRewarded(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_SevenDayRewarded = v;
}
int32 JsonErrorCode::GetSevenDayNotFinished() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _SevenDayNotFinished;
}
void JsonErrorCode::SetSevenDayNotFinished(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_SevenDayNotFinished = v;
}
int32 JsonErrorCode::GetSevenDayNotToday() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _SevenDayNotToday;
}
void JsonErrorCode::SetSevenDayNotToday(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_SevenDayNotToday = v;
}
int32 JsonErrorCode::GetTurntableExpired() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _TurntableExpired;
}
void JsonErrorCode::SetTurntableExpired(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_TurntableExpired = v;
}
int32 JsonErrorCode::GetTurntableBonusRewarded() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _TurntableBonusRewarded;
}
void JsonErrorCode::SetTurntableBonusRewarded(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_TurntableBonusRewarded = v;
}
int32 JsonErrorCode::GetTurntableBonusNumLow() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _TurntableBonusNumLow;
}
void JsonErrorCode::SetTurntableBonusNumLow(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_TurntableBonusNumLow = v;
}
int32 JsonErrorCode::GetTurntableNumLow() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _TurntableNumLow;
}
void JsonErrorCode::SetTurntableNumLow(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_TurntableNumLow = v;
}
int32 JsonErrorCode::GetInsuranceEmpty() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _InsuranceEmpty;
}
void JsonErrorCode::SetInsuranceEmpty(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_InsuranceEmpty = v;
}
int32 JsonErrorCode::GetInsuranceInvalidId() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _InsuranceInvalidId;
}
void JsonErrorCode::SetInsuranceInvalidId(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_InsuranceInvalidId = v;
}
int32 JsonErrorCode::GetInsuranceInUsing() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _InsuranceInUsing;
}
void JsonErrorCode::SetInsuranceInUsing(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_InsuranceInUsing = v;
}
int32 JsonErrorCode::GetInsuranceMaxBuy() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _InsuranceMaxBuy;
}
void JsonErrorCode::SetInsuranceMaxBuy(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_InsuranceMaxBuy = v;
}
int32 JsonErrorCode::GetInsuranceSettleGoldHigh() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _InsuranceSettleGoldHigh;
}
void JsonErrorCode::SetInsuranceSettleGoldHigh(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_InsuranceSettleGoldHigh = v;
}
int32 JsonErrorCode::GetNewbieFeeEmpty() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _NewbieFeeEmpty;
}
void JsonErrorCode::SetNewbieFeeEmpty(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_NewbieFeeEmpty = v;
}
int32 JsonErrorCode::GetNewbieFeeDone() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _NewbieFeeDone;
}
void JsonErrorCode::SetNewbieFeeDone(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_NewbieFeeDone = v;
}
int32 JsonErrorCode::GetNewbieFeeNoDraw() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _NewbieFeeNoDraw;
}
void JsonErrorCode::SetNewbieFeeNoDraw(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_NewbieFeeNoDraw = v;
}
int32 JsonErrorCode::GetDrawRmbOpened() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _DrawRmbOpened;
}
void JsonErrorCode::SetDrawRmbOpened(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_DrawRmbOpened = v;
}
int32 JsonErrorCode::GetDrawRmbLowCoupon() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _DrawRmbLowCoupon;
}
void JsonErrorCode::SetDrawRmbLowCoupon(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_DrawRmbLowCoupon = v;
}
int32 JsonErrorCode::GetDrawRmbNotValid() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _DrawRmbNotValid;
}
void JsonErrorCode::SetDrawRmbNotValid(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_DrawRmbNotValid = v;
}
int32 JsonErrorCode::GetDrawRmbPosRewarded() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _DrawRmbPosRewarded;
}
void JsonErrorCode::SetDrawRmbPosRewarded(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_DrawRmbPosRewarded = v;
}
int32 JsonErrorCode::GetDrawRmbRewarded() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _DrawRmbRewarded;
}
void JsonErrorCode::SetDrawRmbRewarded(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_DrawRmbRewarded = v;
}
int32 JsonErrorCode::GetSlotFishDrawCondError() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _SlotFishDrawCondError;
}
void JsonErrorCode::SetSlotFishDrawCondError(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_SlotFishDrawCondError = v;
}
int32 JsonErrorCode::GetGeneralTaskRewarded() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _GeneralTaskRewarded;
}
void JsonErrorCode::SetGeneralTaskRewarded(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_GeneralTaskRewarded = v;
}
int32 JsonErrorCode::GetGeneralTaskNotFinished() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _GeneralTaskNotFinished;
}
void JsonErrorCode::SetGeneralTaskNotFinished(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_GeneralTaskNotFinished = v;
}
int32 JsonErrorCode::GetGeneralTaskVipFailed() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _GeneralTaskVipFailed;
}
void JsonErrorCode::SetGeneralTaskVipFailed(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_GeneralTaskVipFailed = v;
}
int32 JsonErrorCode::GetMonthCardInvalid() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _MonthCardInvalid;
}
void JsonErrorCode::SetMonthCardInvalid(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_MonthCardInvalid = v;
}
int32 JsonErrorCode::GetWeekCardInvalid() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _WeekCardInvalid;
}
void JsonErrorCode::SetWeekCardInvalid(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_WeekCardInvalid = v;
}
int32 JsonErrorCode::GetSuperMonthCardInvalid() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _SuperMonthCardInvalid;
}
void JsonErrorCode::SetSuperMonthCardInvalid(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_SuperMonthCardInvalid = v;
}
int32 JsonErrorCode::GetRmbCardRewarded() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _RmbCardRewarded;
}
void JsonErrorCode::SetRmbCardRewarded(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_RmbCardRewarded = v;
}
int32 JsonErrorCode::GetBombActCardNumZero() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _BombActCardNumZero;
}
void JsonErrorCode::SetBombActCardNumZero(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_BombActCardNumZero = v;
}
int32 JsonErrorCode::GetBombGameVipLow() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _BombGameVipLow;
}
void JsonErrorCode::SetBombGameVipLow(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_BombGameVipLow = v;
}
int32 JsonErrorCode::GetTechMaxLevel() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _TechMaxLevel;
}
void JsonErrorCode::SetTechMaxLevel(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_TechMaxLevel = v;
}
int32 JsonErrorCode::GetTechItemLow() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _TechItemLow;
}
void JsonErrorCode::SetTechItemLow(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_TechItemLow = v;
}
int32 JsonErrorCode::GetTechUpgradeWhenProducing() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _TechUpgradeWhenProducing;
}
void JsonErrorCode::SetTechUpgradeWhenProducing(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_TechUpgradeWhenProducing = v;
}
int32 JsonErrorCode::GetTechProduceWhenUpgrading() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _TechProduceWhenUpgrading;
}
void JsonErrorCode::SetTechProduceWhenUpgrading(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_TechProduceWhenUpgrading = v;
}
int32 JsonErrorCode::GetTechProduceNumExceed() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _TechProduceNumExceed;
}
void JsonErrorCode::SetTechProduceNumExceed(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_TechProduceNumExceed = v;
}
int32 JsonErrorCode::GetKillBossNotFound() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _KillBossNotFound;
}
void JsonErrorCode::SetKillBossNotFound(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_KillBossNotFound = v;
}
int32 JsonErrorCode::GetTargetNotFound() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _TargetNotFound;
}
void JsonErrorCode::SetTargetNotFound(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_TargetNotFound = v;
}
int32 JsonErrorCode::GetTargetNotFriend() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _TargetNotFriend;
}
void JsonErrorCode::SetTargetNotFriend(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_TargetNotFriend = v;
}
int32 JsonErrorCode::GetFriendApplyListFull() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _FriendApplyListFull;
}
void JsonErrorCode::SetFriendApplyListFull(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_FriendApplyListFull = v;
}
int32 JsonErrorCode::GetFriendListFulll() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _FriendListFulll;
}
void JsonErrorCode::SetFriendListFulll(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_FriendListFulll = v;
}
int32 JsonErrorCode::GetFriendTargetListFull() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _FriendTargetListFull;
}
void JsonErrorCode::SetFriendTargetListFull(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_FriendTargetListFull = v;
}
int32 JsonErrorCode::GetFriendAlreadyFriend() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _FriendAlreadyFriend;
}
void JsonErrorCode::SetFriendAlreadyFriend(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_FriendAlreadyFriend = v;
}
int32 JsonErrorCode::GetFriendChatNotFriend() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _FriendChatNotFriend;
}
void JsonErrorCode::SetFriendChatNotFriend(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_FriendChatNotFriend = v;
}
int32 JsonErrorCode::GetChatPrivateUserOffline() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ChatPrivateUserOffline;
}
void JsonErrorCode::SetChatPrivateUserOffline(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ChatPrivateUserOffline = v;
}
int32 JsonErrorCode::GetChatPrivateInBlock() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ChatPrivateInBlock;
}
void JsonErrorCode::SetChatPrivateInBlock(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ChatPrivateInBlock = v;
}
int32 JsonErrorCode::GetChatPrivateBlocked() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ChatPrivateBlocked;
}
void JsonErrorCode::SetChatPrivateBlocked(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ChatPrivateBlocked = v;
}
int32 JsonErrorCode::GetChatPrivateTargetInvalid() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ChatPrivateTargetInvalid;
}
void JsonErrorCode::SetChatPrivateTargetInvalid(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ChatPrivateTargetInvalid = v;
}
int32 JsonErrorCode::GetChatPublicMute() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ChatPublicMute;
}
void JsonErrorCode::SetChatPublicMute(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ChatPublicMute = v;
}
int32 JsonErrorCode::GetChatGroupNotFound() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ChatGroupNotFound;
}
void JsonErrorCode::SetChatGroupNotFound(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ChatGroupNotFound = v;
}
int32 JsonErrorCode::GetChatGroupNotOwner() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ChatGroupNotOwner;
}
void JsonErrorCode::SetChatGroupNotOwner(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ChatGroupNotOwner = v;
}
int32 JsonErrorCode::GetChatGroupCreateInvalidName() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ChatGroupCreateInvalidName;
}
void JsonErrorCode::SetChatGroupCreateInvalidName(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ChatGroupCreateInvalidName = v;
}
int32 JsonErrorCode::GetChatGroupInvitationInvalid() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ChatGroupInvitationInvalid;
}
void JsonErrorCode::SetChatGroupInvitationInvalid(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ChatGroupInvitationInvalid = v;
}
int32 JsonErrorCode::GetChatGroupPasswdFailed() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ChatGroupPasswdFailed;
}
void JsonErrorCode::SetChatGroupPasswdFailed(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ChatGroupPasswdFailed = v;
}
int32 JsonErrorCode::GetChatGroupFull() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _ChatGroupFull;
}
void JsonErrorCode::SetChatGroupFull(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_ChatGroupFull = v;
}
int32 JsonErrorCode::GetGiftCodeNotSet() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _GiftCodeNotSet;
}
void JsonErrorCode::SetGiftCodeNotSet(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_GiftCodeNotSet = v;
}
int32 JsonErrorCode::GetGiftTargetNoPhone() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _GiftTargetNoPhone;
}
void JsonErrorCode::SetGiftTargetNoPhone(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_GiftTargetNoPhone = v;
}
int32 JsonErrorCode::GetSystemNoted() {
	boost::shared_lock<boost::shared_mutex> rl(_mutex);
	return _SystemNoted;
}
void JsonErrorCode::SetSystemNoted(int32 v) {
	boost::unique_lock<boost::shared_mutex> wl(_mutex);
	_SystemNoted = v;
}
