# 服务器部分模块介绍

## 线程模型
* 目前模块为登录模块,用户模块(包括基本数据和捕鱼玩法数据),定时器,三个模块有各自的线程组
* 用户模块中的捕鱼用户和系统用户耦合问题
   * 耦合程度过高,这个设计有缺陷,正常应该分离处理,按各自线程组,然后线程之间做消息同步
   * 由于高频捕鱼数据的同步处理短时间内没有完善的解决方案,就做成了所有用户消息同一个线程组的模式
   * 可能存在的问题是个别耗时大的消息影响到渔场内消息的效率,暂时还没有这方面的问题

## 用户离线,重登录和踢人处理
   * 用户登录时 setnxex  USER_LOGIN_LOCK 值=serverId 20
      * 成功, 说明未在线, 走登录流程
      * 失败, 说明用户在线, ProtoCmdHelper::PushGmCmd 带上本次登录所在的ServerId和对应的linkid
        * 在处理GmCmd时, 查看ServerId和linkid是否一致
            * 不一致, 说明确实是要把当前的连接踢下线, 执行 kick_duplicate_user
                * NetLink在执行kick_duplicate_user时, 清理本连接上的数据, 发送离线消息给 ThreadUser, 用来保证踢人后NetLink不再发送 LxCheckLoginLock, 同时不关闭连接保证客户端提示正确, 等超时或者用户主动断开
                    * ThreadUser 收到离线消息, 调用 LxUser::Offline 做离线处理
                        * 该行为会发送一个LxSaveUserData, 包含了time_offline数据
                            * 该消息在ThreadData上会触发 LoginLock 的删除操作, 保证下一个连接有效
            * 一致, 说明是客户端发送上来的多次LoginReq导致, 忽略
   * 用户发送心跳包时, 在NetLink里会发送 LxCheckLoginLock 给ThreadUser, 处理LoginLock的有效性保持

## 进出房间处理
* 登录消息处理时,会根据用户身上的fish_table_id和fish_table_index判断是否需要清理捕鱼房间信息
* 经典玩法
   * 进入发送FishEnterRoomReq
   * 用户主动退出发送 QuitRoomReq
   * 用户长时间不发炮 服务器进行 SyncForceLeft
   * 断线重连后,不会回到上次所在的渔场内
* 休闲模式
   * 进入发送 FishEnterRoomReq
   * 用户中途退出发送 QuitRoomReq
   * 鱼潮模式通关成功/鱼潮模式通关失败/休闲模式倒计时结束/休闲模式完成最大资源获取 服务器发送结算消息 SyncRoomFinish
   * 结算消息发送后,服务器将用户与房间断开,该消息不发送给客户端
   * 断线重连会在UserInfo中设置fish_table_index字段,告知用户需要重新发送一次 FishEnterRoomReq,进行重连
   * 休闲模式的次数在进入时已经扣除,后续的重连和游戏结束都不处理次数问题
   * 休闲模式都是单人房间,会在房间使用m_UserQuit标记
      * 用户主动退出了房间,会设置该标记,在Update中会进行判定,回收房间
      * 用户断线的情况,房间不会回收,会等到用户重连或者超时再回收

## 放技能处理
* 所有技能类消息都通过UserCastSkill处理
   * 技能按step分多段处理,通过配置读取每段能够击杀的鱼的数量
   * 服务器并不校验鱼的位置,只做击杀和消耗校验

## 兑换码
* 服务器通过 redis的stream redeem_stream 向Go服务器请求,格式为:"{"uid":"<T1>", "code":"<T2>"}"
* 兑换结果通过GM指令处理模式返回

## 礼券兑换
* 服务器通过 redis的stream exchange_stream 向Go服务器请求,格式为:"{\"uid\":\"<T1>\", \"phone\":\"<T2>\", \"product\":\"<T3>\", \"uid\":<T4>}"
* 兑换结果通过GM指令处理模式返回

## 多渠道以及审核服系统开关控制处理
* 客户端登录协议中带有client_version和channel
   * client_version表示当前客户端版本号, channel表示包来自的渠道
* 服务器在后台管理系统中有客户端版本号设置和渠道系统开关配置
* 用户登录时判定 client_version和后台版本号是否一致
   * 不一致, 使用客户端的本地系统开关配置,大部分系统为关闭
   * 一致, 使用对应渠道的后台系统配置

## 召唤boss处理逻辑
* FishData表中的FunctionID链接到FishFunction表, 对应的_GoldReturn字段填0, 则在鱼死亡时不会给玩家金币
* 击杀鱼时调用FishPlayer::TryKillSummonBoss, 尝试获得一次召唤boss的倍率
* 在计算倍率时,按规则计算两个倍率, 普通倍率和重置后倍率(一次性发给客户端, 无需再次交互做随机)
* 客户端领奖时发送是否重置的标记, 领取对应奖励
*  如果在TryKillSummonBoss时,发现有历史值, 则按邮件发送一次奖励, 可能是断线导致的问题
*  在FishPlayer::OnRecycled时, 同样判定一下该结构, 有值则按邮件发送奖励

## 维护白名单机制
* GM后台在redis中加入一个hset key是sys:white:list subkey和value都是对应的白名单渠道
* GM后台有一个维护开关, 维护时, 在redis中设置 sys:checking 值为0
* ThreadTimer线程检测到该开关值为0时,踢所有人下线, 同时设置开关为1
* 在WsLink中处理 LoginReq包时, 判定是否存在 exists sys:checking,
      存在,则判定客户端发送的渠道号是否在sys:white:list存在 hexists
            存在, 则放行登录包
            不存在, 返回系统维护的错误码
      不存在, 返回系统维护的错误码
* 开启时, redis中设置 sys:checking 到正常状态, 放行所有用户
* 整个维护流程为:
*     GM后台预先增加白名单渠道
*     GM后台设置服务器状态为维护
*     等待一段时间后, 杀掉游戏服务进程, 更新服务程序和配置
*     启动游戏服务进程
*     确认游戏进程完全启动后
*     GM后台设置服务器状态为白名单
*     使用白名单渠道登录, 跑完冒烟测试
*     GM后台设置服务器状态为正常

## 配置更新机制
* GM后台有更新所有配置 sys:reload:all 和更新指定配置 sys:reload 两个功能
* 配置文件上传后, 按需使用对应功能
