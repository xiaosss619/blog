#!/bin/bash
scp /home/fang/FishServer/trunk/twfish/misc/json/* fishgame@192.168.0.14:/game/json/
scp /home/fang/FishServer/trunk/twfish/fishd fishgame@192.168.0.14:/game/bin/
