#!/bin/bash
tar cvzf ./affishd.tar.gz ../fishd ../misc/json/
tar cvzf ./afrankd.tar.gz ../rankd ../misc/json/
tar cvzf ./afchatd.tar.gz ../chatd ../misc/json/
mv ./affishd.tar.gz /mnt/d/Temp/
mv ./afrankd.tar.gz /mnt/d/Temp/
mv ./afchatd.tar.gz /mnt/d/Temp/
