#!/bin/bash
tar cvzf ./afexe.tar.gz ../fishd
mv ./afexe.tar.gz /mnt/d/Temp/
