#include <fstream>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <time.h>
#include <execinfo.h>
#include <string.h>
#include <string>
#include <sys/stat.h>
#include <iostream>
using namespace std;
#include <ifaddrs.h>
#include <netinet/in.h>
#include <string.h>
#include <arpa/inet.h>
#include "jwt-cpp/jwt.h"

#include "Dispatcher.h"
#include "ConfReader/ConfReader.h"
#include "GameUtils.h"
#include "ModuleConnection/NetServer.h"
#include "Include/MySQLProtoHelper.h"
#include "DataCache/RedisData.h"
#include "ModuleHelper/ModuleHelper.h"

const int MAX_STACK_FRAMES = 128;
char cExecuteName[256] = {0};
//程序崩溃捕捉
void sig_crash(int sig)
{
    FILE* fd;
    struct stat buf;
    stat("./crash.log", &buf);
    if(buf.st_size > 10*1000*1000){ // 超过10兆则清空内容
        fd = fopen("./crash.log", "w");
    } else {
        fd = fopen("./crash.log", "at");
    }

    if (NULL == fd)
    {
        exit(0);
    }
    try
    {
        char szLine[512] = {0, };
        time_t t = time(NULL);
        struct tm now;
        localtime_r(&t, &now);
        sprintf(szLine,
				"#########################################################\n[%04d-%02d-%02d %02d:%02d:%02d][crash signal number:%d]\n",
				now.tm_year + 1900,
				now.tm_mon + 1,
				now.tm_mday,
				now.tm_hour,
				now.tm_min,
				now.tm_sec,
				sig);
        fwrite(szLine, 1, strlen(szLine), fd);
#ifdef __linux
        void* array[MAX_STACK_FRAMES];
        size_t size = 0;
        char** strings = NULL;
        size_t i;
        signal(sig, SIG_DFL);
        size = backtrace(array, MAX_STACK_FRAMES);
        strings = (char**)backtrace_symbols(array, size);
        //fprintf(stderr, "oncrash;\n");
        for (i = 0; i < size; ++i)
        {
            char szLine[512] = {0, };
            sprintf(szLine, "%lu %s\n", i, strings[i]);
            fwrite(szLine, 1, strlen(szLine), fd);

            std::string symbol(strings[i]);
            size_t pos1 = symbol.find_first_of("[");
            size_t pos2 = symbol.find_last_of("]");
            std::string address = symbol.substr(pos1 + 1, pos2 - pos1 -1);
            char cmd[512] = {0};
            sprintf(cmd, "addr2line -e %s %s",cExecuteName, address.c_str());
            FILE *fPipe = popen(cmd, "r");
            if(fPipe != NULL){
                char buff[1024];
                memset(buff, 0, sizeof(buff));
                char* ret = fgets(buff, sizeof(buff), fPipe);
                pclose(fPipe);
                fwrite(ret, 1, strlen(ret), fd);
            }
        }
       free(strings);
#endif // __linux
   }
   catch (...){}
   fflush(fd);
   fclose(fd);
   fd = NULL;
   exit(0);
}

static void protoLog(LogLevel level, const char* filename, int line, const std::string& message) {
	LOGINFO("protoError recv[%s][%d][%d][%s]", message.data(), level, line, filename);
}

string GetIpAddr() {
    struct ifaddrs * ifAddrStruct=NULL;
    struct ifaddrs * ifa=NULL;
    void * tmpAddrPtr=NULL;

    getifaddrs(&ifAddrStruct);

    for (ifa = ifAddrStruct; ifa != NULL; ifa = ifa->ifa_next) {
        if (!ifa->ifa_addr) {
            continue;
        }
        if (ifa->ifa_addr->sa_family == AF_INET) { // check it is IP4 AF_INET6 is IP6
            // is a valid IP4 Address
            tmpAddrPtr=&((struct sockaddr_in *)ifa->ifa_addr)->sin_addr;
            char addressBuffer[INET_ADDRSTRLEN] = {0};
            inet_ntop(AF_INET, tmpAddrPtr, addressBuffer, INET_ADDRSTRLEN);
            if( strcmp(addressBuffer, "127.0.0.1") != 0 && strcmp(addressBuffer, "0.0.0.0") != 0 ) {
                if (ifAddrStruct!=NULL) {
                    freeifaddrs(ifAddrStruct);
                }
                return addressBuffer;
            }
        }
    }
    if (ifAddrStruct!=NULL) {
        freeifaddrs(ifAddrStruct);
    }
    return "";
}

static void LogRunning(const string& content) {
    time_t tNow = time(nullptr);
    struct tm lt;
    localtime_r(&tNow, &lt);
	char szTime[64] = {0};
	sprintf(szTime, "[%d-%02d-%02d %02d:%02d:%02d]", lt.tm_year+1900, lt.tm_mon+1, lt.tm_mday, lt.tm_hour, lt.tm_min, lt.tm_sec);
	char szDate[64] = {0};
	sprintf(szDate, "%d%02d%02d", lt.tm_year+1900, lt.tm_mon+1, lt.tm_mday);

    ostringstream fileName;
    fileName << "/game/log/" << szDate << ".log";
    ofstream file(fileName.str(), ios::app);
    file << szTime << content << endl;
    file.close();
}

int main(int argc, char* argv[])
{
    if (GlobalUtils::process_is_running())
    {
        LogRunning("process is running");
        return 0;
    }
    else {
        LogRunning("start process");
    }

    ConfReader cfg;
	try{
		// read cfg file, if possible
		if(!cfg.read("./fishd.cfg")){
			std::cerr<<"Could not open config file!"<<std::endl;
			return -1;
		}
	}
	catch(std::invalid_argument& e){
		// this error can occur if the cfg file cannot be completly parsed
		// the parsed content until failure will be kept
		std::cerr<<"Error reading config file!"<<std::endl;
		std::cerr<<e.what()<<std::endl;
	}
	string strAddr = cfg["ip"].getString();
	int32 nPort = cfg["port"].getInt();
    int32 daemonize = cfg["daemonize"].getInt();
    if( daemonize > 0 ) {
        if( daemon(1, 1) != 0 )
        {
            cout << "failed to daemonize, errno : " << errno << endl;
            return -1;
        }
    }
    int32 redisLog = cfg["redislog"].getInt();
    int32 testServer = cfg["test"].getInt();
    int32 serverId = cfg["serverid"].getInt();
	//获取进程名
	char* ptr = strrchr(argv[0],'/');
	strncpy(cExecuteName, ptr+1, sizeof(cExecuteName) - 1);
	signal(SIGSEGV, sig_crash);     //SIGSEGV，非法内存访问
	signal(SIGABRT, sig_crash);     //SIGABRT，由调用abort函数产生，进程非正常退出
	signal(SIGILL, sig_crash);      //SIGILL, 非法指令
	signal(SIGFPE, sig_crash);      //SIGFPE，数学相关的异常，如被0除，浮点溢出

    GlobalUtils::Init();
	INIT_LOG(LOG_DEBUG);
	SetLogHandler(protoLog);
	RedisManager::GetInstance()->Init("./redis.cfg");
   	srand(time(nullptr));

    JDATA->SystemConstPtr()->init();
    JDATA->ErrorCodePtr()->init();

    if( !sDispatcher->init_sql(cfg["mysql_host"].getString(), cfg["mysql_user"].getString(), cfg["mysql_pwd"].getString()) ) {
        LOGINFO("failed to init database");
        return -1;
    }
	if( !JDATA->LoadAll("../json/") ) {
		LOGINFO("failed to load jsons");
		return -1;
	}
	if( !sGameUtils->Init() ) {
		LOGINFO("failed to init jsons");
        return -1;
    }
    sGameUtils->SetWriteRedisLog(redisLog>0);
    sGameUtils->SetTestServer(testServer>0);
    sGameUtils->SetServerId(serverId);

    sDispatcher->start();
    // 启动监听
	sNetServer->start(strAddr, nPort);
    LOGINFO("FishServer Start...[%d]", sGameUtils->GetServerId());

	sNetServer->wait();
    sDispatcher->wait();
	google::protobuf::ShutdownProtobufLibrary();
}
