#pragma once

#include "Include/ServerDefine.h"

struct tagGrowthFlag {
	int32 _level;
	int32 _loot;
	uint32 _flag;
	tagGrowthFlag() {
		_level = 0;
		_loot = 0;
		_flag = 0;
	}
	tagGrowthFlag& operator=(const tagGrowthFlag& rhs) {
		_level = rhs._level;
		_loot = rhs._loot;
		_flag = rhs._flag;
		return *this;
	}
};

class HelperExps
{
public:
    HelperExps() {};
    ~HelperExps() {};

    bool Init() {
        writeLock wl(_exp_mutex);
        m_maxUserLevel = 0;
        m_maxVipLevel = 0;
        m_maxHeroLevel = 0;
		int32 growthIndex = 0;
		int32 growthIndex2 = 0;
        JDATA->LevelPtr()->ForEach([&](tagJsonLevel* ptr){
            m_arUserLevelExp[ptr->_ID] = ptr->_TotalExp;
			if( ptr->_GrowthFund != 0 ) {
				tagGrowthFlag flag;
				flag._level = ptr->_ID;
				flag._loot = ptr->_GrowthFund;
				flag._flag = (1 << growthIndex);
				growthIndex++;
				m_mapGrowthFlag[flag._level] = flag;
			}
			if( ptr->_GrowthFund2 != 0 ) {
				tagGrowthFlag flag;
				flag._level = ptr->_ID;
				flag._loot = ptr->_GrowthFund2;
				flag._flag = (1 << growthIndex2);
				growthIndex2++;
				m_mapGrowthFlagV2[flag._level] = flag;
			}
            if( ptr->_ID > m_maxUserLevel ) {
                m_maxUserLevel = ptr->_ID;
            }
        });
        JDATA->VIPPtr()->ForEach([&](tagJsonVIP* ptr){
            m_arVipExp[ptr->_ID] = ptr->_TotalExp;
            if( ptr->_ID > m_maxVipLevel ) {
                m_maxVipLevel = ptr->_ID;
            }
        });
        JDATA->HeroLevelPtr()->ForEach([&](tagJsonHeroLevel* ptr){
            m_arHeroLevelExp[ptr->_ID] = ptr->_TotalExp;
            if( ptr->_ID > m_maxHeroLevel ) {
                m_maxHeroLevel = ptr->_ID;
            }
        });
		return true;
    }
	bool GetGrowthFlag(int32 level, int32 ver, tagGrowthFlag& lhs) {
		readLock rl(_exp_mutex);
		if( ver == 0 ) {
			auto it = m_mapGrowthFlag.find(level);
			if( it == m_mapGrowthFlag.end() ) {
				return false;
			}
			lhs = it->second;
		}
		else {
			auto it = m_mapGrowthFlagV2.find(level);
			if( it == m_mapGrowthFlagV2.end() ) {
				return false;
			}
			lhs = it->second;
		}
		return true;
	}
	/**@brief 根据炮台的当前等级和总经验,获取一个目前应该达到的经验+等级
	 * @param nStartLevel 当前等级
	 * @param maxLevel 根据星级计算出来的当前的最大等级
	 * @param totalExp 获得经验后最大可以达到的经验值
	 */
	std::tuple<int32, int32> GetHeroLevelExpByTotalExp(int32 startLevel, int32 maxLevel, int32 totalExp) {
		readLock rl(_exp_mutex);
		int32 nMaxTotalExp = 0;
		for( int32 lv = startLevel+1 ; lv <= m_maxHeroLevel ; ++lv ) {
			if( m_arHeroLevelExp[lv] > totalExp ) {
				return std::make_tuple(lv-1, totalExp);
			}
			if( lv >= maxLevel ) {
				// 到达最大等级限制了
				return std::make_tuple(lv, m_arHeroLevelExp[lv]);
			}
			nMaxTotalExp = m_arHeroLevelExp[lv];
		}
		return std::make_tuple(m_maxHeroLevel, nMaxTotalExp);
	}
	/**@brief 根据用户的当前等级和总经验,获取一个目前应该达到的经验+等级
	 * @param nStartLevel 当前等级
	 * @param maxLevel 当前的最大等级
	 * @param totalExp 获得经验后最大可以达到的经验值
	 */
	std::tuple<int32, int32> GetUserLevelExpByTotalExp(int32 startLevel, int32 totalExp) {
		readLock rl(_exp_mutex);
		int32 nMaxTotalExp = 0;
		for( int32 lv = startLevel+1 ; lv <= m_maxUserLevel ; ++lv ) {
			if( m_arUserLevelExp[lv] > totalExp ) {
				return std::make_tuple(lv-1, totalExp);
			}
			nMaxTotalExp = m_arUserLevelExp[lv];
		}
		return std::make_tuple(m_maxUserLevel, nMaxTotalExp);
	}
	/**@brief 根据用户的当前vip等级和总经验,获取一个目前应该达到的经验+等级
	 * @param nStartLevel 当前等级
	 * @param maxLevel 当前的最大等级
	 * @param totalExp 获得经验后最大可以达到的经验值
	 */
	std::tuple<int32, int32> GetVipLevelExpByTotalExp(int32 startLevel, int32 totalExp) {
		readLock rl(_exp_mutex);
		int32 nMaxTotalExp = 0;
		for( int32 lv = startLevel+1 ; lv <= m_maxVipLevel ; ++lv ) {
			if( m_arVipExp[lv] > totalExp ) {
				return std::make_tuple(lv-1, totalExp);
			}
			nMaxTotalExp = m_arVipExp[lv];
		}
		return std::make_tuple(m_maxVipLevel, nMaxTotalExp);
	}
	int32 GetMaxLevel() {
		readLock rl(_exp_mutex);
		return m_maxUserLevel;
	}
	int32 GetMaxVipLevel() {
		readLock rl(_exp_mutex);
		return m_maxVipLevel;
	}
private:
	// 各种升级经验数组
	boost::shared_mutex _exp_mutex;
	int32 m_maxUserLevel;
	int32 m_maxVipLevel;
	int32 m_maxHeroLevel;	// 经验配置表中的最大炮台等级,炮台实际的最大等级从HeroSet表中获取,即 sHero->GetTurretMaxLevel()才是准确的
	int32 m_arUserLevelExp[MAX_USER_LEVEL];
	int32 m_arVipExp[MAX_VIP_LEVEL];
	int32 m_arHeroLevelExp[MAX_TURRET_LEVEL];
	// 成长基金领取标记,等级表中有若干条带有GrowthFund字段,按顺序做一个uint32的位标记
	// 针对user的user_growth_flag字段按位做是否领取过的判定
	map<int32, tagGrowthFlag> m_mapGrowthFlag;
	map<int32, tagGrowthFlag> m_mapGrowthFlagV2;
};

#define sHExps Singleton<HelperExps>::Instance()
