#pragma once

#include "Include/ServerDefine.h"

class HelperTax
{
public:
    HelperTax() {};
    ~HelperTax() {};

    void Init() {
		map<int32, list< tuple<int64, int32, int32> > > mapData;
        JDATA->KillTaxPtr()->ForEach([&](tagJsonKillTax* ptr){
			auto it = mapData.find(ptr->_FishID);
			if( it == mapData.end() ) {
				list< tuple<int64, int32, int32> > lst;
				lst.push_back(make_tuple(ptr->_GoldValue, ptr->_KillTax, ptr->_HunterRefundRate));
				mapData[ptr->_FishID] = lst;
			}
			else {
				it->second.push_back(make_tuple(ptr->_GoldValue, ptr->_KillTax, ptr->_HunterRefundRate));
			}
        });
        writeLock wl(_mutex);
		m_mapFishTax.swap(mapData);
    }
	double GetTaxRate(int64 gold, int32 fishId, int32 rmbCardParam) {
		boost::shared_mutex _mutex;
		auto it = m_mapFishTax.find(fishId);
		if( it == m_mapFishTax.end() ) {
			it = m_mapFishTax.find(0);
			if( it == m_mapFishTax.end() ) {
				return 0.0f;
			}
		}
		for( auto & tax : it->second ) {
			if( gold >= TUPLE0(tax) ) {
				return max(JDATA->SystemConstPtr()->GetMonthCardEffectMin(), TUPLE1(tax) - rmbCardParam)*1.0f/10000.0f;
			}
		}
		return 0.0f;
	}
	double GetHunterRefundRate(int64 gold, int32 fishId) {
		boost::shared_mutex _mutex;
		auto it = m_mapFishTax.find(fishId);
		if( it == m_mapFishTax.end() ) {
			it = m_mapFishTax.find(0);
			if( it == m_mapFishTax.end() ) {
				return 0.0f;
			}
		}
		for( auto & tax : it->second ) {
			if( gold >= TUPLE0(tax) ) {
				return TUPLE2(tax)*1.0f/100.0f;
			}
		}
		return 0.0f;
	}
private:
	// 各种升级经验数组
	boost::shared_mutex _mutex;
	map<int32, list< tuple<int64, int32, int32> > > m_mapFishTax;
};

#define sHTax Singleton<HelperTax>::Instance()
