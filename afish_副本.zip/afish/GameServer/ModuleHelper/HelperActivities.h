#pragma once

#include "Include/ServerDefine.h"
#include "GameUtils.h"

struct tagActivityInfo {
    int32 _actId;
    int32 _type;
    vector<int64> _params;
    int64 _start;
    int64 _end;
    tagActivityInfo() {
        _actId = 0;
        _start = 0;
        _end = 0;
        _type = 0;
        _params.clear();
    }
    tagActivityInfo& operator=(const tagActivityInfo& rhs) {
        _actId = rhs._actId;
        _type = rhs._type;
        _start = rhs._start;
        _end = rhs._end;
        _params = rhs._params;
        return *this;
    }
};

class HelperActivities
{
public:
    HelperActivities() {};
    ~HelperActivities() {};
public:
	void OnActivityOpen(int32 id, int64 start, int64 end) {
        LOGDEBUG("ACTIVITY OPEN [%d] [%s] - [%s]", id, GlobalUtils::GetTimeByFormat(ETF_LOG, start).c_str(), GlobalUtils::GetTimeByFormat(ETF_LOG, end).c_str());
        tagJsonActivities tag;
        if( !JDATA->ActivitiesPtr()->ByID(id, tag) ) {
            LOGERROR("activity[%d] not found", id);
            return;
        }
        switch(tag._Type) {
        case e_jsonActivitiesType_TurnTable:
            if( tag._ACTParam.size() == 1 ) {
                sHTTable->start(tag, start, end);
            }
            else {
                LOGERROR("ACTIVITY TurnTable error[%d] actparam.size()=%d", id, tag._ACTParam.size());
            }
            break;
        case e_jsonActivitiesType_GeneralTask:
            if( tag._ACTParam.size() == 1 ) {
                sHGTask->start(tag._ACTParam[0], false);
            }
            else {
                LOGERROR("ACTIVITY GeneralTask error[%d] actparam.size()=%d", id, tag._ACTParam.size());
            }
            break;
        case e_jsonActivitiesType_CardDraw:
            if( tag._ACTParam.size() >= 3 ) {
                sHBombAct->start(tag._ACTParam[1], tag._ACTParam[0]);
                sHGTask->start(tag._ACTParam[2], true);
            }
            else {
                LOGERROR("ACTIVITY CardDraw error[%d] actparam.size()=%d", id, tag._ACTParam.size());
            }
            break;
        case e_jsonActivitiesType_NuclearDraw:
            if( tag._ACTParam.size() >= 11 ) {
                sHBombGame->start(tag._ACTParam);
            }
            else {
                LOGERROR("ACTIVITY NuclearDraw error[%d] actparam.size()=%d", id, tag._ACTParam.size());
            }
            break;
        case e_jsonActivitiesType_AdditionLoot:
            if( tag._ACTParam.size() == 1 ) {
                sGameUtils->AddGlobalBuff(tag._ACTParam[0]);
            }
            break;
        case e_jsonActivitiesType_CollectionCard:
            if( tag._ACTParam.size() >= 6 ) {
                sHBombTable->start(tag._ACTParam);
            }
            else {
                LOGERROR("ACTIVITY CollectionCard error[%d] actparam.size()=%d", id, tag._ACTParam.size());
            }
            break;
        case e_jsonActivitiesType_TreasureHunt:
            if( tag._ACTParam.size() == 6 ) {
                // 参数第一位为前N抽不抽大奖，第二位为小奖的groupid，第三位为小奖的数量，第四位为大奖的groupid，第五位为抽奖道具id，第六位为重置奖库的钻石数量。
                m_thConfig.set_act_id(id);
                m_thConfig.set_fake_hunt(tag._ACTParam[0]);
                m_thConfig.set_small_group(tag._ACTParam[1]);
                m_thConfig.set_small_num(tag._ACTParam[2]);
                m_thConfig.set_big_group(tag._ACTParam[3]);
                m_thConfig.set_token(tag._ACTParam[4]);
                m_thConfig.set_reset_diamond(tag._ACTParam[5]);
            }
            else {
                LOGERROR("ACTIVITY TreasureHunt error[%d] actparam.size()=%d", id, tag._ACTParam.size());
            }
            break;
        case e_jsonActivitiesType_HeroDraw:
            if( tag._ACTParam.size() >= 8 && tag._ACTParam.size() % 2 == 0 ) {
                m_dtConfig.set_item_id(tag._ACTParam[0]);
                m_dtConfig.set_diamond_price1(tag._ACTParam[1]);
                m_dtConfig.set_diamond_price10(tag._ACTParam[2]);
                m_dtConfig.set_lottery_id(tag._ACTParam[3]);
                m_dtConfig.set_lottery_ten_base_id(tag._ACTParam[4]);
                m_dtConfig.set_lottery_big_id(tag._ACTParam[5]);
                m_dtConfig.set_lottery_big_mu(tag._ACTParam[6]);
                m_dtConfig.set_lottery_big_sigma(tag._ACTParam[7]);
                for( size_t i = 8 ; i < tag._ACTParam.size() ; i+=2 ) {
                    auto ptr = m_dtConfig.add_loots();
                    ptr->set_key(tag._ACTParam[i]);
                    ptr->set_value(tag._ACTParam[i+1]);
                }
            }
            else {
                LOGERROR("ACTIVITY HeroDraw error[%d] actparam.size()=%d", id, tag._ACTParam.size());
            }
            break;
        case e_jsonActivitiesType_RankActivity:
            if( tag._ACTParam.size() == 4 ) {
                m_irConfig.set_item_id1(tag._ACTParam[0]);
                m_irConfig.set_item_id2(tag._ACTParam[1]);
                m_irConfig.set_win_rank(tag._ACTParam[2]);
                m_irConfig.set_lose_rank(tag._ACTParam[3]);
            }
            else {
                LOGERROR("ACTIVITY HeroDraw error[%d] actparam.size()=%d", id, tag._ACTParam.size());
            }
            break;
        default:
            break;
        }

        writeLock wl(_mutex);
        tagActivityInfo act;
        act._actId = id;
        act._type = tag._Type;
        act._params = tag._ACTParam;
        act._start = start;
        act._end = end;
        m_mapActs[id] = act;
    }
    void OnActivityClose(int32 id) {
        LOGDEBUG("ACTIVITY CLOSE [%d]", id);
        writeLock wl(_mutex);
        auto it = m_mapActs.find(id);
        if( it == m_mapActs.end() ) {
            return;
        }
        switch( it->second._type ) {
        case e_jsonActivitiesType_GeneralTask:
            if( it->second._params.size() == 1 ) {
                sHGTask->end(it->second._params[0]);
            }
            break;
        case e_jsonActivitiesType_TurnTable:
            if( it->second._params.size() == 1 ) {
                sHTTable->end(it->second._params[0]);
            }
            break;
        case e_jsonActivitiesType_AdditionLoot:
            if( it->second._params.size() == 1 ) {
                sGameUtils->RemoveGlobalBuff(it->second._params[0]);
            }
            break;
        case e_jsonActivitiesType_TreasureHunt:
            m_thConfig.Clear();
            break;
        case e_jsonActivitiesType_HeroDraw:
            m_dtConfig.Clear();
            break;
        case e_jsonActivitiesType_RankActivity:
            m_irConfig.Clear();
            break;
        default:
            break;
        }
        m_mapActs.erase(it);
    }
	void GetActivities(map<int32, tagActivityInfo>& mapAct) {
        readLock rl(_mutex);
        mapAct = m_mapActs;
    }
    bool GetActivity(int32 id, tagActivityInfo& lhs) {
        readLock rl(_mutex);
        auto it = m_mapActs.find(id);
        if( it == m_mapActs.end() ) {
            return false;
        }
        lhs = it->second;
        return true;
    }
    // 判定对应的休闲模式目前是否开放
    bool IsCustomActivityOpen(int32 type) {
        int64 tNow = time(nullptr);
        readLock rl(_mutex);
        for( auto it = m_mapActs.begin(); it != m_mapActs.end(); ++it) {
            if( tNow >= it->second._end || tNow <= it->second._start ) {
                continue;
            }
            if( it->second._type == e_jsonActivitiesType_CustomOpen && it->second._params.size() == 1 && it->second._params[0] == type ) {
                return true;
            }
        }
        return false;
    }

    bool IsActivityOpen(int32 actid) {
        int64 tNow = time(nullptr);
        readLock rl(_mutex);
        auto it = m_mapActs.find(actid);
        if( it == m_mapActs.end() ) {
            return false;
        }
        return it->second._start <= tNow && tNow <= it->second._end;
    }

    bool GetTreasureHuntConfig(TreasureHuntConfig& lhs) {
        readLock rl(_mutex);
        if( m_thConfig.act_id() == 0 ) {
            return false;
        }
        lhs = m_thConfig;
        return true;
    }
    bool GetDrawTenConfig(DrawTenConfig& lhs) {
        readLock rl(_mutex);
        if( m_dtConfig.item_id() == 0 ) {
            return false;
        }
        lhs = m_dtConfig;
        return true;
    }
    bool GetItemRankConfig(ItemRankConfig& lhs) {
        readLock rl(_mutex);
        if( m_irConfig.item_id1() == 0 ) {
            return false;
        }
        lhs = m_irConfig;
        return true;
    }
    bool IsActBoardItem(int32 itemId) {
        readLock rl(_mutex);
        return itemId == m_irConfig.item_id1() || itemId == m_irConfig.item_id2();
    }
private:
	boost::shared_mutex _mutex;
    map<int32, tagActivityInfo> m_mapActs;
    TreasureHuntConfig m_thConfig;
    DrawTenConfig m_dtConfig;
    ItemRankConfig m_irConfig;
};

#define sHActs Singleton<HelperActivities>::Instance()
