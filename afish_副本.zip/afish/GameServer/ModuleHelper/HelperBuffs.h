#pragma once

#include "Include/ServerDefine.h"

class HelperBuff
{
public:
    HelperBuff() {};
    ~HelperBuff() {};

    void Init() {
		map<int32, map<int32, int32> > mapItemBuff;
        JDATA->BuffPtr()->ForEach([&](tagJsonBuff* ptr){
			if( ptr->_Type == e_jsonBuffType_AdditionLoot ) {
				for( size_t i = 0; i < ptr->_LootParam.size() ; i += 2 ) {
					auto it = mapItemBuff.find(ptr->_LootParam[i]);
					if( it == mapItemBuff.end() ) {
						map<int32, int32> mapBuffParam;
						mapBuffParam[ptr->_ID] = ptr->_LootParam[i+1];

						mapItemBuff[ptr->_LootParam[i]] = mapBuffParam;
					}
					else {
						it->second[ptr->_ID] = ptr->_LootParam[i+1];
					}
				}
			}
        });
        writeLock wl(_mutex);
		m_mapItemBuffParam.swap(mapItemBuff);
    }
	// 按道具循环对应的掉落buffid和参数
	void ForEachItem(int32 itemId, boost::function<void(int32, int32)> func) {
		readLock rl(_mutex);
		auto it = m_mapItemBuffParam.find(itemId);
		if( it == m_mapItemBuffParam.end() ) {
			return;
		}
		for( auto& it2 : it->second ) {
			func(it2.first, it2.second);
		}
	}
	bool ItemHasExtraDropRate(int32 itemId) {
		readLock rl(_mutex);
		return m_mapItemBuffParam.find(itemId) != m_mapItemBuffParam.end();
	}
private:
	boost::shared_mutex _mutex;
	// itemid ==> buffid ==> param 参数为提高的百分比, 需要/100
	map<int32, map<int32, int32> >m_mapItemBuffParam;
};

#define sHBuff Singleton<HelperBuff>::Instance()
