#pragma once

#include "Include/ServerDefine.h"

class HelperMarket
{
public:
    HelperMarket() {};
    ~HelperMarket() {};
public:
	bool Init() {
		map< int32, Roll > mapMarket;
		JDATA->MarketPtr()->ForEach([&](tagJsonMarket* ptr){
			for( int32 vip = ptr->_VipRange[0] ; vip <= ptr->_VipRange[1]; ++vip ) {
				auto it = mapMarket.find(vip);
				if( it != mapMarket.end() ) {
					it->second.push_value(ptr->_Weight, ptr->_ID);
				}
				else {
					Roll roll;
					roll.push_value(ptr->_Weight, ptr->_ID);
					roll.set_extra(true, JDATA->SystemConstPtr()->GetMarketGoodsNum());
					mapMarket[vip] = roll;
				}
			}
		});
		writeLock wl(_mutex);
		m_mapMarket.swap(mapMarket);
		return true;
	}
	bool GetMarket(int32 vip, Roll& lhs) {
		readLock rl(_mutex);
		auto it = m_mapMarket.find(vip);
		if( it == m_mapMarket.end() ) {
			return false;
		}
		lhs = it->second;
		return true;
	}
private:
	boost::shared_mutex _mutex;
	map<int32, Roll> m_mapMarket;
};

#define sHMarket Singleton<HelperMarket>::Instance()
