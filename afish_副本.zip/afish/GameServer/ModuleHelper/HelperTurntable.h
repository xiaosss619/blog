#pragma once

#include "Include/ServerDefine.h"
#include "RedisKey.h"
#include "GameUtils.h"

struct tagTurntableData {
	int32 _idx;
	int64 _cur;		// 当前值
	int64 _max;		// 累计阀值
	int32 _rate;	// 对应抽水比例 /1000
	int32 _loot;	// 奖励loot
	tagTurntableData() {
		_idx = 0;
		_cur = 0;
		_max = 0;
		_rate = 0;
		_loot = 0;
	}
	tagTurntableData& operator=(const tagTurntableData& rhs) {
		_idx = rhs._idx;
		_cur = rhs._cur;
		_max = rhs._max;
		_rate = rhs._rate;
		_loot = rhs._loot;
		return *this;
	}
};

struct tagTurnTables {
    int32 _ttId;
    int64 _start;
    int64 _end;
    list<tagTurntableData> _lst;
    tagTurnTables() {
        _ttId = 0;
        _start = 0;
        _end = 0;
        _lst.clear();
    }
    tagTurnTables& operator=(const tagTurnTables& rhs) {
        _ttId = rhs._ttId;
        _start = rhs._start;
        _end = rhs._end;
        _lst = rhs._lst;
        return *this;
    }
};

class HelperTurntable
{
public:
    HelperTurntable() {};
    ~HelperTurntable() {};
public:
    void start(const tagJsonActivities& tag, int64 start, int64 end) {
        FETCH_VOID();
        int32 ttid = (int32)tag._ACTParam[0];
        tagJsonTurnTable tagTT;
        if(!JDATA->TurnTablePtr()->ByID(ttid, tagTT))  {
            LOGERROR("activity config error[%d][%d] != 1", tag._ID, ttid);
            return;
        }
        tagTurnTables ttData;
        ttData._ttId = ttid;
        ttData._start = start;
        ttData._end = end;
        for( size_t i = 0 ; i < tagTT._Reward.size(); i+=3 ) {
            int32 idx = i/3;
            tagTurntableData data;
            data._idx = idx;
            data._max = (int32)tagTT._Reward[i];
            data._loot = (int32)tagTT._Reward[i+2];
            data._rate = (int32)tagTT._Reward[i+1];
            string strKey = RedisKey::MakeSysTurntableKey(sGameUtils->GetServerId(), ttid, idx);
            int64 curGold = 0;
            if( !pConnection->get(strKey, curGold) ) {
                pConnection->set(strKey, curGold);
                pConnection->expire(strKey, end-start+5);
            }
            data._cur = curGold;
            ttData._lst.push_front(data);   // 需要从尾部遍历
        }
        writeLock wl(_mutex);
        m_mapActs[ttid] = ttData;
    }
    void end(int32 ttid) {
        writeLock wl(_mutex);
        m_mapActs.erase(ttid);
    }
	// 玩一次转盘 返回对应的idx和lootid
    std::tuple<int32, int32> PlayTurntable(int32 ttid, int64 cost) {
        // 转盘活动需要重置一下数据
        RedisConnectionIdGetter idGetter(enumRedisServerTypeData);
        auto pConnection = idGetter.GetConnection();
        if( pConnection == nullptr ) {
            return make_tuple(-1, 0);
        }
        int32 idx = -1;
        int32 lootId = 0;
        Roll ttRoll;
        map<int32, int32> mapRandLoot;
        writeLock wl(_mutex);
        auto it = m_mapActs.find(ttid);
        if( it == m_mapActs.end() ) {
            return make_tuple(-1, 0);
        }
        for( auto & tt : it->second._lst ) {
            if( tt._max == 0 ) {
                ttRoll.push_value(100, tt._idx);
                mapRandLoot[tt._idx] = tt._loot;
            }
            else {
                tt._cur += (cost*tt._rate/1000);
                if( idx == -1 ) {
                    if( tt._cur >= tt._max ) {
                        tt._cur = tt._cur - tt._max;
                        idx = tt._idx;
                        lootId = tt._loot;
                    }
                }
                string strKey = RedisKey::MakeSysTurntableKey(sGameUtils->GetServerId(), ttid, tt._idx);
                if( !pConnection->exists(strKey) ){
                    LOGERROR("TURNTABLE key failed[%s]", strKey.c_str());
                    return make_tuple(-1, 0);
                }
                pConnection->set(strKey, tt._cur);
            }
        }
        if( idx == -1 ) {
            idx = ttRoll.roll();
            lootId = mapRandLoot[idx];
        }
        return make_tuple(idx, lootId);
    }
    // 获取当前开放的转盘活动数据
    std::tuple<int32, int64, int64> GetOpenedTurntableInfo() {
        readLock rl(_mutex);
        for( auto it = m_mapActs.begin(); it != m_mapActs.end(); ++it) {
            return make_tuple(it->second._ttId, it->second._start, it->second._end);
        }
        return make_tuple(0, 0, 0);
    }

private:
	boost::shared_mutex _mutex;
    map<int32, tagTurnTables> m_mapActs;
};

#define sHTTable Singleton<HelperTurntable>::Instance()
