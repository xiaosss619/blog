#pragma once

#include "Include/ServerDefine.h"

class HelperTech
{
public:
    HelperTech() {};
    ~HelperTech() {};

    void Init() {
		map<int32, map<int32, tagJsonInstituteLevel> > mapTechs;
        JDATA->InstituteLevelPtr()->ForEach([&](tagJsonInstituteLevel* ptr){
			auto it = mapTechs.find(ptr->_InstituteID);
			if( it == mapTechs.end() ){
				map<int32, tagJsonInstituteLevel> mapData;
				mapData[ptr->_Level] = *ptr;
				mapTechs[ptr->_InstituteID] = mapData;
			}
			else {
				it->second[ptr->_Level] = *ptr;
			}
        });
        writeLock wl(_mutex);
		m_mapTechs.swap(mapTechs);
    }
	bool GetTechUpgradeData(int32 techId, int32 lv, tagJsonInstituteLevel& lhs) {
		readLock rl(_mutex);
		auto it = m_mapTechs.find(techId);
		if( it == m_mapTechs.end() ) {
			return false;
		}
		auto it2 = it->second.find(lv);
		if( it2 == it->second.end() ) {
			return false;
		}
		lhs = it2->second;
		return true;
	}
	int32 GetTechEffect(int32 techId, int32 lv) {
		tagJsonInstituteLevel data;
		if( GetTechUpgradeData(techId, lv, data) ) {
			return data._LevelEffect;
		}
		return 0;
	}
	bool GetTechEffect(int32 techId, int32 lv, IntPair& ip) {
		tagJsonInstituteLevel data;
		if( GetTechUpgradeData(techId, lv, data) ) {
			ip.set_key(data._LevelEffect);
			ip.set_value(data._LevelEffect2);
			return true;
		}
		return false;
	}
private:
	boost::shared_mutex _mutex;
	map<int32, map<int32, tagJsonInstituteLevel> > m_mapTechs;
};

#define sHTech Singleton<HelperTech>::Instance()
