#pragma once

#include "Include/ServerDefine.h"

struct tagLottery
{
    // 随机掉落
    Roll _roll;
    // 必掉
    list<int32> _loots;
    tagLottery() {
        _roll.clear();
        _loots.clear();
    }
    tagLottery& operator=(const tagLottery& rhs) {
        _roll = rhs._roll;
        _loots = rhs._loots;
        return *this;
    }
};

class HelperLottery
{
public:
    HelperLottery() {};
    ~HelperLottery() {};
public:
    bool Init() {
        map<int32, tagLottery> mapLottery;
        JDATA->LotteryPtr()->ForEach([&](tagJsonLottery* ptr) {
            tagLottery lot;
            for( size_t i = 0; i < ptr->_LootIDs.size(); i += 2 ) {
                if( ptr->_LootIDs[i+1] == -1 ) {
                    lot._loots.push_back(ptr->_LootIDs[i]);
                }
                else {
                    lot._roll.push_value(ptr->_LootIDs[i+1], ptr->_LootIDs[i]);
                }
            }
            lot._roll.set_extra(ptr->_IsRepeat, ptr->_Selection);
            mapLottery[ptr->_ID] = lot;
        });

        writeLock wl(_mutex);
        m_mapLottery.swap(mapLottery);
        return true;
    }
    // 兑换券抽奖使用, 奖池中选一个道具, lottery中的必掉项被pass了
    bool GetSingleLotteryItem(int32 lotterId, ItemPair& item) {
        Roll roll;
        {
            readLock rl(_mutex);
            auto it = m_mapLottery.find(lotterId);
            if( it == m_mapLottery.end() ) {
                LOGERROR("lotteryId[%d] not found", lotterId);
                return false;
            }
            roll = it->second._roll;
        }
        map<int32,int64> mapItem;
        for(int32 i = 0; i < roll.times() ; ++i ) {
            int32 lootId = roll.roll();
            GetLootItem(lootId, mapItem);
        }
        if( mapItem.size() > 0 ) {
            item.set_item_id(mapItem.begin()->first);
            item.set_item_num(mapItem.begin()->second);
            return true;
        }
        return false;
    }
    void GetLotteryItem(int32 lotterId, map<int32,int64>& mapItem) {
        Roll roll;
        map<int32, int32> mapTurret;
        map<int32, int32> mapSwing;
        {
            readLock rl(_mutex);
            auto it = m_mapLottery.find(lotterId);
            if( it == m_mapLottery.end() ) {
                LOGERROR("lotteryId[%d] not found", lotterId);
                return;
            }
            roll = it->second._roll;
            for( auto & loot : it->second._loots ) {
                GetLootItem(loot, mapItem, mapTurret, mapSwing);
            }
        }
        for(int32 i = 0; i < roll.times() ; ++i ) {
            int32 lootId = roll.roll();
            GetLootItem(lootId, mapItem, mapTurret, mapSwing);
        }
    }

    void GetLotteryItem(int32 lotterId, map<int32,int64>& mapItem, map<int32, int32>& mapTurret, map<int32, int32>& mapSwing) {
        Roll roll;
        {
            readLock rl(_mutex);
            auto it = m_mapLottery.find(lotterId);
            if( it == m_mapLottery.end() ) {
                LOGERROR("lotteryId[%d] not found", lotterId);
                return;
            }
            roll = it->second._roll;
            for( auto & loot : it->second._loots ) {
                GetLootItem(loot, mapItem, mapTurret, mapSwing);
            }
        }
        for(int32 i = 0; i < roll.times() ; ++i ) {
            int32 lootId = roll.roll();
            GetLootItem(lootId, mapItem, mapTurret, mapSwing);
        }
    }
    void ForEachLotteryLoot(int32 lotteryId, boost::function<void(int32)> func) {
        Roll roll;
        {
            readLock rl(_mutex);
            auto it = m_mapLottery.find(lotteryId);
            if( it == m_mapLottery.end() ) {
                LOGERROR("lotteryId[%d] not found", lotteryId);
                return;
            }
            roll = it->second._roll;
            for( auto & loot : it->second._loots ) {
                func(loot);
            }
        }
        for(int32 i = 0; i < roll.times() ; ++i ) {
            int32 lootId = roll.roll();
            func(lootId);
        }
    }
    bool GetLootItem(int32 iLootId, map<int32,int64>& mapItem) {
        map<int32, int32> mapTurret;
        map<int32, int32> mapSwing;
        return GetLootItem(iLootId, mapItem, mapTurret, mapSwing);
    }
    // 按id获取loot对应奖励道具列表
    bool GetLootItem(int32 iLootId, map<int32,int64>& mapItem, map<int32, int32>& mapTurret, map<int32, int32>& mapSwing) {
        tagJsonLoot xmlLoot;
        if (!JDATA->LootPtr()->ByID(iLootId, xmlLoot)) {
            return false;
        }
        for( size_t j = 0; j < xmlLoot._ItemList.size(); j+=2 ) {
            int32 itemId = xmlLoot._ItemList[j];
            int64 itemNum = xmlLoot._ItemList[j+1];
            if( JDATA->ItemPtr()->MainTypeByID(itemId) != 0 && itemNum > 0 ) {
                GlobalUtils::SimpleMapAdd(mapItem, itemId, itemNum);
            }
        }
        for( size_t i=0; i < xmlLoot._TurretList.size() ; i+=2 ) {
            int32 id = xmlLoot._TurretList[i];
            int32 num = xmlLoot._TurretList[i+1];
            GlobalUtils::SimpleMapAdd(mapTurret, id, num);
        }
        for( size_t i=0; i < xmlLoot._SwingList.size() ; i+=2 ) {
            int32 id = xmlLoot._SwingList[i];
            int32 num = xmlLoot._SwingList[i+1];
            GlobalUtils::SimpleMapAdd(mapSwing, id, num);
        }
        return true;
    }
    int32 GetBombGameLootItemNum(int32 iLootId, int32 bombItem) {
        map<int32,int64> mapItem;
        map<int32, int32> mapTurret;
        map<int32, int32> mapSwing;
        if( !GetLootItem(iLootId, mapItem, mapTurret, mapSwing) ) {
            return 0;
        }
        auto it = mapItem.find(bombItem);
        if( it == mapItem.end() ) {
            return 0;
        }
        return it->second;
    }
private:
	boost::shared_mutex _mutex;
	map<int32, tagLottery> m_mapLottery;
};

#define sHLottery Singleton<HelperLottery>::Instance()
