#pragma once

#include "Include/ServerDefine.h"

class HelperBombTable
{
public:
    HelperBombTable() {
        writeLock wl(_mutex);
        m_config.Clear();
        m_mapRelations.clear();
        m_mapCampNumRelations.clear();
    };
    ~HelperBombTable() {};

    void start(const vector<int64>& vecParam) {
        // vecParam.size() == 6
        int32 gid = vecParam[1];
        map< int32, set<int32> > mapRelations;
        map<int32, int32> campRelations;
        JDATA->CardRelationPtr()->ForEach([&](tagJsonCardRelation* ptr){
            if( ptr->_Group == gid ) {
                if( ptr->_Type == e_jsonCardRelationType_CampRelation ) {
                    // 阵营数量羁绊
                    if( ptr->_CardRelationParam.size() >= 1 ) {
                        campRelations[ptr->_CardRelationParam[0]] = ptr->_ID;
                    }
                }
                else {
                    auto it = mapRelations.find(ptr->_ID);
                    if( it == mapRelations.end() ) {
                        set<int32> data;
                        mapRelations[ptr->_ID] = data;
                        it = mapRelations.find(ptr->_ID);
                    }
                    for( size_t i = 0; i < ptr->_CardRelationParam.size(); ++i ) {
                        it->second.insert(ptr->_CardRelationParam[i]);
                    }
                }
            }
        });
        writeLock wl(_mutex);
        m_config.set_card_num(vecParam[0]);
        m_config.set_relation_group(vecParam[1]);
        m_config.set_table_id(vecParam[2]);
        m_config.set_pool_relation_id(vecParam[3]);
        m_config.set_pool_reward(vecParam[4]);
        m_config.set_yell_pool_id(vecParam[5]);
        m_mapRelations.swap(mapRelations);
        m_mapCampNumRelations.swap(campRelations);
    }
    // 遍历所有的羁绊
    void ForEachRelation(boost::function<void(int32, const set<int32>&)> func) {
        readLock rl(_mutex);
        for(auto & it : m_mapRelations) {
            func(it.first, it.second);
        }
    }
    // 根据当前阵营卡牌的数量, 查找满足条件的阵营数量id
    void ForCampNum(int32 num, boost::function<void(int32)> func) {
        readLock rl(_mutex);
        for( auto & it : m_mapCampNumRelations ) {
            if( num >= it.first ) {
                func(it.second);
            }
        }
    }
    int32 GetMaxCardNum() {
        readLock rl(_mutex);
        return m_config.card_num();
    }
    void GetConfig(BombTableInfo& lhs) {
        readLock rl(_mutex);
        lhs = m_config;
    }
private:
	boost::shared_mutex _mutex;
    // 卡牌羁绊id ==> 卡牌列表
	map< int32, set<int32> > m_mapRelations;
    // 阵营数量 ==> 羁绊id
    map< int32, int32 > m_mapCampNumRelations;
    // 每一轮的手牌数量
    BombTableInfo m_config;
};

#define sHBombTable Singleton<HelperBombTable>::Instance()
