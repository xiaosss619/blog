#pragma once

#include "Include/ServerDefine.h"

struct tagRelationInfo {
    int32 _id;
    int32 _type;
    int32 _param;       //
    int32 _loot;        // 奖励
    int32 _voucherLoot; // 禁止话费渠道对应的奖励
    set<int32> _cards;
    vector<ItemPair> _items;
    tagRelationInfo() {
        _id = 0;
        _type = 0;
        _param = 0;
        _loot = 0;
        _voucherLoot = 0;
        _cards.clear();
        _items.clear();
    }
    tagRelationInfo& operator=(const tagRelationInfo & rhs) {
        _id = rhs._id;
        _type = rhs._type;
        _param = rhs._param;
        _loot = rhs._loot;
        _voucherLoot = rhs._voucherLoot;
        _cards = rhs._cards;
        _loot = rhs._loot;
        _items = rhs._items;
        return *this;
    }
};

class HelperTreasure
{
public:
    HelperTreasure() {
        writeLock wl(_mutex);
        m_mapGroupRelationInfo.clear();
    };
    ~HelperTreasure() {};
    void Init() {
        set<int32> treasureRelation;
        JDATA->FishDataPtr()->ForEach([&](tagJsonFishData* ptr){
            if( ptr->_Type == e_jsonFishDataType_TreasureBox ) {
                // 所有宝箱鱼使用的羁绊
                treasureRelation.insert(ptr->_TreasureBoxParam);
            }
        });
        map< int32,list<tagRelationInfo> > mapInfo;
        JDATA->CardRelationPtr()->ForEach([&](tagJsonCardRelation* ptr){
            if( treasureRelation.find(ptr->_Group) == treasureRelation.end() ) {
                return;
            }
            tagRelationInfo info;
            info._id = ptr->_ID;
            info._type = ptr->_Type;
            info._loot = ptr->_Reward;
            info._param = 999;
            info._voucherLoot = ptr->_ChannelReward;
            if( ptr->_ControlReward.size() > 0 && ptr->_ControlReward.size() % 2 == 0 ) {
                for( size_t i = 0; i < ptr->_ControlReward.size(); i+=2 ) {
                    ItemPair item;
                    item.set_item_id(ptr->_ControlReward[i]);
                    item.set_item_num(ptr->_ControlReward[i+1]);
                    info._items.push_back(item);
                }
            }
            switch( ptr->_Type ) {
            case e_jsonCardRelationType_CampRelation:
                // 宝箱鱼不存在该类羁绊, 不做处理
                break;
            case e_jsonCardRelationType_CardRelation:
                for( size_t i = 0; i < ptr->_CardRelationParam.size(); ++i ) {
                    info._cards.insert(ptr->_CardRelationParam[i]);
                }
                break;
            case e_jsonCardRelationType_SingleCamp:
            case e_jsonCardRelationType_WeiCamp:
            case e_jsonCardRelationType_ShuCamp:
            case e_jsonCardRelationType_WuCamp:
                if( ptr->_CardRelationParam.size() == 1 ) {
                    info._param = ptr->_CardRelationParam[0];
                }
                break;
            default:
                break;
            }
            auto it = mapInfo.find(ptr->_Group);
            if( it == mapInfo.end() ) {
                list<tagRelationInfo> lst;
                lst.push_back(info);
                mapInfo[ptr->_Group] = lst;
            }
            else {
                it->second.push_back(info);
            }
        });
        writeLock wl(_mutex);
        m_mapGroupRelationInfo.clear();
        m_mapGroupRelationInfo.swap(mapInfo);
    }

    int32 GetRewards(int32 gid, const set<int32>& cards, bool isBannedVoucher, vector<int32>& loots, vector<ItemPair>& items) {
        auto it = m_mapGroupRelationInfo.find(gid);
        if( it == m_mapGroupRelationInfo.end() ) {
            LOGERROR("Treasure group not found[%d]", gid);
            return 0;
        }
        int32 nCampWei = 0;
        int32 nCampShu = 0;
        int32 nCampWu = 0;
        int32 nCampQun = 0;
        for( auto& card : cards ) {
            int32 camp = JDATA->CardPtr()->CampByID(card);
            switch(camp) {
            case e_jsonCardCamp_Shu:
                ++nCampShu;
                break;
            case e_jsonCardCamp_Wei:
                ++nCampWei;
                break;
            case e_jsonCardCamp_Wu:
                ++nCampWu;
                break;
            case e_jsonCardCamp_Qun:
                ++nCampQun;
                break;
            default:
                break;
            }
        }
        int32 relationId = 0;
        int32 nCampSingle = (!!nCampWei) + (!!nCampShu) + (!!nCampWu) + (!!nCampQun);
        for( auto & info : it->second ) {
            switch(info._type) {
            case e_jsonCardRelationType_CardRelation:
            {
                bool bAllFound = true;
                for( auto & card : info._cards ) {
                    if( cards.find(card) == cards.end() ) {
                        bAllFound = false;
                        break;
                    }
                }
                if( bAllFound ) {
                    if(isBannedVoucher) {
                        loots.push_back(info._voucherLoot);
                    }
                    else {
                        loots.push_back(info._voucherLoot);
                    }
                    for( size_t i = 0; i < info._items.size() ; ++i ) {
                        items.push_back(info._items[i]);
                    }
                    relationId = info._id;
                }
                break;
            }
            case e_jsonCardRelationType_SingleCamp:
                if( nCampSingle == info._param ) {
                    if(isBannedVoucher) {
                        loots.push_back(info._voucherLoot);
                    }
                    else {
                        loots.push_back(info._voucherLoot);
                    }
                    for( size_t i = 0; i < info._items.size() ; ++i ) {
                        items.push_back(info._items[i]);
                    }
                    relationId = info._id;
                }
                break;
            case e_jsonCardRelationType_WeiCamp:
                if( nCampWei == info._param ) {
                    if(isBannedVoucher) {
                        loots.push_back(info._voucherLoot);
                    }
                    else {
                        loots.push_back(info._voucherLoot);
                    }
                    for( size_t i = 0; i < info._items.size() ; ++i ) {
                        items.push_back(info._items[i]);
                    }
                    relationId = info._id;
                }
                break;
            case e_jsonCardRelationType_ShuCamp:
                if( nCampShu == info._param ) {
                    if(isBannedVoucher) {
                        loots.push_back(info._voucherLoot);
                    }
                    else {
                        loots.push_back(info._voucherLoot);
                    }
                    for( size_t i = 0; i < info._items.size() ; ++i ) {
                        items.push_back(info._items[i]);
                    }
                    relationId = info._id;
                }
                break;
            case e_jsonCardRelationType_WuCamp:
                if( nCampWu == info._param ) {
                    if(isBannedVoucher) {
                        loots.push_back(info._voucherLoot);
                    }
                    else {
                        loots.push_back(info._voucherLoot);
                    }
                    for( size_t i = 0; i < info._items.size() ; ++i ) {
                        items.push_back(info._items[i]);
                    }
                    relationId = info._id;
                }
                break;
            default:
                break;
            }
        }
        return relationId;
    }
private:
	boost::shared_mutex _mutex;
    // 羁绊组 ==> 卡牌羁绊id ==> 卡牌列表+奖励
    map< int32, list<tagRelationInfo> > m_mapGroupRelationInfo;
};

#define sHTreasure Singleton<HelperTreasure>::Instance()
