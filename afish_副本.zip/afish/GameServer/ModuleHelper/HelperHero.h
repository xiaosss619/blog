#pragma once

#include "Include/ServerDefine.h"

typedef map<int32, int32> AttrMap;
typedef map<int32, AttrMap> LevelAttrs;
typedef map<int32, LevelAttrs> HeroLevelAttrs;

// 把英雄id+等级/星级+属性绑成一个key
union HeroAttr{
    int64 _key;
    struct {
        int64 _hid  : 32;   // 英雄配置id
        int64 _lv   : 16;   // 英雄等级/星级
        int64 _attr : 16;   // 英雄属性
    };
    static int64 MakeKey(int32 hid, int32 lv, int32 attr) {
        HeroAttr v;
        v._hid = hid;
        v._lv = lv;
        v._attr = attr;
        return v._key;
    }
};

struct tagHeroRelation {
    int32 _id;
    set<int32> _heros;
    int32 _level;
    int32 _star;
    int32 _attr;
    int32 _value;
    int32 _mailId;
    tagHeroRelation() {
        _id = 0;
        _heros.clear();
        _level = 0;
        _star = 0;
        _attr = 0;
        _value = 0;
        _mailId = 0;
    }
    tagHeroRelation& operator=(const tagHeroRelation& rhs) {
        _id = rhs._id;
        _heros = rhs._heros;
        _level = rhs._level;
        _star = rhs._star;
        _attr = rhs._attr;
        _value = rhs._value;
        _mailId = rhs._mailId;
        return *this;
    }
};

class HelperHero
{
public:
    HelperHero() {};
    ~HelperHero() {};
/////////////////////////////////////////////////////////////////////////////
// 炮台配置相关
public:
    bool Init() {
        map<int64, int32> mapHeroLevelAttr;
        JDATA->HeroAttributePtr()->ForEach([&](tagJsonHeroAttribute* ptr){
            for( size_t i = 0; i < ptr->_Attribute.size(); i+=2 ) {
                int32 attr = ptr->_Attribute[i];
                int32 value = ptr->_Attribute[i+1];
                int64 key = HeroAttr::MakeKey(ptr->_HeroID, ptr->_Level, attr);
                mapHeroLevelAttr[key] = value;
            }
        });
        map<int64, int32> mapHeroStarAttr;
        JDATA->HeroSetPtr()->ForEach([&](tagJsonHeroSet* ptr){
            for( size_t i = 0; i < ptr->_StarAttribute.size(); i+=2 ) {
                int32 attr = ptr->_StarAttribute[i];
                int32 value = ptr->_StarAttribute[i+1];
                int64 key = HeroAttr::MakeKey(ptr->_ID, 0, attr);
                mapHeroStarAttr[key] = value;
            }
        });
        map<int32, set<int32> > mapHeroRelationSet;
        map<int32, tagHeroRelation> mapHeroRelationData;
        JDATA->HeroRelationPtr()->ForEach([&](tagJsonHeroRelation* ptr){
            tagHeroRelation tag;
            tag._id = ptr->_ID;
            tag._heros.clear();
            for( size_t i = 0 ; i < ptr->_HeroList.size() ; ++i ){
                tag._heros.insert(ptr->_HeroList[i]);
            }
            tag._level = ptr->_LevelCondition;
            tag._star = ptr->_StarCondition;
            if( ptr->_Attribute.size() == 2 ) {
                tag._attr = ptr->_Attribute[0];
                tag._value = ptr->_Attribute[1];
            }
            tag._mailId = ptr->_MailID;
            if( tag._attr != 0 && tag._value != 0 && tag._level + tag._star > 0 && !tag._heros.empty() ) {
                mapHeroRelationData[tag._id] = tag;
            }
            for( size_t i = 0; i < ptr->_HeroList.size(); i++ ) {
                auto it = mapHeroRelationSet.find(ptr->_HeroList[i]);
                if( it == mapHeroRelationSet.end() ) {
                    set<int32> data;
                    data.insert(ptr->_ID);
                    mapHeroRelationSet[ptr->_HeroList[i]] = data;
                }
                else {
                    it->second.insert(ptr->_ID);
                }
            }
        });
        int32 mhMin = 200;
        int32 mhMax = 6000;
        int32 mhGold = 0;
        JDATA->MenghuoBattlePtr()->ForEach([&](tagJsonMenghuoBattle* ptr){
            if( ptr->_Range.size() == 2) {
                int32 minR = ptr->_Range[0];
                int32 maxR = ptr->_Range[1];
                if( minR <= mhMin ) {
                    mhMin = minR;
                }
                if( maxR > mhMax ) {
                    mhMax = maxR;
                }
                if( minR >= mhGold ) {
                    mhGold = minR;
                }
            }
        });

        writeLock wl(_mutex);
        m_mapHeroLevelAttr.swap(mapHeroLevelAttr);
        m_mapHeroStarAttr.swap(mapHeroStarAttr);
        m_mapHeroRelation.swap(mapHeroRelationSet);
        m_mapHeroRelationData.swap(mapHeroRelationData);
        m_confMenghuo.set_min_rate(mhMin);
        m_confMenghuo.set_max_rate(mhMax);
        m_confMenghuo.set_gold_rate(mhGold);
        return true;
    }
    int32 GetHeroLevelAttrValue(int32 hid, int32 lv, int32 attr) {
        readLock wl(_mutex);
        int64 key = HeroAttr::MakeKey(hid, lv, attr);
        auto it = m_mapHeroLevelAttr.find(key);
        if( it == m_mapHeroLevelAttr.end() ) {
            return 0;
        }
        return it->second;
    }
    int32 GetHeroStarAttrValue(int32 hid, int32 star, int32 attr) {
        readLock wl(_mutex);
        int64 key = HeroAttr::MakeKey(hid, 0, attr);
        auto it = m_mapHeroStarAttr.find(key);
        if( it == m_mapHeroStarAttr.end() ) {
            return 0;
        }
        return it->second*star;
    }
    bool GetHeroRelationData(int32 rid, tagHeroRelation& lhs) {
        auto it = m_mapHeroRelationData.find(rid);
        if( it == m_mapHeroRelationData.end() ) {
            return false;
        }
        lhs = it->second;
        return true;
    }
    bool GetHeroUserRelationSet(int32 hid, set<int32>& relas) {
        readLock rl(_mutex);
        auto it = m_mapHeroRelation.find(hid);
        if( it == m_mapHeroRelation.end() ) {
            return false;
        }
        relas = it->second;
        return true;
    }
    int32 GetMenghuoMaxRate() {
        readLock rl(_mutex);
        return m_confMenghuo.max_rate();
    }
    int32 GetMenghuoMinRate() {
        readLock rl(_mutex);
        return m_confMenghuo.min_rate();
    }
    int32 GetMenghuoGoldRate() {
        readLock rl(_mutex);
        return m_confMenghuo.gold_rate();
    }
private:
	boost::shared_mutex _mutex;
    map<int64, int32> m_mapHeroLevelAttr;
    map<int64, int32> m_mapHeroStarAttr;
    map<int32, tagHeroRelation> m_mapHeroRelationData; // 英雄关联到的用户羁绊id
    map<int32, set<int32> > m_mapHeroRelation;
    JsonMenghuoConfig m_confMenghuo;  // 孟获的最小(key)和最大(value)倍数
};

#define sHero Singleton<HelperHero>::Instance()
