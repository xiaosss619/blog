#pragma once

#include "Include/ServerDefine.h"

class HelperBombAct
{
public:
    HelperBombAct() {
        writeLock wl(_mutex);
        m_nCardNum = 0;
        m_mapRelations.clear();
        m_mapCampNumRelations.clear();
    };
    ~HelperBombAct() {};

    void start(int32 gid, int32 cardNum) {
        map< int32, set<int32> > mapRelations;
        map<int32, int32> campRelations;
        JDATA->CardRelationPtr()->ForEach([&](tagJsonCardRelation* ptr){
            if( ptr->_Group == gid ) {
                if( ptr->_Type == e_jsonCardRelationType_CampRelation ) {
                    // 阵营数量羁绊
                    if( ptr->_CardRelationParam.size() >= 1 ) {
                        campRelations[ptr->_CardRelationParam[0]] = ptr->_ID;
                    }
                }
                else {
                    auto it = mapRelations.find(ptr->_ID);
                    if( it == mapRelations.end() ) {
                        set<int32> data;
                        mapRelations[ptr->_ID] = data;
                        it = mapRelations.find(ptr->_ID);
                    }
                    for( size_t i = 0; i < ptr->_CardRelationParam.size(); ++i ) {
                        it->second.insert(ptr->_CardRelationParam[i]);
                    }
                }
            }
        });
        writeLock wl(_mutex);
        m_mapRelations.swap(mapRelations);
        m_mapCampNumRelations.swap(campRelations);
        m_nCardNum = cardNum;
    }
    // 遍历所有的羁绊
    void ForEachRelation(boost::function<void(int32, const set<int32>&)> func) {
        readLock rl(_mutex);
        for(auto & it : m_mapRelations) {
            func(it.first, it.second);
        }
    }
    // 根据当前阵营卡牌的数量, 查找满足条件的阵营数量id
    void ForCampNum(int32 num, boost::function<void(int32)> func) {
        readLock rl(_mutex);
        for( auto & it : m_mapCampNumRelations ) {
            if( num >= it.first ) {
                func(it.second);
            }
        }
    }
    int32 GetMaxCardNum() {
        readLock rl(_mutex);
        return m_nCardNum;
    }
private:
	boost::shared_mutex _mutex;
    // 卡牌羁绊id ==> 卡牌列表
	map< int32, set<int32> > m_mapRelations;
    // 阵营数量 ==> 羁绊id
    map< int32, int32 > m_mapCampNumRelations;
    // 每一轮的手牌数量
    int32 m_nCardNum;
};

#define sHBombAct Singleton<HelperBombAct>::Instance()
