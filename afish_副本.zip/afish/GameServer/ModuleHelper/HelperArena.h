#pragma once

#include "Include/ServerDefine.h"

struct tagArenaLoot {
	int32 _dayLoot;
	int32 _weekLoot;
	int32 _dayMail;
	int32 _weekMail;
	tagArenaLoot() {
		_dayLoot = 0;
		_weekLoot = 0;
		_dayMail = 0;
		_weekMail = 0;
	}
	tagArenaLoot& operator=(const tagArenaLoot& rhs) {
		_dayLoot = rhs._dayLoot;
		_weekLoot = rhs._weekLoot;
		_dayMail = rhs._dayMail;
		_weekMail = rhs._weekMail;
		return *this;
	}
};

struct tagBulletinLoot {
	int32 _killLoot;
	int32 _killMail;
	int32 _luckLoot;
	int32 _luckMail;
	tagBulletinLoot() {
		memset(this, 0, sizeof(struct tagBulletinLoot));
	}
	tagBulletinLoot& operator=(const tagBulletinLoot& rhs) {
		memcpy(this, &rhs, sizeof(tagBulletinLoot));
		return *this;
	}
};

struct tagBoardLoot {
	int32 _loot;
	int32 _mail;
	tagBoardLoot() {
		_loot = 0;
		_mail = 0;
	}
	tagBoardLoot& operator=(const tagBoardLoot& rhs) {
		_loot = rhs._loot;
		_mail = rhs._mail;
		return *this;
	}
};

class HelperArena
{
public:
    HelperArena() {};
    ~HelperArena() {};
public:
	bool Init() {
		map< int32, tagArenaLoot > mapLoot;
		tagArenaLoot dftLoot;
		JDATA->ArenaRewardPtr()->ForEach([&](tagJsonArenaReward* ptr){
			if( ptr->_RankMax == 0 ) {
				// 最后一条了
				dftLoot._dayLoot = ptr->_DailyRewardLoot;
				dftLoot._weekLoot = ptr->_WeeklyRewardLoot;
				dftLoot._dayMail = ptr->_DailyRewardMail;
				dftLoot._weekMail = ptr->_WeeklyRewardMail;
			}
			else {
				for( int32 rank = ptr->_RankMin ; rank <= ptr->_RankMax ; ++rank ) {
					tagArenaLoot loot;
					loot._dayLoot = ptr->_DailyRewardLoot;
					loot._weekLoot = ptr->_WeeklyRewardLoot;
					loot._dayMail = ptr->_DailyRewardMail;
					loot._weekMail = ptr->_WeeklyRewardMail;
					mapLoot[rank] = loot;
				}
			}
		});
		map<int32, int32> mapRank;
		map<int32, map<int32, tagBulletinLoot> > mapBulletin;
		JDATA->SummonRankRewardPtr()->ForEach([&](tagJsonSummonRankReward* ptr){
			auto it = mapRank.find(ptr->_BossID);
			if( it == mapRank.end() || it->second < ptr->_RankMax ){
				mapRank[ptr->_BossID] = ptr->_RankMax;
			}
			for( int32 rank = ptr->_RankMin ; rank <= ptr->_RankMax ; ++rank ) {
				tagBulletinLoot loot;
				loot._killLoot = ptr->_KillRewardLoot;
				loot._killMail = ptr->_KillRewardMail;
				loot._luckLoot = ptr->_RateRewardLoot;
				loot._luckMail = ptr->_RateRewardMail;
				mapBulletin[ptr->_BossID][rank] = loot;
			}
		});
		map<int32, int32> mapBoardRank;
		map<int32, map<int32, tagBoardLoot> > mapBoardLoot;
		JDATA->RankRewardPtr()->ForEach([&](tagJsonRankReward* ptr){
			auto it = mapRank.find(ptr->_RankID);
			if( it == mapRank.end() || it->second < ptr->_RankMax ){
				mapRank[ptr->_RankID] = ptr->_RankMax;
			}
			for( int32 rank = ptr->_RankMin ; rank <= ptr->_RankMax ; ++rank ) {
				tagBoardLoot loot;
				loot._loot = ptr->_WeeklyRewardLoot;
				loot._mail = ptr->_WeeklyRewardMail;
				mapBoardLoot[ptr->_RankID][rank] = loot;
			}
		});

		writeLock wl(_mutex);
		m_mapArenaLoot.swap(mapLoot);
		m_ComfortLoot = dftLoot;
		m_mapBulletinLoot.swap(mapBulletin);
		m_mapBulletinRank.swap(mapRank);
		m_mapBoardRank.swap(mapBoardRank);
		m_mapBoardLoot.swap(mapBoardLoot);

		return true;
	}
	// 根据排名获得竞技场奖励
	// TUPLE0 每日奖励
	// TUPLE1 每周奖励
	// TUPLE2 每日邮件
	// TUPLE3 每周邮件
	std::tuple<int32, int32, int32, int32> GetArenaLoot(int32 rank) {
		readLock rl(_mutex);
		auto it = m_mapArenaLoot.find(rank);
		if( it != m_mapArenaLoot.end() ) {
			return std::make_tuple(it->second._dayLoot, it->second._weekLoot, it->second._dayMail, it->second._weekMail);
		}
		return std::make_tuple(m_ComfortLoot._dayLoot, m_ComfortLoot._weekLoot, m_ComfortLoot._dayMail, m_ComfortLoot._weekMail);
	}
	bool GetBulletinLoot(int32 bossId, int32 rank, tagBulletinLoot& lhs) {
		readLock rl(_mutex);
		auto it = m_mapBulletinLoot.find(bossId);
		if( it == m_mapBulletinLoot.end() ) {
			return false;
		}
		auto it2 = it->second.find(rank);
		if( it2 == it->second.end() ) {
			return false;
		}
		lhs = it2->second;
		return true;
	}
	int32 GetBulletinMaxRank(int32 bossId) {
		readLock rl(_mutex);
		auto it = m_mapBulletinRank.find(bossId);
		if(it == m_mapBulletinRank.end()) {
			return 0;
		}
		return it->second;
	}
	bool GetBoardLoot(int32 boardId, int32 rank, tagBoardLoot& lhs) {
		readLock rl(_mutex);
		auto it = m_mapBoardLoot.find(boardId);
		if( it == m_mapBoardLoot.end() ) {
			return false;
		}
		auto it2 = it->second.find(rank);
		if( it2 == it->second.end() ) {
			return false;
		}
		lhs = it2->second;
		return true;
	}
	int32 GetBoardMaxRank(int32 boardId) {
		readLock rl(_mutex);
		auto it = m_mapBoardRank.find(boardId);
		if(it == m_mapBoardRank.end()) {
			return 0;
		}
		return it->second;
	}
private:
	boost::shared_mutex _mutex;
	map<int32, tagArenaLoot> m_mapArenaLoot;
	tagArenaLoot m_ComfortLoot;
	map<int32, map<int32, tagBulletinLoot> > m_mapBulletinLoot;
	map<int32, int32> m_mapBulletinRank;
	map<int32, map<int32, tagBoardLoot> > m_mapBoardLoot;
	map<int32, int32> m_mapBoardRank;
};

#define sHArena Singleton<HelperArena>::Instance()
