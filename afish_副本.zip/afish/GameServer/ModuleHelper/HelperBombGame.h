#pragma once

#include "Include/ServerDefine.h"

class HelperBombGame
{
public:
    HelperBombGame() {
        writeLock wl(_mutex);
        m_config.Clear();
        m_mapRelations.clear();
        m_mapCampNumRelations.clear();
        m_cardPool.clear();
        m_cardPoolIn3.clear();
        m_mapCampPool.clear();
    };
    ~HelperBombGame() {};

    void start(const vector<int64>& vecParam) {
        // vecParam是13个参数, 外面已经判定过了
        map< int32, set<int32> > mapRelations;
        map<int32, int32> campRelations;
        JDATA->CardRelationPtr()->ForEach([&](tagJsonCardRelation* ptr){
            if( ptr->_Group == vecParam[1] ) {
                if( ptr->_Type == e_jsonCardRelationType_CampRelation ) {
                    // 阵营数量羁绊
                    if( ptr->_CardRelationParam.size() >= 1 ) {
                        campRelations[ptr->_CardRelationParam[0]] = ptr->_ID;
                    }
                }
                else {
                    auto it = mapRelations.find(ptr->_ID);
                    if( it == mapRelations.end() ) {
                        set<int32> data;
                        mapRelations[ptr->_ID] = data;
                        it = mapRelations.find(ptr->_ID);
                    }
                    for( size_t i = 0; i < ptr->_CardRelationParam.size(); ++i ) {
                        it->second.insert(ptr->_CardRelationParam[i]);
                    }
                }
            }
        });
        writeLock wl(_mutex);
        m_cardPool.clear();
        m_cardPoolIn3.clear();
        m_mapCampPool.clear();
        m_vecCards.clear();
        // 卡池初始化
        JDATA->CardPtr()->ForEach([&](tagJsonCard* ptr){
            m_cardPool.push_value(100, ptr->_ID);
            m_vecCards.push_back(ptr->_ID);
            auto it = m_mapCampPool.find(ptr->_Camp);
            if( it == m_mapCampPool.end() ){
                Roll dice;
                dice.push_value(10, ptr->_ID);
                m_mapCampPool[ptr->_Camp] = dice;
            }
            else {
                it->second.push_value(10, ptr->_ID);
            }
            if( ptr->_Camp != e_jsonCardCamp_Qun ) {
                m_cardPoolIn3.push_value(100, ptr->_ID);
            }
        });
        m_mapRelations.swap(mapRelations);
        m_mapCampNumRelations.swap(campRelations);
        // vecParam是13个参数, 外面已经判定过了
        m_config.set_card_num(vecParam[0]);
        m_config.set_relation_group(vecParam[1]);
        m_config.set_bomb_item_id(vecParam[2]);
        m_config.set_pool_rate(vecParam[3]);
        m_config.set_yell_gold(vecParam[4]);
        m_config.set_yell_gold_id(vecParam[5]);
        m_config.set_yell_gold_sec(vecParam[6]);
        m_config.set_yell_pool_id(vecParam[7]);
        m_config.set_pool_relation_id(vecParam[8]);
        m_config.set_pool_reward(vecParam[9]);
        // m_config.set_bomb_limit(vecParam[10]);
        // m_config.set_bomb_limit_rate(vecParam[11]);
        m_config.set_high_relation1(vecParam[10]);
        m_config.set_high_relation2(vecParam[11]);
        for( size_t i = 12 ; i < vecParam.size() ; ++i ) {
            m_config.add_times(vecParam[i]);
        }
    }
    void GetGameConfig(BombGameInfo& conf) {
        readLock rl(_mutex);
        conf = m_config;
    }
    // 遍历所有的羁绊
    void ForEachRelation(boost::function<void(int32, const set<int32>&)> func) {
        readLock rl(_mutex);
        for(auto & it : m_mapRelations) {
            func(it.first, it.second);
        }
    }
    // 根据当前阵营卡牌的数量, 查找满足条件的阵营数量id
    void ForCampNum(int32 num, boost::function<void(int32)> func) {
        readLock rl(_mutex);
        for( auto & it : m_mapCampNumRelations ) {
            if( num >= it.first ) {
                func(it.second);
            }
        }
    }
    void GetAllCards(vector<int32>& cards) {
        readLock rl(_mutex);
        cards = m_vecCards;
    }
    void RandCards(set<int32>& cards) {
        readLock rl(_mutex);
        Roll dice = m_cardPool;
        dice.set_extra(true, 1);
        for( int i = 0; i < m_config.card_num(); ++i ) {
            cards.insert(dice.roll());
        }
    }
private:
	boost::shared_mutex _mutex;
    // 卡牌羁绊id ==> 卡牌列表
	map< int32, set<int32> > m_mapRelations;
    // 阵营数量 ==> 羁绊id
    map< int32, int32 > m_mapCampNumRelations;
    Roll m_cardPool;
    vector<int32> m_vecCards;
    // 除群雄外的其他卡牌
    Roll m_cardPoolIn3;
    BombGameInfo m_config;
    // 阵营卡池
    map<int32, Roll> m_mapCampPool;
// 核弹场各种控分随机函数
public:
    // 三国阵营中取n个
    void RandCampIn3(int32 num, set<int32>& camps) {
        Roll dice;
        dice.push_value(10, e_jsonCardCamp_Shu);
        dice.push_value(10, e_jsonCardCamp_Wei);
        dice.push_value(10, e_jsonCardCamp_Wu);
        dice.set_extra(true, num);
        for( int i = 0; i < num; i++ ) {
            camps.insert(dice.roll());
        }
    }
    int32 RandCampIn2() {
        Roll dice;
        dice.push_value(10, e_jsonCardCamp_Wei);
        dice.push_value(10, e_jsonCardCamp_Wu);
        return dice.roll();
    }
    void RandCardsInCamp(int32 camp, int32 num, set<int32>& cards) {
        readLock rl(_mutex);
        auto it = m_mapCampPool.find(camp);
        if( it == m_mapCampPool.end() ) {
            return;
        }
        Roll dice = it->second;
        dice.set_extra(true, num);
        for( int32 i = 0; i < num; i++ ) {
            cards.insert(dice.roll());
        }
    }
    void RandCards0(set<int32>& cards) {
        // 在魏蜀吴阵营中随机1个阵营，从中取4张牌，剩下一张牌取另外两个阵营中1张。
        set<int32> camps;
        RandCampIn3(2, camps);
        int32 count = 0;
        for( auto it = camps.begin() ; it != camps.end() ; ++it, ++count ) {
            if( count == 0 ) {
                RandCardsInCamp(*it, 4, cards);
            }
            else {
                RandCardsInCamp(*it, 1, cards);
            }
        }
    }
    void RandCards1(set<int32>& cards) {
        // 随机在群雄阵营中随机1张牌，剩下4张牌在剩下的魏蜀吴阵营中随机。
        Roll dice;
        {
            readLock rl(_mutex);
            dice = m_cardPoolIn3;
            dice.set_extra(true, 4);
        }
        // 群雄取一张
        RandCardsInCamp(e_jsonCardCamp_Qun, 1, cards);

        // 其他卡池取4张
        for( int i = 0; i < 4; i++ ) {
            cards.insert(dice.roll());
        }
    }
    void RandCards2(set<int32>& cards) {
        // 随机在群雄阵营中随机1张牌，在魏蜀吴阵营中随机2个阵营，从中各取2张牌。

        // 群雄取一张
        RandCardsInCamp(e_jsonCardCamp_Qun, 1, cards);

        set<int32> camps;
        RandCampIn3(2, camps);
        for( auto& camp : camps ) {
            RandCardsInCamp(camp, 2, cards);
        }
    }
    void RandCards3(set<int32>& cards) {
        // 在蜀中取1张牌，剩下随机一个阵营取4张。
        RandCardsInCamp(RandCampIn2(), 4, cards);
        RandCardsInCamp(e_jsonCardCamp_Shu, 1, cards);
    }
    void RandWhenNeed(set<int32>& cards) {
        int32 type = GlobalUtils::GetRandNumber(0,2);
        switch( type ) {
        case 0:
            return RandCards0(cards);
        case 1:
            return RandCards1(cards);
        default:
            return RandCards2(cards);
        }
    }
    void RandWhenLimit(set<int32>& cards) {
        int32 type = GlobalUtils::GetRandNumber(0,2);
        switch( type ) {
        case 0:
            return RandCards3(cards);
        case 1:
            return RandCards1(cards);
        default:
            return RandCards2(cards);
        }
    }
};

#define sHBombGame Singleton<HelperBombGame>::Instance()
