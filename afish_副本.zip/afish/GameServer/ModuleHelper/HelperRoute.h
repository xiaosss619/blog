#pragma once

#include "Include/ServerDefine.h"


struct tagRoutePoint {
	float _speed;
	float _rotation;
	float _gradient;
	float _duration;
	tagRoutePoint() {}
	tagRoutePoint(float speed, float rotation, float gradient, float duration) {
		_speed = speed;
		_rotation = rotation;
		_gradient = gradient;
		_duration = duration;
	}
	tagRoutePoint& operator=(const tagRoutePoint& rhs) {
		_speed = rhs._speed;
		_rotation = rhs._rotation;
		_gradient = rhs._gradient;
		_duration = rhs._duration;
		return *this;
	}
};

struct tagRouteData {
	int32 _id;
	int32 _startPosX;
	int32 _startPosY;
	float _lifeTime;
	vector<tagRoutePoint> _points;
	tagRouteData() {}
	tagRouteData& operator=(const tagRouteData& rhs) {
		_id = rhs._id;
		_startPosX = rhs._startPosX;
		_startPosY = rhs._startPosY;
		_lifeTime = rhs._lifeTime;
		_points.clear();
		_points.assign(rhs._points.begin(), rhs._points.end());
		return *this;
	}
};

class HelperRoute
{
public:
    HelperRoute() {};
    ~HelperRoute() {};
public:
    bool Init() {
        map<int32, tagRouteData> mapRouteData;
        // 重新构造一下路径表
        map<int, tagJsonFishRoute> data;
        JDATA->FishRoutePtr()->ForEach([&](tagJsonFishRoute* ptr) {
            tagRoutePoint point(ptr->_Speed, ptr->_Rotation, ptr->_Gradient, ptr->_Duration);
            tagRouteData route;
            route._id = ptr->_RouteID;
            route._startPosX = ptr->_StartPosX;
            route._startPosY = ptr->_StartPosY;
            route._lifeTime = ptr->_LifeTime;
            route._points.push_back(point);

            auto itRoute = mapRouteData.find(ptr->_RouteID);
            if( itRoute != mapRouteData.end() ) {
                itRoute->second._points.push_back(point);
            }
            else {
                mapRouteData[ptr->_RouteID] = route;
            }
        });
        writeLock wl(_route_mutex);
        m_mapRouteData.swap(mapRouteData);
		return true;
    }
	bool GetRouteData(int32 routeid, tagRouteData& lhs) {
		readLock rl(_route_mutex);
		auto it = m_mapRouteData.find(routeid);
		if( it != m_mapRouteData.end() ) {
			lhs = it->second;
			return true;
		}
		return false;
	}

private:
	boost::shared_mutex _route_mutex;
	// FishRoute根据routeid重新构造一次
	map<int32, tagRouteData> m_mapRouteData;
};

#define sHRoute Singleton<HelperRoute>::Instance()
