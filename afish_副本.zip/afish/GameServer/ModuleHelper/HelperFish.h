#pragma once

#include "Include/ServerDefine.h"

class HelperFish
{
public:
    HelperFish() {};
    ~HelperFish() {};
public:
    bool Init() {
		Roll tt_pool;
		map<int32, tagJsonFishData> mapFish;
		int32 minScore = 9999999;
		int32 maxScore = 0;
		JDATA->FishDataPtr()->ForEach([&](tagJsonFishData* ptr) {
			if( ptr->_FunctionID > 0 ) {
				tagJsonFishFunction func;
				if( JDATA->FishFunctionPtr()->ByID(ptr->_FunctionID, func) ) {
					if( func._Type == e_jsonFishFunctionType_TurnTable ) {
						if( minScore > ptr->_ScoreMin ) {
							minScore = ptr->_ScoreMin;
						}
						if( maxScore < ptr->_Score ) {
							maxScore = ptr->_Score;
						}
					}
				}
			}
		});
		// 内圈是2-9,外圈是分值/内圈
		minScore /= 9;
		maxScore /= 2;
		for( int i = minScore; i <= maxScore ; ++i ) {
			if( i % 10 == 0 ) {
				tt_pool.push_value(10,i);
			}
		}
		tt_pool.set_extra(true, 0);

        map<int32, Roll> mapRoll;
        JDATA->FishGroupPtr()->ForEach([&](tagJsonFishGroup* ptr) {
            auto itRoll = mapRoll.find(ptr->_GroupID);
            if( itRoll != mapRoll.end() ) {
                itRoll->second.push_value(ptr->_FishIDWeight, ptr->_FishID);
            }
            else {
                Roll stc;
                stc.push_value(ptr->_FishIDWeight, ptr->_FishID);
                mapRoll[ptr->_GroupID] = stc;
            }
        });

        writeLock wl(_mutex);
	    _turntable_pool = tt_pool;
        m_mapFishGroupRollInfo.swap(mapRoll);
        return true;
    }
	// groupid 鱼组id
	bool GetFishGroupRollInfo(int32 groupid, Roll& lhs) {
		readLock rl(_mutex);
		auto it = m_mapFishGroupRollInfo.find(groupid);
		if( it != m_mapFishGroupRollInfo.end() ) {
			lhs = it->second;
			return true;
		}
		return false;
	}
	void GetTurnTablePool(Roll& lhs) {
		readLock rl(_mutex);
		lhs = _turntable_pool;
	}
private:
	boost::shared_mutex _mutex;
	map<int32, Roll> m_mapFishGroupRollInfo;
	Roll _turntable_pool;	// 转盘鱼的随机取值库,按FishData表中所有转盘鱼类型,取出对应的鱼分做随机库
};

#define sHFish Singleton<HelperFish>::Instance()
