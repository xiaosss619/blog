#pragma once

#include "Include/ServerDefine.h"

class HelperItem
{
public:
    HelperItem() {};
    ~HelperItem() {};

    bool Init() {
        map<int32, int32> mapWingItem;
        map<int32, int32> mapHeroItem;
        int32 expItem = 0;
        JDATA->ItemPtr()->ForEach([&](tagJsonItem* ptr) {
            switch( ptr->_MainType ) {
            case e_jsonItemMainType_SwingPart:
                mapWingItem[ptr->_Misc] = ptr->_ID;
                break;
            case e_jsonItemMainType_TurretPart:
                mapHeroItem[ptr->_Misc] = ptr->_ID;
                break;
            case e_jsonItemMainType_ExpBook:
                expItem = ptr->_ID;
                break;
            default:
                break;
            }
        });
        writeLock wl(_mutex);
        m_mapWingItem.swap(mapWingItem);
        m_mapHeroItem.swap(mapHeroItem);
        m_itemHeroLevelUp = expItem;
        return true;
    }
    int32 GetWingItemPart(int32 wid) {
        readLock rl(_mutex);
        auto it = m_mapWingItem.find(wid);
        if( it == m_mapWingItem.end() ) {
            return 0;
        }
        return it->second;
    }
    int32 GetHeroItemPart(int32 hid) {
        readLock rl(_mutex);
        auto it = m_mapHeroItem.find(hid);
        if( it == m_mapHeroItem.end() ) {
            return 0;
        }
        return it->second;
    }
    int32 GetHeroLevelupItem() {
        readLock rl(_mutex);
        return m_itemHeroLevelUp;
    }
private:
	boost::shared_mutex _mutex;
    map<int32, int32> m_mapWingItem;
    map<int32, int32> m_mapHeroItem;
    int32 m_itemHeroLevelUp;
};

#define sHItem Singleton<HelperItem>::Instance()
