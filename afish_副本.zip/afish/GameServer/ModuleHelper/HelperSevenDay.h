#pragma once

#include "Include/ServerDefine.h"

struct tagSevenDay {
    SevenDayInfo _info;
    int32 _day;
    int32 _param;
    int32 _addState;
    tagSevenDay() {
        _info.Clear();
        _day = 0;
        _param = 0;
        _addState = 0;
    }
    tagSevenDay& operator=(const tagSevenDay& rhs) {
        _info = rhs._info;
        _day = rhs._day;
        _param = rhs._param;
        _addState = rhs._addState;
        return *this;
    }
    void Log() {
        LOGDEBUG("SEVENDAY day[%d] param[%d] state[%d] data[%s]", _day, _param, _addState, _info.DebugString().c_str());
    }
};

class HelperSevenDay
{
public:
    HelperSevenDay() {};
    ~HelperSevenDay() {};

    void Init() {
        map<int32, list<tagSevenDay> > mapSevenDay;
        JDATA->NewBieCarnivalPtr()->ForEach([&](tagJsonNewBieCarnival* ptr){
            if( ptr->_Condition.size() == 3 ) {
                tagSevenDay tag;
                tag._param = ptr->_Condition[1];
                tag._day = ptr->_Day;
                tag._addState = ptr->_ConditionNumAddState;
                tag._info.set_quest_id(ptr->_ID);
                tag._info.set_quest_status(EQS_Accepted);
                tag._info.set_quest_target_num(0);
                tag._info.set_quest_target_need(ptr->_Condition[2]);
                auto it = mapSevenDay.find(ptr->_Condition[0]);
                if( it != mapSevenDay.end() ) {
                    it->second.push_back(tag);
                }
                else {
                    list<tagSevenDay> lst;
                    lst.push_back(tag);
                    mapSevenDay[ptr->_Condition[0]] = lst;
                }
            }
        });
        writeLock wl(_mutex);
        m_mapSevenDay.swap(mapSevenDay);
    }
    // 按目标类型, 注册天数, 获得可以领取或者执行的任务列表
    void GetSevenDayQuests(int32 type, int32 param, int32 regDays, list<SevenDayInfo>& lst) {
        readLock wl(_mutex);
        auto it = m_mapSevenDay.find(type);
        if( it == m_mapSevenDay.end() ) {
            return;
        }
        for( auto& info : it->second ) {
            if( info._addState == 0 && regDays < info._day ) {
                // 注册天数必须>=活动天数才能获得该任务
                continue;
            }
            if( info._param != 0 && info._param != param ) {
                continue;
            }
            lst.push_back(info._info);
        }
    }
private:
	boost::shared_mutex _mutex;
    // 目标类型 ==>
	map<int32, list<tagSevenDay> > m_mapSevenDay;
};

#define sHDay7 Singleton<HelperSevenDay>::Instance()
