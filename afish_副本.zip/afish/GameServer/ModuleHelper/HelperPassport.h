#pragma once

#include "Include/ServerDefine.h"

class HelperPassport
{
public:
    HelperPassport() {};
    ~HelperPassport() {};

    void Init() {
		map<int32, map<int32, int32> > mapPassportId;
		map<int32, int32> mapGroupMaxLevel;
        JDATA->PeriodPassPtr()->ForEach([&](tagJsonPeriodPass* ptr){
			mapPassportId[ptr->_GroupID][ptr->_Level] = ptr->_ID;
			if( mapGroupMaxLevel[ptr->_GroupID] < ptr->_Level ) {
				mapGroupMaxLevel[ptr->_GroupID] = ptr->_Level;
			}
        });
		writeLock wl(_mutex);
		m_mapPassportId.swap(mapPassportId);
		m_mapGroupMaxLevel.swap(mapGroupMaxLevel);
    }
	int32 GetGroupMaxLevel(int32 gid) {
		readLock rl(_mutex);
		auto it = m_mapGroupMaxLevel.find(gid);
		if( it == m_mapGroupMaxLevel.end() ) {
			return 0;
		}
		return it->second;
	};
	bool GetGroupLevelData(int32 gid, int32 lv, tagJsonPeriodPass& lhs) {
		readLock rl(_mutex);
		auto it = m_mapPassportId.find(gid);
		if( it == m_mapPassportId.end() ) {
			return false;
		}
		auto it2 = it->second.find(lv);
		if( it2 == it->second.end() ) {
			return false;
		}
		return JDATA->PeriodPassPtr()->ByID(it2->second, lhs);
	}
	int32 GetGroupLevelByExp(int32 gid, int64 exp) {
		int32 lv = 0;
        JDATA->PeriodPassPtr()->ForEachWithBreak([&](tagJsonPeriodPass* ptr){
			if( ptr->_GroupID == gid && ptr->_TotalExp > exp ) {
				lv = ptr->_Level;
				return true;
			}
			return false;
        });
		return lv;
	}
private:
	boost::shared_mutex _mutex;
	// PeriodPass表 groupId => Level => ID
	map<int32, map<int32, int32> > m_mapPassportId;
	map<int32, int32> m_mapGroupMaxLevel;
};

#define sHPass Singleton<HelperPassport>::Instance()
