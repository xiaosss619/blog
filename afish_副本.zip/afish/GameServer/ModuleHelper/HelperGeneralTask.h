#pragma once

#include "Include/ServerDefine.h"

struct tagGeneralTask {
    GeneralTaskInfo _info;
    int32 _param;   // 参数
    int32 _gid; // 活动id
    tagGeneralTask() {
        _info.Clear();
        _param = 0;
        _gid = 0;
    }
    tagGeneralTask& operator=(const tagGeneralTask& rhs) {
        _info = rhs._info;
        _param = rhs._param;
        _gid = rhs._gid;
        return *this;
    }
};

class HelperGeneralTask
{
public:
    HelperGeneralTask() {};
    ~HelperGeneralTask() {};
    // rewardOnFinish 本组任务是否完成时直接给予奖励
    void start(int32 gid, bool rewardOnFinish) {
        map<int32, map<int32, tagGeneralTask> > mapGTask;
        JDATA->GeneralTaskPtr()->ForEach([&](tagJsonGeneralTask* ptr){
            if( ptr->_GroupID == gid && ptr->_Condition.size() == 3 ) {
                tagGeneralTask tag;
                tag._param = ptr->_Condition[1];
                tag._gid = ptr->_GroupID;
                tag._info.set_task_id(ptr->_ID);
                tag._info.set_task_status(EQS_Accepted);
                tag._info.set_task_target_num(0);
                tag._info.set_task_target_need(ptr->_Condition[2]);
                auto it = mapGTask.find(ptr->_Condition[0]);
                if( it != mapGTask.end() ) {
                    it->second[ptr->_ID] = tag;
                }
                else {
                    map<int32, tagGeneralTask> data;
                    data[ptr->_ID] = tag;
                    mapGTask[ptr->_Condition[0]] = data;
                }
            }
        });
        writeLock wl(_mutex);
        for( auto& it : mapGTask ) {
            auto old = m_mapGTask.find(it.first);
            if( old == m_mapGTask.end() ) {
                m_mapGTask[it.first] = it.second;
            }
            else {
                old->second.insert(it.second.begin(), it.second.end());
            }
        }
        m_setOpenedGroup.insert(gid);
        if( rewardOnFinish ) {
            m_setRewardOnFinish.insert(gid);
        }
    }
    void end(int32 gid) {
        writeLock wl(_mutex);
        m_setOpenedGroup.erase(gid);
        m_setRewardOnFinish.erase(gid);
    }
    // 按目标类型 获得可以领取或者执行的任务列表
    void GetGeneralTasks(int32 type, int32 param, list<GeneralTaskInfo>& lst) {
        readLock wl(_mutex);
        auto it = m_mapGTask.find(type);
        if( it == m_mapGTask.end() ) {
            return;
        }
        for( auto& info : it->second ) {
            // 该组任务未开启
            if( m_setOpenedGroup.find(info.second._gid) == m_setOpenedGroup.end() ) {
                continue;
            }
            if( info.second._param != 0 && info.second._param != param ) {
                continue;
            }
            lst.push_back(info.second._info);
        }
    }
    // 按目标类型获得任务列表,不判定param值
    // 在reset每日类型任务时, 每日使用道具和击杀鱼,param值都非0, 但是重置时并不关心具体的param, 只关心目标类型
    void GetGeneralTasks(int32 type, list<GeneralTaskInfo>& lst) {
        readLock wl(_mutex);
        auto it = m_mapGTask.find(type);
        if( it == m_mapGTask.end() ) {
            return;
        }
        for( auto& info : it->second ) {
            // 该组任务未开启
            if( m_setOpenedGroup.find(info.second._gid) == m_setOpenedGroup.end() ) {
                continue;
            }
            lst.push_back(info.second._info);
        }
    }
    bool IsGroupOpen(int32 gid) {
        readLock wl(_mutex);
        return m_setOpenedGroup.find(gid) != m_setOpenedGroup.end();
    }
    bool IsTaskGroupRewardOnFinish(int32 gid) {
        readLock wl(_mutex);
        return m_setRewardOnFinish.find(gid) != m_setRewardOnFinish.end();
    }
private:
	boost::shared_mutex _mutex;
    // 目标类型 ==>
	map<int32, map<int32, tagGeneralTask> > m_mapGTask;
    set<int32> m_setOpenedGroup;
    // 完成时直接给予奖励, 无需领取
    set<int32> m_setRewardOnFinish;
};

#define sHGTask Singleton<HelperGeneralTask>::Instance()
