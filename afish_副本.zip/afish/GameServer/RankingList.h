#pragma once

#include "ServerDefine.h"
#include "Include/RedisKey.h"

class RankingList {
public:
	RankingList() {};
	~RankingList() {};

public:
	std::tuple<int32, int32> UserDoArena(uint64 userId, int32 score, int64 tNow);

public:
    // 核弹场开奖
	int64 BombGamePoolReward(int64 rate);
    // 核弹场增加奖金
	void BombGamePoolInc(int64 gold);
	int64 GetBombGamePoolGold();
    // 核弹场开奖名单
	void GetBombGamePoolList(BombGamePoolListResp& resp);
	void PushBombGamePoolList(const string& strName, int64 gold);
public:
	int64 GetTableSummonPool(int32 tableIndex);
	void TableSummonPoolIncrby(int32 tableIndex, int64 gold);
	// 按比例扣除奖池金额 返回实际扣除的金额
	int64 TableSummonPoolDecPct(int32 tableIndex, int64 poolRate, int64 curB, int64 maxB);
	void LoadSummonPool();
	void AddSummonPoolKiller(int32 tableIndex, const SummonBossKiller& killer);
	void GetSummonPoolKillers(int32 tableIndex, list<SummonBossKiller>& killers);
private:
	void TryLockRedisKey(RedisConnection* pConnection, const string& key, boost::function<void()> func);
private:
    // 初始化在ThreadTimer中加载, 之后是只读, 不需要加锁
	int64 m_poolMax104;
	int64 m_poolMax105;
};

#define sRankingList Singleton<RankingList>::Instance()
