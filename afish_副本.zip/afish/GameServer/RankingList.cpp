#include "RankingList.h"
#include "ModuleHelper.h"
#include "Include/RedisKey.h"
#include "DataCache/RedisData.h"
#include "Dispatcher.h"
#include "LxGameLogHelper.h"

int64 RankingList::GetBombGamePoolGold() {
    FETCH_RETURN(0);
    int64 gold = 0;
    pConnection->get(RedisKey::MakeSysBombGamePoolKey(), gold);
    return gold;
}

void RankingList::TryLockRedisKey(RedisConnection* pConnection, const string& key, boost::function<void()> func) {
    while( true ) {
        if( pConnection->setnxex(key, "1", 1) ) {
            func();
            pConnection->del(key);
            return;
        }
        usleep(1000);
    }
}

int64 RankingList::BombGamePoolReward(int64 rate) {
    FETCH_RETURN(0);
    int64 gold = 0;
    TryLockRedisKey(pConnection, SYS_BOMB_GAME_POOL_LOCK, [&](){
        int64 pool = 0;
        pConnection->get(RedisKey::MakeSysBombGamePoolKey(), pool);
        gold = pool * rate / 10000;
        pConnection->incrby(RedisKey::MakeSysBombGamePoolKey(), -gold);
    });
    return max(gold, 0L);
}

void RankingList::BombGamePoolInc(int64 gold) {
    FETCH_VOID();
    TryLockRedisKey(pConnection, SYS_BOMB_GAME_POOL_LOCK, [&](){
        int64 pool = 0;
        pConnection->get(RedisKey::MakeSysBombGamePoolKey(), pool);
        pool = min(999999999999, pool+gold);
        pConnection->set(RedisKey::MakeSysBombGamePoolKey(), pool);
    });
}

int64 RankingList::GetTableSummonPool(int32 tableIndex) {
    FETCH_RETURN(0);
    int64 gold = 0;
    pConnection->get(RedisKey::MakeSysSummonPoolKey(tableIndex), gold);
    return gold;
}

void RankingList::TableSummonPoolIncrby(int32 tableIndex, int64 gold) {
    FETCH_VOID();
    ostringstream ss;
    ss << SYS_SUMMON_POOL_LOCK << tableIndex;
    int64 poolMax = (tableIndex == 104)?m_poolMax104:m_poolMax105;
    TryLockRedisKey(pConnection, ss.str(), [&](){
        int64 pool = 0;
        pConnection->get(RedisKey::MakeSysSummonPoolKey(tableIndex), pool);
        pool = min(poolMax, pool+gold);
        pConnection->set(RedisKey::MakeSysSummonPoolKey(tableIndex), pool);
    });
}

// 按比例扣除奖池金额 返回实际扣除的金额
int64 RankingList::TableSummonPoolDecPct(int32 tableIndex, int64 poolRate, int64 curB, int64 maxB) {
    FETCH_RETURN(0);
    double rate = min(1.0f, (curB*1.0f)/(maxB*1.0f));
    double pRate = poolRate*1.0f/100.0f;
    ostringstream ss;
    ss << SYS_SUMMON_POOL_LOCK << tableIndex;
    int64 gold = 0;
    // 这里是给redis加锁 开奖行为比较少, 这里碰撞的几率不高
    TryLockRedisKey(pConnection, ss.str(), [&](){
        int64 pool = 0;
        pConnection->get(RedisKey::MakeSysSummonPoolKey(tableIndex), pool);
        gold = pool*rate*pRate;
        pConnection->incrby(RedisKey::MakeSysSummonPoolKey(tableIndex), -gold);
    });
    return max(gold, 0L);
}

void RankingList::LoadSummonPool() {
    tagJsonGamePlay tag;
    m_poolMax104 = 99999999999;
    if( JDATA->GamePlayPtr()->ByID(104, tag) && tag._GameRefund.size() >= 3 ) {
        m_poolMax104 = tag._GameRefund[2];
    }
    m_poolMax105 = 999999999999;
    if( JDATA->GamePlayPtr()->ByID(105, tag) && tag._GameRefund.size() >= 3 ) {
        m_poolMax105 = tag._GameRefund[2];
    }
}

void RankingList::AddSummonPoolKiller(int32 tableIndex, const SummonBossKiller& killer) {
    FETCH_VOID();
    ostringstream oss;
    oss << killer.name() << "," << killer.rate() << "," << killer.gold() << "," << killer.fish_index();
    pConnection->lpush(RedisKey::MakeSysSummonKillerKey(tableIndex), oss.str());
}

void RankingList::GetSummonPoolKillers(int32 tableIndex, list<SummonBossKiller>& killers) {
    FETCH_VOID();
    vector<std::string> vecMessage;
    pConnection->lrange(RedisKey::MakeSysSummonKillerKey(tableIndex), 0, 50, vecMessage);
    for( size_t i = 0; i < vecMessage.size(); ++i ) {
        vector<string> vec;
        GlobalUtils::GetStrArray(vecMessage[i], ",", vec);
        if( vec.size() == 3 ) {
            SummonBossKiller killer;
            killer.set_name(vec[0]);
            killer.set_rate(vec[1]);
            killer.set_gold(vec[2]);
            if( tableIndex == 104 ) {
                killer.set_fish_index("312");
            }
            else {
                killer.set_fish_index("313");
            }
            killers.push_back(killer);
        }
        else if( vec.size() == 4 ) {
            SummonBossKiller killer;
            killer.set_name(vec[0]);
            killer.set_rate(vec[1]);
            killer.set_gold(vec[2]);
            killer.set_fish_index(vec[3]);
            killers.push_back(killer);
        }
    }
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
std::tuple<int32, int32> RankingList::UserDoArena(uint64 userId, int32 score, int64 tNow) {
    RedisConnectionIdGetter idGetter(enumRedisServerTypeData);
    auto pConnection = idGetter.GetConnection();
    if( pConnection == nullptr ) {
        LOGERROR("no redis found");
        return std::make_tuple(-1,-1);
    }
    int32 newRank = -1;
    int32 oldRank = pConnection->zrevrank(RedisKey::MakeArenaDayKey(), userId);
    int32 oldScore = U_RankScore::GetScore(pConnection->zscore(RedisKey::MakeArenaDayKey(), userId));
    if( oldRank == -1 || score > oldScore ){
        // oldRank = -1 表示第一次打竞技场
        // 大于才有必要往里塞
        int64 redisScore = U_RankScore::MakeScore(tNow, score);
        pConnection->zadd(RedisKey::MakeArenaDayKey(), userId, redisScore);
        newRank = pConnection->zrevrank(RedisKey::MakeArenaDayKey(), userId);
    }
    if( oldRank != -1 ) {
        oldRank += 1;// redis返回是 0 based 数值
    }
    if( newRank != -1 ) {
        newRank += 1;
    }
    return std::make_tuple(oldRank, newRank);
}

void RankingList::GetBombGamePoolList(BombGamePoolListResp& resp) {
    FETCH_VOID();
    vector<string> vecMessage;
    pConnection->lrange(RedisKey::MakeSysBombGamePoolListKey(), 0, 50, vecMessage);
    for( size_t i = 0; i < vecMessage.size(); ++i ) {
        resp.add_records(vecMessage[i]);
    }
}

void RankingList::PushBombGamePoolList(const string& strName, int64 gold) {
    FETCH_VOID();
    ostringstream os;
    os << strName << "," << gold;
    pConnection->lpush(RedisKey::MakeSysBombGamePoolListKey(), os.str());
}

