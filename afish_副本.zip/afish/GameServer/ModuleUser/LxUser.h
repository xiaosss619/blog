#pragma once

#include "ServerDefine.h"
#include "GameUtils.h"
#include "Include/RedisProtoHelper.h"
#include "UserHelper/UserHelperMail.h"
#include "UserHelper/UserHelperHero.h"
#include "UserHelper/UserHelperWing.h"
#include "UserHelper/UserHelperQuest.h"
#include "UserHelper/UserHelperSevenDay.h"
#include "UserHelper/UserHelperMarket.h"
#include "UserHelper/UserHelperDrawRmb.h"
#include "UserHelper/UserHelperGeneralTask.h"
#include "UserHelper/UserHelperBombAct.h"
#include "UserHelper/UserHelperTurnTable.h"
#include "UserHelper/UserHelperTech.h"
#include "UserHelper/UserHelperBuff.h"
#include "UserHelper/UserHelperTreasure.h"
#include "UserHelper/UserHelperCounter.h"
#include "UserHelper/UserHelperFriend.h"
#include "UserHelper/UserHelperBlock.h"
#include "UserHelper/UserHelperFrozens.h"
#include "UserHelper/UserHelperGiftCounter.h"
#include "UserHelper/UserHelperBoss.h"
#include "UserHelper/UserHelperHunt.h"

enum E_UserServerFlag {
    EUSF_TableBonus101      = 0x0000000000000001,   //
    EUSF_TableBonus102      = 0x0000000000000002,   //
    EUSF_TableBonus103      = 0x0000000000000004,   //
    EUSF_TableBonus104      = 0x0000000000000008,   //
    EUSF_FixChargeBonus     = 0x0000000000000010,   // 已经使用, 历史参数, 修复过一次充值bonus过高的错误, deprecated
    EUSF_InNewbieProtect    = 0x0000000000000020,   // 处于新手保护中
    EUSF_VoucherCtrlInited  = 0x0000000000000040,   // 话费控制字段是否初始化过
};

enum E_UserTodayFlag {
    EUTF_RewardTable101         = 0x00000001,   // 101今日是否爆机
    EUTF_RewardTable102         = 0x00000002,   // 102今日是否爆机
    EUTF_RewardTable103         = 0x00000004,   // 103今日是否爆机
    EUTF_RewardTable104         = 0x00000008,   // 104今日是否爆机
    EUTF_EatLunch               = 0x00000010,   // 午餐是否领取
    EUTF_EatSupper              = 0x00000020,   // 晚餐是否领取
    EUTF_WeekCardReward         = 0x00000040,   // 今日周卡是否领取
    EUTF_MonthCardReward        = 0x00000080,   // 今日月卡是否领取
    EUTF_SuperMonthCardReward   = 0x00000100,   // 今日超值月卡是否领取
};

enum E_UserSensitiveFlag {
    EUSTF_Voucher      = 0x00000001,   // 话费系统
    EUSTF_GiftCodeSet  = 0x00000002,   // 礼物系统是否设置过密码
};

// 核弹场中奖广播延迟发送
struct tagDelayBombGamePoolYell {
    int32 _yell_id;
    list<string> _lst;
    tagDelayBombGamePoolYell() {
        _yell_id = 0;
        _lst.clear();
    }
    tagDelayBombGamePoolYell& operator=(const tagDelayBombGamePoolYell& rhs) {
        _yell_id = rhs._yell_id;
        _lst = rhs._lst;
        return *this;
    }
};
// 本类成员变量不做封装,直接提供给ModuleUser下属的所有类使用
class LxUser
{
GETSET(uint64, Key);
GETSET_BOOL(ProcessingOffline);
GETSET(int32, ConnectionId);
GETSET(int64, LastLowFrameTime);
GETSET(int32, SkillSuper);
GETSET(int32, SkillSuperTick);
public:
    LxUser();
    ~LxUser();
UINFOFUNC(m_userInfo);
    bool Init(int32 connectionid, const LxUserOnline& info);
    void OnRecycled();
    bool IsValid();
    // 每3秒update一次
    void Update(int32 dt);
    void FillLoginResp(UserLoginResp& resp);
    string GetLogAccInfoJson();
    string GetLogAccInfoRedisJson();
    // 保存用户兑换商品记录
    void LogExchange(int64 guid, const string& product, int64 tNow, int32 status);
    // 获取用户的注册天数
    int32 GetRegDays();
    void GetTargetInfo(TargetInfo& lhs);
    void UpdateTargetInfo();
    void RandCards(int32 num, set<int32>& cards) {
        std::shuffle(m_vecCards.begin(), m_vecCards.end(), _generator);
        for( int32 i = 0; i < num ; i++ ) {
            cards.insert( m_vecCards[i] );
        }
    }
    void RewardCards(int32 gid, const set<int32>& cards);
public:
    UserInfo m_userInfo;
    vector<int32> m_vecCards;
    list<UserChargeData> m_lstCharge;
    // 核弹场中奖记录
    list<BombGameRecord> m_lstBombGameRecord;
    // 兑换商品列表
    map<int64, UserExchangeData> m_mapExchanges;
    set<int32> m_treasureCards;
    int32 m_nTreasureRelationId;
    void SetFieldValue(const string& field, const string& value);
public:
    bool GiveWing(int32 idx, int32 lv, int32 reason) { return _wing.GiveWing(idx, lv, reason); }
    bool HasWing(int32 idx) { return _wing._tpl.Has(idx); }
    int32 GetCurWingAttr(int32 attr) { return _wing.GetWingAttr(GetCurWingIndex(), attr); }
    int32 GetWingAttr(int32 idx, int32 attr) { return _wing.GetWingAttr(idx, attr); }
    int32 GetCurWingIndex();
    int32 WingUpgrade(int32 idx, const ItemPair& item, WingUpgradeResp& msg) { return _wing.WingUpgrade(idx, item, msg); }
    int32 WingGetPower(int32 idx) { return _wing.WingGetPower(idx); }
    UserHelperWing _wing;
public:
    bool GiveHero(int32 tindex, int32 baseLevel, int32 baseStar, int32 reason) { return _hero.GiveHero(tindex, baseLevel, baseStar, reason); }
    bool HasHero(int32 tid) { return _hero._tpl.Has(tid); }
    HeroInfo* GetHero(int32 tid) { return _hero._tpl.GetPtr(tid); };
    bool GetCurHero(HeroInfo& lhs) { return _hero._tpl.Get(PBGetUserHeroIndex(), lhs); };
    int32 GetCurHeroStar();
    int32 HeroLevelup(int32 tid) { return _hero.HeroLevelup(tid); };
    int32 HeroStarCharge(int32 tid) { return _hero.HeroStarCharge(tid); };
    void HeroSetArenaTime() { _hero.HeroSetArenaTime(PBGetUserHeroIndex()); }
    void HeroSetCasualTime() { _hero.HeroSetCasualTime(PBGetUserHeroIndex()); }
    void HeroActivateWing(int32 idx, int32 widx) { _hero.ActivateWing(idx, widx); }
    void HeroUpdatePower(int32 tid) { _hero.HeroUpdatePower(tid); }
    void OnChangeHero(int32 tid);
    int32 HeroChangeBullet(int32 tid, int32 itemId) { return _hero.HeroChangeBullet(tid, itemId); }
    int32 GetHeroStarAttrValue(int32 attr) { return _hero.HeroGetStarAttrValue(attr); }
    UserHelperHero _hero;
public:
    bool GiveQuest(int32 qid) { return _quest.GiveQuest(qid); };
    void OnQuestGetLevelGift(int32 level) { _quest.OnGetLevelGift(level); }
    void OnQuestChangeTurretRate() { _quest.OnChangeTurretRate(); }
    void OnQuestFishKilled(int32 findex, const set<int32>& setTaskGroup, int64 gold) { _quest.OnQuestFishKilled(findex, setTaskGroup, gold); }
    void OnUseSkill(int32 skillId) { _quest.OnUseSkill(skillId); };
    void OnQuestUseSkillType(int32 skillType) { _quest.OnUseSkillType(skillType); };
    int32 QuestReward(int32 qid) { return _quest.QuestReward(qid); };
    void RandQuest(const set<int32>& qset, const vector<int64>& qvec) { _quest.RandQuest(qset, qvec); };
    void OnQuestUserLevelup(int32 level) { _quest.OnUserLevelup(level); }
    UserHelperQuest _quest;
public:
    // 七日任务数据变化
    void Day7Inc(int32 type, int32 param, int64 value);
    void Day7Set(int32 type, int32 param, int64 value);
    int32 Day7Reward(int32 qid) { return _day7.Day7Reward(qid); };
    int32 Day7ExpReward();
    void Day7OnQuestFishKilled(const set<int32>& setTaskGroup);
    UserHelperSevenDay _day7;
public:
    // 七日任务数据变化
    int32 TreasureHuntReset(bool switchAct) { return _treasure.Reset(switchAct); };
    int32 TreasureHunt(TreasureHuntResp& msg) { return _treasure.Hunt(msg); };
    int32 TreasureHuntSetReward(int32 id1, int32 id2) { return _treasure.SetReward(id1, id2); };
    UserHelperTreasure _treasure;
public:
    // 通用任务数据变化
    void GTaskInc(int32 type, int64 param, int64 value);
    void GTaskSet(int32 type, int64 param, int64 value);
    void GTaskReset(int32 type);
    int32 GTaskReward(int32 qid) { return _gtask.GTaskReward(qid); };
    std::tuple<bool, int32> GTaskInfo(int32 qid) { return _gtask.GTaskInfo(qid); };
    void GTaskOnQuestFishKilled(const set<int32>& setTaskGroup);
    UserHelperGeneralTask _gtask;
public:
    void TurnTableInit(int32 ttid) { _tts.TurnTableInit(ttid); }
    // 转盘活动
    int32 TurnTableBonus(int32 ttid, int32 num, int32 flat, int32 lootId) {
        return _tts.TurnTableBonus(ttid, num, flat, lootId);
    }
    int32 TurnTablePlay(int32 ttid, int32 num, TurntablePlayResp& msg) {
        return _tts.TurnTablePlay(ttid, num, msg);
    }
    UserHelperTurnTable _tts;
public:
    void MailDelete(int64 mailId) { _mail.MailDelete(mailId); };
    bool MailRead(int64 mailId) { return _mail.MailRead(mailId); };
    bool MailReward(int64 mailId) { return _mail.MailReward(mailId); };
	bool SendMail(int32 nMailType, int64 gold) {
        map<int32, int64> mapItem;
        return SendMail(nMailType, 0, gold, mapItem, "", "");
    }
	bool SendMail(int32 nMailType, const string& strContent) {
        map<int32, int64> mapItem;
        return SendMail(nMailType, 0, 0, mapItem, "", strContent);
    }
	bool SendMail(int32 nMailType) {
        map<int32, int64> mapItem;
        return SendMail(nMailType, 0, 0, mapItem, "", "");
    }
	bool SendMail(int32 nMailType, int64 iDiamond, int64 iGold, const map<int32, int64>& mapItem, const string& title, const string& content);
    bool SendMail(LxMail& mail);
    UserHelperMail _mail;
public:
    void GetDrawRmbClientInfo(DrawRmbClientInfo& info) { _draw.GetDrawRmbClientInfo(info); }
    int32 DrawReward(int32 pos, bool isCharge) { return _draw.DrawReward(pos, isCharge); };
    int32 DrawOpen() { return _draw.DrawOpen(); };
    int32 DrawClose() { return _draw.DrawClose(); };
    UserHelperDrawRmb _draw;
public:
    int32 BuyMarket(int32 pid) { return _market.Buy(pid); }
    void RandMarket(bool bNotifyClient) { _market.RandMarket(bNotifyClient); }
    UserHelperMarket _market;
public:
    void NotifyNewFriendApply() { m_dirtySystem.insert(ERDS_FriendNewApply); }
    void NotifyNewFriend() { m_dirtySystem.insert(ERDS_FriendNewFriend); }
    bool HasFriend(uint64 userId) { return _friend.HasFriend(userId); }
    void FriendApplyAccepted(uint64 userId) { _friend.FriendApplyAccepted(userId); };
    void FriendForceRemoved(uint64 userId) { _friend.FriendForceRemoved(userId); };
    tuple<int32, bool> AcceptOneApply(RedisConnection* pConnection, uint64 userId) { return _friend.AcceptOneApply(pConnection, userId); };
    int32 RemoveFriend(RedisConnection* pConnection, uint64 userId) { return _friend.RemoveFriend(pConnection, userId); };
    bool UpdateFriend(const TargetInfo& info) { return _friend.UpdateFriend(info); };
    void FriendComment(uint64 userId, const string& comment) { _friend.FriendComment(userId, comment); };
    void UpdateFriend(uint64 userId) {
        FETCH_VOID();
        return _friend.UpdateFriend(pConnection, userId);
    };
    bool IsFriendOffline(uint64 userId) { return _friend.IsFriendOffline(userId); };
    bool IsFriend(uint64 userId) { return _friend.IsFriend(userId); };
    UserHelperFriend _friend;
public:
    int32 BlockAdd(uint64 userId) { return _block.BlockAdd(userId); }
    int32 BlockDel(uint64 userId) { return _block.BlockDel(userId); }
    UserHelperBlock _block;
public:
    void InitBombAct() { _bombAct.ResetActData(true); };
    void GetBombActInfo(BombActCardInfoResp& resp) { _bombAct.GetBombActInfo(resp); };
    int32 CardClick(int32 pos, BombActCardClickResp& resp) { return _bombAct.CardClick(pos, resp); };
    UserHelperBombAct _bombAct;
    void GetBombGameInfo(BombGameInfoResp& resp);
    int32 PlayBombGame(int32 times, BombGamePlayResp& resp);
    int32 CheckCardsRewards(int32 bombId, int32 times, const set<int32>& userCards, set<int32>& relations);
public:
    void CounterAdd(int32 type, int32 num) { return _counter.Add(type, num); };
    UserHelperCounter _counter;
public:
    int32 TechUpgrade(int32 tid) { return _tech.Upgrade(tid); };
    int32 TechAccelerate(TechAccelerateReq& msg) { return _tech.Accelerate(msg); };
    int32 TechProduce(int32 tid, const ItemPair& item) { return _tech.Produce(tid, item); };
    int32 TechProductGet(int32 tid) { return _tech.ProductGet(tid); };
    int32 TechProduceAccelerate(TechProduceAccelerateReq& msg) { return _tech.ProduceAccelerate(msg); };
    int32 TechGetTurretRate() { return _tech.GetTurretRateEffect(); };
    int32 TechGetFastEffect() { return _tech.GetFastEffect(); };
    int32 TechGetFuryEffect() { return _tech.GetFuryEffect(); };
    int32 TechGetSuperWeaponEffect() { return _tech.GetSuperWeaponEffect(); };
    bool TechIsLocked(int32 tid) { return _tech.IsLocked(tid); };
    UserHelperTech _tech;
public:
    void BuffActivate(int32 buffId) { _buff.Activate(buffId); };
    int32 GetItemExtraDropRate(int32 itemId, int64 now) { return _buff.GetItemExtraDropRate(itemId, now); }
    UserHelperBuff _buff;
public:
    UserHelperFrozens _frozens;
public:
    bool CanSendItem(int32 itemId, int64 num) { return _gcounter.CanSendItem(itemId, num); }
    void GiftSend(int32 itemId, int64 num) { _gcounter.GiftSend(itemId, num); }
    void GiftWitdraw(const string& param) { _gcounter.GiftWithdraw(param); };
    UserHelperGiftCounter _gcounter;
public:
    bool IsBossBonused(int32 bossIdx) { return _boss.IsBossBonused(bossIdx); }
    // 召唤boss
    void OnBossSummoned(int32 bossIdx) { _boss.OnBossSummoned(bossIdx); }
    // 击杀boss
    void OnBossKilled(int32 bossIdx) { _boss.OnBossKilled(bossIdx); }
    UserHelperBoss _boss;
public:
    // 击杀boss
    void OnHuntKilled(int64 guid) { _hunt.OnHuntKilled(guid); }
    void OnHuntMissed(int64 guid) { _hunt.OnHuntMissed(guid); }
    // 尝试过围猎, 设置奖金
    void OnHunted(int64 guid, int64 gold, int64 itemGold) { _hunt.OnHunted(guid, gold, itemGold); }
    // 领取围猎奖励
    void OnHuntRewarded(int64 guid, int32 type) { _hunt.OnHuntRewarded(guid, type); }
    // boss消耗
    void OnHuntHitCost(int64 guid, int32 bossIdx, int64 cost) { _hunt.OnHuntHitCost(guid, bossIdx, cost); }
    // 获取对应boss的消耗, 可累积
    int64 GetHuntHitCost(int64 guid) { return _hunt.GetHuntHitCost(guid); }
    void OnBroken() { _hunt.OnBroken(); }
    bool GetHuntBossData(int64 guid, HuntBossSimple& lhs) { return _hunt.GetHuntBossData(guid, lhs); }
    UserHelperHunt _hunt;
public:
    bool IsInNewbieProtect() { return PBGetServerFlag() & EUSF_InNewbieProtect; }
    void SetNewbieProtected() { PBSetServerFlag(PBGetServerFlag() | EUSF_InNewbieProtect); }
    void RemoveNewbieProtect() {
        int64 flag = PBGetServerFlag();
        flag &= ~EUSF_InNewbieProtect;
        PBSetServerFlag(flag);
    }
    bool IsVoucherCtrlInited() { return PBGetServerFlag() & EUSF_VoucherCtrlInited; }
    void SetVoucherCtrlInited() { PBSetServerFlag(PBGetServerFlag() | EUSF_VoucherCtrlInited); }

    int32 CheckEnterRoom(const tagJsonGamePlay& rhs);
    // 判断桌面今日爆机奖励是否已经领取
    bool IsTableRewarded(int32 tableIndex) {
        switch( tableIndex ) {
        case 101:
            return PBGetTodayFlag() & EUTF_RewardTable101;
        case 102:
            return PBGetTodayFlag() & EUTF_RewardTable102;
        case 103:
            return PBGetTodayFlag() & EUTF_RewardTable103;
        case 104:
            return PBGetTodayFlag() & EUTF_RewardTable104;
        default:
            return true;
        }
    }
    void SetTableRewarded(int32 tableIndex) {
        switch( tableIndex ) {
        case 101:
            PBSetTodayFlag(PBGetTodayFlag() | EUTF_RewardTable101);
            break;
        case 102:
            PBSetTodayFlag(PBGetTodayFlag() | EUTF_RewardTable102);
            break;
        case 103:
            PBSetTodayFlag(PBGetTodayFlag() | EUTF_RewardTable103);
            break;
        case 104:
            PBSetTodayFlag(PBGetTodayFlag() | EUTF_RewardTable104);
            break;
        default:
            break;
        }
    }
    bool IsRmbCardRewarded(int32 flag) { return PBGetTodayFlag() & flag; }
    void SetRmbCardReward(int32 flag)  { return PBSetTodayFlag(PBGetTodayFlag() | flag); }

    bool IsSensitiveSystemBanned(int32 flag) {
        return PBGetSensitiveFlag() & flag;
    }
    void SetSensitiveSystemBanned(int32 flag) {
        PBSetSensitiveFlag(PBGetSensitiveFlag()|flag);
    }
    void UnsetSensitiveSystemBanned(int32 flag) {
        int32 ss = PBGetSensitiveFlag();
        ss &= ~flag;
        PBSetSensitiveFlag(ss);
    }
    void SetGiftCode(const string& code);
public:
    void GiveLoot(int32 iLoot, int32 reason, bool isChargeLoot, bool isVipBonus=false);
    void GiveLottery(int32 lotteryId, int32 reason);
    // 道具使用,失败则返回失败enum值
    int32 ItemUse(const UserItemUseReq& req);
    bool CanRemoveItem(const map<int32, int64>& mapItem);
    void RemoveItem(const map<int32, int64>& mapItem, int32 reason);
    bool CanChangeItem(int32 iItemId, int64 iChangeNum);
    bool ItemChange(int32 iItemId, int64 iChangeNum, int32 reason, bool isChargeLoot);
    void OnItemChange(const ItemPair& item);
    int64 GetItemNum(int32 iItemId) {
        auto it = m_mapItem.find(iItemId);
        if( it == m_mapItem.end() ) {
            return 0;
        }
        return it->second;
    }
    void ItemRecycle();
    void ItemRecyclePayPrice(int64 itemNum, const vector<int64>& vecPrice);
    void SlientFix();
    map<int32, ItemPair> m_dirtyItems;
    map<int64, int64> m_mapItem;
////////////////////////////////////////////////////////////////////////////////
public:
    void ProcessPacket(WrapPacket& pkg, WrapPacket& response);
public:
    void SendSystemHint(const string& strMsg);
    // 发送属性变化消息,依赖本消息将用户变化后的属性存储到redis
    void SendUserInfoChange(int32 reason);
    // 金币变化,生成一个属性变化结构和一个道具变化结构
    bool CanChangeGold(int64 iChange) { return m_userInfo.user_gold() + iChange >= 0; }
    bool ChangeGold(int64 iChange, int32 reason, bool fireCost=false);
    bool CanChangeCrystal(int64 iChange) { return m_userInfo.user_crystal() + iChange >= 0; }
    bool ChangeCrystal(int64 iChange, int32 reason, bool fireCost=false);
    bool CanChangeDiamond(int64 iChange);
    bool ChangeDiamond(int64 iChange, int32 reason, bool isChargeLoot);
    void IncGameTime(int32 gameTime);
    void AddExp(int32 iExp);
    void AddBattlePassExp(int64 iExp);
    // 一键领取通行证当前奖励
    void PassportReward();
    // 通行证购买经验
    int32 PassportBuyExp(int32 levels);
    void AddVipExp(int32 iExp);
    void ChangeCurEnergy(int32 chg);
    // 绑定手机号
    void BindUserPhone(const string& phone);
    // 绑定邮箱
    void BindUserIdCard(const string& idcard);
    // 刷新能量值
    void UpdateEnergy();
    void UpdateArenaData(int32 rank, int32 score);
    void UpdateBulletinData(int32 fishIndex, int32 kill, int32 rate, int32 bomb);

    // 获得玩家当前金币资产总价值 金币+核弹
    int64 GetUserGoldProperty();
    // 用来判断是否可以通过破产保护机制杀鱼
    bool CanKillByBrokenBonus(int64 tableMax);
    // 使用破产保护机制杀了一条鱼
    void KillByBrokenBonus(int64 gold);
    // 开始新手话费红包活动
    void StartNewbieFee(int32 id, int32 seconds);
    // 给予贫困补助
    void RewardPoverty(int64 iGold);

    bool IsBattlePassBought();
    // 充值
    // @param product 配置表商品id
    // @param orderNo 自己的订单号
    // @param tpOrderNo 第三方支付的订单号
    // @param src 支付来源
    void Charged(const string& product, const string& orderNo, const string& tpOrderNo, const string& src);
    // 尝试执行一次跨天
    bool CrossDay();
    void UpdateBoardData();
    void AfterLogin();
    void Offline();
    int32 SignDay();
    bool IsVipGiftBought(int32 level) {
        return m_userInfo.vip_gift_flag() & (1<<level);
    }
    bool IsRmbCardWeek(int64 tNow) { return PBGetTimeWeek() > tNow; }
    bool IsRmbCardMonth(int64 tNow) { return PBGetTimeMonth() > tNow; }
    bool IsRmbCardSuperMonth(int64 tNow) { return PBGetTimeMonthSuper() > tNow; }
    int32 GetMaxEnergy();
    void DoVipDailyFix();
    void SetVipGiftBoughtFlag(int32 level) {
        uint32 flag = m_userInfo.vip_gift_flag();
        flag |= (1<<level);
        PBSetVipGiftFlag(flag);
    }
    void SetFishTableInfo(int32 tid, int32 tindex, int64 endTime);
    int32 GetFishTableId();
    void TideCompleted(int32 tideId);
    int64 GetCouponNum();
    // 由于版本迭代, 存在多个版本的新手完结任务, 因此本函数用来判定玩家是否完成了新手阶段的引导任务
    bool IsNewbieEnd() { return m_bNewbieEnd; }
    void SetNewbieEnd() { m_bNewbieEnd = true; }
    int32 DrawTen(int32 type, DrawTenResp& resp);
    int32 DrawTenPeriodReward();
    void DrawTenUpdate();
private:
    // 获得商品购买次数
    int32 GetChargeTimes(const string& strProductName);
    void OnFieldChange(E_UserInfoFieldEnum field);
    bool IsBombLimit(int32 bombId);
    void BombGameNewRecord(const BombGameRecord& info);
    void BombGamePushYell(int32 yellId, const string& strStarName, const string& reward) {
        tagDelayBombGamePoolYell tag;
        tag._yell_id = yellId;
        tag._lst.push_back(strStarName);
        tag._lst.push_back(reward);
        m_lstYells.push_back(tag);
    }
private:
    set<E_UserInfoFieldEnum> m_dirtyFields;
    list<UserChargeData> m_dirtyProducts;
    list<BombGameRecord> m_dirtyBombGameRecord;
    set<int64> m_dirtyExchanges;
    // 需要发送的小红点
    set<int32> m_dirtySystem;
    int32 m_nFishTablef;    // 房间系数
    int64 m_nFireCost;  // 开火消耗的金币
    int32 m_nFireLastTable; // 上次开火的房间
    int64 m_nFireCrystalCost;  // 开火消耗的魔晶
    int32 m_nFireLastCrystalTable; // 上次魔晶开火的房间
    std::default_random_engine _generator;
    bool m_bNewbieEnd;
    list<tagDelayBombGamePoolYell> m_lstYells;
    int64 m_tmLastBoardUpdate;
    int64 m_tmLastCheckLink;
public:
    // 均值为mu，方差为sigma的 符合正态分布的随机值 param为系数,只在兑换券抽奖使用
    int32 GetNormalDistributionNumber(double mu, double sigma, double param = 1.0f) {
        std::normal_distribution<double> distribution(mu, sigma);
        return (int32)(distribution(_generator)*param+0.5);
    }
private:
    int32 GetDrawTenBigNum(int32 mu, int32 sigma) {
        std::normal_distribution<double> distribution( mu, sigma );
        int32 number = distribution(_generator);
        return max((int32)sqrt(mu), min(number, mu*2));
    }

////////////////////////////////////////////////////////////////////////////////////////////////
// 捕鱼个人奖池+输赢分处理部分
public:
    void ResetFishPool(const vector<int64>& vecPersonalFund);
    void FishPoolKillFish(int64 gold);
    void FishPoolOnFire(int64 gold);
    void FishPoolCheck();
    bool IsUserInChargeBonus();
    // 个人奖池是否在释放
    bool IsFishPoolInUse();
    // 获得个人奖池概率
    float GetFishPoolRate();
    void FishPoolOnCharge(int64 bonus);
    void FishPoolShrink();
    // @brief 获得玩家净分
    // @param m 渔场的M值
    // @param inFast 是否处于急速阶段
    // @param inFury 是否处于狂暴阶段
    int64 GetUserWin(int64 m, bool inFast, bool inFury);
////////////////////////////////////////////////////////////////////////////////////////////////
public:
    int32 GetHeroRelationAttr(int32 key) {
        auto it = m_mapHeroRelationAttr.find(key);
        if( it == m_mapHeroRelationAttr.end() ) {
            return 0;
        }
        return it->second;
    }
    void InitUserAttr();
    void OnHeroRelationChange(int32 hid);
    void TryActivateRelation(int32 rid);
private:
    map<int32, int32> m_mapHeroRelationAttr;    // 玩家激活的羁绊属性
    set<int32> m_setHeroRelation;        // 玩家已经激活的羁绊id

////////////////////////////////////////////////////////////////////////////////////////////////
public:
    void SetSkill(int32 sklId, int64 tick) {
        if( tick == 0 ) {
            m_mapSkillBackup.erase(sklId);
        }
        else {
            m_mapSkillBackup[sklId] = tick;
        }
    }
    int64 GetSkill(int32 sklId) {
        auto it = m_mapSkillBackup.find(sklId);
        if( it == m_mapSkillBackup.end() ) return 0;
        return it->second;
    }
private:
    map<int32, int64> m_mapSkillBackup;
};
