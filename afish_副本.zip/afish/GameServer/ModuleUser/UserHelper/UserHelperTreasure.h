#pragma once

#include "UserHelperTpl.h"

class LxUser;
class UserHelperTreasure {
public:
    void Init(LxUser* pUser);
    void InitTreasure(const TreasureInfo& rhs);

    int32 Reset(bool switchAct);
    int32 Hunt(TreasureHuntResp& msg);
    int32 SetReward(int32 id1, int32 id2);
    bool FillProto(SyncUserInfoChange& user,LxSaveData& save) {
        bool bFilled = false;
        _tpl.ForEachDirty([&](TreasureInfo* ptr) {
            *save.add_treasures() = *ptr;
            *user.add_treasures() = *ptr;
            bFilled = true;
        });
        _tpl.ClearChange();
        return bFilled;
    }
    void FillLoginResp(UserLoginResp& resp) {
        resp.clear_treasures();
        _tpl.ForEach([&](TreasureInfo* ptr) {
            *resp.add_treasures() = *ptr;
        });
    }
private:
    tuple<int32,int32> GetPrice(int32 num);
    void ChangeTreasure(const TreasureInfo& rhs);
public:
    UserHelperTpl<int32, TreasureInfo> _tpl;
    LxUser* m_pUser;
};
