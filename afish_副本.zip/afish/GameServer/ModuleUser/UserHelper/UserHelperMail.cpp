#include "UserHelperMail.h"
#include "../LxUser.h"
#include "LxGameLogHelper.h"
#include "Dispatcher.h"

void UserHelperMail::Init(LxUser* pUser) {
    m_pUser = pUser;
    _tpl.Init();
}

bool UserHelperMail::MailRead(int64 mailId) {
    auto pMail = _tpl.GetPtr(mailId);
    if( pMail == nullptr ) {
        return false;
    }
    pMail->set_mail_read(1);
    _tpl.OnChange(mailId);

	LOG_USER_MAIL(m_pUser
                , pMail->mail_id()
                , pMail->mail_read()*10+pMail->mail_rewarded()
                , pMail->mail_type());
    return true;
}

bool UserHelperMail::MailReward(int64 mailId) {
    auto pMail = _tpl.GetPtr(mailId);
    if( pMail == nullptr ) {
        return false;
    }
    if( pMail->mail_rewarded() != 0 ) {
        return false;
    }
    if( pMail->mail_gold() == 0
        && pMail->mail_diamond() == 0
        && pMail->mail_items_size() == 0 ) {
        // 没奖励
        return false;
    }
    pMail->set_mail_rewarded(1);
    pMail->set_mail_read(1);
    // 这里不做CanChange设定, 因为在SendMail和LoadMail中都对<0的值进行了处理,这里只会是增加,不会失败
    if( pMail->mail_gold() > 0 ) {
        m_pUser->ChangeGold(pMail->mail_gold(), 100000+pMail->mail_type());
    }
    if( pMail->mail_diamond() > 0 ) {
        m_pUser->ChangeDiamond(pMail->mail_diamond(), 100000+pMail->mail_type(), false);
    }
    for( int32 i = 0 ; i < pMail->mail_items_size() ; ++i ) {
        m_pUser->ItemChange(pMail->mail_items(i).item_id(), pMail->mail_items(i).item_num(), 100000+pMail->mail_type(), false);
    }
    _tpl.OnChange(mailId);

	LOG_USER_MAIL(m_pUser
                , pMail->mail_id()
                , pMail->mail_read()*10+pMail->mail_rewarded()
                , pMail->mail_type());
    return true;
}

void UserHelperMail::NewMail(const LxMail& mail) {
    _tpl.Set(mail.mail_id(), mail);
    _tpl.OnChange(mail.mail_id());
}

bool UserHelperMail::FillProto(SyncUserInfoChange& user,LxSaveData& save) {
    bool bFilled = false;
    _tpl.ForEachDirty([&](LxMail* pMail) {
        *save.add_mails() = *pMail;
        bFilled = true;
    });
    _tpl.ForEachRemoved([&](const int64& mid) {
        save.add_del_mails(mid);
        bFilled = true;
    });
    _tpl.ClearChange();
    return bFilled;
}
