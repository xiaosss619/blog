#pragma once

#include "UserHelperTpl.h"

class LxUser;
class UserHelperBoss {
public:
    void Init(LxUser* pUser);
    void InitBoss(const BossInfo& qi);

    bool FillProto(LxSaveData& save);

    bool IsBossBonused(int32 bossIdx);
    // 召唤boss
    void OnBossSummoned(int32 bossIdx);
    // 击杀boss
    void OnBossKilled(int32 bossIdx);
private:
    void InitOne(int32 bossIdx);
public:
    UserHelperTpl<int32, BossInfo> _tpl;
    LxUser* m_pUser;
};
