#pragma once

#include "UserHelperTpl.h"

class LxUser;
class UserHelperGiftCounter {
public:
    void Init(LxUser* pUser);
    void InitCounter(const ItemPair& info);
    void GiftSend(int32 itemId, int64 num);
    void GiftWithdraw(const string& param);
    bool CanSendItem(int32 itemId, int64 num);

    bool FillProto(SyncUserInfoChange& user,LxSaveData& save) {
        bool bFilled = false;
        _tpl.ForEachDirty([&](ItemPair* ptr) {
            *user.add_gcounter() = *ptr;
            *save.add_gcounter() = *ptr;
            bFilled = true;
        });
        _tpl.ClearChange();
        return bFilled;
    }
    void FillLoginResp(UserLoginResp& resp) {
        resp.clear_gcounter();
        _tpl.ForEach([&](ItemPair* ptr) {
            *resp.add_gcounter() = *ptr;
        });
    }

    void CrossDay();
public:
    UserHelperTpl<int32, ItemPair> _tpl;
    LxUser* m_pUser;
};
