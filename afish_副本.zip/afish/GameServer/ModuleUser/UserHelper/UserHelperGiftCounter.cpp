#include "UserHelperGiftCounter.h"
#include "../LxUser.h"
#include "ModuleHelper.h"
#include "Dispatcher.h"
#include "LxGameLogHelper.h"

void UserHelperGiftCounter::Init(LxUser* pUser) {
    m_pUser = pUser;
    _tpl.Init();
}

void UserHelperGiftCounter::InitCounter(const ItemPair& info) {
    _tpl.Set(info.item_id(), info);
}

void UserHelperGiftCounter::CrossDay() {
    _tpl.ForEach([&](ItemPair* ptr) {
        ptr->set_item_change(0);
        ptr->set_item_num(0);
        _tpl.OnChange(ptr->item_id());
    });
}

bool UserHelperGiftCounter::CanSendItem(int32 itemId, int64 num) {
    tagJsonVIP tag;
    if( !JDATA->VIPPtr()->ByID(m_pUser->PBGetUserVip(), tag) ) {
        return false;
    }
    if( tag._SendGift == 0 ) {
        LOGERROR("user[%lu] vip[%d] can not send gift", m_pUser->GetKey(), tag._ID);
        return false;
    }
    if( tag._SendGiftAmount.size() == 0 || tag._SendGiftAmount.size()%4 != 0 ) {
        LOGERROR("user[%lu] vip[%d] gift config error[%d]", m_pUser->GetKey(), tag._ID, tag._SendGiftAmount.size());
        return false;
    }
    int32 maxCount = 0; // 最大次数
    int64 maxNum = 0;   // 最大数量
    for( size_t i = 0 ; i < tag._SendGiftAmount.size() ; i+=4 ) {
        if( tag._SendGiftAmount[i] == itemId ) {
            maxNum = tag._SendGiftAmount[i+1];
            maxCount = tag._SendGiftAmount[i+2];
            break;
        }
    }
    auto ptr = _tpl.GetPtr(itemId);
    if( ptr == nullptr ) {
        ItemPair item;
        item.set_item_id(itemId);
        item.set_item_change(0);
        item.set_item_num(0);
        _tpl.Set(itemId, item);
        ptr = _tpl.GetPtr(itemId);
    }
    if( maxCount >= 0 && ptr->item_change() + 1 > maxCount ) {
        LOGERROR("user[%lu] count max[%ld] [%d]", m_pUser->GetKey(), ptr->item_change()+1, maxCount);
        return false;
    }
    if( maxNum >= 0 && ptr->item_num() + num > maxNum ) {
        LOGERROR("user[%lu] num max[%ld] [%d]", m_pUser->GetKey(), ptr->item_num() + num, maxNum);
        return false;
    }
    return true;
}

void UserHelperGiftCounter::GiftSend(int32 itemId, int64 num) {
    auto ptr = _tpl.GetPtr(itemId);
    if( ptr == nullptr ) {
        ItemPair item;
        item.set_item_id(itemId);
        item.set_item_change(1);
        item.set_item_num(num);
        _tpl.Set(itemId, item);
    }
    else {
        ptr->set_item_change(ptr->item_change()+1);
        ptr->set_item_num(ptr->item_num()+num);
    }
    _tpl.OnChange(itemId);
}

void UserHelperGiftCounter::GiftWithdraw(const string& param) {
    vector<int64> vec;
    GlobalUtils::GetNumArray(param, "|", vec);
    if( vec.size() != 2 ) {
        LOGERROR("user[%lu] gift withdraw failed[%s]", m_pUser->GetKey(), param.c_str());
        return;
    }
    int32 itemId = (int32)vec[0];
    int32 itemNum = vec[1];
    auto ptr = _tpl.GetPtr(itemId);
    if( ptr == nullptr ) {
        LOGERROR("user[%lu] withdraw gift failed[%d][%ld]", m_pUser->GetKey(), itemId, itemNum);
        return;
    }
    if( ptr->item_change() <= 1 ) {
         ptr->set_item_change(0);
    }
    else {
         ptr->set_item_change(ptr->item_change()-1);
    }

    if( ptr->item_num() <= itemNum ) {
         ptr->set_item_num(0);
    }
    else {
         ptr->set_item_num(ptr->item_num()-itemNum);
    }
    _tpl.OnChange(itemId);
}
