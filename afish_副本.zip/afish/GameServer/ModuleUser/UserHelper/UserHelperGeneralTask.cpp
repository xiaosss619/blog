#include "UserHelperGeneralTask.h"
#include "../LxUser.h"
#include "ModuleHelper.h"
#include "Dispatcher.h"
#include "LxGameLogHelper.h"

void UserHelperGeneralTask::Init(LxUser* pUser) {
    m_pUser = pUser;
    _tpl.Init();
}

void UserHelperGeneralTask::InitGTask(const GeneralTaskInfo& qi) {
    int32 qid = qi.task_id();
    if( qi.task_target_num() >= qi.task_target_need() ) {
        GeneralTaskInfo qq = qi;
        qq.set_task_target_num(qq.task_target_need());
        _tpl.Set(qid, qq);
    }
    else {
        _tpl.Set(qid, qi);
    }
}

void UserHelperGeneralTask::GTaskInc(const GeneralTaskInfo& qi, int64 value) {
    int32 qid = qi.task_id();
    auto ptr = _tpl.GetPtr(qid);
    if( ptr == nullptr ) {
        InitGTask(qi);
        ptr = _tpl.GetPtr(qid);
    }
    if( ptr == nullptr || ptr->task_status() != EGTS_Accepted ) {
        return;
    }
    ptr->set_task_target_num(ptr->task_target_num()+value);
    bool finished = false;
    if( ptr->task_target_num() >= ptr->task_target_need() ) {
        ptr->set_task_target_num(ptr->task_target_need());
        ptr->set_task_status(EGTS_Finished);
        LOG_GENERAL_TASK(m_pUser, qid, EGTS_Finished);
        finished = true;
    }
    _tpl.OnChange(qid);
    if( finished && sHGTask->IsTaskGroupRewardOnFinish(JDATA->GeneralTaskPtr()->GroupIDByID(qid)) ) {
        GTaskReward(qid);
    }
}

void UserHelperGeneralTask::GTaskReset(const GeneralTaskInfo& qi) {
    int32 qid = qi.task_id();
    auto ptr = _tpl.GetPtr(qid);
    if( ptr == nullptr ) {
        InitGTask(qi);
        return;
    }
    // 有了任务要重置一下数量
    ptr->set_task_target_num(0);
    ptr->set_task_target_need(qi.task_target_need());
    ptr->set_task_status(EGTS_Accepted);
    _tpl.OnChange(qid);
}

void UserHelperGeneralTask::GTaskSet(const GeneralTaskInfo& qi, int64 value) {
    int32 qid = qi.task_id();
    auto ptr = _tpl.GetPtr(qid);
    if( ptr == nullptr ) {
        InitGTask(qi);
        ptr = _tpl.GetPtr(qid);
    }
    if( ptr == nullptr || ptr->task_status() != EGTS_Accepted ) {
        return;
    }
    // 配置更新时可能会修改需求数量, 这里同步更新一下
    ptr->set_task_target_need(qi.task_target_need());
    if( value > ptr->task_target_num() ) {
        ptr->set_task_target_num(value);
    }
    bool finished = false;
    if( ptr->task_target_num() >= ptr->task_target_need() ) {
        ptr->set_task_target_num(ptr->task_target_need());
        ptr->set_task_status(EGTS_Finished);
        LOG_GENERAL_TASK(m_pUser, qid, EGTS_Finished);
        finished = true;
    }
    _tpl.OnChange(qid);
    if( finished && sHGTask->IsTaskGroupRewardOnFinish(JDATA->GeneralTaskPtr()->GroupIDByID(qid)) ) {
        GTaskReward(qid);
    }
}

bool UserHelperGeneralTask::FillProto(SyncUserInfoChange& user,LxSaveData& save) {
    bool bFilled = false;
    _tpl.ForEachDirty([&](GeneralTaskInfo* ptr) {
        *user.add_gtasks() = *ptr;
        *save.add_gtasks() = *ptr;
        bFilled = true;
    });
    _tpl.ForEachRemoved([&](const int32& pid) {
        save.add_del_gtasks(pid);
        bFilled = true;
    });
    _tpl.ClearChange();
    return bFilled;
}

int32 UserHelperGeneralTask::GTaskReward(int32 qid) {
    tagJsonGeneralTask tag;
    if( !JDATA->GeneralTaskPtr()->ByID(qid, tag) ) {
        LOGERROR("user has unknown qid[%d]", qid);
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    if( tag._LootID.size() != 1 && tag._LootID.size() != 3 ) {
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    auto ptr = _tpl.GetPtr(qid);
    if( ptr == nullptr ) {
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    int32 lootId = 0;
    int32 lootVip = 0;
    switch(ptr->task_status()) {
    case EGTS_Accepted:
        return JDATA->ErrorCodePtr()->GetGeneralTaskNotFinished();
    case EGTS_VipRewarded:
        return JDATA->ErrorCodePtr()->GetGeneralTaskRewarded();
    case EGTS_Rewarded:
        // 领取了普通奖励, 这次要领vip的
        if( tag._LootID.size() != 3 ) {
            return JDATA->ErrorCodePtr()->GetSystemError();
        }
        if( m_pUser->PBGetUserVip() < tag._LootID[1] ) {
            return JDATA->ErrorCodePtr()->GetGeneralTaskVipFailed();
        }
        lootVip = tag._LootID[2];
        ptr->set_task_status(EGTS_VipRewarded);
        break;
    case EGTS_Finished:
        if( tag._LootID.size() > 0 ) {
            lootId = tag._LootID[0];
            ptr->set_task_status(EGTS_Rewarded);
        }
        if( tag._LootID.size() == 3 && m_pUser->PBGetUserVip() >= tag._LootID[1] ) {
            lootVip = tag._LootID[2];
            ptr->set_task_status(EGTS_VipRewarded);
        }
        break;
    }
    m_pUser->GiveLoot(lootId, ELRI_GeneralTaskReward, false);
    m_pUser->GiveLoot(lootVip, ELRI_GeneralTaskReward, false);
    LOG_GENERAL_TASK(m_pUser, qid, ptr->task_status());

    _tpl.OnChange(qid);
    return JDATA->ErrorCodePtr()->GetSuccess();
}

void UserHelperGeneralTask::CheckExpired() {
    // 通用任务跨天处理, 把不再生效的任务组清理掉
    vector<int32> vec;
    _tpl.ForEach([&](GeneralTaskInfo* ptr){
        int32 gid = JDATA->GeneralTaskPtr()->GroupIDByID(ptr->task_id());
        if( gid == 0 || !sHGTask->IsGroupOpen(gid) ) {
            vec.push_back(ptr->task_id());
        }
    });
    for( size_t i = 0; i < vec.size() ; i++ ) {
        _tpl.Remove(vec[i]);
    }
}

std::tuple<bool, int32> UserHelperGeneralTask::GTaskInfo(int32 qid) {
    auto ptr = _tpl.GetPtr(qid);
    if( ptr == nullptr ) {
        return std::make_tuple(false, 0);
    }
    return std::make_tuple(ptr->task_target_num() >= ptr->task_target_need(), ptr->task_target_num());
}
