#pragma once

#include "UserHelperTpl.h"

class LxUser;
class UserHelperTech {
public:
    void Init(LxUser* pUser);
    void InitNewbie();
    void InitTech(const TechInfo& qi);
    bool Update(int64 now);

    void RmbUpgrade(int32 techId, int32 lv);
    int32 Upgrade(int32 techId);
    int32 Accelerate(TechAccelerateReq& msg);
    int32 GetTurretRateEffect();
    int32 GetFastEffect();
    int32 GetFuryEffect();
    int32 GetSuperWeaponEffect();
    int32 Produce(int32 tid, const ItemPair& item);
    int32 ProductGet(int32 tid);
    int32 ProduceAccelerate(TechProduceAccelerateReq& msg);
    bool IsLocked(int32 tid);
    void Unlock(int32 tid);

    bool FillProto(SyncUserInfoChange& user,LxSaveData& save);
    void FillLoginResp(UserLoginResp& resp) {
        resp.clear_techs();
        _tpl.ForEach([&](TechInfo* ptr) {
            *resp.add_techs() = *ptr;
        });
    }

private:
    int32 GetDiamondPrice(int32 seconds);
    // 把pSrc的数量累计到pDst上, num=-1表示全部累计
    void ItemProduced(ItemPair* pSrc, ItemPair* pDst, int32 num) {
        if( num == -1 || pSrc->item_num() <= num ) {
            pDst->set_item_id(pSrc->item_id());
            pDst->set_item_num(pDst->item_num()+pSrc->item_num());
            pDst->set_item_change(pDst->item_num());
            pSrc->set_item_id(0);
            pSrc->set_item_num(0);
            pSrc->set_item_change(0);
        }
        else {
            pDst->set_item_id(pSrc->item_id());
            pDst->set_item_num(pDst->item_num()+num);
            pDst->set_item_change(pDst->item_num());
            pSrc->set_item_num(pSrc->item_num()-num);
            pSrc->set_item_change(pSrc->item_num());
        }
    }
    bool CheckProducing(TechInfo* pTech);
public:
    UserHelperTpl<int32, TechInfo> _tpl;
    LxUser* m_pUser;
};
