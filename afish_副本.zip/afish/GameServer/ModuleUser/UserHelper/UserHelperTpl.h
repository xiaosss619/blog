#pragma once

#include "Include/ServerDefine.h"

template<typename KeyType, typename InfoType>
class UserHelperTpl {
public:
    bool Has(const KeyType& key) {
        return m_mapData.find(key) != m_mapData.end();
    }
    void Set(const KeyType& key, const InfoType& rhs) {
        auto it = m_mapData.find(key);
        if( it == m_mapData.end() ) {
            m_mapData[key] = rhs;
        }
        else {
            it->second = rhs;
        }
    }
    bool Get(const KeyType& key, InfoType& lhs) {
        auto it = m_mapData.find(key);
        if( it == m_mapData.end() ) {
            return false;
        }
        lhs = it->second;
        return true;
    }
    InfoType* GetPtr(const KeyType& key) {
        auto it = m_mapData.find(key);
        if( it == m_mapData.end() ) {
            return nullptr;
        }
        return &it->second;
    }
    void Remove(const KeyType& key) {
        m_mapData.erase(key);
        m_setRemoved.insert(key);
    }
    void OnChange(const KeyType& key) {
        m_dirty.insert(key);
    }
    void Init() {
        m_setRemoved.clear();
        m_dirty.clear();
        m_mapData.clear();
    };
	void ForEach(boost::function<void(InfoType*)> func) {
		for( auto & it : m_mapData ) {
   			func(&it.second);
		}
	}
	void ForEachWithBreak(boost::function<bool(InfoType*)> func) {
		for( auto & it : m_mapData ) {
   			if( func(&it.second) ) {
                break;
            }
		}
	}
	void ForEachDirty(boost::function<void(InfoType*)> func) {
		for( auto & key : m_dirty ) {
            auto ptr = GetPtr(key);
            if( ptr != nullptr ) {
    			func(ptr);
            }
		}
	}
    void ForEachRemoved(boost::function<void(const KeyType&)> func) {
		for( auto & key : m_setRemoved ) {
  			func(key);
		}
    }
    void ClearChange() {
        m_dirty.clear();
        m_setRemoved.clear();
    }
    size_t Size() {
        return m_mapData.size();
    }
    bool Empty() {
        return m_mapData.empty();
    }
public:
    set<KeyType> m_setRemoved;
    set<KeyType> m_dirty;
    map<KeyType, InfoType> m_mapData;
};
