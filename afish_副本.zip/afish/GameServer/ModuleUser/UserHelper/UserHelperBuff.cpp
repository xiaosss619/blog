#include "UserHelperBuff.h"
#include "../LxUser.h"
#include "ModuleHelper.h"
#include "Dispatcher.h"
#include "LxGameLogHelper.h"

void UserHelperBuff::Init(LxUser* pUser) {
    m_pUser = pUser;
    _tpl.Init();
}

void UserHelperBuff::InitBuff(const BuffInfo& qi) {
    _tpl.Set(qi.buff_id(), qi);
}

bool UserHelperBuff::FillProto(SyncUserInfoChange& user,LxSaveData& save) {
    bool bFilled = false;
    _tpl.ForEachDirty([&](BuffInfo* ptr) {
        *user.add_buffs() = *ptr;
        *save.add_buffs() = *ptr;
        bFilled = true;
    });
    _tpl.ClearChange();
    return bFilled;
}

void UserHelperBuff::Activate(int32 buffId) {
    int32 seconds = JDATA->BuffPtr()->DurationByID(buffId);
    auto ptr = _tpl.GetPtr(buffId);
    if( ptr == nullptr ) {
        BuffInfo buff;
        buff.set_buff_id(buffId);
        buff.set_buff_end(sGameUtils->GetFakeTimeNow() + seconds);
        InitBuff(buff);
    }
    else {
        int64 end_time = 0;
        int64 now = sGameUtils->GetFakeTimeNow();
        if( ptr->buff_end() <= now ) {
            end_time = now + seconds;
        }
        else {
            end_time = ptr->buff_end() + seconds;
        }
        ptr->set_buff_end(end_time);
    }
    _tpl.OnChange(buffId);
}

int32 UserHelperBuff::GetItemExtraDropRate(int32 itemId, int64 now) {
    int32 rate = 0;
    sHBuff->ForEachItem(itemId, [&](int32 buffId, int32 dropRate){
        auto ptr = _tpl.GetPtr(buffId);
        if( ptr != nullptr && ptr->buff_end() > now ) {
            rate += dropRate;
        }
    });
    return rate;
}
