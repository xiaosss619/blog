#pragma once

#include "UserHelperTpl.h"

class LxUser;
class UserHelperBlock {
public:
    void Init(LxUser* pUser);
    void InitBlock(const TargetInfo& qi);
    int32 BlockAdd(uint64 userId);
    int32 BlockDel(uint64 userId);

    bool FillProto(SyncUserInfoChange& user,LxSaveData& save);
    void FillLoginResp(UserLoginResp& resp) {
        resp.clear_blocks();
        _tpl.ForEach([&](TargetInfo* ptr) {
            *resp.add_blocks() = *ptr;
        });
    }
    bool HasFriend(uint64 userId) {
        return _tpl.Has(userId);
    }
public:
    UserHelperTpl<uint64, TargetInfo> _tpl;
    LxUser* m_pUser;
};
