#pragma once

#include "UserHelperTpl.h"

class LxUser;
class UserHelperDrawRmb {
public:
    void Init(LxUser* pUser);
    void InitDraw(const DrawRmbInfo& info) {
        _tpl.Set(info.act_id(), info);
    }
    int32 DrawReward(int32 pos, bool isCharge);
    int32 DrawReward(const string& productId);
    int32 DrawOpen();
    int32 DrawClose();
    void GetDrawRmbClientInfo(DrawRmbClientInfo& info);

    bool FillProto(SyncUserInfoChange& user, LxSaveData& save);
private:
    // 当只随机到一份话费券奖励时, 获得该奖励的随机位置
    int32 GetVoucherItemPosWhenOne(int32 m0, int32 sigma3, int32 sigma5);
public:
    UserHelperTpl<int32, DrawRmbInfo> _tpl;
    LxUser* m_pUser;
};
