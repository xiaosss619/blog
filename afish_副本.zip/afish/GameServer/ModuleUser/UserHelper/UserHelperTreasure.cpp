#include "UserHelperTreasure.h"
#include "../LxUser.h"
#include "ModuleHelper.h"
#include "Dispatcher.h"
#include "LxGameLogHelper.h"

void UserHelperTreasure::Init(LxUser* pUser) {
    m_pUser = pUser;
    _tpl.Init();
}

void UserHelperTreasure::InitTreasure(const TreasureInfo& rhs) {
    _tpl.Set(rhs.pos(), rhs);
}

void UserHelperTreasure::ChangeTreasure(const TreasureInfo& rhs) {
    _tpl.Set(rhs.pos(), rhs);
    _tpl.OnChange(rhs.pos());
}

tuple<int32,int32> UserHelperTreasure::GetPrice(int32 num) {
    tagJsonDiamondTimes tag;
    if( JDATA->DiamondTimesPtr()->ByTimes(num, tag) && tag._TreasurePrice.size() == 2 ) {
        return std::make_tuple(tag._TreasurePrice[0], tag._TreasurePrice[1]);
    }
    int32 diamond = 0;
    int32 items = 0;
    JDATA->DiamondTimesPtr()->ForEach([&](tagJsonDiamondTimes* ptr){
        if( ptr->_TreasurePrice.size() == 2 && ptr->_TreasurePrice[0] > diamond ) {
            diamond = ptr->_TreasurePrice[0];
            items = ptr->_TreasurePrice[1];
        }
    });
    return std::make_tuple(diamond, items);
}

int32 UserHelperTreasure::Reset(bool switchAct) {
    TreasureHuntConfig config;
    if( !sHActs->GetTreasureHuntConfig(config) ) {
        LOGERROR("[%lu] no activity", m_pUser->GetKey());
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    if( m_pUser->PBGetTreasureHuntId() != config.act_id() ) {
        LOGERROR("[%lu] id failed", m_pUser->GetKey());
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    if( !switchAct ) {
        if( !m_pUser->ChangeDiamond(-config.reset_diamond(), ELRD_TreasureHuntReset, false) ) {
            LOGERROR("[%lu] diamond low", m_pUser->GetKey());
            return JDATA->ErrorCodePtr()->GetSystemError();
        }
    }
    m_pUser->PBSetTreasureHuntNum(0);
    Roll dice;
    JDATA->TreasureHuntPtr()->ForEach([&](tagJsonTreasureHunt* ptr){
        if( ptr->_GroupID == config.small_group() ) {
            dice.push_value(ptr->_ServerWeight, ptr->_ID);
        }
    });
    dice.set_extra(true, config.small_num());
    for( int32 i = 0 ; i < config.small_num() ; i++ ) {
        tagJsonTreasureHunt tag;
        int32 tid = dice.roll();
        if( !JDATA->TreasureHuntPtr()->ByID(tid, tag) ) {
            LOGERROR("[%lu]failed to find treasure id [%d]", m_pUser->GetKey(), tid);
            continue;
        }
        TreasureInfo info;
        info.set_pos(i);
        info.set_loot_id(tag._Loot);
        info.set_hunted(false);
        info.set_weight(tag._PlayerWeight);
        ChangeTreasure(info);
    }
    // 重置两个大宝藏数据
    {
        TreasureInfo info;
        info.set_pos(config.small_num());
        info.set_loot_id(0);
        info.set_hunted(false);
        ChangeTreasure(info);
    }
    {
        TreasureInfo info;
        info.set_pos(config.small_num()+1);
        info.set_loot_id(0);
        info.set_hunted(false);
        ChangeTreasure(info);
    }
    m_pUser->SendUserInfoChange(EPIC_TreasureHuntReset);
    return JDATA->ErrorCodePtr()->GetSuccess();
}

int32 UserHelperTreasure::Hunt(TreasureHuntResp& msg) {
    m_pUser->SendUserInfoChange(0);
    TreasureHuntConfig config;
    if( !sHActs->GetTreasureHuntConfig(config) ) {
        LOGERROR("[%lu] no activity", m_pUser->GetKey());
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    if( m_pUser->PBGetTreasureHuntId() != config.act_id() ) {
        if( Reset(true) != JDATA->ErrorCodePtr()->GetSuccess() ) {
            LOGERROR("[%lu] reset failed", m_pUser->GetKey());
            return JDATA->ErrorCodePtr()->GetSystemError();
        }
    }
    Roll dice;
    _tpl.ForEach([&](TreasureInfo* ptr){
        if( !ptr->hunted() ) {
            if( ptr->pos() >= config.small_num() ) {
                // 大宝藏
                if( m_pUser->PBGetTreasureHuntNum() >= config.fake_hunt() ) {
                    dice.push_value(ptr->weight(), ptr->pos());
                }
            }
            else {
                dice.push_value(ptr->weight(), ptr->pos());
            }
        }
    });
    if( dice.empty() ) {
        LOGERROR("[%lu] need reset treasure", m_pUser->GetKey());
        return JDATA->ErrorCodePtr()->GetSystemError();
    }

    auto price = GetPrice(m_pUser->PBGetTreasureHuntNum()+1);
    int32 diamond = TUPLE0(price);
    int32 items = TUPLE1(price);
    // 正常寻宝, 扣钱或者道具
    if( items < 0 || diamond < 0 ) {
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    if( !m_pUser->ItemChange(config.token(), -items, ELRD_TreasureHunt, false) ) {
        if( !m_pUser->ChangeDiamond(-diamond, ELRD_TreasureHunt, false) ) {
            LOGERROR("[%lu] diamond low", m_pUser->GetKey());
            return JDATA->ErrorCodePtr()->GetSystemError();
        }
    }
    int32 pos = dice.roll();
    auto ptr = _tpl.GetPtr(pos);
    if( ptr == nullptr ) {
        LOGERROR("[%lu] pos error[%d]", m_pUser->GetKey(), pos);
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    ptr->set_hunted(true);
    _tpl.OnChange(ptr->pos());
    m_pUser->PBIncTreasureHuntNum(1);
    m_pUser->GiveLoot(ptr->loot_id(), ELRI_TreasureHunt, false);
    m_pUser->SendUserInfoChange(EPIC_TreasureHunt);

    *msg.mutable_data() = *ptr;
    return JDATA->ErrorCodePtr()->GetSuccess();
}

int32 UserHelperTreasure::SetReward(int32 id1, int32 id2) {
    TreasureHuntConfig config;
    if( !sHActs->GetTreasureHuntConfig(config) ) {
        LOGERROR("[%lu] no activity", m_pUser->GetKey());
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    if( m_pUser->PBGetTreasureHuntId() != config.act_id() ) {
        if( Reset(true) != JDATA->ErrorCodePtr()->GetSuccess() ) {
            LOGERROR("[%lu] id failed", m_pUser->GetKey());
            return JDATA->ErrorCodePtr()->GetSystemError();
        }
    }
    auto ptr1 = _tpl.GetPtr(config.small_num());
    auto ptr2 = _tpl.GetPtr(config.small_num()+1);
    if( ptr1 == nullptr || ptr2 == nullptr ) {
        LOGERROR("[%lu] pos error[%d][%d]", m_pUser->GetKey(), config.small_num(), config.small_num()+1);
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    if( ptr1->hunted() || ptr2->hunted() ) {
        LOGERROR("[%lu] pos hunted pos[%d][%d] pos[%d][%d]", m_pUser->GetKey(), config.small_num(), ptr1->hunted(), config.small_num()+1, ptr2->hunted());
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    tagJsonTreasureHunt tag1;
    tagJsonTreasureHunt tag2;
    if( !JDATA->TreasureHuntPtr()->ByID(id1, tag1) || !JDATA->TreasureHuntPtr()->ByID(id2, tag2) ) {
        LOGERROR("[%lu] treasure id failed[%d][%d]", m_pUser->GetKey(), id1, id2);
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    if( tag1._GroupID != config.big_group() || tag2._GroupID != config.big_group() ) {
        LOGERROR("[%lu] treasure group failed [%d][%d] big_group[%d]", m_pUser->GetKey(), id1, id2, config.big_group());
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    ptr1->set_loot_id(tag1._Loot);
    ptr1->set_weight(tag1._PlayerWeight);

    ptr2->set_loot_id(tag2._Loot);
    ptr2->set_weight(tag2._PlayerWeight);
    _tpl.OnChange(config.small_num());
    _tpl.OnChange(config.small_num()+1);
    m_pUser->SendUserInfoChange(EPIC_TreasureHuntSetReward);
    return JDATA->ErrorCodePtr()->GetSuccess();
}
