#include "UserHelperFriend.h"
#include "../LxUser.h"
#include "ModuleHelper.h"
#include "DataCache/ProtoCmdHelper.h"

void UserHelperFriend::Init(LxUser* pUser) {
    m_pUser = pUser;
    m_lstOnlineNeedInit.clear();
    _tpl.Init();
}

void UserHelperFriend::InitFriend(const TargetInfo& info) {
    _tpl.Set(info.t_id(), info);
    m_lstOnlineNeedInit.push_back(info.t_id());
}

void UserHelperFriend::Update(RedisConnection* pConnection) {
    if( m_lstOnlineNeedInit.empty() ) {
        return;
    }
    int32 num = 0;
    while( !m_lstOnlineNeedInit.empty() ) {
        uint64 uid = m_lstOnlineNeedInit.front();
        UpdateFriend(pConnection, uid);
        m_lstOnlineNeedInit.pop_front();
        if( ++num >= 5 ) {
            break;
        }
    }
}

void UserHelperFriend::RefreshMe(RedisConnection* pConnection) {
    vector<string> vecData;
    vecData.push_back(GlobalUtils::ToString(m_pUser->GetKey()));
    _tpl.ForEach([&](TargetInfo* ptr){
        if( ptr->t_offline() == 0 ) {
            // 對在綫用戶發一個上綫
            ProtoCmdHelper::PushGmCmd(pConnection, ptr->t_id(), EIC_FriendUpdate, vecData);
        }
    });
}

void UserHelperFriend::UpdateFriend(RedisConnection* pConnection, uint64 userId) {
    if( !_tpl.Has(userId) ) {
        return;
    }

    TargetInfo info;
    if( !RedisData::GetUserTargetInfo(pConnection, userId, info) ) {
        return;
    }
    UpdateFriend(info);
}

bool UserHelperFriend::UpdateFriend(const TargetInfo& info) {
    auto ptr = _tpl.GetPtr(info.t_id());
    if( ptr == nullptr ) {
        return false;
    }
    // comment是自己保存的数据, 保持不变
    string strComment = ptr->t_comment();
    _tpl.Set(info.t_id(), info);
    ptr->set_t_comment(strComment);
    _tpl.OnChange(info.t_id());
    return true;
}

void UserHelperFriend::FriendComment(uint64 userId, const string& comment) {
    auto ptr = _tpl.GetPtr(userId);
    if( ptr == nullptr ) {
        return;
    }
    ptr->set_t_comment(comment);
    _tpl.OnChange(userId);
}

bool UserHelperFriend::IsFriendOffline(uint64 userId) {
    auto ptr = _tpl.GetPtr(userId);
    if( ptr == nullptr ) {
        return true;
    }
    return ptr->t_offline() > 0;
}

void UserHelperFriend::FriendApplyAccepted(uint64 userId) {
    // 如果用戶7天內未登録, 該用戶會從redis中刪除, 此時可能會出現單向好友
    // 後續刪除好友時注意處理一下即可
    RedisConnectionIdGetter idGetter(enumRedisServerTypeData);
    auto pConnection = idGetter.GetConnection();
    if( pConnection == nullptr ) {
        LOGERROR("no redis connection");
        return;
    }
    TargetInfo info;
    if( !RedisData::GetUserTargetInfo(pConnection, userId, info) ) {
        LOGERROR("no cache in redis[%ld]", userId);
        return;
    }
    _tpl.Set(info.t_id(), info);
    _tpl.OnChange(info.t_id());
    m_pUser->NotifyNewFriend();
}

void UserHelperFriend::FriendForceRemoved(uint64 userId) {
    _tpl.Remove(userId);
}

tuple<int32, bool> UserHelperFriend::AcceptOneApply(RedisConnection* pConnection, uint64 userId) {
    if( m_pUser->HasFriend(userId) ) {
        return make_tuple(JDATA->ErrorCodePtr()->GetFriendAlreadyFriend(), true);
    }
    // 自己好友列表滿
    if( RedisData::IsFriendListFull(pConnection, m_pUser->GetKey()) ) {
        return make_tuple(JDATA->ErrorCodePtr()->GetFriendListFulll(), false);
    }
    // 對方好友列表滿
    if( RedisData::IsFriendListFull(pConnection, userId) ) {
        return make_tuple(JDATA->ErrorCodePtr()->GetFriendTargetListFull(), false);
    }
    string strHashKey = RedisKey::MakeUserApplyKey(m_pUser->GetKey());
    int64 ret = pConnection->zscore(strHashKey, userId);
    if( ret <= 0 ) {
        return make_tuple(JDATA->ErrorCodePtr()->GetSystemError(), true);
    }
    // 從申請信息中構造好友結構
    TargetInfo info;
    if( !RedisData::GetUserTargetInfo(pConnection, userId, info) ) {
        return make_tuple(JDATA->ErrorCodePtr()->GetSystemError(), true);
    }
    _tpl.Set(info.t_id(), info);
    _tpl.OnChange(info.t_id());
    m_pUser->NotifyNewFriend();

    // 因為是接受申請, 所以這裏反向推一個命令給對方, 讓他加自己為好友
    vector<string> vec;
    vec.push_back(GlobalUtils::ToString(m_pUser->GetKey()));
    ProtoCmdHelper::PushGmCmd(pConnection, userId, EIC_FriendApplyAccepted, vec);

    return make_tuple(JDATA->ErrorCodePtr()->GetSuccess(), true);
}

int32 UserHelperFriend::RemoveFriend(RedisConnection* pConnection, uint64 userId) {
    auto ptr = _tpl.GetPtr(userId);
    if( ptr == nullptr ) {
        return JDATA->ErrorCodePtr()->GetSuccess();
    }
    _tpl.Remove(userId);

    // 這裏反向推一個命令給對方, 讓對方也把自己刪除
    vector<string> vec;
    vec.push_back(GlobalUtils::ToString(m_pUser->GetKey()));
    ProtoCmdHelper::PushGmCmd(pConnection, userId, EIC_FriendForceRemoved, vec);

    return JDATA->ErrorCodePtr()->GetSuccess();
}

bool UserHelperFriend::FillProto(SyncUserInfoChange& user, LxSaveData& save) {
    bool bFilled = false;
    _tpl.ForEachDirty([&](TargetInfo* ptr) {
        *user.add_friends() = *ptr;
        *save.add_friends() = *ptr;
        bFilled = true;
    });
    _tpl.ForEachRemoved([&](const uint64& fid) {
        user.add_del_friends(fid);
        save.add_del_friends(fid);
        bFilled = true;
    });
    _tpl.ClearChange();
    return bFilled;
}
