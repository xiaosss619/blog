#pragma once

#include "UserHelperTpl.h"

class LxUser;
class UserHelperTurnTable {
public:
    void Init(LxUser* pUser);
    void InitTurnTable(const TurnTableInfo& qi);
    void TurnTableInit(int32 ttid);
    int32 TurnTableBonus(int32 ttid, int32 num, int32 flag, int32 lootId);
    int32 TurnTablePlay(int32 ttid, int32 num, TurntablePlayResp& msg);
    void CrossDay();
    bool FillProto(SyncUserInfoChange& user,LxSaveData& save);
    void FillLoginResp(UserLoginResp& resp) {
        resp.clear_tts();
        _tpl.ForEach([&](TurnTableInfo* ptr) {
            *resp.add_tts() = *ptr;
        });
    }
public:
    UserHelperTpl<int32, TurnTableInfo> _tpl;
    LxUser* m_pUser;
};
