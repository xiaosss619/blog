#include "UserHelperFrozens.h"
#include "../LxUser.h"
#include "ModuleHelper.h"
#include "Dispatcher.h"
#include "LxGameLogHelper.h"
#include "Handler/RedisCmdHandler.h"

void UserHelperFrozens::Init(LxUser* pUser) {
    m_pUser = pUser;
    _tpl.Init();
}

void UserHelperFrozens::InitAssets(const FrozenAssets& info) {
    _tpl.Set(info.asset_id(), info);
}

bool UserHelperFrozens::FillProto(SyncUserInfoChange& user, LxSaveData& save) {
    bool bFilled = false;
    _tpl.ForEachDirty([&](FrozenAssets* ptr) {
        *user.add_frozens() = *ptr;
        *save.add_frozens() = *ptr;
        bFilled = true;
    });
    _tpl.ForEachRemoved([&](const uint64& aid) {
        user.add_del_frozens(aid);
        save.add_del_frozens(aid);
        bFilled = true;
    });
    _tpl.ClearChange();
    return bFilled;
}

int64 UserHelperFrozens::GetFrozenItems(int32 itemId) {
    int64 itemNum = 0;
    int64 now = sGameUtils->GetFakeTimeNow();
    set<int64> expires;
    _tpl.ForEach([&](FrozenAssets* ptr) {
        if( now >= ptr->expires() ) {
            // 应该要解冻了
            expires.insert(ptr->asset_id());
        }
        else {
            if( itemId == ptr->item().item_id() ) {
                itemNum += ptr->item().item_num();
            }
        }
    });
    for( auto & aid : expires ) {
        _tpl.Remove(aid);
    }
    return itemNum;
}

void UserHelperFrozens::Charged(const ItemPair& rhs) {
    int64 now = sGameUtils->GetFakeTimeNow();
    CheckExpired(now);
    m_pUser->PBIncAutoid(1);
    FrozenAssets fa;
    fa.set_asset_id(m_pUser->PBGetAutoid());
    fa.set_expires(now+JDATA->SystemConstPtr()->GetRechargeFrozenTime()*TIME_DAY);
    fa.set_reason(EAFR_ChargeTime);
    *fa.mutable_item() = rhs;
    _tpl.Set(fa.asset_id(), fa);
    _tpl.OnChange(fa.asset_id());
}

void UserHelperFrozens::CheckExpired(int64 now) {
    set<int64> expires;
    _tpl.ForEach([&](FrozenAssets* ptr) {
        if( now >= ptr->expires() ) {
            // 应该要解冻了
            expires.insert(ptr->asset_id());
        }
    });
    for( auto & aid : expires ) {
        _tpl.Remove(aid);
    }
}
