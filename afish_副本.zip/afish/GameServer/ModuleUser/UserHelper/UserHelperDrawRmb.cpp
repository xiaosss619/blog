#include "UserHelperDrawRmb.h"
#include "../LxUser.h"
#include "LxGameLogHelper.h"
#include "Dispatcher.h"
/*
按Coupon表的记录条数作为周期天数
每个周期内累计数值:
DrawRmbInfo:
    // 以下数据在周期内累计, 周期id不变, 不会发生变化
    act_draw_num
    act_draw_rmb_num

    // 以下为单次抽奖内5个红包的相关数据, 不进行抽奖重置不会改变
    act_reward_num
    act_rewards
    act_reward_show
*/

void UserHelperDrawRmb::Init(LxUser* pUser) {
    m_pUser = pUser;
    _tpl.Init();
}

int32 UserHelperDrawRmb::DrawOpen() {
    int32 actId = m_pUser->PBGetDrawRmbId();
    if( actId != 0 ) {
        return JDATA->ErrorCodePtr()->GetDrawRmbOpened();
    }
    tagJsonCouponDraw tagJson;
    if( !sGameUtils->GetCouponDrawData(tagJson) ) {
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    if( tagJson._LotteryList.size() != 5 || tagJson._Purchase.size() != 10 ) {
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    int32 iItemId = JDATA->SystemConstPtr()->GetCoupon();
    if( !m_pUser->CanChangeItem(iItemId, -tagJson._Coupon) ) {
        return JDATA->ErrorCodePtr()->GetDrawRmbLowCoupon();
    }

    int32 num = JDATA->CouponPtr()->Size();
    if( num == 0 ) {
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    actId = (m_pUser->PBGetLoginNum() / num ) + 1;
    auto ptr = _tpl.GetPtr(actId);
    if( ptr == nullptr ) {
        DrawRmbInfo info;
        info.set_act_id(actId);
        info.set_act_draw_num(0);
        info.set_act_draw_rmb_num(0);
        info.set_act_voucher_num(0);

        _tpl.Set(info.act_id(), info);
        ptr = _tpl.GetPtr(actId);
    }
    if( ptr == nullptr ) {
        LOGERROR("DRAWOPEN failed[%lu] unexpected", m_pUser->GetKey());
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    m_pUser->ItemChange(iItemId, -tagJson._Coupon, ELRD_DrawRmb, false);
    m_pUser->PBSetDrawRmbId(actId);
    // 如果已经有了,说明是本周期内多次开启的活动, 设置 act_reward_num act_rewards act_reward_show即可
    // act_draw_num act_draw_rmb_num 在周期内不会重置
    ptr->set_act_reward_num(0);
    // 开启次数+1
    ptr->set_act_draw_num(ptr->act_draw_num()+1);
    for( size_t i = 0 ; i < tagJson._LotteryList.size() ; ++i ) {
        sHLottery->GetSingleLotteryItem(tagJson._LotteryList[i], *ptr->add_act_rewards());
        ptr->add_act_reward_show(-1);// 5个红包初始化成未抽状态
    }
    do {
        int32 m0 = tagJson._PhoneVoucherMaxTimes - ptr->act_draw_rmb_num();
        int32 q0 = tagJson._DrawTimes - ptr->act_draw_num();
        // 计算有没有话费红包出现
        if( m0 <= 0 ) {
            // 本周期内已经抽中的话费红包数量超过上限, 则本不再出现话费红包
            break;
        }
        if( q0 <= 0 ) {
            // 由于本次开启在上面已经+1, 所以要 < 才不出现
            // 本周期内开启抽奖次数超过预期, 不再出现话费红包
            break;
        }
        if( tagJson._ChargeParam <= 0 ) {
            // 配置错误
            LOGERROR("DRAWRMB _ChargeParam failed[%d]", tagJson._ChargeParam);
            break;
        }
        double mu = m0*1.0/q0;
        double sigma = mu / 3.0f;
        int32 voucherNum = min(3, m_pUser->GetNormalDistributionNumber(mu, sigma));// 策划需求每次最多3个话费红包 2021/06/29 11:16
        if( voucherNum <= 0 ) {
            break;
        }
        int32 iVoucherItemID = JDATA->SystemConstPtr()->GetPhoneVoucherItemID();
        int32 t = (int32)m_pUser->PBGetTotalCharge();   // 总充值
        int32 F = JDATA->ItemPtr()->MiscByID(iVoucherItemID);       // 单次话费兑换需要消耗的话费券数量
        int32 k = tagJson._PhoneVoucherMax;     // 每个活动周期中话费券的最大产出量
        int32 n = tagJson._ChargeParam;         // 玩家话费产出的参数
        int32 a = tagJson._ChargeRate;          // 话费产出的比例参数
        float c = tagJson._RewardRate*1.0f/100.0f;

        double b = a*1.0/100.0f + t*1.0f/(t+n);
        list<int32> lstNum; // 话费红包数量
        int32 L0 = (int32)(k*b - ptr->act_voucher_num()); // 初始话费抽奖池总数
        int32 j0 = 0;
        for( int32 i = 0 ; i < voucherNum ; ++i ) {
            mu = L0*1.0/m0; // 话费券预期数量
            sigma = mu / 3.0f;
            j0 = m_pUser->GetNormalDistributionNumber(mu, sigma, c);
            if( j0 <= 1 ) {
                j0 = 1;
            }
            if( j0 >= F ) {
                // 防一下出现随机出极大值, 正常逻辑是不会出现的
                j0 = F;
            }
            L0 -= j0;
            lstNum.push_back(j0);
        }
        lstNum.sort();  // sort之后, 最大的在最后一个

        int32 fixRate = 1;
        ItemPair itemFix;
        if( sGameUtils->GetChannelItemRecycle(m_pUser->PBGetClientChannel(), iVoucherItemID, itemFix) ) {
            iVoucherItemID = itemFix.item_id();
            fixRate = itemFix.item_num();
        }
        if( voucherNum == 1 ) {
            int32 p1 = 250;
            int32 p2 = 400;
            if( tagJson._PositionSigma.size() == 2 && tagJson._PositionSigma[0] != 0 && tagJson._PositionSigma[1] != 0 ) {
                p1 = tagJson._PositionSigma[0];
                p2 = tagJson._PositionSigma[1];
            }
            int32 index = GetVoucherItemPosWhenOne(m0, p1, p2);
            ptr->mutable_act_rewards(index)->set_item_id(iVoucherItemID);
            int32 itemNum = lstNum.back()*fixRate;
            ptr->mutable_act_rewards(index)->set_item_change(itemNum);
            ptr->mutable_act_rewards(index)->set_item_num(itemNum);
            lstNum.pop_back();
        }
        else {
            // 红包数量大于1时，较小的红包在1-3号位随机，最大的红包固定在5号位。
            voucherNum--;
            ptr->mutable_act_rewards(4)->set_item_id(iVoucherItemID);
            int32 itemNum = lstNum.back()*fixRate;
            ptr->mutable_act_rewards(4)->set_item_change(itemNum);
            ptr->mutable_act_rewards(4)->set_item_num(itemNum);
            lstNum.pop_back();

            Roll posRoll;   // 话费红包位置随机
            posRoll.push_value(10, 1);
            posRoll.push_value(10, 2);
            posRoll.push_value(10, 3);
            posRoll.set_extra(true, voucherNum);
            for( int32 i = 0; i < voucherNum ; i++ ) {
                int32 index = posRoll.roll() - 1;
                ptr->mutable_act_rewards(index)->set_item_id(iVoucherItemID);
                int32 itemNum = lstNum.back()*fixRate;
                ptr->mutable_act_rewards(index)->set_item_change(itemNum);
                ptr->mutable_act_rewards(index)->set_item_num(itemNum);
                lstNum.pop_back();
            }
        }

    }while(0);
    _tpl.OnChange(actId);
    m_pUser->SendUserInfoChange(0);
    return JDATA->ErrorCodePtr()->GetSuccess();
}

int32 UserHelperDrawRmb::GetVoucherItemPosWhenOne(int32 m0, int32 sigma3, int32 sigma5) {
    double mu = 3;
    double sigma = 3*100.0f/sigma3;
    double minPos = 1.0f;
    if( m0 <= 10 ) {
        mu = 5;
        sigma = 5*100.0f/sigma5;
        minPos = 2.0f;
    }

    double n = m_pUser->GetNormalDistributionNumber(mu,sigma);
    double N = n;
    if( n > mu ) {
        N = n - mu;
    }
    return (int32)max(minPos, min(mu, N)) - 1;
}

int32 UserHelperDrawRmb::DrawClose() {
    int32 actId = m_pUser->PBGetDrawRmbId();
    if( actId == 0 ) {
        return JDATA->ErrorCodePtr()->GetDrawRmbNotValid();
    }
    auto ptr = _tpl.GetPtr(actId);
    if( ptr == nullptr ) {
        LOGERROR("CLOSE RMBDRAW failed[%lu][%d]", m_pUser->GetKey(), actId);
        return JDATA->ErrorCodePtr()->GetDrawRmbNotValid();
    }
    ptr->set_act_reward_num(0);
    ptr->clear_act_rewards();
    ptr->clear_act_reward_show();
    _tpl.OnChange(actId);
    m_pUser->PBSetDrawRmbId(0);
    m_pUser->SendUserInfoChange(0);
    return JDATA->ErrorCodePtr()->GetSuccess();
}

void UserHelperDrawRmb::GetDrawRmbClientInfo(DrawRmbClientInfo& info) {
    info.set_act_id(0);
    int32 actId = m_pUser->PBGetDrawRmbId();
    if( actId != 0 ) {
        auto ptr = _tpl.GetPtr(actId);
        if( ptr == nullptr ) {
            return;
        }
        info.set_act_id(actId);
        info.set_act_reward_num(ptr->act_reward_num());
        for( int32 i = 0; i < ptr->act_rewards_size(); i++ ) {
            auto item = info.add_act_rewards();
            *item = ptr->act_rewards(i);
            item->set_item_change(item->item_num());
        }
        for( int32 i = 0; i < ptr->act_reward_show_size(); i++ ) {
            info.add_act_reward_show(ptr->act_reward_show(i));
        }
    }
}

int32 UserHelperDrawRmb::DrawReward(const string& productId) {
    m_pUser->SendUserInfoChange(0); // 清理一下当前的变化, 保证本条的只针对抽奖, 用于客户端表现
    int32 actId = m_pUser->PBGetDrawRmbId();
    if( actId == 0 ) {
        return JDATA->ErrorCodePtr()->GetDrawRmbNotValid();
    }
    tagJsonCouponDraw tag;
    if( !sGameUtils->GetCouponDrawData(tag) ) {
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    auto ptr = _tpl.GetPtr(actId);
    if( ptr == nullptr ) {
        LOGERROR("CLOSE RMBDRAW failed[%lu][%d]", m_pUser->GetKey(), actId);
        return JDATA->ErrorCodePtr()->GetDrawRmbNotValid();
    }
    // 必须是最后一次, 才能是充值抽奖
    if( ptr->act_reward_num() != 4 ) {
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    // 找到最后一次对应的pos
    for( int32 i = 0 ; i < ptr->act_reward_show_size(); i++ ) {
        if( ptr->act_reward_show(i) == -1 ) {
            // 找到对应还没点过的位置, 认为是最后一次充值抽奖的位置
            return DrawReward(i, true);
        }
    }
    return JDATA->ErrorCodePtr()->GetSystemError();
}

int32 UserHelperDrawRmb::DrawReward(int32 pos, bool isCharge) {
    m_pUser->SendUserInfoChange(0); // 清理一下当前的变化, 保证本条的只针对抽奖, 用于客户端表现
    int32 actId = m_pUser->PBGetDrawRmbId();
    if( actId == 0 ) {
        return JDATA->ErrorCodePtr()->GetDrawRmbNotValid();
    }
    tagJsonCouponDraw tag;
    if( !sGameUtils->GetCouponDrawData(tag) ) {
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    auto ptr = _tpl.GetPtr(actId);
    if( ptr == nullptr ) {
        LOGERROR("CLOSE RMBDRAW failed[%lu][%d]", m_pUser->GetKey(), actId);
        return JDATA->ErrorCodePtr()->GetDrawRmbNotValid();
    }
    // 5个红包, 这里硬编码了
    if( pos < 0 || pos >= 5 ) {
        LOGERROR("user[%lu] draw pos[%d] failed", m_pUser->GetKey(), pos);
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    if( ptr->act_reward_show(pos) != -1 ) {
        return JDATA->ErrorCodePtr()->GetDrawRmbPosRewarded();
    }
    int32 rewardNum = ptr->act_reward_num();
    if( rewardNum >= 5 ) {
        return JDATA->ErrorCodePtr()->GetDrawRmbRewarded();
    }
    // _Purchase中22一对填5对, 第一次
    if( tag._Purchase.size() != 10 ) {
        LOGERROR("user[%lu] draw pos[%d] json error[%d]", m_pUser->GetKey(), pos, tag._Purchase.size());
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    switch(atoi(tag._Purchase[rewardNum*2].data())){
    case 0:
        // 免费, 直接领取
        if( isCharge ) {
            LOGERROR("user[%lu] draw[%d] pos[%d] when charge", m_pUser->GetKey(), rewardNum, pos);
            return JDATA->ErrorCodePtr()->GetSystemError();
        }
        break;
    case e_jsonCouponDrawPurchase_Diamond:
        if( isCharge ) {
            LOGERROR("user[%lu] draw[%d] pos[%d] when charge", m_pUser->GetKey(), rewardNum, pos);
            return JDATA->ErrorCodePtr()->GetSystemError();
        }
        // 扣钻石
        if( !m_pUser->ChangeDiamond(-atoi(tag._Purchase[rewardNum*2+1].data()), ELRD_DrawRmb, false) ) {
            return JDATA->ErrorCodePtr()->GetDiamondLow();
        }
        break;
    case e_jsonCouponDrawPurchase_RMB:
        // 充值领取, 只会在充值成功时发起
        if( !isCharge ) {
            LOGERROR("user[%lu] draw[%d] pos[%d] without charge", m_pUser->GetKey(), rewardNum, pos);
            return JDATA->ErrorCodePtr()->GetSystemError();
        }
        break;
    default:
        LOGERROR("user[%lu] draw pos[%d] json error[%s]", m_pUser->GetKey(), pos, tag._Purchase[pos*2].data());
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    ptr->set_act_reward_show(pos, rewardNum);
    ptr->set_act_reward_num(rewardNum+1);
    _tpl.OnChange(actId);
    int32 voucherNum = m_pUser->GetItemNum(JDATA->SystemConstPtr()->GetPhoneVoucherItemID());
    // 给奖励
    auto item = ptr->act_rewards(rewardNum);
    if( item.item_id() == JDATA->SystemConstPtr()->GetPhoneVoucherItemID()) {
        ptr->set_act_draw_rmb_num(ptr->act_draw_rmb_num()+1);
        ptr->set_act_voucher_num(ptr->act_voucher_num()+item.item_num());
    }
    m_pUser->ItemChange(item.item_id(), item.item_num(), ELRI_DrawRmb, false);
    m_pUser->SendUserInfoChange(EPIC_DrawRmb);
    {
        LOG_COUPON_DRAW(m_pUser,
                        voucherNum,
                        tag._DrawTimes - ptr->act_draw_num(),
                        tag._PhoneVoucherMaxTimes - ptr->act_draw_rmb_num(),
                        item.item_id(), item.item_num(),
                        rewardNum,
                        ptr->act_rewards(0).item_id(),ptr->act_rewards(0).item_num(),
                        ptr->act_rewards(1).item_id(),ptr->act_rewards(1).item_num(),
                        ptr->act_rewards(2).item_id(),ptr->act_rewards(2).item_num(),
                        ptr->act_rewards(3).item_id(),ptr->act_rewards(3).item_num(),
                        ptr->act_rewards(4).item_id(),ptr->act_rewards(4).item_num() );
    }
    return JDATA->ErrorCodePtr()->GetSuccess();
}

bool UserHelperDrawRmb::FillProto(SyncUserInfoChange& user, LxSaveData& save) {
    bool bFilled = false;
    _tpl.ForEachDirty([&](DrawRmbInfo* pDraw) {
        *save.add_draws() = *pDraw;
        bFilled = true;
    });
    _tpl.ClearChange();
    return bFilled;
}
