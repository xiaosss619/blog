#include "UserHelperHunt.h"
#include "../LxUser.h"
#include "ModuleHelper.h"
#include "Dispatcher.h"
#include "LxGameLogHelper.h"

void UserHelperHunt::Init(LxUser* pUser) {
    m_pUser = pUser;
    _tpl.Init();
}

void UserHelperHunt::InitHunt(const HuntBossSimple& qi) {
    _tpl.Set(qi.bossid(), qi);
}

void UserHelperHunt::InitOne(int64 guid, int32 bossIdx) {
    HuntBossSimple info;
    info.set_bossid(guid);
    info.set_index(bossIdx);
    info.set_cost(0);
    info.set_gold(0);
    info.set_item_gold(0);
    info.set_createtime(sGameUtils->GetFakeTimeNow());  // 由于某些bug导致OnHunted没触发, 可以用createtime来保一手过期
    info.set_endtime(0);
    info.set_sync_save(true);
    InitHunt(info);
    LOG_HUNT_BOSS_INFO(m_pUser, guid, bossIdx, 0, 0, 0, EHBS_created);
}

bool UserHelperHunt::FillProto(SyncUserInfoChange& user, LxSaveData& save) {
    bool bFilled = false;
    int64 now = sGameUtils->GetFakeTimeNow();
    _tpl.ForEachDirty([&](HuntBossSimple* ptr) {
        if( ptr->sync_client() ) {
            ptr->set_sync_client(false);
            *user.add_hunts() = *ptr;
            bFilled = true;
        }
        if( ptr->sync_save() ) {
            ptr->set_sync_save(false);
            *save.add_hunts() = *ptr;
            bFilled = true;
        }
        else {
            if( ptr->cost_time() > 0 && now - ptr->cost_time() > 3 ) {
                // 上面的没保存, 并且上次消耗的保存已经超过3秒了, 保存一次
                ptr->set_cost_time(0);
                *save.add_hunts() = *ptr;
                bFilled = true;
            }
        }
    });
    _tpl.ForEachRemoved([&](int64 guid){
        user.add_del_hunts(guid);
        save.add_del_hunts(guid);
        bFilled = true;
    });
    _tpl.ClearChange();
    return bFilled;
}

bool UserHelperHunt::Update(int64 now) {
    bool bHunted = false;
    set<int64> expired;
    _tpl.ForEach([&](HuntBossSimple* ptr) {
        if( (ptr->endtime() > 0 && ptr->endtime() <= now) ) {
            // 触发过围猎的, 且过期了, 就不再返还
            expired.insert(ptr->bossid());
            LOG_HUNT_BOSS_INFO(m_pUser, ptr->bossid(), ptr->index(), ptr->cost(), ptr->gold(), ptr->item_gold(), EHBS_expired);
        }
        if( ptr->endtime() == 0 ) {
            // 未触发过围猎, 并且在boss消失时也未得到处理的
            if( now >= ptr->createtime() + 6*TIME_MIN ) {
                // 6分钟的冗余 boss固定5分钟生存周期
                int64 fishMinRefund = JDATA->FishDataPtr()->SummonBossRefundMinByID(ptr->index());
                if( ptr->cost() > fishMinRefund*1000000 ) {
                    // 使用固定的100万炮倍作为领取门槛
                    int64 itemGold = ptr->cost()*sHTax->GetHunterRefundRate(m_pUser->GetUserGoldProperty(), ptr->index());
                    int64 gold = itemGold;
                    {
                        int32 div = JDATA->SystemConstPtr()->GetHunterRefundDivider();
                        if( div > 0 ) {
                            gold /= div;
                        }
                        gold = (gold/10000)*10000;
                    }
                    OnHunted(ptr->bossid(), gold, itemGold);
                    bHunted = true;
                }
                else {
                    expired.insert(ptr->bossid());
                    LOG_HUNT_BOSS_INFO(m_pUser, ptr->bossid(), ptr->index(), ptr->cost(), ptr->gold(), ptr->item_gold(), EHBS_missed);
                }
            }
        }
    });
    for( auto& bossid : expired ) {
        _tpl.Remove(bossid);
    }
    return bHunted || !expired.empty();
}

// 击杀boss
void UserHelperHunt::OnHuntKilled(int64 guid) {
    auto ptr = _tpl.GetPtr(guid);
    if( ptr == nullptr ) {
        return;
    }
    LOG_HUNT_BOSS_INFO(m_pUser, ptr->bossid(), ptr->index(), ptr->cost(), ptr->gold(), ptr->item_gold(), EHBS_killed);
    _tpl.Remove(guid);
}

// 领取围猎奖励
void UserHelperHunt::OnHuntRewarded(int64 guid, int32 type) {
    auto ptr = _tpl.GetPtr(guid);
    if( ptr == nullptr ) {
        return;
    }
    LOG_HUNT_BOSS_INFO(m_pUser, ptr->bossid(), ptr->index(), ptr->cost(), ptr->gold(), ptr->item_gold(), type);
    _tpl.Remove(guid);
}

// 领取围猎奖励
void UserHelperHunt::OnHuntMissed(int64 guid) {
    auto ptr = _tpl.GetPtr(guid);
    if( ptr == nullptr ) {
        return;
    }
    LOG_HUNT_BOSS_INFO(m_pUser, ptr->bossid(), ptr->index(), ptr->cost(), ptr->gold(), ptr->item_gold(), EHBS_missed);
    _tpl.Remove(guid);
}

void UserHelperHunt::OnHunted(int64 guid, int64 gold, int64 itemGold) {
    auto ptr = _tpl.GetPtr(guid);
    if( ptr == nullptr ) {
        return;
    }
    ptr->set_gold(gold);
    ptr->set_item_gold(itemGold);
    ptr->set_endtime(sGameUtils->GetFakeTimeNow() + JDATA->SystemConstPtr()->GetHunterRefundTime());
    ptr->set_sync_client(true);
    ptr->set_sync_save(true);
    LOG_HUNT_BOSS_INFO(m_pUser, ptr->bossid(), ptr->index(), ptr->cost(), ptr->gold(), ptr->item_gold(), EHBS_waiting);
    _tpl.OnChange(guid);
}

// boss消耗
void UserHelperHunt::OnHuntHitCost(int64 guid, int32 bossIdx, int64 cost) {
    auto ptr = _tpl.GetPtr(guid);
    if( ptr == nullptr ) {
        InitOne(guid, bossIdx);
        ptr = _tpl.GetPtr(guid);
    }
    ptr->set_cost(ptr->cost()+cost);
    ptr->set_cost_time(sGameUtils->GetFakeTimeNow());
    _tpl.OnChange(guid);
}

void UserHelperHunt::OnBroken() {
    _tpl.ForEach([&](HuntBossSimple* ptr) {
        if( ptr->endtime() == 0 ) {
            // 6分钟的冗余 boss固定5分钟生存周期
            int64 fishMinRefund = JDATA->FishDataPtr()->SummonBossRefundMinByID(ptr->index());
            if( ptr->cost() > fishMinRefund*1000000 ) {
                // 破产相当于把当前的消耗生成一个新的可领取的围猎, 发送给客户端, 让他领取
                int64 guid = RedisData::GenerateBossGuid();
                OnHuntHitCost(guid, ptr->index(), ptr->cost());
                // 使用固定的100万炮倍作为领取门槛
                int64 itemGold = ptr->cost()*sHTax->GetHunterRefundRate(m_pUser->GetUserGoldProperty(), ptr->index());
                int64 gold = itemGold;
                {
                    int32 div = JDATA->SystemConstPtr()->GetHunterRefundDivider();
                    if( div > 0 ) {
                        gold /= div;
                    }
                    gold = (gold/10000)*10000;
                }
                OnHunted(guid, gold, itemGold);
                // 把当前这只清空消耗, 可以继续累计
                ptr->set_cost(0);
                _tpl.OnChange(ptr->bossid());
            }
        }
    });
}

// 获取对应boss的消耗, 可累积
int64 UserHelperHunt::GetHuntHitCost(int64 guid) {
    auto ptr = _tpl.GetPtr(guid);
    if( ptr == nullptr ) {
        return 0;
    }
    return ptr->cost();
}

// 获取对应boss的奖励
bool UserHelperHunt::GetHuntBossData(int64 guid, HuntBossSimple& lhs) {
    return _tpl.Get(guid, lhs);
}
