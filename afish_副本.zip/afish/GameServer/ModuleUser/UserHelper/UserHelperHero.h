#pragma once

#include "UserHelperTpl.h"
#include "ModuleHelper/ModuleHelper.h"
#include "DataCache/RedisData.h"

class LxUser;
class UserHelperHero {
public:
    void Init(LxUser* pUser) {
        m_pUser = pUser;
        _tpl.Init();
    }
    void InitHero(const HeroInfo& ti) {
        _tpl.Set(ti.hero_index(), ti);
    }
    // 炮台升级
    int32 HeroLevelup(int32 idx);
    // 炮台充能
    int32 HeroStarCharge(int32 idx);
    // 炮台设置竞技场参与时间
    void HeroSetArenaTime(int32 idx);
    // 炮台设置休闲场场参与时间
    void HeroSetCasualTime(int32 idx);
    void HeroAllResetTime();
    int32 HeroGetPower(int32 idx);
    int32 HeroGetStarAttrValue(int32 attr);
    void HeroUpdatePower(int32 tid);
    int32 HeroChangeBullet(int32 tid, int32 itemId);
    // 给予一个指定等级和星级的炮台
    bool GiveHero(int32 tindex, int32 baseLevel, int32 baseStar, int32 giveType);
    bool FillProto(SyncUserInfoChange& user,LxSaveData& save) {
        bool bFilled = false;
        _tpl.ForEachDirty([&](HeroInfo* ptr) {
            *user.add_heros() = *ptr;
            *save.add_heros() = *ptr;
            bFilled = true;
        });
        _tpl.ClearChange();
        return bFilled;
    }
    void FillLoginResp(UserLoginResp& resp) {
        resp.clear_heros();
        _tpl.ForEach([&](HeroInfo* ptr) {
            *resp.add_heros() = *ptr;
        });
    }
    bool HasHero(int32 tIndex) {
        return _tpl.Has(tIndex);
    }
    void ActivateWing(int32 idx, int32 widx);
    void CheckPower();
    void ForEachHero(boost::function<void(int32)> func) {
        _tpl.ForEach([&](HeroInfo* ptr) {
            func(ptr->hero_index());
        });
    }
    int32 GetHeroLevel(int32 hid);
    int32 GetHeroStar(int32 hid);
private:
    void UpdatePower(HeroInfo* hero);
public:
    UserHelperTpl<int64, HeroInfo> _tpl;
    LxUser* m_pUser;
};
