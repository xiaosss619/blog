#pragma once

#include "UserHelperTpl.h"

class LxUser;
class UserHelperWing {
public:
    void Init(LxUser* pUser) {
        m_pUser = pUser;
        _tpl.Init();
    }
    void InitWing(const WingInfo& si) {
        _tpl.Set(si.wing_index(), si);
    }
    bool GiveWing(int32 idx, int32 lv, int32 reason);
    int32 WingUpgrade(int32 idx, const ItemPair& item, WingUpgradeResp& msg);
    void WingUpdatePower(int32 wid);
    int32 WingGetPower(int32 wid);

    bool FillProto(SyncUserInfoChange& user,LxSaveData& save) {
        bool bFilled = false;
        _tpl.ForEachDirty([&](WingInfo* ptr) {
            *user.add_wings() = *ptr;
            *save.add_wings() = *ptr;
            bFilled = true;
        });
        _tpl.ClearChange();
        return bFilled;
    }
    void FillLoginResp(UserLoginResp& resp) {
        resp.clear_wings();
        _tpl.ForEach([&](WingInfo* ptr) {
            *resp.add_wings() = *ptr;
        });
    }
    int32 GetWingAttr(int idx, int32 attr);
    void CheckPower();
private:
    int32 GetItemSwingUpgradeRate(int32 iItemId);
public:
    UserHelperTpl<int64, WingInfo> _tpl;
    LxUser* m_pUser;
};
