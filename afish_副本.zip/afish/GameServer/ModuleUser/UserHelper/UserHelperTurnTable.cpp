#include "UserHelperTurnTable.h"
#include "../LxUser.h"
#include "ModuleHelper.h"
#include "Dispatcher.h"
#include "LxGameLogHelper.h"

void UserHelperTurnTable::Init(LxUser* pUser) {
    m_pUser = pUser;
    _tpl.Init();
}

void UserHelperTurnTable::InitTurnTable(const TurnTableInfo& qi) {
    _tpl.Set(qi.tt_id(), qi);
}

bool UserHelperTurnTable::FillProto(SyncUserInfoChange& user,LxSaveData& save) {
    bool bFilled = false;
    _tpl.ForEachDirty([&](TurnTableInfo* ptr) {
        *user.add_tts() = *ptr;
        *save.add_tts() = *ptr;
        bFilled = true;
    });
    _tpl.ClearChange();
    return bFilled;
}

void UserHelperTurnTable::TurnTableInit(int32 ttid) {
    auto ptr = _tpl.GetPtr(ttid);
    if( ptr != nullptr ) {
        // 已经有了,说明初始化过了
        return;
    }
    TurnTableInfo info;
    info.set_tt_id(ttid);
    info.set_tt_total_num(0);
    info.set_tt_num(0);
    info.set_tt_ten_num(0);
    info.set_tt_flag(0);
    _tpl.Set(ttid, info);
    _tpl.OnChange(ttid);
    m_pUser->SendUserInfoChange(0);
}

int32 UserHelperTurnTable::TurnTableBonus(int32 ttid, int32 num, int32 flag, int32 lootId) {
    auto ptr = _tpl.GetPtr(ttid);
    if( ptr == nullptr ) {
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    if( ptr->tt_flag() & flag ) {
        return JDATA->ErrorCodePtr()->GetTurntableBonusRewarded();
    }
    if( ptr->tt_total_num() < num ) {
        return JDATA->ErrorCodePtr()->GetTurntableBonusNumLow();
    }
    ptr->set_tt_flag( ptr->tt_flag() | flag );
    _tpl.OnChange(ttid);
    m_pUser->GiveLoot(lootId, ELRI_TurntableBonus, false);
    m_pUser->SendUserInfoChange(EPIC_TurntableBonus);
    return JDATA->ErrorCodePtr()->GetSuccess();
}

int32 UserHelperTurnTable::TurnTablePlay(int32 ttid, int32 num, TurntablePlayResp& msg) {
    tagJsonTurnTable tag;
    if( !JDATA->TurnTablePtr()->ByID(ttid, tag) ) {
        return JDATA->ErrorCodePtr()->GetTurntableExpired();
    }
    auto ptr = _tpl.GetPtr(ttid);
    if( ptr == nullptr ) {
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    if( tag._VIPNeed != 0 ) {
        // =0时不限制次数
        int32 maxPlay = tag._DailyFreeTime;// 每日可以转的最大次数
        for( size_t i = 0; i < tag._VIPTime.size(); i+=2 ) {
            if( m_pUser->PBGetUserVip() == tag._VIPTime[i] ) {
                maxPlay += tag._VIPTime[i+1];
                break;
            }
        }
        if( ptr->tt_num() + ptr->tt_ten_num()*10 + num >= maxPlay ) {
            return JDATA->ErrorCodePtr()->GetTurntableNumLow();
        }
    }
    int32 logDec = ELRD_TurntableOnce;
    int32 logInc = ELRI_TurntableOnce;
    int32 reason = EPIC_TurntableOnce;
    // 先判断vip次数
    int64 cost = tag._OncePrice;
    if( num == 1 ) {
        // 单次的
        if( ptr->tt_num() < tag._DailyFreeTime ) {
            cost = 0;
        }
    }
    else {
        logDec = ELRD_TurntableTen;
        logInc = ELRI_TurntableTen;
        reason = EPIC_TurntableTen;
        cost = tag._TenPrice;
    }
    if( tag._PriceItem == JDATA->SystemConstPtr()->GetGold() ) {
        if( !m_pUser->ChangeGold(-cost, logDec) ) {
            return JDATA->ErrorCodePtr()->GetGoldLow();
        }
    }
    else if( tag._PriceItem == JDATA->SystemConstPtr()->GetDiamond() ) {
        if( !m_pUser->ChangeDiamond(-cost, logDec, false) ) {
            return JDATA->ErrorCodePtr()->GetDiamondLow();
        }
    }
    else {
        if( !m_pUser->ItemChange(tag._PriceItem, -cost, logDec, false) ) {
            return JDATA->ErrorCodePtr()->GetItemUseNumLow();
        }
    }
    for( int32 i = 0 ; i < num ; i++ ) {
        auto result = sHTTable->PlayTurntable(ttid, cost/num);
        int32 idx = TUPLE0(result);
        int32 lootId = TUPLE1(result);
        if( idx != -1 ) {
            msg.add_loots(idx);
            m_pUser->GiveLoot(lootId, logInc, false);
        }
    }
    if( num == 1 ) {
        ptr->set_tt_num(ptr->tt_num()+1);
    }
    else {
        ptr->set_tt_ten_num(ptr->tt_ten_num()+1);
    }
    ptr->set_tt_total_num(ptr->tt_total_num()+num);
    _tpl.OnChange(ttid);
    m_pUser->SendUserInfoChange(reason);
    LOG_USER_TURNTABLE(m_pUser,
                        ttid,
                        ptr->tt_num() + ptr->tt_ten_num()*10,
                        ptr->tt_total_num(),
                        num);
    return JDATA->ErrorCodePtr()->GetSuccess();
}

void UserHelperTurnTable::CrossDay() {
    vector<int32> vec;
    _tpl.ForEach([&](TurnTableInfo* ptr){
        ptr->set_tt_num(0);
        ptr->set_tt_ten_num(0);
        vec.push_back(ptr->tt_id());
    });
    for( size_t i = 0; i < vec.size(); i++ ) {
        _tpl.OnChange(vec[i]);
    }
}

