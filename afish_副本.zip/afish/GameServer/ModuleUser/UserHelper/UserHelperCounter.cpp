#include "UserHelperCounter.h"
#include "../LxUser.h"
#include "ModuleHelper.h"
#include "Dispatcher.h"
#include "LxGameLogHelper.h"

void UserHelperCounter::Init(LxUser* pUser) {
    m_pUser = pUser;
    _tpl.Init();
}

void UserHelperCounter::InitCounter(const DayCounterInfo& info) {
    _tpl.Set(info.type(), info);
}

void UserHelperCounter::InitNewbie() {
    for( int32 type = e_jsonGeneralTaskDynamicTarget_start ; type < e_jsonGeneralTaskDynamicTarget_end ; type++ ) {
        if( _tpl.Has(type) ) {
            continue;
        }
        DayCounterInfo info;
        info.set_type(type);
        info.set_today(0);
        info.set_yesterday(0);
        _tpl.Set(info.type(), info);
        _tpl.OnChange(type);
    }
}

bool UserHelperCounter::FillProto(LxSaveData& save) {
    bool bFilled = false;
    _tpl.ForEachDirty([&](DayCounterInfo* ptr) {
        *save.add_counters() = *ptr;
        bFilled = true;
    });
    _tpl.ClearChange();
    return bFilled;
}

void UserHelperCounter::CrossDay() {
    _tpl.ForEach([&](DayCounterInfo* ptr){
        ptr->set_yesterday(ptr->today());
        ptr->set_today(0);
        _tpl.OnChange(ptr->type());
    });
}

void UserHelperCounter::Add(int32 type, int32 num) {
    auto ptr = _tpl.GetPtr(type);
    if( ptr == nullptr ) {
        return;
    }
    ptr->set_today(ptr->today()+num);
    _tpl.OnChange(ptr->type());
}
