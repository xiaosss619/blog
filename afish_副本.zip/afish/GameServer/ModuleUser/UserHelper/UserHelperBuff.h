#pragma once

#include "UserHelperTpl.h"

class LxUser;
class UserHelperBuff {
public:
    void Init(LxUser* pUser);
    void InitBuff(const BuffInfo& qi);

    void Activate(int32 buffId);
    int32 GetItemExtraDropRate(int32 itemId, int64 now);

    bool FillProto(SyncUserInfoChange& user,LxSaveData& save);
    void FillLoginResp(UserLoginResp& resp) {
        resp.clear_buffs();
        _tpl.ForEach([&](BuffInfo* ptr) {
            *resp.add_buffs() = *ptr;
        });
    }
public:
    UserHelperTpl<int32, BuffInfo> _tpl;
    LxUser* m_pUser;
};
