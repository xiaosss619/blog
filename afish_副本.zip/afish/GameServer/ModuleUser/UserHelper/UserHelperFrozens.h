#pragma once

#include "UserHelperTpl.h"

class LxUser;
class UserHelperFrozens {
public:
    void Init(LxUser* pUser);
    void InitAssets(const FrozenAssets& qi);

    bool FillProto(SyncUserInfoChange& user, LxSaveData& save);
    void FillLoginResp(UserLoginResp& resp) {
        resp.clear_frozens();
        _tpl.ForEach([&](FrozenAssets* ptr) {
            *resp.add_frozens() = *ptr;
        });
    }
    void Charged(const ItemPair& rhs);
    int64 GetFrozenItems(int32 itemId);
    void CheckExpired(int64 now);
public:
    UserHelperTpl<int64, FrozenAssets> _tpl;
    LxUser* m_pUser;
};
