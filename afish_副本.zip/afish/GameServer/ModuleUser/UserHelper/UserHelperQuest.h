#pragma once

#include "UserHelperTpl.h"

class LxUser;
class UserHelperQuest {
public:
    void Init(LxUser* pUser);
    void InitQuest(const QuestInfo& qi);
    bool GiveQuest(int32 qid);
    int32 QuestReward(int32 qid);
    bool IsNewbieEnd();
    // 只是不想遍历两次,这两个东西里的内容应该是一样的,一个用来检测,一个用来rand
    void RandQuest(const set<int32>& qset, const vector<int64>& qvec);
    bool FillProto(SyncUserInfoChange& user,LxSaveData& save);
    void FillLoginResp(UserLoginResp& resp) {
        resp.clear_quests();
        _tpl.ForEach([&](QuestInfo* ptr) {
            if( ptr->quest_status() != EQS_Rewarded ) {
                *resp.add_quests() = *ptr;
            }
        });
    }
    void OnQuestFishKilled(int32 findex, const set<int32>& setTaskGroup, int64 gold);
    void OnUseSkill(int32 skillId);
    void OnUseSkillType(int32 skillType);
    void OnUserLevelup(int32 level);
    void OnChangeTurretRate();
    void OnGetLevelGift(int32 level);
    void OnCurrentTurretStar(int32 star);
private:
    bool GenerateQuestInfo(int32 index, QuestInfo& lhs);
public:
    UserHelperTpl<int32, QuestInfo> _tpl;
    set<int32> m_setCompleted;
    LxUser* m_pUser;
};
