#pragma once

#include "UserHelperTpl.h"

class LxUser;
class UserHelperMarket {
public:
    void Init(LxUser* pUser);
    void InitMarket(const UserMarket& rhs);
    void RandMarket(bool bNotifyClient);
    bool FillProto(SyncUserInfoChange& user,LxSaveData& save);
    int32 Buy(int32 pid);
public:
    UserHelperTpl<int32, UserMarket> _tpl;
    LxUser* m_pUser;
};
