#include "UserHelperMarket.h"
#include "../LxUser.h"
#include "ModuleHelper.h"
#include "Dispatcher.h"
#include "LxGameLogHelper.h"

void UserHelperMarket::Init(LxUser* pUser) {
    m_pUser = pUser;
    _tpl.Init();
}

void UserHelperMarket::InitMarket(const UserMarket& rhs) {
    _tpl.Set(rhs.product_id(), rhs);
}

void UserHelperMarket::RandMarket(bool bNotifyClient) {
    Roll roll;
    if( !sHMarket->GetMarket(m_pUser->PBGetUserVip(), roll) || roll.times() == 0 ) {
        LOGERROR("MARKET failed[%lu] [%d] times[%d]", m_pUser->GetKey(), m_pUser->PBGetUserVip(), roll.times());
        return;
    }
    // 清空所有,重新初始化
    vector<int32> vec;
    _tpl.ForEach([&](UserMarket* ptr) {
        vec.push_back(ptr->product_id());
    });
    for( size_t i = 0; i < vec.size() ; ++i ) {
        _tpl.Remove(vec[i]);
    }
    if( bNotifyClient ) {
        // 先发送一个消息回去让客户端清空
        m_pUser->SendUserInfoChange(EPIC_RandMarket);
    }

    for( int32 i = 0; i < roll.times(); ++i ) {
        UserMarket mkt;
        mkt.set_product_id(roll.roll());
        mkt.set_bought(0);
        _tpl.Set(mkt.product_id(), mkt);
        _tpl.OnChange(mkt.product_id());
    }
    if( bNotifyClient ) {
        m_pUser->SendUserInfoChange(EPIC_RandMarket);
    }
}

bool UserHelperMarket::FillProto(SyncUserInfoChange& user,LxSaveData& save) {
    bool bFilled = false;
    _tpl.ForEachDirty([&](UserMarket* ptr) {
        *user.add_markets() = *ptr;
        *save.add_markets() = *ptr;
        bFilled = true;
    });
    _tpl.ForEachRemoved([&](const int32& pid) {
        user.add_del_markets(pid);
        save.add_del_markets(pid);
        bFilled = true;
    });
    _tpl.ClearChange();
    return bFilled;
}

int32 UserHelperMarket::Buy(int32 pid) {
    auto ptr = _tpl.GetPtr(pid);
    if( ptr == nullptr ) {
        return JDATA->ErrorCodePtr()->GetBuyMarketIllegal();
    }
    if( ptr->bought() != 0 ) {
        return JDATA->ErrorCodePtr()->GetBuyMarketBought();
    }
    tagJsonMarket mkt;
    if( !JDATA->MarketPtr()->ByID(pid, mkt) ) {
        return JDATA->ErrorCodePtr()->GetBuyMarketIllegal();
    }
    if( mkt._Diamond > 0 && !m_pUser->CanChangeDiamond(-mkt._Diamond) ) {
        return JDATA->ErrorCodePtr()->GetDiamondLow();
    }
    if( mkt._Gold > 0 && !m_pUser->CanChangeGold(-mkt._Gold) ) {
        return JDATA->ErrorCodePtr()->GetGoldLow();
    }
    m_pUser->ChangeDiamond(-mkt._Diamond, ELRD_BuyMarket, false);
    m_pUser->ChangeGold(-mkt._Gold, ELRD_BuyMarket);
    ptr->set_bought(1);
    m_pUser->ItemChange(mkt._ItemId, mkt._ItemNum, ELRI_BuyMarket, false);
    _tpl.OnChange(pid);
    m_pUser->GTaskInc(e_jsonGeneralTaskCondition_Market_Purchase, 0, 1);
    return JDATA->ErrorCodePtr()->GetSuccess();
}
