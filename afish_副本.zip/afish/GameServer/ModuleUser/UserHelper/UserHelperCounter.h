#pragma once

#include "UserHelperTpl.h"

class LxUser;
class UserHelperCounter {
public:
    void Init(LxUser* pUser);
    void InitCounter(const DayCounterInfo& info);
    void InitNewbie();

    void Add(int32 type, int32 num);
    int32 GetYesterday(int32 type) {
        auto ptr = _tpl.GetPtr(type);
        if( ptr == nullptr ) {
            return 0;
        }
        return ptr->yesterday();
    }

    bool FillProto(LxSaveData& save);
    void CrossDay();
public:
    UserHelperTpl<int32, DayCounterInfo> _tpl;
    LxUser* m_pUser;
};
