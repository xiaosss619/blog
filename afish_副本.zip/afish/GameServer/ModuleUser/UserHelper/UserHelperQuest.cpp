#include "UserHelperQuest.h"
#include "../LxUser.h"
#include "ModuleHelper.h"
#include "Dispatcher.h"
#include "LxGameLogHelper.h"

void UserHelperQuest::Init(LxUser* pUser) {
    m_pUser = pUser;
    _tpl.Init();
    m_setCompleted.clear();
}

void UserHelperQuest::InitQuest(const QuestInfo& qi) {
    if( qi.quest_status() == EQS_Rewarded ) {
        m_setCompleted.insert( qi.quest_id() );
    }
    else {
        _tpl.Set(qi.quest_id(), qi);
    }
}

bool UserHelperQuest::GenerateQuestInfo(int32 index, QuestInfo& lhs) {
    tagJsonQuest tag;
    if( !JDATA->QuestPtr()->ByID(index, tag) ) {
        LOGERROR("unknow quest id[%d]", index);
        return false;
    }
    lhs.set_quest_id(index);
    lhs.set_quest_status(EQS_Accepted);
    lhs.set_quest_target_num(0);
    lhs.set_quest_target_need(tag._ConditionNum);
    return true;
}

bool UserHelperQuest::FillProto(SyncUserInfoChange& user,LxSaveData& save) {
    bool bFilled = false;
    _tpl.ForEachDirty([&](QuestInfo* ptr) {
        *user.add_quests() = *ptr;
        *save.add_quests() = *ptr;
        bFilled = true;
    });
    _tpl.ForEachRemoved([&](const int64& qid) {
        user.add_del_quests(qid);
        save.add_del_quests(qid);
        bFilled = true;
    });
    _tpl.ClearChange();
    return bFilled;
}

bool UserHelperQuest::GiveQuest(int32 qid) {
    // 已经完成过的任务不能接
    if( m_setCompleted.find(qid) != m_setCompleted.end() ) {
        return false;
    }
    QuestInfo qi;
    if( !GenerateQuestInfo(qid, qi) ) {
        LOGERROR("failed to give quest[%d]", qid);
        return false;
    }
    tagJsonQuest tag;
    if( !JDATA->QuestPtr()->ByID(qid, tag) ) {
        LOGERROR("failed to give quest[%d]", qid);
        return false;
    }

    switch( tag._Condition ) {
    case e_jsonQuestCondition_UserLevel:
        qi.set_quest_target_num(m_pUser->PBGetUserLevel());
        break;
    case e_jsonQuestCondition_TurretStar:
        if( m_pUser->GetCurHeroStar() >= tag._Param ) {
            qi.set_quest_target_num(qi.quest_target_need());
        }
        break;
    case e_jsonQuestCondition_Swing:
        if( m_pUser->GetCurWingIndex() > 0 ) {
            qi.set_quest_target_num(qi.quest_target_need());
        }
        break;
    case e_jsonQuestCondition_LevelPack:
        if( m_pUser->PBGetUserLevelReward() >= tag._Param ) {
            qi.set_quest_target_num(qi.quest_target_need());
        }
        break;
    default:
        break;
    }
    if( qi.quest_target_num() >= qi.quest_target_need() ) {
        qi.set_quest_status(EQS_Finished);
    }
    _tpl.Set(qid, qi);
    _tpl.OnChange(qid);

    LOG_QUEST(m_pUser, qid, qi.quest_status());
    return true;
}

bool UserHelperQuest::IsNewbieEnd() {
    for( auto & qid : m_setCompleted ) {
        if( JDATA->QuestPtr()->NewbieEndMarkByID(qid) != 0) {
            return true;
        }
    }
    return false;
}

void UserHelperQuest::RandQuest(const set<int32>& qset, const vector<int64>& qvec) {
    // 如果上一个渔场任务已经领取过奖励,则会在领奖时从任务列表中直接删除,这里只需要判定身上有没有对应房间任务列表中的任务即可
    bool bGiveQuest = true;
    int32 qidToDelete = 0;
    // 只会从渔场里发起,所以这里只要验证下在不在qset,就能确定是不是渔场任务
    _tpl.ForEachWithBreak([&](QuestInfo* ptr){
        tagJsonQuest tag;
        if( !JDATA->QuestPtr()->ByID(ptr->quest_id(), tag) ) {
            LOGERROR("user has unknown qid[%d]", ptr->quest_id());
            return false;
        }
        if( qset.find(ptr->quest_id()) != qset.end() ) {
            // 身上有一个渔场任务,但是尚未完成,说明进的还是上次的渔场,这里保持任务即可
            bGiveQuest = false;
            qidToDelete = 0;
            return true;
        }
        else {
            if( tag._Type == e_jsonQuestType_RandomQuest ) {
                // 身上的任务属于渔场任务,但是不在当前渔场的任务列表内,说明换房间了
                // 直接删除对应任务,然后给新的即可
                bGiveQuest = true;
                qidToDelete = ptr->quest_id();
                return true;
            }
            return false;
        }
    });
    if( qidToDelete != 0 ) {
        _tpl.Remove(qidToDelete);
    }
    if( bGiveQuest && qvec.size() > 0 ) {
        int32 newqid = (int32)(qvec[GlobalUtils::GetRandNumber(0,qvec.size()-1)]);
        GiveQuest(newqid);
    }
}

int32 UserHelperQuest::QuestReward(int32 qid) {
    tagJsonQuest tag;
    if( !JDATA->QuestPtr()->ByID(qid, tag) ) {
        LOGERROR("user has unknown qid[%d]", qid);
        return JDATA->ErrorCodePtr()->GetQuestRewardUnknown();
    }
    auto ptr = _tpl.GetPtr(qid);
    if( ptr == nullptr ) {
        return JDATA->ErrorCodePtr()->GetQuestRewardNoQuest();
    }
    if( ptr->quest_status() != EQS_Finished ) {
        return JDATA->ErrorCodePtr()->GetQuestRewardStatusFailed();
    }
    ptr->set_quest_status(EQS_Rewarded);
    m_pUser->GiveLoot(tag._RewardLoot, ELRI_FishQuest, false);
    LOG_QUEST(m_pUser, qid, ptr->quest_status());

    if( tag._Type == e_jsonQuestType_RandomQuest ) {
        // 如果是渔场内任务,完成了给完奖励就直接删除
        _tpl.Remove(qid);
        CALL_THREAD_SIMPLE(m_pUser, LxRandQuest);
    }
    else{
        // 如果是新手主线终结任务, 设置一下终结标记
        if( tag._NewbieEndMark != 0 ) {
            m_pUser->SetNewbieEnd();
        }
        m_setCompleted.insert(qid);
        _tpl.OnChange(qid);
        int32 postQuestId = sGameUtils->GetPostQuestId(m_pUser->PBGetClientChannel(), qid);
        if( postQuestId == 0 ) {
            postQuestId = tag._PostQuestID;
        }
        // 这里只根据是否有后续来判断是否要给予新任务
        if( postQuestId != 0 ) {
            LxGiveQuest pkg;
            pkg.set_quest_id(postQuestId);
            CALL_THREAD(m_pUser, LxGiveQuest, pkg);
        }
        else {
            // 如果无后续,判断一下
            if( m_pUser->PBGetFishTableId() != 0 ) {
                // 在渔场内,并且完成主线的最后一个任务
                if( m_pUser->IsNewbieEnd() ) {
                    CALL_THREAD_SIMPLE(m_pUser, LxRandQuest);
                }
            }
        }
    }
    if( tag._RedEnvelope.size() == 2 ) {
        m_pUser->StartNewbieFee(tag._RedEnvelope[0], tag._RedEnvelope[1]);
    }
    return JDATA->ErrorCodePtr()->GetSuccess();
}

void UserHelperQuest::OnQuestFishKilled(int32 findex, const set<int32>& setTaskGroup, int64 gold) {
    _tpl.ForEach([&](QuestInfo* ptr) {
        if( ptr->quest_status() != EQS_Accepted ) {
            // 不是正在进行中的任务不需要检查
            return;
        }
        tagJsonQuest tag;
        if( !JDATA->QuestPtr()->ByID(ptr->quest_id(), tag) ) {
            LOGERROR("user has unknown qid[%d]", ptr->quest_id());
            return;
        }
        tagJsonFishData fishData;
        if( !JDATA->FishDataPtr()->ByID(findex, fishData) ) {
            LOGERROR("unknown fish[%d]", findex);
            return;
        }
        bool isDirty = false;
        switch( tag._Condition ) {
        case e_jsonQuestCondition_KillFishID:
            if( tag._Param == 0 || findex == tag._Param ) {
                isDirty = true;
                ptr->set_quest_target_num(ptr->quest_target_num()+1);
            }
            break;
        case e_jsonQuestCondition_GetGoldByFishing:
            {
                isDirty = true;
                ptr->set_quest_target_num(ptr->quest_target_num()+gold);
            }
            break;
        case e_jsonQuestCondition_KillGroupFish:
            if( setTaskGroup.find(tag._Param) != setTaskGroup.end() ) {
                isDirty = true;
                ptr->set_quest_target_num(ptr->quest_target_num()+1);
            }
            break;
        default:
            return;
        }
        if( isDirty ) {
            if( ptr->quest_target_num() >= ptr->quest_target_need() ) {
                ptr->set_quest_target_num(ptr->quest_target_need());
                ptr->set_quest_status(EQS_Finished);
            }
            _tpl.OnChange(ptr->quest_id());
        }
    });
}

void UserHelperQuest::OnUseSkill(int32 skillId) {
    _tpl.ForEach([&](QuestInfo* ptr) {
        if( ptr->quest_status() != EQS_Accepted ) {
            // 不是正在进行中的任务不需要检查
            return;
        }
        tagJsonQuest tag;
        if( !JDATA->QuestPtr()->ByID(ptr->quest_id(), tag) ) {
            LOGERROR("user has unknown qid[%d]", ptr->quest_id());
            return;
        }
        if( tag._Condition != e_jsonQuestCondition_UseSkill ) {
            return;
        }
        if( tag._Param == skillId ) {
            ptr->set_quest_target_num(ptr->quest_target_num()+1);
            if( ptr->quest_target_num() >= ptr->quest_target_need() ) {
                ptr->set_quest_target_num(ptr->quest_target_need());
                ptr->set_quest_status(EQS_Finished);
            }
            _tpl.OnChange(ptr->quest_id());
        }
    });
}

void UserHelperQuest::OnUseSkillType(int32 skillType) {
    _tpl.ForEach([&](QuestInfo* ptr) {
        if( ptr->quest_status() != EQS_Accepted ) {
            // 不是正在进行中的任务不需要检查
            return;
        }
        tagJsonQuest tag;
        if( !JDATA->QuestPtr()->ByID(ptr->quest_id(), tag) ) {
            LOGERROR("user has unknown qid[%d]", ptr->quest_id());
            return;
        }
        if( tag._Condition != e_jsonQuestCondition_UseSkillType ) {
            return;
        }
        if( tag._Param == skillType ) {
            ptr->set_quest_target_num(ptr->quest_target_num()+1);
            if( ptr->quest_target_num() >= ptr->quest_target_need() ) {
                ptr->set_quest_target_num(ptr->quest_target_need());
                ptr->set_quest_status(EQS_Finished);
            }
            _tpl.OnChange(ptr->quest_id());
        }
    });
}

void UserHelperQuest::OnChangeTurretRate() {
    _tpl.ForEach([&](QuestInfo* ptr) {
        if( ptr->quest_status() != EQS_Accepted ) {
            // 不是正在进行中的任务不需要检查
            return;
        }
        tagJsonQuest tag;
        if( !JDATA->QuestPtr()->ByID(ptr->quest_id(), tag) ) {
            LOGERROR("user has unknown qid[%d]", ptr->quest_id());
            return;
        }
        if( tag._Condition != e_jsonQuestCondition_TurretTimes ) {
            return;
        }
        ptr->set_quest_target_num(ptr->quest_target_num()+1);
        if( ptr->quest_target_num() >= ptr->quest_target_need() ) {
            ptr->set_quest_target_num(ptr->quest_target_need());
            ptr->set_quest_status(EQS_Finished);
        }
        _tpl.OnChange(ptr->quest_id());
    });
}

void UserHelperQuest::OnGetLevelGift(int32 level) {
    _tpl.ForEach([&](QuestInfo* ptr) {
        if( ptr->quest_status() != EQS_Accepted ) {
            // 不是正在进行中的任务不需要检查
            return;
        }
        tagJsonQuest tag;
        if( !JDATA->QuestPtr()->ByID(ptr->quest_id(), tag) ) {
            LOGERROR("user has unknown qid[%d]", ptr->quest_id());
            return;
        }
        if( tag._Condition != e_jsonQuestCondition_LevelPack ) {
            return;
        }
        if( tag._Param == level ) {
            ptr->set_quest_target_num(ptr->quest_target_num()+1);
            if( ptr->quest_target_num() >= ptr->quest_target_need() ) {
                ptr->set_quest_target_num(ptr->quest_target_need());
                ptr->set_quest_status(EQS_Finished);
            }
            _tpl.OnChange(ptr->quest_id());
        }
    });
}

void UserHelperQuest::OnUserLevelup(int32 level) {
    _tpl.ForEach([&](QuestInfo* ptr) {
        if( ptr->quest_status() != EQS_Accepted ) {
            // 不是正在进行中的任务不需要检查
            return;
        }
        int32 cond = JDATA->QuestPtr()->ConditionByID(ptr->quest_id());
        if( cond != e_jsonQuestCondition_UserLevel ) {
            return;
        }
        ptr->set_quest_target_num(level);
        if( ptr->quest_target_num() >= ptr->quest_target_need() ) {
            ptr->set_quest_status(EQS_Finished);
        }
        _tpl.OnChange(ptr->quest_id());
    });
}

void UserHelperQuest::OnCurrentTurretStar(int32 star) {
    _tpl.ForEach([&](QuestInfo* ptr) {
        if( ptr->quest_status() != EQS_Accepted ) {
            // 不是正在进行中的任务不需要检查
            return;
        }
        tagJsonQuest tag;
        if( !JDATA->QuestPtr()->ByID(ptr->quest_id(), tag) ) {
            LOGERROR("user has unknown qid[%d]", ptr->quest_id());
            return;
        }
        if( tag._Condition != e_jsonQuestCondition_TurretStar ) {
            return;
        }
        if( star < tag._Param ) {
            return;
        }
        ptr->set_quest_target_num(ptr->quest_target_num()+1);
        if( ptr->quest_target_num() >= ptr->quest_target_need() ) {
            ptr->set_quest_target_num(ptr->quest_target_need());
            ptr->set_quest_status(EQS_Finished);
        }
        _tpl.OnChange(ptr->quest_id());
    });
}
