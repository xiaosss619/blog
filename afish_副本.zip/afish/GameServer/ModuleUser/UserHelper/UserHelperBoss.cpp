#include "UserHelperBoss.h"
#include "../LxUser.h"
#include "ModuleHelper.h"
#include "Dispatcher.h"
#include "LxGameLogHelper.h"

void UserHelperBoss::Init(LxUser* pUser) {
    m_pUser = pUser;
    _tpl.Init();
}

void UserHelperBoss::InitBoss(const BossInfo& qi) {
    _tpl.Set(qi.boss_id(), qi);
}

void UserHelperBoss::InitOne(int32 bossIdx) {
    BossInfo info;
    info.set_boss_id(bossIdx);
    info.set_summoned(0);
    info.set_killed(0);
    info.set_hunted(0);
    InitBoss(info);
}

bool UserHelperBoss::FillProto(LxSaveData& save) {
    bool bFilled = false;
    _tpl.ForEachDirty([&](BossInfo* ptr) {
        *save.add_boss() = *ptr;
        bFilled = true;
    });
    _tpl.ClearChange();
    return bFilled;
}

bool UserHelperBoss::IsBossBonused(int32 bossIdx) {
    auto ptr = _tpl.GetPtr(bossIdx);
    if( ptr == nullptr ) {
        return false;
    }
    return ptr->killed() > 0;
}

// 召唤boss
void UserHelperBoss::OnBossSummoned(int32 bossIdx) {
    auto ptr = _tpl.GetPtr(bossIdx);
    if( ptr == nullptr ) {
        InitOne(bossIdx);
        ptr = _tpl.GetPtr(bossIdx);
    }
    ptr->set_summoned(ptr->summoned()+1);
    _tpl.OnChange(bossIdx);
}

// 击杀boss
void UserHelperBoss::OnBossKilled(int32 bossIdx) {
    auto ptr = _tpl.GetPtr(bossIdx);
    if( ptr == nullptr ) {
        InitOne(bossIdx);
        ptr = _tpl.GetPtr(bossIdx);
    }
    ptr->set_killed(ptr->killed()+1);
    _tpl.OnChange(bossIdx);
}
