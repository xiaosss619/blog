#pragma once

#include "UserHelperTpl.h"

class LxUser;
class UserHelperHunt {
public:
    void Init(LxUser* pUser);
    void InitHunt(const HuntBossSimple& qi);

    bool FillProto(SyncUserInfoChange& user, LxSaveData& save);
    void FillLoginResp(UserLoginResp& resp) {
        resp.clear_hunts();
        _tpl.ForEach([&](HuntBossSimple* ptr) {
            *resp.add_hunts() = *ptr;
        });
    }
    bool Update(int64 now);

    void OnHunted(int64 guid, int64 gold, int64 itemGold);
    // 击杀boss
    void OnHuntKilled(int64 guid);
    void OnHuntMissed(int64 guid);
    // 领取围猎奖励
    void OnHuntRewarded(int64 guid, int32 type);
    // boss消耗
    void OnHuntHitCost(int64 guid, int32 bossIdx, int64 cost);
    // 获取对应boss的消耗, 可累积
    int64 GetHuntHitCost(int64 guid);
    void OnBroken();
    // 获取对应boss的奖励
    bool GetHuntBossData(int64 guid, HuntBossSimple& lhs);
private:
    void InitOne(int64 guid, int32 bossIdx);
public:
    UserHelperTpl<int64, HuntBossSimple> _tpl;
    LxUser* m_pUser;
};
