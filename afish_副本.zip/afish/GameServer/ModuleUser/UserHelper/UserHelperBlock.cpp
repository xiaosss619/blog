#include "UserHelperBlock.h"
#include "../LxUser.h"
#include "ModuleHelper.h"
#include "Dispatcher.h"
#include "LxGameLogHelper.h"
#include "Handler/RedisCmdHandler.h"

void UserHelperBlock::Init(LxUser* pUser) {
    m_pUser = pUser;
    _tpl.Init();
}

void UserHelperBlock::InitBlock(const TargetInfo& info) {
    _tpl.Set(info.t_id(), info);
}

int32 UserHelperBlock::BlockAdd(uint64 userId) {
    if( _tpl.Has(userId) ) {
        return JDATA->ErrorCodePtr()->GetSuccess();
    }
    FETCH_RETURN(JDATA->ErrorCodePtr()->GetSystemError());
    if( m_pUser->IsFriend(userId) ) {
        m_pUser->RemoveFriend(pConnection, userId);
    }

    TargetInfo info;
    if( !RedisData::GetUserTargetInfo(pConnection, userId, info) ) {
        return JDATA->ErrorCodePtr()->GetTargetNotFound();
    }
    _tpl.Set(userId, info);
    _tpl.OnChange(userId);
    return JDATA->ErrorCodePtr()->GetSuccess();
}

int32 UserHelperBlock::BlockDel(uint64 userId) {
    if( !_tpl.Has(userId) ) {
        return JDATA->ErrorCodePtr()->GetSuccess();
    }
    _tpl.Remove(userId);
    return JDATA->ErrorCodePtr()->GetSuccess();
}

bool UserHelperBlock::FillProto(SyncUserInfoChange& user, LxSaveData& save) {
    bool bFilled = false;
    _tpl.ForEachDirty([&](TargetInfo* ptr) {
        *user.add_blocks() = *ptr;
        *save.add_blocks() = *ptr;
        bFilled = true;
    });
    _tpl.ForEachRemoved([&](const uint64& fid) {
        user.add_del_blocks(fid);
        save.add_del_blocks(fid);
        bFilled = true;
    });
    _tpl.ClearChange();
    return bFilled;
}
