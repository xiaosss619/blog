#include "UserHelperTech.h"
#include "../LxUser.h"
#include "ModuleHelper.h"
#include "Dispatcher.h"
#include "LxGameLogHelper.h"

void UserHelperTech::Init(LxUser* pUser) {
    m_pUser = pUser;
    _tpl.Init();
}

void UserHelperTech::InitTech(const TechInfo& qi) {
    TechInfo info = qi;
    int32 maxLevel = JDATA->InstitutePtr()->MaxLevelByID(qi.tech_id());
    if( info.tech_level() >= maxLevel ) {
        info.set_tech_level(maxLevel);
        info.set_tech_time(0);
    }
    _tpl.Set(info.tech_id(), info);
}

void UserHelperTech::InitNewbie() {
    JDATA->InstitutePtr()->ForEach([&](tagJsonInstitute* ptr){
        if( _tpl.Has(ptr->_ID) ) {
            return;
        }
        TechInfo info;
        info.set_tech_id(ptr->_ID);
        info.set_tech_level(0);
        info.set_tech_time(0);
        info.set_diamond_acc(0);
        info.set_item_acc(0);
        info.set_locked(ptr->_IsLock);
        _tpl.Set(info.tech_id(), info);
        _tpl.OnChange(ptr->_ID);
    });
}

bool UserHelperTech::FillProto(SyncUserInfoChange& user,LxSaveData& save) {
    bool bFilled = false;
    _tpl.ForEachDirty([&](TechInfo* ptr) {
        *user.add_techs() = *ptr;
        *save.add_techs() = *ptr;
        bFilled = true;
    });
    _tpl.ClearChange();
    return bFilled;
}

bool UserHelperTech::IsLocked(int32 tid) {
    auto ptr = _tpl.GetPtr(tid);
    if( ptr == nullptr ) return true;
    return ptr->locked();
}

void UserHelperTech::Unlock(int32 tid) {
    auto ptr = _tpl.GetPtr(tid);
    if( ptr == nullptr ) return;
    ptr->set_locked(false);
    _tpl.OnChange(tid);
}

void UserHelperTech::RmbUpgrade(int32 techId, int32 lv) {
    auto pTech = _tpl.GetPtr(techId);
    if( pTech == nullptr ) {
        LOGERROR("user[%lu] RmbUpgrade failed[%d][%d]", m_pUser->GetKey(), techId, lv);
        return;
    }
    if( lv > JDATA->InstitutePtr()->MaxLevelByID(techId) ) {
        LOGERROR("user[%lu] RmbUpgrade failed[%d][%d]", m_pUser->GetKey(), techId, lv);
        return;
    }
    if( lv <= pTech->tech_level() ) {
        return;
    }
    // 直接升级
    int32 oldLv = pTech->tech_level();
    pTech->set_tech_level(lv);
    pTech->set_tech_time(0);
    _tpl.OnChange(techId);
    LOG_TECH_UPGRADE(m_pUser, pTech->tech_id(), oldLv, pTech->tech_level(), pTech->diamond_acc(), pTech->item_acc());
}

int32 UserHelperTech::Upgrade(int32 techId) {
    auto pTech = _tpl.GetPtr(techId);
    if( pTech == nullptr || pTech->tech_time() != 0 ) {
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    if( pTech->products().end_time() != 0 ) {
        return JDATA->ErrorCodePtr()->GetTechUpgradeWhenProducing();
    }
    // 判断科技等级是否已经最大
    if( pTech->tech_level() >= JDATA->InstitutePtr()->MaxLevelByID(techId) ) {
        return JDATA->ErrorCodePtr()->GetTechMaxLevel();
    }
    tagJsonInstituteLevel tech;
    if( !sHTech->GetTechUpgradeData(techId, pTech->tech_level(), tech) || (tech._UpgradeNeeds.size() % 2) != 0 ) {
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    for( size_t i = 0; i < tech._UpgradeNeeds.size() ; i+=2 ) {
        if( !m_pUser->CanChangeItem(tech._UpgradeNeeds[i], -tech._UpgradeNeeds[i+1]) ) {
            return JDATA->ErrorCodePtr()->GetTechItemLow();
        }
    }
    for( size_t i = 0; i < tech._UpgradeNeeds.size() ; i+=2 ) {
        m_pUser->ItemChange(tech._UpgradeNeeds[i], -tech._UpgradeNeeds[i+1], ELRD_TechUpgrade, false);
    }

    if( tech._UpgradeTime == 0 ) {
        // 直接升级
        pTech->set_tech_level(pTech->tech_level()+1);
        LOG_TECH_UPGRADE(m_pUser, pTech->tech_id(), pTech->tech_level()-1, pTech->tech_level(), pTech->diamond_acc(), pTech->item_acc());
    }
    else {
        pTech->set_tech_time(sGameUtils->GetFakeTimeNow() + tech._UpgradeTime);
    }
    _tpl.OnChange(techId);

    m_pUser->SendUserInfoChange(EPIC_TechUpgrade);
    return JDATA->ErrorCodePtr()->GetSuccess();
}

int32 UserHelperTech::GetDiamondPrice(int32 seconds) {
    int32 per = JDATA->SystemConstPtr()->GetTimesPerDiamond();
    if( per == 0 ) {
        per = 5;
    }
    if( seconds % (per*TIME_MIN) == 0 ) {
        // 正好整除
        return seconds/(per*TIME_MIN);
    }
    return (seconds+per*TIME_MIN)/(per*TIME_MIN);
}

int32 UserHelperTech::Accelerate(TechAccelerateReq& msg) {
    int32 techId = msg.tech_id();
    auto pTech = _tpl.GetPtr(techId);
    if( pTech == nullptr || pTech->tech_time() == 0 ) {
        return JDATA->ErrorCodePtr()->GetSystemError();
    }

    int64 now = sGameUtils->GetFakeTimeNow();
    if( pTech->tech_time() <= now ) {
        return JDATA->ErrorCodePtr()->GetSuccess();
    }
    if( msg.diamond() > 0 ) {
        int32 costDiamond = GetDiamondPrice(pTech->tech_time() - now);
        if( costDiamond > msg.diamond() ) {
            costDiamond = msg.diamond();
        }
        if( !m_pUser->ChangeDiamond(-costDiamond, ELRD_TechAccelerate, false) ) {
            return JDATA->ErrorCodePtr()->GetDiamondLow();
        }
        int32 seconds = JDATA->SystemConstPtr()->GetTimesPerDiamond()*TIME_MIN*costDiamond;
        if( pTech->tech_time() - seconds <= now ) {
            pTech->set_tech_time(0);
            pTech->set_tech_level(pTech->tech_level()+1);
            pTech->set_diamond_acc(pTech->diamond_acc()+seconds);
            LOG_TECH_UPGRADE(m_pUser, pTech->tech_id(), pTech->tech_level()-1, pTech->tech_level(), pTech->diamond_acc(), pTech->item_acc());
        }
        else {
            pTech->set_diamond_acc(pTech->diamond_acc()+seconds);
            pTech->set_tech_time(pTech->tech_time() - seconds);
        }
        _tpl.OnChange(techId);
    }
    else {
        for( int i = 0 ; i < msg.items_size() ; ++i ) {
            int32 itemId = msg.items(i).item_id();
            int64 itemNum = msg.items(i).item_num();
            tagJsonItem tagItem;
            if( !JDATA->ItemPtr()->ByID(itemId, tagItem)
                || tagItem._MainType != e_jsonItemMainType_AcceleratorCard
                || tagItem._Misc <= 0 ) {
                continue;
            }
            if( m_pUser->ItemChange(itemId, -itemNum, ELRD_TechAccelerate, false) ) {
                pTech->set_item_acc(pTech->item_acc()+tagItem._Misc*itemNum);
                pTech->set_tech_time(pTech->tech_time() - tagItem._Misc*itemNum);
                _tpl.OnChange(techId);
                if( pTech->tech_time() <= now ) {
                    pTech->set_tech_time(0);
                    pTech->set_tech_level(pTech->tech_level()+1);
                    LOG_TECH_UPGRADE(m_pUser, pTech->tech_id(), pTech->tech_level()-1, pTech->tech_level(), pTech->diamond_acc(), pTech->item_acc());
                    break;
                }
            }
        }
    }
    m_pUser->SendUserInfoChange(EPIC_TechAccelerate);
    return JDATA->ErrorCodePtr()->GetSuccess();
}

int32 UserHelperTech::GetTurretRateEffect() {
    auto ptr = _tpl.GetPtr(e_jsonInstituteID_TurretPower);
    if( ptr == nullptr ) {
        return 0;
    }
    return sHTech->GetTechEffect(ptr->tech_id(), ptr->tech_level());
}

int32 UserHelperTech::GetFastEffect() {
    auto ptr = _tpl.GetPtr(e_jsonInstituteID_Rapid);
    if( ptr == nullptr ) {
        return 0;
    }
    return sHTech->GetTechEffect(ptr->tech_id(), ptr->tech_level());
}

int32 UserHelperTech::GetFuryEffect() {
    auto ptr = _tpl.GetPtr(e_jsonInstituteID_Crazy);
    if( ptr == nullptr ) {
        return 0;
    }
    return sHTech->GetTechEffect(ptr->tech_id(), ptr->tech_level());
}

int32 UserHelperTech::GetSuperWeaponEffect() {
    auto ptr = _tpl.GetPtr(e_jsonInstituteID_SuperWeapon);
    if( ptr == nullptr ) {
        return 0;
    }
    return sHTech->GetTechEffect(ptr->tech_id(), ptr->tech_level());
}

bool UserHelperTech::Update(int64 now) {
    bool bTechChanged = false;
    _tpl.ForEach([&](TechInfo* ptr){
        if( ptr->tech_time() > 0 && ptr->tech_time() <= now ) {
            ptr->set_tech_time(0);
            ptr->set_tech_level(ptr->tech_level()+1);
            LOG_TECH_UPGRADE(m_pUser, ptr->tech_id(), ptr->tech_level()-1, ptr->tech_level(), ptr->diamond_acc(), ptr->item_acc());
            _tpl.OnChange(ptr->tech_id());
            bTechChanged = true;
        }
        if( ptr->tech_id() == e_jsonInstituteID_Nuclear ) {
            if( CheckProducing(ptr) ) {
                _tpl.OnChange(ptr->tech_id());
                bTechChanged = true;
            }
        }
    });
    return bTechChanged;
}

int32 UserHelperTech::Produce(int32 tid, const ItemPair& item) {
    if( tid != e_jsonInstituteID_Nuclear ) {
        LOGERROR("user[%lu] ProduceFailed", m_pUser->GetKey());
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    auto pTech = _tpl.GetPtr(tid);
    if( pTech == nullptr ) {
        LOGERROR("user[%lu] ProduceFailed", m_pUser->GetKey());
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    if( pTech->tech_time() != 0 ) {
        return JDATA->ErrorCodePtr()->GetTechProduceWhenUpgrading();
    }
    if( pTech->tech_level() <= 0 ) {
        LOGERROR("user[%lu] ProduceFailed", m_pUser->GetKey());
        return JDATA->ErrorCodePtr()->GetSystemError();
    }

    tagJsonInstitute tag;
    if( !JDATA->InstitutePtr()->ByID(tid, tag) || tag._InstitutionParam.size() != 3 ) {
        LOGERROR("user[%lu] ProduceFailed", m_pUser->GetKey());
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    int32 materialItemId = tag._InstitutionParam[0];
    int64 costPer = tag._InstitutionParam[1];
    int32 productId = tag._InstitutionParam[2];
    if( item.item_num() <= 0 || item.item_id() != materialItemId ) {
        LOGERROR("user[%lu] ProduceFailed", m_pUser->GetKey());
        return JDATA->ErrorCodePtr()->GetSystemError();
    }

    IntPair ip;
    if( !sHTech->GetTechEffect(pTech->tech_id(), pTech->tech_level(), ip) ) {
        LOGERROR("user[%lu] ProduceFailed", m_pUser->GetKey());
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    int32 maxProduceNum = ip.key();
    int32 secondsPerBomb = ip.value();
    if( pTech->products().producing().item_num() + item.item_num() > maxProduceNum ) {
        // 检测生产是否超过限制
        LOGERROR("user[%lu] ProduceFailed", m_pUser->GetKey());
        return JDATA->ErrorCodePtr()->GetTechProduceNumExceed();
    }
    if( !m_pUser->CanChangeItem(materialItemId, -item.item_num()) ) {
        return JDATA->ErrorCodePtr()->GetItemUseNumLow();
    }
    if( !m_pUser->CanChangeGold(-costPer*item.item_num()) ) {
        return JDATA->ErrorCodePtr()->GetGoldLow();
    }
    m_pUser->ItemChange(materialItemId, -item.item_num(), ELRD_TechProduceBomb, false);
    m_pUser->ChangeGold(-costPer*item.item_num(), ELRD_TechProduceBomb);

    auto pProduct = pTech->mutable_products();
    int64 now = sGameUtils->GetFakeTimeNow();
    auto ptrProducing = pProduct->mutable_producing();
    if( pTech->products().end_time() == 0 ) {
        // 不在生产中
        ptrProducing->set_item_id(productId);
        ptrProducing->set_item_num(item.item_num());
        ptrProducing->set_item_change(ptrProducing->item_num());
        pProduct->set_end_time(now + item.item_num()*secondsPerBomb);
    }
    else {
        // 增加生产个数, 延长生产时间
        ptrProducing->set_item_num(ptrProducing->item_num()+item.item_num());
        ptrProducing->set_item_change(ptrProducing->item_num());
        pProduct->set_end_time(pProduct->end_time() + item.item_num()*secondsPerBomb);
    }
    _tpl.OnChange(tid);
    m_pUser->SendUserInfoChange(EPIC_TechProduceBomb);
    return JDATA->ErrorCodePtr()->GetSuccess();
}

int32 UserHelperTech::ProductGet(int32 tid) {
    auto pTech = _tpl.GetPtr(tid);
    if( pTech == nullptr ) {
        LOGERROR("user[%lu] GetFailed", m_pUser->GetKey());
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    auto pProduct = pTech->mutable_products()->mutable_products();
    if( pProduct->item_num() <= 0 ) {
        LOGERROR("user[%lu] GetFailed", m_pUser->GetKey());
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    if( !m_pUser->ItemChange(pProduct->item_id(), pProduct->item_num(), ELRI_TechProduceBombGet, false) ) {
        LOGERROR("user[%lu] GetFailed", m_pUser->GetKey());
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    pProduct->set_item_id(0);
    pProduct->set_item_num(0);
    pProduct->set_item_change(0);
    _tpl.OnChange(tid);
    m_pUser->SendUserInfoChange(EPIC_TechProduceBombGet);
    return JDATA->ErrorCodePtr()->GetSuccess();
}

int32 UserHelperTech::ProduceAccelerate(TechProduceAccelerateReq& msg) {
    int32 techId = msg.tech_id();
    auto pTech = _tpl.GetPtr(techId);
    if( pTech == nullptr ) {
        LOGERROR("user[%lu] AccFailed", m_pUser->GetKey());
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    if( pTech->products().end_time() == 0 ) {
        // 没有需要加速的商品
        LOGERROR("user[%lu] AccFailed", m_pUser->GetKey());
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    IntPair ip;
    if( !sHTech->GetTechEffect(pTech->tech_id(), pTech->tech_level(), ip) ) {
        LOGERROR("user[%lu] AccFailed", m_pUser->GetKey());
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    int32 secondsPerBomb = ip.value();
    if( secondsPerBomb == 0 ) {
        LOGERROR("user[%lu] AccFailed", m_pUser->GetKey());
        return JDATA->ErrorCodePtr()->GetSystemError();
    }

    auto pProduct = pTech->mutable_products();
    int64 now = sGameUtils->GetFakeTimeNow();
    if( pProduct->end_time() <= now ) {
        LOGERROR("user[%lu] AccFailed", m_pUser->GetKey());
        return JDATA->ErrorCodePtr()->GetSuccess();
    }
    int32 seconds = 0;
    for( int i = 0 ; i < msg.items_size() ; ++i ) {
        int32 itemId = msg.items(i).item_id();
        int64 itemNum = msg.items(i).item_num();
        tagJsonItem tagItem;
        if( !JDATA->ItemPtr()->ByID(itemId, tagItem)
            || tagItem._MainType != e_jsonItemMainType_AcceleratorCard
            || tagItem._Misc <= 0 ) {
            continue;
        }
        if( m_pUser->ItemChange(itemId, -itemNum, ELRD_TechProduceBombAccelerate, false) ) {
            seconds += tagItem._Misc*itemNum;
        }
    }

    auto ptrProducing = pProduct->mutable_producing();
    auto ptrDone = pProduct->mutable_products();
    if( msg.diamond() > 0 ) {
        // 清空所有cd
        int32 costDiamond = GetDiamondPrice(pTech->products().end_time() - now);
        if( costDiamond > msg.diamond() ) {
            costDiamond = msg.diamond();
        }
        if( !m_pUser->ChangeDiamond(-costDiamond, ELRD_TechProduceBombAccelerate, false) ) {
            return JDATA->ErrorCodePtr()->GetDiamondLow();
        }
        int32 seconds = JDATA->SystemConstPtr()->GetTimesPerDiamond()*TIME_MIN*costDiamond;
        if( pProduct->end_time() - seconds <= now ) {
            pProduct->set_end_time(0);
            ItemProduced(ptrProducing, ptrDone, -1);
        }
        else {
            pProduct->set_end_time(pProduct->end_time() - seconds);
        }
    }
    else {
        if( now + seconds >= pProduct->end_time() ) {
            pProduct->set_end_time(0);
            ItemProduced(ptrProducing, ptrDone, -1);
        }
        else {
            int32 accNum = seconds/secondsPerBomb;
            if( accNum > 0 ) {
                ItemProduced(ptrProducing, ptrDone, accNum);
            }
            pProduct->set_end_time(pProduct->end_time()-seconds);
        }
    }

    _tpl.OnChange(techId);
    m_pUser->SendUserInfoChange(EPIC_TechProduceBombAccelerate);
    return JDATA->ErrorCodePtr()->GetSuccess();
}

bool UserHelperTech::CheckProducing(TechInfo* pTech) {
    auto ptr = pTech->mutable_products();
    if( ptr->end_time() == 0 ) {
        return false;
    }
    IntPair ip;
    if( !sHTech->GetTechEffect(pTech->tech_id(), pTech->tech_level(), ip) ) {
        LOGERROR("user[%lu] CheckProducingFailed", m_pUser->GetKey());
        return false;
    }
    int32 secondsPerBomb = ip.value();
    if( secondsPerBomb == 0 ) {
        LOGERROR("user[%lu] CheckProducingFailed", m_pUser->GetKey());
        return false;
    }
    int64 now = sGameUtils->GetFakeTimeNow();
    auto ptrProducing = ptr->mutable_producing();
    auto ptrDone = ptr->mutable_products();
    if( now >= ptr->end_time() ) {
        // 已经全部结束了
        ptr->set_end_time(0);
        ItemProduced(ptrProducing, ptrDone, -1);
        return true;
    }
    else {
        int32 seconds = ptr->end_time() - now;// 剩余的生产时间
        int32 leftNum = seconds/secondsPerBomb;
        if( seconds % secondsPerBomb != 0 ) {
            // 不整除, 得多一个
            leftNum += 1;
        }
        // 目标个数与最多个数相减, 获得应该已经生产成功的个数
        int32 prdNum = ptrProducing->item_num()-leftNum;
        if( prdNum > 0 ) {
            ItemProduced(ptrProducing, ptrDone, prdNum);
            if( ptrProducing->item_num() == 0 ) {
                ptr->set_end_time(0);
            }
            return true;
        }
    }
    return false;
}
