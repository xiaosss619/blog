#pragma once

#include "UserHelperTpl.h"

class LxUser;
class UserHelperSevenDay {
public:
    void Init(LxUser* pUser);
    void InitDay7(const SevenDayInfo& qi);
    bool IsFinished(int32 qid) { return m_setFinished.find(qid) != m_setFinished.end(); }
    bool IsRewarded(int32 qid) { return m_setRewarded.find(qid) != m_setRewarded.end(); }
    void Day7Inc(const SevenDayInfo& qi, int64 value);
    void Day7Set(const SevenDayInfo& qi, int64 value);
    int32 Day7Reward(int32 qid);
    bool FillProto(SyncUserInfoChange& user,LxSaveData& save);
    void FillLoginResp(UserLoginResp& resp) {
        resp.clear_sevendays();
        _tpl.ForEach([&](SevenDayInfo* ptr) {
            *resp.add_sevendays() = *ptr;
        });
    }
public:
    UserHelperTpl<int32, SevenDayInfo> _tpl;
    set<int32> m_setRewarded;
    set<int32> m_setFinished;
    LxUser* m_pUser;
};
