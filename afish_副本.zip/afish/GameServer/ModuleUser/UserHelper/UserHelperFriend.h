#pragma once

#include "UserHelperTpl.h"

class RedisConnection;
class LxUser;
class UserHelperFriend {
public:
    void Init(LxUser* pUser);
    void InitFriend(const TargetInfo& qi);
    bool UpdateFriend(const TargetInfo& qi);
    void UpdateFriend(RedisConnection* pConnection, uint64 userId);
    void FriendComment(uint64 userId, const string& comment);
    void FriendApplyAccepted(uint64 userId);
    void FriendForceRemoved(uint64 userId);
    bool IsFriendOffline(uint64 userId);
    bool IsFriend(uint64 userId) { return _tpl.Has(userId); };
    tuple<int32, bool> AcceptOneApply(RedisConnection* pConnection, uint64 userId);
    int32 RemoveFriend(RedisConnection* pConnection, uint64 userId);

    // 通知所有好友刷新一下自己的信息, 目前用於上下綫
    void RefreshMe(RedisConnection* pConnection);
    void Update(RedisConnection* pConnection);

    bool FillProto(SyncUserInfoChange& user,LxSaveData& save);
    void FillLoginResp(UserLoginResp& resp) {
        resp.clear_friends();
        _tpl.ForEach([&](TargetInfo* ptr) {
            *resp.add_friends() = *ptr;
        });
    }
    bool HasFriend(uint64 userId) {
        return _tpl.Has(userId);
    }
public:
    UserHelperTpl<uint64, TargetInfo> _tpl;
    LxUser* m_pUser;
    std::list<uint64> m_lstOnlineNeedInit;
};
