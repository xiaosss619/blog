#pragma once

#include "UserHelperTpl.h"
// 目前寻找羁绊的方法有点繁琐
// 遍历羁绊表, 找所有羁绊在手牌中是否存在
// 遍历手牌数据, 统计阵营后, 查看阵营数羁绊是否成立
// 实际上应该按手牌做一个树状的羁绊图解, 按手牌id大小排列, 然后按顺序查找指定羁绊是否存在

class LxUser;
class UserHelperBombAct {
public:
    void Init(LxUser* pUser);
    // 活动id或者羁绊组id发生变化时, 重置数据
    void ResetActData(bool needSave);
    void GetBombActInfo(BombActCardInfoResp& resp);

    int32 CardClick(int32 pos, BombActCardClickResp& resp);

    void ResetCards();
    // 初始化卡牌, 只且只能在用户上线时调用
    void InitCard(const BombActCardInfo& card);
    void InitCardRelation() {
        set<int32> newRelations;
        CalcCardRelation(newRelations);
    }
    // 跨天时调用, 用于清空昨日数据, 重新初始化今日数据
    void CrossDay();
    bool FillProto(LxSaveData& save);

    // 按当前翻开的卡片, 计算当前羁绊情况
    void CalcCardRelation(set<int32>& newRelations);
private:
    // 获得数量最多阵营的卡牌数量
    int32 GetMaxCardNumOfCamp();
public:
    UserHelperTpl<int64, BombActCardInfo> _tpl;
    LxUser* m_pUser;
    Roll m_cardPool;
    set<int32> m_usedCard;  // 目前已经翻到的卡牌
    set<int32> m_relations; // 目前已经激活的羁绊
};
