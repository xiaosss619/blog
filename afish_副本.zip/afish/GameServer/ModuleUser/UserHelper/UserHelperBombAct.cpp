#include "UserHelperBombAct.h"
#include "../LxUser.h"
#include "LxGameLogHelper.h"
#include "Dispatcher.h"

void UserHelperBombAct::Init(LxUser* pUser) {
    m_pUser = pUser;
    ResetActData(false);
}

void UserHelperBombAct::ResetActData(bool needSave) {
    _tpl.Init();
    m_cardPool.clear();
    m_usedCard.clear();
    m_relations.clear();
    int32 cardNum = sHBombAct->GetMaxCardNum();
    for( int32 i = 0 ; i < cardNum ; ++i ) {
        BombActCardInfo card;
        card.set_pos(i);
        card.set_card_id(0);
        _tpl.Set(i, card);
        if( needSave ) {
            _tpl.OnChange(i);
        }
    }
    // 卡池初始化
    JDATA->CardPtr()->ForEach([&](tagJsonCard* ptr){
        m_cardPool.push_value(100, ptr->_ID);
    });
    m_cardPool.set_extra(true, 1);
}

void UserHelperBombAct::GetBombActInfo(BombActCardInfoResp& resp) {
    _tpl.ForEach([&](BombActCardInfo* ptr){
        *resp.add_cards() = *ptr;
    });
    for( auto & id : m_relations ) {
        resp.add_combos(id);
    }
}

void  UserHelperBombAct::InitCard(const BombActCardInfo& card) {
    _tpl.Set(card.pos(), card);
    if( card.card_id() != 0 ) {
        m_usedCard.insert(card.card_id());
        m_cardPool.remove_value(card.card_id());
    }
}

int32 UserHelperBombAct::CardClick(int32 pos, BombActCardClickResp& resp) {
    auto ptr = _tpl.GetPtr(pos);
    if( ptr == nullptr ) {
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    if( ptr->card_id() != 0 ) {
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    int32 cardId = m_cardPool.roll();

    BombActCardInfo card;
    card.set_pos(pos);
    card.set_card_id(cardId);
    _tpl.Set(pos, card);
    _tpl.OnChange(pos);
    *resp.mutable_card() = card;
    m_usedCard.insert(card.card_id());


    set<int32> newRelations;
    CalcCardRelation(newRelations);
    vector<int32> vecLoot;
    if( newRelations.size() == 0 ) {
        LOG_BOMB_ACT_CARD_FLIP(m_pUser, m_usedCard.size(), cardId, 0);
    }
    for( auto & id : newRelations ) {
        resp.add_combos(id);
        LOG_BOMB_ACT_CARD_FLIP(m_pUser, m_usedCard.size(), cardId, id);
        if( m_pUser->IsSensitiveSystemBanned(EUSTF_Voucher) ) {
            vecLoot.push_back(JDATA->CardRelationPtr()->ChannelRewardByID(id));
        }
        else {
            vecLoot.push_back(JDATA->CardRelationPtr()->RewardByID(id));
        }
    }

    for( size_t i = 0 ; i < vecLoot.size() ; i++ ) {
        m_pUser->GiveLoot(vecLoot[i], ELRI_BombActCardRelation, false);
    }
    return JDATA->ErrorCodePtr()->GetSuccess();
}

void UserHelperBombAct::CrossDay() {
    ResetActData(true);
}

void UserHelperBombAct::ResetCards() {
    _tpl.Init();
    m_cardPool.clear();
    m_usedCard.clear();
    m_relations.clear();
    int32 cardNum = sHBombAct->GetMaxCardNum();
    for( int32 i = 0 ; i < cardNum ; ++i ) {
        BombActCardInfo card;
        card.set_pos(i);
        card.set_card_id(0);
        _tpl.Set(i, card);
        _tpl.OnChange(i);
    }
    // 卡池初始化
    JDATA->CardPtr()->ForEach([&](tagJsonCard* ptr){
        m_cardPool.push_value(100, ptr->_ID);
    });
    m_cardPool.set_extra(true, 1);
}

void UserHelperBombAct::CalcCardRelation(set<int32>& newRelations) {
    map<int32, int32> campRelations; // 数量对应relationId
    // 卡牌组合类羁绊
    sHBombAct->ForEachRelation([&](int32 rid, const set<int32>& cards){
        bool bComplete = true;
        for( auto& card : cards ) {
            if( m_usedCard.find(card) == m_usedCard.end() ) {
                bComplete = false;
                break;
            }
        }
        if( bComplete ) {
            if( m_relations.find(rid) == m_relations.end() ) {
                m_relations.insert(rid);
                newRelations.insert(rid);
            }
        }
    });
    int32 maxCampNum = GetMaxCardNumOfCamp();
    sHBombAct->ForCampNum(maxCampNum, [&](int32 rid){
        if( m_relations.find(rid) == m_relations.end() ) {
            m_relations.insert(rid);
            newRelations.insert(rid);
        }
    });
}

int32 UserHelperBombAct::GetMaxCardNumOfCamp() {
    int32 maxCount = 0;
    map<int32, int32> mapCampCount;
    _tpl.ForEach([&](BombActCardInfo* ptr){
        if( ptr->card_id() != 0 ) {
            int32 camp = JDATA->CardPtr()->CampByID(ptr->card_id());
            if( camp != 0 ) {
                int32 campNum = 0;
                auto it = mapCampCount.find(camp);
                if( it == mapCampCount.end() ) {
                    mapCampCount[camp] = 1;
                    campNum = 1;
                }
                else {
                    it->second++;
                    campNum = it->second;
                }
                if( maxCount < campNum ) {
                    maxCount =campNum;
                }
            }
        }
    });
    return maxCount;
}

bool UserHelperBombAct::FillProto(LxSaveData& save) {
    bool bFilled = false;
    _tpl.ForEachDirty([&](BombActCardInfo* ptr) {
        *save.add_cards() = *ptr;
        bFilled = true;
    });
    _tpl.ClearChange();
    return bFilled;
}
