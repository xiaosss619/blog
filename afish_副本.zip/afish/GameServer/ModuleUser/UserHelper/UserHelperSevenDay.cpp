#include "UserHelperSevenDay.h"
#include "../LxUser.h"
#include "ModuleHelper.h"
#include "Dispatcher.h"
#include "LxGameLogHelper.h"

void UserHelperSevenDay::Init(LxUser* pUser) {
    m_pUser = pUser;
    _tpl.Init();
    m_setRewarded.clear();
    m_setFinished.clear();
}

void UserHelperSevenDay::InitDay7(const SevenDayInfo& qi) {
    int32 qid = qi.quest_id();
    if( qi.quest_status() == EQS_Rewarded ) {
        m_setRewarded.insert(qid);
    }
    else if( qi.quest_status() == EQS_Finished ) {
        m_setFinished.insert(qid);
    }
    if( qi.quest_target_num() >= qi.quest_target_need() ) {
        SevenDayInfo qq = qi;
        qq.set_quest_target_num(qi.quest_target_need());
        _tpl.Set(qid, qq);
    }
    else {
        _tpl.Set(qid, qi);
    }
}

void UserHelperSevenDay::Day7Inc(const SevenDayInfo& qi, int64 value) {
    int32 qid = qi.quest_id();
    if( IsFinished(qid) || IsRewarded(qid) ) {
        return;
    }
    auto ptr = _tpl.GetPtr(qid);
    if( ptr == nullptr ) {
        InitDay7(qi);
        ptr = _tpl.GetPtr(qid);
    }
    if( ptr == nullptr ) {
        return;
    }
    ptr->set_quest_target_num(ptr->quest_target_num()+value);
    if( ptr->quest_target_num() >= ptr->quest_target_need() ) {
        ptr->set_quest_target_num(ptr->quest_target_need());
        ptr->set_quest_status(EQS_Finished);
        m_setFinished.insert(qid);
    }
    _tpl.OnChange(qid);
}

void UserHelperSevenDay::Day7Set(const SevenDayInfo& qi, int64 value) {
    int32 qid = qi.quest_id();
    if( IsFinished(qid) || IsRewarded(qid) ) {
        return;
    }
    auto ptr = _tpl.GetPtr(qid);
    if( ptr == nullptr ) {
        InitDay7(qi);
        ptr = _tpl.GetPtr(qid);
    }
    if( ptr == nullptr ) {
        return;
    }
    if( value > ptr->quest_target_num() ) {
        ptr->set_quest_target_num(value);
    }
    if( ptr->quest_target_num() >= ptr->quest_target_need() ) {
        ptr->set_quest_target_num(ptr->quest_target_need());
        ptr->set_quest_status(EQS_Finished);
        m_setFinished.insert(qid);
    }
    _tpl.OnChange(qid);
}

bool UserHelperSevenDay::FillProto(SyncUserInfoChange& user,LxSaveData& save) {
    bool bFilled = false;
    _tpl.ForEachDirty([&](SevenDayInfo* ptr) {
        *user.add_sevendays() = *ptr;
        *save.add_sevendays() = *ptr;
        bFilled = true;
    });
    _tpl.ClearChange();
    return bFilled;
}

int32 UserHelperSevenDay::Day7Reward(int32 qid) {
    tagJsonNewBieCarnival tag;
    if( !JDATA->NewBieCarnivalPtr()->ByID(qid, tag) ) {
        LOGERROR("user has unknown qid[%d]", qid);
        return JDATA->ErrorCodePtr()->GetSystemError();
    }

    if( m_pUser->GetRegDays() < tag._Day ) {
        // 注册天数还没到开放的天数, 无法领取
        return JDATA->ErrorCodePtr()->GetSevenDayNotToday();
    }

    auto ptr = _tpl.GetPtr(qid);
    if( ptr == nullptr ) {
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    if( ptr->quest_status() == EQS_Rewarded ) {
        return JDATA->ErrorCodePtr()->GetSevenDayRewarded();
    }
    if( ptr->quest_status() == EQS_Accepted ) {
        return JDATA->ErrorCodePtr()->GetSevenDayNotFinished();
    }
    m_setFinished.erase(qid);
    m_setRewarded.insert(qid);
    ptr->set_quest_status(EQS_Rewarded);
    m_pUser->PBIncSevenDayExp(tag._RewardEXP);
    m_pUser->GiveLoot(tag._LootID, ELRI_SevenDay, false);
    LOG_SEVEN_DAY(m_pUser, qid, ptr->quest_status());

    _tpl.OnChange(qid);
    return JDATA->ErrorCodePtr()->GetSuccess();
}
