#pragma once

#include "UserHelperTpl.h"

class LxUser;
class UserHelperGeneralTask {
public:
    void Init(LxUser* pUser);
    void InitGTask(const GeneralTaskInfo& qi);
    void GTaskInc(const GeneralTaskInfo& qi, int64 value);
    void GTaskSet(const GeneralTaskInfo& qi, int64 value);
    void GTaskReset(const GeneralTaskInfo& qi);
    int32 GTaskReward(int32 qid);
    std::tuple<bool, int32> GTaskInfo(int32 qid);
    void CheckExpired();
    bool FillProto(SyncUserInfoChange& user,LxSaveData& save);
    void FillLoginResp(UserLoginResp& resp) {
        resp.clear_gtasks();
        _tpl.ForEach([&](GeneralTaskInfo* ptr) {
            *resp.add_gtasks() = *ptr;
        });
    }
public:
    UserHelperTpl<int32, GeneralTaskInfo> _tpl;
    LxUser* m_pUser;
};
