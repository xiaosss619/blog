#include "UserHelperWing.h"
#include "LxGameLogHelper.h"
#include "../LxUser.h"
#include "Dispatcher.h"

bool UserHelperWing::GiveWing(int32 idx, int32 lv, int32 reason) {
    if( _tpl.Has(idx) ) {
        int32 itemId = sHItem->GetWingItemPart(idx);
        int32 itemNum = JDATA->WingDataPtr()->CombinationNumByID(idx);
        m_pUser->ItemChange(itemId, itemNum, reason, false);
        return true;
    }

    WingInfo wing;
    wing.set_wing_index(idx);
    wing.set_wing_level(lv);
    _tpl.Set(idx, wing);
    _tpl.OnChange(idx);
    LOG_WING_BORN(m_pUser, wing.wing_index(), wing.wing_level());
    WingUpdatePower(idx);
    int32 defaultHeroId = JDATA->WingDataPtr()->TurretSetIDByID(idx);
    if( m_pUser->HasHero(defaultHeroId) ) {
        m_pUser->HeroActivateWing(defaultHeroId, idx);
        if( m_pUser->PBGetUserHeroIndex() == defaultHeroId ) {
            // 如果激活翅膀的是当前使用的英雄, 要尝试修改一下渔场的形象
            CALL_THREAD_SIMPLE(m_pUser, LxUserChangeTurret);
        }
    }
    return true;
}

int32 UserHelperWing::GetItemSwingUpgradeRate(int32 iItemId) {
    tagJsonItem item;
    if( !JDATA->ItemPtr()->ByID(iItemId, item) ) {
        return 0;
    }
    if( item._MainType != e_jsonItemMainType_Talisman ) {
        return 0;
    }
    return item._Misc;
}

int32 UserHelperWing::WingUpgrade(int32 idx, const ItemPair& item, WingUpgradeResp& msg) {
    auto ptr = _tpl.GetPtr(idx);
    if( ptr == nullptr ) {
        LOGERROR("user[%lu] no wing[%d]", m_pUser->GetKey(), idx);
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    tagJsonWingData tagWing;
    if( !JDATA->WingDataPtr()->ByID(idx, tagWing) ) {
        LOGERROR("user[%lu] no wing config[%d]", m_pUser->GetKey(), idx);
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    if( ptr->wing_level() >= tagWing._MaxLevel ) {
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    tagJsonWingAttribute tagLevel;
    if( !JDATA->WingAttributePtr()->ByLevel(ptr->wing_level(), tagLevel) ) {
        LOGERROR("user[%lu] no wing attr config[%d]", m_pUser->GetKey(), idx);
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    if( tagWing._UpgradeItemCost.size() != tagLevel._ItemCostNumber.size() ) {
        LOGERROR("user[%lu] wing[%d] lv[%d] item cost size failed", m_pUser->GetKey(), idx, ptr->wing_level());
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    map<int32, int64> mapItem;
    for( size_t i = 0; i < tagLevel._ItemCostNumber.size(); ++i ) {
        mapItem[tagWing._UpgradeItemCost[i]] = tagLevel._ItemCostNumber[i];
    }
    int32 addRate = 0;
    if( item.item_id() != 0 ) {
        addRate = GetItemSwingUpgradeRate(item.item_id());
        mapItem[item.item_id()] = item.item_num();
    }
    if( !m_pUser->CanRemoveItem(mapItem) ) {
        for( auto & item : mapItem ) {
            LOGERROR("user[%lu] wing[%d] lv[%d] item[%d][%ld] not enough[%ld]", m_pUser->GetKey(), idx, ptr->wing_level(), item.first, item.second, m_pUser->GetItemNum(item.first));
        }
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    m_pUser->RemoveItem(mapItem, ELRD_SwingUpgrade);
    msg.set_success(false);
    int32 oldLevel = ptr->wing_level();
    int32 rate = GlobalUtils::GetRandNumber(0, 100);
    if( rate <= tagLevel._Success + addRate ) {
        msg.set_success(true);
        ptr->set_wing_level(oldLevel+1);
        WingUpdatePower(idx);
        m_pUser->GTaskSet(e_jsonGeneralTaskCondition_Swing_Strength, ptr->wing_index(), ptr->wing_level());
    }
    _tpl.OnChange(idx);
    LOG_WING_UPGRADE(m_pUser, idx, oldLevel, ptr->wing_level(), rate*1000 + tagLevel._Success + addRate);
    return JDATA->ErrorCodePtr()->GetSuccess();
}

int32 UserHelperWing::GetWingAttr(int idx, int32 attr) {
    auto wing = _tpl.GetPtr(idx);
    if( wing == nullptr ) {
        return 0;
    }
    tagJsonWingAttribute tag;
    if( !JDATA->WingAttributePtr()->ByLevel(wing->wing_level(), tag) ) {
        return 0;
    }
    if( tag._UpgradeAttribute.size() % 2 != 0 ) {
        LOGERROR("user[%lu] wing[%d] attr size failed", m_pUser->GetKey(), idx);
        return 0;
    }
    for( size_t i = 0 ; i < tag._UpgradeAttribute.size() ; i+=2 ) {
        if( attr == tag._UpgradeAttribute[i] ) {
            return tag._UpgradeAttribute[i+1];
        }
    }
    return 0;
}

int32 UserHelperWing::WingGetPower(int32 wid) {
    auto wing = _tpl.GetPtr(wid);
    if( wing == nullptr ) {
        return 0;
    }
    return wing->wing_power();
}

// 翅膀进阶后要重算战力
void UserHelperWing::WingUpdatePower(int32 wid) {
    auto wing = _tpl.GetPtr(wid);
    if( wing == nullptr ) {
        return;
    }
    tagJsonWingData swData;
    if( !JDATA->WingDataPtr()->ByID(wing->wing_index(), swData) && swData._PowerParam.size() == 4 ) {
        return;
    }
    int32 param = swData._PowerParam[2];
    int32 tid = swData._TurretSetID;
    if( m_pUser->HasHero(tid) ) {
        param = swData._PowerParam[3];
    }
    int32 power = (swData._PowerParam[0] + swData._PowerParam[1]*wing->wing_level()*param);
    wing->set_wing_power(power);
    if( tid != 0 ) {
        m_pUser->HeroUpdatePower(tid);
    }
    _tpl.OnChange(wid);
}

void UserHelperWing::CheckPower() {
    _tpl.ForEach([&](WingInfo* ptr){
        if( ptr->wing_power() == 0 ) {
            WingUpdatePower(ptr->wing_index());
        }
    });
}
