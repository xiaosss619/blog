#include "UserHelperHero.h"
#include "LxGameLogHelper.h"
#include "LxUser.h"
#include "Dispatcher.h"

// 炮台升级
int32 UserHelperHero::HeroLevelup(int32 idx) {
    auto hero = _tpl.GetPtr(idx);
    if( hero == nullptr ) {
        LOGINFO("user[%lu] no hero [%d]", m_pUser->GetKey(), idx);
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    if( hero->hero_level() >= JDATA->HeroSetPtr()->MaxLevelByID(idx) ) {
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    int32 nextExp = JDATA->HeroLevelPtr()->TotalExpByID(hero->hero_level()+1);
    if( nextExp == 0 ) {
        LOGINFO("user[%lu] hero max level cur[%d]", m_pUser->GetKey(), hero->hero_level());
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    int32 expNeed = nextExp - hero->hero_level_exp();
    int32 reduce = 0;
    if( hero->hero_wing_index() != 0 ) {
        reduce = m_pUser->GetWingAttr(hero->hero_wing_index(), e_jsonWingAttributeUpgradeAttribute_ReduceHeroLevelCost);
    }
    expNeed = expNeed*(1000-reduce)/1000;
    int32 itemId = sHItem->GetHeroLevelupItem();
    if( !m_pUser->ItemChange(itemId, -expNeed, ELRD_TurretLevelUp, false) ) {
        LOGINFO("user[%lu] hero levelup item[%d] need[%d] not enough", m_pUser->GetKey(), itemId, expNeed);
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    hero->set_hero_level(hero->hero_level()+1);
    hero->set_hero_level_exp(nextExp);
    UpdatePower(hero);
    _tpl.OnChange(idx);

    LOG_HERO_LEVELUP(m_pUser, idx, hero->hero_level(), hero->hero_level()-1);
    m_pUser->GTaskSet(e_jsonGeneralTaskCondition_Turret_Level, idx, hero->hero_level());
    m_pUser->OnHeroRelationChange(idx);
    return JDATA->ErrorCodePtr()->GetSuccess();
}

// 炮台升星
int32 UserHelperHero::HeroStarCharge(int32 idx) {
    auto hero = _tpl.GetPtr(idx);
    if( hero == nullptr ) {
        LOGERROR("user[%lu] no hero[%d]", m_pUser->GetKey(), idx);
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    if( hero->hero_star() >= JDATA->HeroSetPtr()->MaxStarByID(idx) ) {
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    int32 starIndex = (hero->hero_star()-1)/6+1;
    tagJsonHeroStar tagStar;
    if( !JDATA->HeroStarPtr()->ByID(starIndex, tagStar) ) {
        LOGERROR("user[%lu] starIndex failed[%d] [%d]", m_pUser->GetKey(), hero->hero_star(), starIndex);
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    tagJsonHeroSet tagHero;
    if( !JDATA->HeroSetPtr()->ByID(idx, tagHero) ) {
        LOGERROR("user[%lu] hero config failed[%d]", m_pUser->GetKey(), idx);
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    if( tagStar._ItemCostNumber.size() != 3 || tagHero._StarItemCost.size() != 3 ) {
        LOGERROR("user[%lu] hero[%d] star item cost size failed", m_pUser->GetKey(), idx);
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    map<int32, int64> mapItem;
    mapItem[tagHero._StarItemCost[0]] = tagStar._ItemCostNumber[0];
    int32 reduce = 0;
    if( hero->hero_wing_index() != 0 ) {
        reduce = m_pUser->GetWingAttr(hero->hero_wing_index(), e_jsonWingAttributeUpgradeAttribute_ReduceHeroStarCost);
    }
    mapItem[tagHero._StarItemCost[1]] = tagStar._ItemCostNumber[1]*(1000-reduce)/1000;
    bool starUp = false;
    if( hero->hero_star_charge() == tagStar._EnergyPoint - 1 ) {
        // 充能最后一次会升星, 要多消耗一个道具
        mapItem[tagHero._StarItemCost[2]] = tagStar._ItemCostNumber[2];
        starUp = true;
    }
    if( !m_pUser->CanRemoveItem(mapItem) ) {
        for( auto & item : mapItem ) {
            LOGERROR("user[%lu] starIndex[%d] hero[%d] star item[%d][%ld] not enough[%ld]", m_pUser->GetKey(), starIndex, idx, item.first, item.second, m_pUser->GetItemNum(item.first));
        }
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    int32 oldStar = hero->hero_star();
    int32 oldCharge = hero->hero_star_charge();
    m_pUser->RemoveItem(mapItem, ELRD_TurretStar);
    if( starUp ) {
        hero->set_hero_star(oldStar+1);
        hero->set_hero_star_charge(0);
        UpdatePower(hero);
    }
    else {
        hero->set_hero_star_charge(oldCharge+1);
    }
    LOG_HERO_STAR_CHARGE(m_pUser, idx, oldStar, oldCharge, hero->hero_star(), hero->hero_star_charge());
    _tpl.OnChange(idx);
    m_pUser->OnHeroRelationChange(idx);
    return JDATA->ErrorCodePtr()->GetSuccess();
}

// 给予一个指定等级和星级的炮台
bool UserHelperHero::GiveHero(int32 tindex, int32 baseLevel, int32 baseStar, int32 reason) {
    if( tindex == 0 ) {
        return false;
    }
    if( HasHero(tindex) ) {
        int32 itemId = sHItem->GetHeroItemPart(tindex);
        int32 itemNum = JDATA->HeroSetPtr()->CombinationNumByID(tindex);
        m_pUser->ItemChange(itemId, itemNum, reason, false);
        return true;
    }
    HeroInfo info;
    info.set_hero_index(tindex);
    info.set_hero_wing_index(0);
    info.set_hero_level(baseLevel);
    info.set_hero_level_exp(JDATA->HeroLevelPtr()->TotalExpByID(baseLevel));
    info.set_hero_star(baseStar);
    info.set_hero_star_charge(0);
    int32 defaultSwing = JDATA->HeroSetPtr()->SwingIDByID(tindex);
    if( m_pUser->HasWing(defaultSwing) ) {
        info.set_hero_wing_index(defaultSwing);
    }

    LOG_HERO_BORN(m_pUser, tindex, reason);

    _tpl.Set(tindex, info);
    UpdatePower(_tpl.GetPtr(tindex));
    _tpl.OnChange(tindex);
    m_pUser->GTaskInc(e_jsonGeneralTaskCondition_Turret_Total, tindex, 1);

    return true;
}

void UserHelperHero::HeroSetArenaTime(int32 tid) {
    auto pHero = _tpl.GetPtr(tid);
    if( pHero == nullptr ) {
        return;
    }
    pHero->set_hero_arena_time(sGameUtils->GetFakeTimeNow());
    _tpl.OnChange(tid);
}

void UserHelperHero::HeroSetCasualTime(int32 tid) {
    auto pHero = _tpl.GetPtr(tid);
    if( pHero == nullptr ) {
        return;
    }
    pHero->set_hero_casual_time(sGameUtils->GetFakeTimeNow());
    _tpl.OnChange(tid);
}

// 激活翅膀
void UserHelperHero::ActivateWing(int32 idx, int32 widx) {
    auto ptr = _tpl.GetPtr(idx);
    if( ptr == nullptr ) {
        return;
    }
    ptr->set_hero_wing_index(widx);
    UpdatePower(ptr);
    _tpl.OnChange(idx);
}

int32 UserHelperHero::HeroChangeBullet(int32 tid, int32 itemId) {
    auto hero = _tpl.GetPtr(tid);
    if( hero == nullptr ) {
        return JDATA->ErrorCodePtr()->GetTurretEquipNoTurret();
    }
    if( itemId != 0 ) {
        if( JDATA->ItemPtr()->MainTypeByID(itemId) != e_jsonItemMainType_BulletSkin ) {
            return JDATA->ErrorCodePtr()->GetTurretChangeBulletTypeFail();
        }
    }
    int32 oldBulletId = hero->hero_bullet_index();
    if( oldBulletId != 0 ) {
        // 卸下老的
        if( !m_pUser->ItemChange(oldBulletId, 1, 0, false) ) {
            return JDATA->ErrorCodePtr()->GetSystemError();
        }
        hero->set_hero_bullet_index(0);
        _tpl.OnChange(tid);
    }
    if( itemId != 0 ) {
        if( !m_pUser->ItemChange(itemId, -1, 0, false) ) {
            return JDATA->ErrorCodePtr()->GetSystemError();
        }
        hero->set_hero_bullet_index(itemId);
        _tpl.OnChange(tid);
    }
    return JDATA->ErrorCodePtr()->GetSuccess();
}

int32 UserHelperHero::HeroGetPower(int32 idx) {
    auto hero = _tpl.GetPtr(idx);
    if(hero == nullptr) {
        return 0;
    }
    return hero->hero_power();
}

void UserHelperHero::HeroUpdatePower(int32 tid) {
    auto hero = _tpl.GetPtr(tid);
    if(hero == nullptr) {
        return;
    }
    UpdatePower(hero);
}

void UserHelperHero::UpdatePower(HeroInfo* hero) {
    tagJsonHeroSet data;
    if( !JDATA->HeroSetPtr()->ByID(hero->hero_index(), data) || data._PowerParam.size() != 3 ) {
        return;
    }
    int32 power = (data._PowerParam[0]*hero->hero_level() + data._PowerParam[1]*hero->hero_star())*data._PowerParam[2];
    power += m_pUser->WingGetPower(hero->hero_wing_index());
    hero->set_hero_power(power);
    if( hero->hero_index() == m_pUser->PBGetUserHeroIndex() ) {
        m_pUser->PBSetUserPower(power);
    }
    _tpl.OnChange(hero->hero_index());
}

int32 UserHelperHero::HeroGetStarAttrValue(int32 attr) {
    int32 value = 0;
    _tpl.ForEach([&](HeroInfo* ptr){
        value += sHero->GetHeroStarAttrValue(ptr->hero_index(), ptr->hero_star(), attr);
    });
    return value;
}

void UserHelperHero::CheckPower() {
    _tpl.ForEach([&](HeroInfo* ptr){
        if( ptr->hero_power() == 0 ) {
            UpdatePower(ptr);
        }
    });
}

void UserHelperHero::HeroAllResetTime() {
    _tpl.ForEach([&](HeroInfo* ptr){
        ptr->set_hero_arena_time(0);
        ptr->set_hero_casual_time(0);
        _tpl.OnChange(ptr->hero_index());
    });
}

int32 UserHelperHero::GetHeroLevel(int32 hid) {
    auto hero = _tpl.GetPtr(hid);
    if( hero == nullptr ) {
        return 0;
    }
    return hero->hero_level();
}
int32 UserHelperHero::GetHeroStar(int32 hid) {
    auto hero = _tpl.GetPtr(hid);
    if( hero == nullptr ) {
        return 0;
    }
    return hero->hero_star();
}
