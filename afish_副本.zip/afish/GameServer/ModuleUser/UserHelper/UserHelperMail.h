#pragma once

#include "UserHelperTpl.h"

class LxUser;
class UserHelperMail {
public:
    void Init(LxUser* pUser);
    void NewMail(const LxMail& mail);
    void InitMail(const LxMail& mail) {
        _tpl.Set(mail.mail_id(), mail);
    }
    bool MailReward(int64 mailId);
    bool MailRead(int64 mailId);
    void MailDelete(int64 mailId) { _tpl.Remove(mailId); };

    bool FillProto(SyncUserInfoChange& user,LxSaveData& save);
public:
    UserHelperTpl<int64, LxMail> _tpl;
    LxUser* m_pUser;
};
