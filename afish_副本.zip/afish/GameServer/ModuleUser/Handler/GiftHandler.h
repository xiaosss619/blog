#pragma once

#include "ServerDefine.h"

class LxUser;
class GiftHandler
{
public:
	GiftHandler() {};
	~GiftHandler() {};
///////////////////////////////////////////////////////////////////////////////////////
//消息处理
public:
	static void ProcessSGiftSendReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
};
