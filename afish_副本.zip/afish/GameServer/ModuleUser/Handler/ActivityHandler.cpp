#include "ActivityHandler.h"
#include "LxUser.h"
#include "DataCache/RedisData.h"
#include "GameUtils.h"
#include "ModuleHelper.h"
#include "Dispatcher.h"
#include "LxGameLogHelper.h"

void ActivityHandler::ProcessUserExchangeReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	UserExchangeReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());

	do {
		tagJsonExchange config;
		if( !JDATA->ExchangePtr()->ByProductName(request.product(), config) ) {
			packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetExchangeNoProduct());
			break;
		}
		if( config._LootID == 0 && request.phone().empty() ) {
			packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
			break;
		}
		bool bValid = true;
		for( size_t i = 0; i < config._Price.size(); i+=2 ) {
			if( !pUser->CanChangeItem(config._Price[i], -config._Price[i+1]) ) {
				bValid = false;
				break;
			}
		}
		if( !bValid ) {
			packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetExchangeItemLow());
			break;
		}
		if( config._GoldPrice > 0 && !pUser->CanChangeGold(-config._GoldPrice) ) {
			packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetGoldLow());
			break;
		}
		if( config._DiamondPrice > 0 && !pUser->CanChangeDiamond(-config._DiamondPrice) ) {
			packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetDiamondLow());
			break;
		}
		bool bCost = false;
		for( size_t i = 0; i < config._Price.size(); ++i ) {
			pUser->ItemChange(config._Price[i], -config._Price[i+1], ELRD_Exchange, false);
			bCost = true;
		}
		if( config._GoldPrice > 0 ) {
			pUser->ChangeGold(-config._GoldPrice, ELRD_Exchange);
			bCost = true;
		}
		if( config._DiamondPrice > 0 ) {
			pUser->ChangeDiamond(-config._DiamondPrice, ELRD_Exchange, false);
			bCost = true;
		}
		if( !bCost ) {
			packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
			break;
		}
		LOG_EXCHANGE(pUser, request.product());
		pUser->SendUserInfoChange(0);
		pUser->PBIncAutoid(1);
		int64 guid = pUser->PBGetAutoid();
		if( config._LootID != 0 ) {
			pUser->GiveLoot(config._LootID, ELRI_Exchange, false);
			pUser->LogExchange(guid, request.product(), sGameUtils->GetFakeTimeNow(), EES_Success);
			if( config._Type == e_jsonExchangeType_ArenaExchange ) {
				pUser->GTaskInc(e_jsonGeneralTaskCondition_Arena_Exchange, 0, 1);
			}
			else if( config._Type == e_jsonExchangeType_TowerExchange ) {
				pUser->GTaskInc(e_jsonGeneralTaskCondition_Tower_Exchange, 0, 1);
			}
		}
		pUser->SendUserInfoChange(EPIC_Exchange);
	} while(0);
	LxGameHelper::MakeUserExchangeResp(packetResponse);
}

void ActivityHandler::ProcessExchangeCodeReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	ExchangeCodeReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
	do {
		FETCH_RESPONSE_BREAK(packetResponse);
		pConnection->xadd(RedisKey::MakeGoKeyRewardCode(), "rc", RedisKey::MakeGoDataRewardCode(pUser->GetKey(), request.code()));
	} while(0);
	LxGameHelper::MakeExchangeCodeResp(packetResponse);
}

void ActivityHandler::ProcessExchangeStockReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
	ExchangeStockResp msg;
	LxGameHelper::MakeExchangeStockResp(packetResponse, msg);
}

void ActivityHandler::ProcessUserActivityReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
	UserActivityResp msg;
	do {
		JDATA->ActivitiesPtr()->ForEach([&](tagJsonActivities* ptr){
			switch(ptr->_NotifyType) {
			case e_jsonActivitiesNotifyType_None:
				break;
			case e_jsonActivitiesNotifyType_Always:
			{
				auto act = msg.add_acts();
				act->set_act_id(ptr->_ID);
				break;
			}
			case e_jsonActivitiesNotifyType_InTime:
			{
				tagActivityInfo act;
				if( sHActs->GetActivity(ptr->_ID, act) ) {
					auto p = msg.add_acts();
					p->set_act_id(act._actId);
					p->set_act_type(act._type);
					p->set_start_time(act._start);
					p->set_end_time(act._end);
					// 转盘数据没有时机初始化, 在这里进行一下
					if( act._type == e_jsonActivitiesType_TurnTable && act._params.size() == 1 ) {
						pUser->TurnTableInit(act._params[0]);
					}
				}
				break;
			}
			default:
				break;
			}
		});
	} while(0);
	LxGameHelper::MakeUserActivityResp(packetResponse, msg);
}

void ActivityHandler::ProcessDay7RewardReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	UserSevenDayRewardReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
	pUser->SendUserInfoChange(0);
	int32 nRet = pUser->Day7Reward(request.qid());
	packetResponse.set_errorcode(nRet);
	if( nRet == JDATA->ErrorCodePtr()->GetSuccess() ) {
		pUser->SendUserInfoChange(EPIC_SevenDay);
	}
	LxGameHelper::MakeUserSevenDayRewardResp(packetResponse);
}

void ActivityHandler::ProcessDay7ExpRewardReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	pUser->SendUserInfoChange(0);
	int32 nRet = pUser->Day7ExpReward();
	packetResponse.set_errorcode(nRet);
	if( nRet == JDATA->ErrorCodePtr()->GetSuccess() ) {
		pUser->SendUserInfoChange(EPIC_SevenDayExp);
	}
	LxGameHelper::MakeUserSevenDayExpRewardResp(packetResponse);
}

void ActivityHandler::ProcessGeneralTaskRewardReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	GeneralTaskRewardReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
	pUser->SendUserInfoChange(0);
	int32 nRet = pUser->GTaskReward(request.task_id());
	packetResponse.set_errorcode(nRet);
	if( nRet == JDATA->ErrorCodePtr()->GetSuccess() ) {
		pUser->SendUserInfoChange(EPIC_GeneralTask);
	}
	LxGameHelper::MakeGeneralTaskRewardResp(packetResponse);
}

void ActivityHandler::ProcessTurntableBonusReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	TurntableBonusReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
	pUser->SendUserInfoChange(0);
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
	auto tt = sHTTable->GetOpenedTurntableInfo();
	int32 ttid = TUPLE0(tt);
	int32 idx = request.idx();
	do {
		tagJsonTurnTable tag;
		if( !JDATA->TurnTablePtr()->ByID(ttid, tag) ) {
			packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetTurntableExpired());
			break;
		}
		if( (int32)tag._Guarantee.size() <= idx*2 ) {
			packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
			break;
		}
		int32 num = (int32)tag._Guarantee[idx*2];
		int32 lootId = (int32)tag._Guarantee[idx*2+1];
		int32 flag = (1 << idx);
		int32 ret = pUser->TurnTableBonus(ttid, num, flag, lootId);
		packetResponse.set_errorcode(ret);
	} while(0);
	LxGameHelper::MakeTurntableBonusResp(packetResponse);
}

void ActivityHandler::ProcessTurntablePlayReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	TurntablePlayReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
	pUser->SendUserInfoChange(0);
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
	auto tt = sHTTable->GetOpenedTurntableInfo();
	int32 num = request.num();
	if( num != 1 ) {
		num = 10;
	}
	TurntablePlayResp msg;
	msg.set_num(num);
	packetResponse.set_errorcode(pUser->TurnTablePlay(TUPLE0(tt), num, msg));
	LxGameHelper::MakeTurntablePlayResp(packetResponse, msg);
}

void ActivityHandler::ProcessGetNewbieGiftReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	GetNewbieGiftReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
	GetNewbieGiftResp msg;
	do {
		if( pUser->PBGetNeedNewbieGift() == 0 ) {
			packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
			break;
		}
		int32 lootId = 0;
		if( pUser->IsSensitiveSystemBanned(EUSTF_Voucher) ) {
			lootId = JDATA->SystemConstPtr()->GetChannelInitialLoot();
		}
		else {
			if( request.gift_type() == ENGT_Lx ) {
				lootId = JDATA->SystemConstPtr()->GetOfficialInitialLoot();
			}
			else if( request.gift_type() == ENGT_Others ) {
				lootId = JDATA->SystemConstPtr()->GetOtherInitialLoot();
			}
			else {
				packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
				break;
			}
		}
		if( !JDATA->LootPtr()->ContainID(lootId) ) {
			packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
			break;
		}
		msg.set_loot_id(lootId);
		pUser->PBSetNeedNewbieGift(0);
		pUser->GiveLoot(lootId, ELRI_NewbieGift, false);
		pUser->SendUserInfoChange(EPIC_NewbieGift);
	} while(0);
	LxGameHelper::MakeGetNewbieGiftResp(packetResponse, msg);
}

void ActivityHandler::ProcessMonthCardRewardReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    do {
		if( pUser->PBGetMcardEnd() == 0 ) {
			packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetMonthCardInvalid());
			break;
		}
		int32 lootId = JDATA->SystemConstPtr()->GetMonthCard_DailyReward();
		if( pUser->PBGetMcardToday() != 0 || lootId == 0 ) {
			packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
			break;
		}
		// 给予月卡奖励loot
		pUser->GiveLoot(lootId, ELRI_MonthCard, false);
		pUser->PBSetMcardToday(1);
		pUser->SendUserInfoChange(EPIC_MonthCard);
    }while(0);
    LxGameHelper::MakeMonthCardRewardResp(packetResponse);
}

void ActivityHandler::ProcessTreasureHuntReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	TreasureHuntResp msg;
	packetResponse.set_errorcode(pUser->TreasureHunt(msg));
	LxGameHelper::MakeTreasureHuntResp(packetResponse, msg);
}

void ActivityHandler::ProcessTreasureHuntResetReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	packetResponse.set_errorcode(pUser->TreasureHuntReset(false));
    LxGameHelper::MakeTreasureHuntResetResp(packetResponse);
}

void ActivityHandler::ProcessTreasureHuntSetRewardReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	TreasureHuntSetRewardReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
	packetResponse.set_errorcode(pUser->TreasureHuntSetReward(request.t_id1(), request.t_id2()));
    LxGameHelper::MakeTreasureHuntSetRewardResp(packetResponse);
}

void ActivityHandler::ProcessDrawTenReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	DrawTenReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
	DrawTenResp msg;
	packetResponse.set_errorcode(pUser->DrawTen(request.type(), msg));
    LxGameHelper::MakeDrawTenResp(packetResponse, msg);
}

void ActivityHandler::ProcessDrawTenPeriodRewardReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	packetResponse.set_errorcode(pUser->DrawTenPeriodReward());
    LxGameHelper::MakeDrawTenPeriodRewardResp(packetResponse);
}
