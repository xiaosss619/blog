#pragma once

#include "ServerDefine.h"

class LxUser;
class TechHandler
{
public:
	TechHandler() {};
	~TechHandler() {};
///////////////////////////////////////////////////////////////////////////////////////
//消息处理
public:
	static void ProcessTechUpgradeReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessTechAccelerateReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessTechProduceReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessTechProductGetReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessTechProduceAccelerateReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
};
