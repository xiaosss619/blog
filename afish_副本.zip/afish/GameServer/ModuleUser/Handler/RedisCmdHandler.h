#pragma once

#include "ServerDefine.h"

class LxUser;
class RedisCmdHandler
{
public:
    static void ProcessCmd(RedisConnection* pConnection, LxUser* pUser);
	// 执行字符串指令，来自gm或者redis中的跨线程指令
	static void Do(LxUser* pUser, int32 cmd, const rapidjson::Value& param);
private:
	static void DoCommandRewardCode(LxUser* pUser, const rapidjson::Value& param);
	static void DoCommandGMMail(LxUser* pUser, const rapidjson::Value& param);
	static void DoCommandCouponResult(LxUser* pUser, const rapidjson::Value& param);

    static void CheckProtoCmd(LxUser* pUser, RedisConnection* pConnection);
};
