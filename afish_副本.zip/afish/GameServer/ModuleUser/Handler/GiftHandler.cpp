#include "GiftHandler.h"
#include "LxUser.h"
#include "LxGameLogHelper.h"
#include "ModuleHelper.h"
#include "DataCache/ProtoCmdHelper.h"
#include "Dispatcher.h"

void GiftHandler::ProcessSGiftSendReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
    SGiftSendReq request;
	if ( !request.ParseFromString(packet.data())) {
        LOGINFO("parse failed");
        return;
    }
    packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    do{
        FETCH_RESPONSE_BREAK(packetResponse);
        int32 minPop = JDATA->SystemConstPtr()->GetSendGiftsNeedPopularity();
        if( pUser->PBGetPopularity() < minPop || RedisData::GetUserPopularity(pConnection, request.rid()) < minPop ) {
            LOGINFO("user[%lu] or recv[%lu] pop not enough[%d] ", pUser->GetKey(), request.rid(), minPop);
            packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
            break;
        }

        int32 itemId = request.item().item_id();
        int64 itemNum = request.item().item_num();
        int64 extraNum = ceil(sGameUtils->GetGiftFee(itemId, itemNum));
        if( itemNum <= 0 || !pUser->CanChangeItem(itemId, -(itemNum+extraNum)) ) {
            LOGINFO("user[%lu] item[%d] not enough[%ld] ", pUser->GetKey(), itemId, itemNum+extraNum);
            packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
            break;
        }
        int64 guid = RedisData::GenerateGiftId(pConnection);
        if( guid == 0 ) {
            LOGINFO("user[%lu] gift id failed", pUser->GetKey());
            packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
            break;
        }
        GiftData gift;
        gift.set_gid(guid);
        if( !RedisData::GetUserTargetInfo(pConnection, request.rid(), *gift.mutable_receiver()) ) {
            LOGINFO("user[%lu] no receiver[%lu]", pUser->GetKey(), request.rid());
        	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetTargetNotFound());
            break;
        }
        if( !pUser->CanSendItem(itemId, itemNum) ) {
            LOGINFO("user[%lu] item[%d] num[%ld] limited", pUser->GetKey(), itemId, itemNum);
            packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
            break;
        }
        int64 now = sGameUtils->GetFakeTimeNow();
        pUser->GetTargetInfo(*gift.mutable_sender());
        *gift.mutable_item() = request.item();
        gift.set_fee(extraNum);
        gift.set_status(EGS_RecvAccepting);

        gift.set_gtime(now);
        gift.set_expires(now + JDATA->SystemConstPtr()->GetReceiveGiftsTime()*TIME_MIN);
        // 签名会比较长, 不在礼物系统中保存
        gift.mutable_sender()->clear_t_sign();
        gift.mutable_sender()->clear_t_comment();
        gift.mutable_receiver()->clear_t_sign();
        gift.mutable_receiver()->clear_t_comment();

        if( !RedisProtoHelper::RedisSaveHSET(pConnection, SYS_GIFT_KEY, GlobalUtils::ToString(guid), gift) ) {
            LOGERROR("GIFT save error[%s]", gift.DebugString().c_str());
            packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
            break;
        }

        pUser->GiftSend(itemId, itemNum);
        pUser->ItemChange(itemId, -(itemNum+extraNum), ELRD_SendGift, false);
        LOG_GIFT(gift);
        {
            GiftChannelCmd cmd;
            cmd.set_cmd(CHAT_LxSaveGift);
            *cmd.mutable_gift() = gift;
            ProtoCmdHelper::PushGiftCmd(pConnection, cmd);
        }
        pUser->SendUserInfoChange(EPIC_Gift);
    } while(0);
    LxGameHelper::MakeSGiftSendResp(packetResponse);
}
