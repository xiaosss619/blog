#include "InventoryHandler.h"
#include "LxUser.h"

void InventoryHandler::ProcessUserItemReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	UserItemReq request;
	if ( !request.ParseFromString(packet.data())) {
        LOGINFO("parse failed");
        return;
    }
	UserItemResp response;
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    for( auto & item : pUser->m_mapItem ) {
        auto p = response.add_items();
        p->set_item_id(item.first);
        p->set_item_change(item.second);
        p->set_item_num(item.second);
    }
    LxGameHelper::MakeUserItemResp(packetResponse, response);
}

void InventoryHandler::ProcessUserItemUseReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	UserItemUseReq request;
	if ( !request.ParseFromString(packet.data())) {
        LOGINFO("parse failed");
        return;
    }
	packetResponse.set_errorcode(pUser->ItemUse(request));
	LxGameHelper::MakeUserItemUseResp(packetResponse);
}
