#pragma once

#include "ServerDefine.h"

class LxUser;
class MailHandler
{
public:
	MailHandler() {};
	~MailHandler() {};
///////////////////////////////////////////////////////////////////////////////////////
//消息处理
public:
	static void ProcessUserMailReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessUserReadMailReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessUserDeleteMailReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessUserRewardMailReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
};
