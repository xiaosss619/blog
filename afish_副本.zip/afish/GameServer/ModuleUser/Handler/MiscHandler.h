#pragma once

#include "ServerDefine.h"

class LxUser;
class MiscHandler
{
public:
	MiscHandler() {};
	~MiscHandler() {};
///////////////////////////////////////////////////////////////////////////////////////
//消息处理
public:
	static void ProcessUserChargeReq(LxUser* pUser, WrapPacket& packet, WrapPacket& response);
	static void ProcessModifyNameReq(LxUser* pUser, WrapPacket& packet, WrapPacket& response);
	static void ProcessModifySignReq(LxUser* pUser, WrapPacket& packet, WrapPacket& response);
	static void ProcessSignDayReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessPovertyRewardReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessSaveUserDefineDataReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessLevelRewardReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessGrowthRewardReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessQuestRewardReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessBuyTideReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessUserBuyVipGiftReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessUserBuyMarketReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessUserRandMarketReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessSlotFishDrawReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessTodayTableRewardReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessBattlePassRewardReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessPassportRewardReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessPassportBuyExpReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessTechUpgradeReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessTechAccelerateReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
};
