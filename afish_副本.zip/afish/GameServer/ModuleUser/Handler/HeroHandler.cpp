#include "HeroHandler.h"
#include "LxUser.h"
#include "LxGameLogHelper.h"
#include "ModuleHelper.h"
#include "Dispatcher.h"

void HeroHandler::ProcessHeroSwitchReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
    HeroSwitchReq request;
	if ( !request.ParseFromString(packet.data())) {
        LOGINFO("parse failed");
        return;
    }
    packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    do{
        int32 fishTableIndex = pUser->PBGetFishTableIndex();
        if( fishTableIndex != 0 && JDATA->GamePlayPtr()->GameTypeByID(fishTableIndex) == e_jsonGamePlayGameType_Arena ) {
            // 竞技场内不允许换炮台
            packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetTurretEquipInArena());
            break;
        }
        int32 tid = request.hero_index();
        if( !pUser->HasHero(tid) ) {
            packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetTurretIdError());
            break;
        }
        if( pUser->PBGetUserHeroIndex() != tid ) {
            pUser->OnChangeHero(tid);
            pUser->SendUserInfoChange(EPIC_TurretChange);

            // 同步一个换炮台给渔场
            WrapPacket tpkg = packet;
            tpkg.clear_data();
            LxGameHelper::MakeLxUserChangeTurret(tpkg);
            sDispatcher->dispatch(tpkg);
        }
    } while(0);
    LxGameHelper::MakeHeroSwitchResp(packetResponse);
}

void HeroHandler::ProcessHeroChangeBulletReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
    HeroChangeBulletReq request;
	if ( !request.ParseFromString(packet.data())) {
        LOGINFO("parse failed");
        return;
    }
    int32 tid = request.hero_index();
    int32 itemId = request.item_id();
    int32 nRet = pUser->HeroChangeBullet(tid, itemId);
    packet.set_errorcode(nRet);
    if( nRet == JDATA->ErrorCodePtr()->GetSuccess() ) {
        pUser->SendUserInfoChange(0);
        WrapPacket tpkg = packet;
        tpkg.clear_data();
        LxGameHelper::MakeLxUserChangeTurret(tpkg);
        sDispatcher->dispatch(tpkg);
    }
    LxGameHelper::MakeHeroChangeBulletResp(packetResponse);
}

void HeroHandler::ProcessHeroLevelupReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
    HeroLevelupReq request;
	if ( !request.ParseFromString(packet.data())) {
        LOGINFO("parse failed");
        return;
    }
    packetResponse.set_errorcode(pUser->HeroLevelup(request.hero_index()));
    pUser->SendUserInfoChange(EPIC_TurretExp);
    LxGameHelper::MakeHeroLevelupResp(packetResponse);
}

void HeroHandler::ProcessHeroStarChargeReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
    HeroStarChargeReq request;
	if ( !request.ParseFromString(packet.data())) {
        LOGINFO("parse failed");
        return;
    }
    packetResponse.set_errorcode(pUser->HeroStarCharge(request.hero_index()));
    pUser->SendUserInfoChange(EPIC_TurretStarExp);
    LxGameHelper::MakeHeroStarChargeResp(packetResponse);
}

void HeroHandler::ProcessWingUpgradeReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
    WingUpgradeReq request;
	if ( !request.ParseFromString(packet.data())) {
        LOGINFO("parse failed");
        return;
    }
    WingUpgradeResp msg;
    packetResponse.set_errorcode(pUser->WingUpgrade(request.wing_index(), request.item(), msg));
    pUser->SendUserInfoChange(EPIC_SwingUpgrade);
    LxGameHelper::MakeWingUpgradeResp(packetResponse, msg);
}
