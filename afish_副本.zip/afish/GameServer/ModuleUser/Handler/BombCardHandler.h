#pragma once

#include "ServerDefine.h"

class LxUser;
class BombCardHandler
{
public:
	BombCardHandler() {};
	~BombCardHandler() {};
///////////////////////////////////////////////////////////////////////////////////////
//消息处理
public:
	static void ProcessBombActCardInfoReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessBombActCardClickReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessBombGameInfoReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessBombGamePlayReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessBombGamePoolListReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
};
