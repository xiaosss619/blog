#pragma once

#include "ServerDefine.h"

class LxUser;
class ActivityHandler
{
public:
	ActivityHandler() {};
	~ActivityHandler() {};
///////////////////////////////////////////////////////////////////////////////////////
//消息处理
public:
	static void ProcessUserExchangeReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessExchangeCodeReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessExchangeStockReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessUserActivityReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessDay7RewardReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessDay7ExpRewardReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessTurntableBonusReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessTurntablePlayReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessGetNewbieGiftReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessGeneralTaskRewardReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessMonthCardRewardReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessTreasureHuntReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessTreasureHuntResetReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessTreasureHuntSetRewardReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessDrawTenReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessDrawTenPeriodRewardReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
};
