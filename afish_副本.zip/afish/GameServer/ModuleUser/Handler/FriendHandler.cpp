#include "FriendHandler.h"
#include "LxUser.h"
#include "LxGameHelper.h"
#include "DataCache/ProtoCmdHelper.h"

void FriendHandler::ProcessFriendInfoReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	FriendInfoReq request;
	if ( !request.ParseFromString(packet.data())) {
        LOGINFO("parse failed");
        return;
    }
	FriendInfoResp response;
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());

    do{
        FETCH_RESPONSE_BREAK(packetResponse);
        uint64 uUserId = request.t_id();
        TargetInfo info;
        if( !RedisData::GetUserTargetInfo(pConnection, uUserId, info) ) {
        	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetTargetNotFound());
            break;
        }
        if( !info.has_t_pop() ) {
            info.set_t_pop(0);
        }
        *response.mutable_t_data() = info;
        if( pUser->UpdateFriend(info) ) {
            pUser->SendUserInfoChange(0);
        }
    }while(0);

    LxGameHelper::MakeFriendInfoResp(packetResponse, response);
}

void FriendHandler::ProcessFriendApplyReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	FriendApplyReq request;
	if ( !request.ParseFromString(packet.data())) {
        LOGINFO("parse failed");
        return;
    }
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    do {
        uint64 uUserId = request.t_id();
        if( uUserId == pUser->GetKey() ) {
        	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
            break;
        }
        FETCH_RESPONSE_BREAK(packetResponse);
        if( RedisData::IsUserBlocked(pConnection, uUserId, pUser->GetKey())
            || RedisData::IsUserBlocked(pConnection, pUser->GetKey(), uUserId) ) {
            packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
            break;
        }
        if( !RedisData::HasUser(uUserId, pConnection) ) {
        	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetTargetNotFound());
            break;
        }
        // 對方申請列表滿
        if( RedisData::IsApplyListFull(pConnection, uUserId) ) {
        	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetFriendApplyListFull());
            break;
        }

        // 自己好友列表滿
        if( RedisData::IsFriendListFull(pConnection, pUser->GetKey()) ) {
        	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetFriendListFulll());
            break;
        }
        string strHashKey = RedisKey::MakeUserApplyKey(uUserId);
        if( !pConnection->zadd(strHashKey, pUser->GetKey(), sGameUtils->GetFakeTimeNow()) ) {
        	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
            break;
        }
        ProtoCmdHelper::PushGmCmd(pConnection, uUserId, EIC_FriendNewApply);
    } while(0);
    LxGameHelper::MakeFriendApplyResp(packetResponse);
}

void FriendHandler::ProcessFriendApplyListReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    FriendApplyListResp response;
    do {
        FETCH_RESPONSE_BREAK(packetResponse);
        string strHashKey = RedisKey::MakeUserApplyKey(pUser->GetKey());
        std::vector< std::pair<int64, int64 > > values;
        if( pConnection->zrevrange(strHashKey, 0, -1, values) ) {
            for( size_t i = 0; i < values.size(); i++ ) {
                TargetInfo info;
                if( RedisData::GetUserTargetInfo(pConnection, values[i].first, info) ) {
                    auto ptr = response.add_datas();
                    *ptr = info;
                }
            }
        }
    }while(0);
    LxGameHelper::MakeFriendApplyListResp(packetResponse, response);
}

void FriendHandler::ProcessFriendAcceptOneReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	FriendAcceptOneReq request;
	if ( !request.ParseFromString(packet.data())) {
        LOGINFO("parse failed");
        return;
    }
    uint64 applyId = request.t_id();
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    do {
        FETCH_RESPONSE_BREAK(packetResponse);
        auto data = pUser->AcceptOneApply(pConnection, applyId);
        packetResponse.set_errorcode(TUPLE0(data));
        if( TUPLE1(data) ) {
            pConnection->zrem(RedisKey::MakeUserApplyKey(pUser->GetKey()), applyId);
        }
    } while(0);
    pUser->SendUserInfoChange(0);
    LxGameHelper::MakeFriendAcceptOneResp(packetResponse);
}

void FriendHandler::ProcessFriendAcceptAllReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	FriendAcceptAllReq request;
	if ( !request.ParseFromString(packet.data())) {
        LOGINFO("parse failed");
        return;
    }
    FriendAcceptAllResp response;
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    do {
        FETCH_RESPONSE_BREAK(packetResponse);
        string strHashKey = RedisKey::MakeUserApplyKey(pUser->GetKey());
        vector<uint64> vecApplys;
        if( !pConnection->zrevrange(strHashKey, 0, -1, vecApplys) ) {
        	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
            break;
        }
        for( size_t i = 0; i < vecApplys.size(); i++ ) {
            uint64 applyId = vecApplys[i];
            auto data = pUser->AcceptOneApply(pConnection, applyId);
            if( TUPLE1(data) ) {
                pConnection->zrem(RedisKey::MakeUserApplyKey(pUser->GetKey()), applyId);
                response.add_t_id(applyId);
            }
            if( TUPLE0(data) == JDATA->ErrorCodePtr()->GetFriendListFulll() ) {
                // 自己好友列表滿了, 跳出循環
                break;
            }
        }
    } while(0);
    pUser->SendUserInfoChange(0);
    LxGameHelper::MakeFriendAcceptAllResp(packetResponse, response);
}

void FriendHandler::ProcessFriendRejectOneReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	FriendRejectOneReq request;
	if ( !request.ParseFromString(packet.data())) {
        LOGINFO("parse failed");
        return;
    }
    uint64 applyId = request.t_id();
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    do {
        FETCH_RESPONSE_BREAK(packetResponse);
        pConnection->zrem(RedisKey::MakeUserApplyKey(pUser->GetKey()), applyId);
    } while(0);
    LxGameHelper::MakeFriendRejectOneResp(packetResponse);
}

void FriendHandler::ProcessFriendRejectAllReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    do {
        FETCH_RESPONSE_BREAK(packetResponse);
        string strHashKey = RedisKey::MakeUserApplyKey(pUser->GetKey());
        pConnection->del(strHashKey);
    } while(0);
    LxGameHelper::MakeFriendRejectAllResp(packetResponse);
}

void FriendHandler::ProcessFriendRemoveReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	FriendRemoveReq request;
	if ( !request.ParseFromString(packet.data())) {
        LOGINFO("parse failed");
        return;
    }
    uint64 fid = request.t_id();
	FriendRemoveResp response;
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    do {
        FETCH_RESPONSE_BREAK(packetResponse);
        packetResponse.set_errorcode(pUser->RemoveFriend(pConnection, fid));
    } while(0);
    pUser->SendUserInfoChange(0);
    LxGameHelper::MakeFriendRemoveResp(packetResponse, response);
}

void FriendHandler::ProcessFriendCommentReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	FriendCommentReq request;
	if ( !request.ParseFromString(packet.data())) {
        LOGINFO("parse failed");
        return;
    }
    string strComment = request.comment();
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    pUser->FriendComment(request.t_id(), request.comment());
    pUser->SendUserInfoChange(0);
    LxGameHelper::MakeFriendCommentResp(packetResponse);
}

void FriendHandler::ProcessBlockAddReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	BlockAddReq request;
	if ( !request.ParseFromString(packet.data())) {
        LOGINFO("parse failed");
        return;
    }
    packetResponse.set_errorcode(pUser->BlockAdd(request.t_id()));
    pUser->SendUserInfoChange(0);
    LxGameHelper::MakeBlockAddResp(packetResponse);
}

void FriendHandler::ProcessBlockDelReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	BlockDelReq request;
	if ( !request.ParseFromString(packet.data())) {
        LOGINFO("parse failed");
        return;
    }
    packetResponse.set_errorcode(pUser->BlockDel(request.t_id()));
    pUser->SendUserInfoChange(0);
    LxGameHelper::MakeBlockDelResp(packetResponse);
}
