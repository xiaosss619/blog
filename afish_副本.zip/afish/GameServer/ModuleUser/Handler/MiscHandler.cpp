#include "MiscHandler.h"
#include "LxUser.h"
#include "DataCache/RedisData.h"
#include "GameUtils.h"
#include "ModuleHelper.h"
#include "Dispatcher.h"
#include "LxGameLogHelper.h"
#include "LxSlot.h"

void MiscHandler::ProcessUserChargeReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
    UserChargeReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
	if( !sGameUtils->IsTestServer() ) {
		LOGERROR("CHARGE[%lu] in external server", pUser->GetKey());
		return;
	}
	tagJsonCharge tag;
	UserChargeResp response;
	if( !JDATA->ChargePtr()->ByProductName(request.product(), tag) ) {
		packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetChargeProductNotFound());
	}
	else {
		string strRandCode = GlobalUtils::GenerateRandCode(pUser->GetKey() % 1000000, 15);
		pUser->Charged(request.product(), strRandCode, strRandCode, "H5");
		packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
		auto pProduct = response.mutable_product();
		pProduct->set_product(request.product());
		pProduct->set_buy_time(sGameUtils->GetFakeTimeNow());
		pUser->SendUserInfoChange(EPIC_UserCharge);// 发送一下数据变化,同时存redis
	}
	LxGameHelper::MakeUserChargeResp(packetResponse, response);
}

void MiscHandler::ProcessModifyNameReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	ModifyNameReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
	do {
		if( request.name().size() >= MAX_NAME_LEN ) {
			packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetChangeNameInvalidName());
			break;
		}
		string strName = request.name();
		if( strName.find("'") != string::npos
			|| strName.find("\"") != string::npos
			|| strName.find("\\") != string::npos
			|| strName.find(",") != string::npos
			|| strName.find(";") != string::npos
			|| strName.find("%") != string::npos
			|| strName.find("|") != string::npos
			|| sGameUtils->IsDirtyWord(request.name()) ) {
			packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetChangeNameInvalidName());
			break;
		}
		int32 itemId = JDATA->SystemConstPtr()->GetNameChangeItem();
		if( !pUser->ItemChange(itemId, -1, ELRD_Rename, false) ) {
			packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetChangeNameNoItem());
			break;
		}
		pUser->PBSetUserName(request.name());
		pUser->SendUserInfoChange(EPIC_ChangeName);
	} while(0);
	LxGameHelper::MakeModifyNameResp(packetResponse);
}

void MiscHandler::ProcessModifySignReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	ModifySignReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
	do {
		string strSign = request.sign();
		if( strSign.size() >= MAX_SIGN_LEN ) {
			packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetChangeSignTooLong());
			break;
		}
		if( strSign.find("'") != string::npos
			|| strSign.find("\"") != string::npos
			|| strSign.find("\\") != string::npos
			|| strSign.find("%") != string::npos
			|| sGameUtils->IsDirtyWord(strSign) ) {
			packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetChangeSignInvalid());
			break;
		}
		pUser->PBSetUserSign(strSign);
		pUser->SendUserInfoChange(EPIC_ChangeSign);
	} while(0);
	LxGameHelper::MakeModifySignResp(packetResponse);
}

// 每日签到/月卡签到
void MiscHandler::ProcessSignDayReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	packetResponse.set_errorcode(pUser->SignDay());
	LxGameHelper::MakeSignDayResp(packetResponse);
}

//贫困补助
void MiscHandler::ProcessPovertyRewardReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
	do {
		pUser->SendUserInfoChange(0);
		tagJsonVIP tagVip;
		if( !JDATA->VIPPtr()->ByID(pUser->PBGetUserVip(), tagVip) || tagVip._Poverty.size() != 2 ) {
			packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
			break;
		}
		if( (int64)pUser->PBGetTodayPovertyNum() >= tagVip._Poverty[0] ) {
			packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetPovertyNumLow());
			break;
		}
		pUser->RewardPoverty(tagVip._Poverty[1]);
	} while(0);
	LxGameHelper::MakePovertyRewardResp(packetResponse);
	pUser->SendUserInfoChange(EPIC_PovertyReward);
}

void MiscHandler::ProcessSaveUserDefineDataReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	SaveUserDefineDataReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
	if( request.user_data().size() <= 4096 && RedisData::SetUserDefineData(pUser->GetKey(), request.user_data()) ) {
		packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
	}
	else {
		packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
	}
	LxGameHelper::MakeSaveUserDefineDataResp(packetResponse);
}

void MiscHandler::ProcessLevelRewardReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
	int32 nLevel = pUser->PBGetUserLevel();
	// 1级没礼包
	if( nLevel == 1 || pUser->PBGetUserLevelReward() >=nLevel ) {
		// 客户端按升级触发等级礼包自动领取, 前期升级过快会导致连续两个请求过来, 第一个把礼包领完了, 第二个返回一个错误
		// 因此这种情况, 没有能领取的认为是成功的即可
		packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
	}
	else{
		// 先把渔场内可能产生的扣金币发送下去, 保证礼包数据正确
		pUser->SendUserInfoChange(0);
		// 2级才有礼包
		int32 curRewardLv = max(2, pUser->PBGetUserLevelReward()+1);
		for( int32 i = curRewardLv; i <= nLevel ; ++i ) {
			pUser->OnQuestGetLevelGift(i);
			pUser->GiveLoot(JDATA->LevelPtr()->RewardLootByID(i), ELRI_LevelGift, false);
		}
		pUser->PBSetUserLevelReward(nLevel);// 每次领取到当前等级
		pUser->SendUserInfoChange(EPIC_LevelReward);
	}
	LxGameHelper::MakeLevelRewardResp(packetResponse);
}

void MiscHandler::ProcessGrowthRewardReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	GrowthRewardReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
	int32 nRewardLevel = request.level();
	do {
		if( pUser->PBGetUserLevel() < nRewardLevel ) {
			packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetNoGrowthReward());
			break;
		}
		if( pUser->PBGetUserGrowthFund() == 0 ) {
			packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetNoGrowthReward());
			break;
		}
		uint32 flag = pUser->PBGetUserGrowthFlag();
		tagGrowthFlag growthFlag;
		if( !sHExps->GetGrowthFlag(nRewardLevel, pUser->PBGetUserGrowthFundVersion(), growthFlag) ) {
			packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetNoGrowthReward());
			break;
		}
		if( (flag & growthFlag._flag) != 0 ) {
			packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetGrowthRewarded());
			break;
		}
		pUser->GiveLoot(growthFlag._loot, ELRI_GrowthFund, false);
		flag |= growthFlag._flag;
		pUser->PBSetUserGrowthFlag(flag);
		pUser->SendUserInfoChange(EPIC_GrowthReward);
	} while(0);
	LxGameHelper::MakeGrowthRewardResp(packetResponse);
}

void MiscHandler::ProcessQuestRewardReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	QuestRewardReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
	int32 nRet = pUser->QuestReward(request.quest_id());
	packetResponse.set_errorcode(nRet);
	if( nRet == JDATA->ErrorCodePtr()->GetSuccess() ) {
		pUser->SendUserInfoChange(EPIC_QuestReward);
	}
	LxGameHelper::MakeQuestRewardResp(packetResponse);
}

void MiscHandler::ProcessBuyTideReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	int32 maxTide = pUser->PBGetUserLastTide();
	int32 curTide = pUser->PBGetUserCurTide();
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
	do {
		if( maxTide <= curTide ) {
			packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetBuyTideNoLastTide());
			break;
		}
		list<int32> lstLoot;
		auto ret = sGameUtils->GetTideDiamond(curTide, maxTide, lstLoot);
		int64 diamond = TUPLE1(ret);
		if( TUPLE0(ret) == false || diamond == 0 ) {
			// 没找到关卡,只能说明今天的关卡已经超过了昨天的,不需要买了
			packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetBuyTideNoNeed());
			break;
		}
		if( !pUser->ChangeDiamond(-diamond, ELRD_BuyTide, false) ) {
			packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetDiamondLow());
			break;
		}
		for( auto & loot : lstLoot ) {
			pUser->GiveLoot(loot, ELRI_BuyTide, false);
		}
		pUser->PBSetUserCurTide(maxTide);
		pUser->SendUserInfoChange(EPIC_BuyTide);
	} while(0);
	LxGameHelper::MakeBuyTideResp(packetResponse);
}

void MiscHandler::ProcessUserBuyVipGiftReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	UserBuyVipGiftReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
	do {
		int32 level = request.level();
		if( pUser->PBGetUserVip() < level ) {
			packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetVipGiftLowVip());
			break;
		}
		if( pUser->IsVipGiftBought(level) ) {
			packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetVipGiftBought());
			break;
		}
		// 读取vip表,检查钻石
		tagJsonVIP vipData;
		if( !JDATA->VIPPtr()->ByID(level, vipData) || vipData._VIPRewardPack.size() != 2 ) {
			packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetVipGiftIllegal());
			break;
		}
		if( !pUser->ChangeDiamond(-vipData._VIPRewardPack[1], ELRD_BuyVipGift, false) ) {
			packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetDiamondLow());
			break;
		}
		pUser->GiveLoot(vipData._VIPRewardPack[0], ELRI_VipGift, false);
		pUser->SetVipGiftBoughtFlag(level);
		pUser->GTaskInc(e_jsonGeneralTaskCondition_VIP_Privilege, 0, 1);
		pUser->SendMail(JDATA->SystemConstPtr()->GetVIPPrivilegeMail(), GlobalUtils::ToString(level));
	} while(0);
	LxGameHelper::MakeUserBuyVipGiftResp(packetResponse);
	pUser->SendUserInfoChange(EPIC_VipGift);
}

void MiscHandler::ProcessUserBuyMarketReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	UserBuyMarketReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
	do {
		int32 ret = pUser->BuyMarket(request.product_id());
		if( ret != JDATA->ErrorCodePtr()->GetSuccess() ) {
			packetResponse.set_errorcode(ret);
			break;
		}
		pUser->SendUserInfoChange(EPIC_BuyMarket);
	} while(0);
	LxGameHelper::MakeUserBuyMarketResp(packetResponse);
}

void MiscHandler::ProcessUserRandMarketReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
	do {
		int32 num = pUser->PBGetMarketRandNum();
		int32 diamond = sGameUtils->GetMarketTimesDiamond(num+1);
		if( !pUser->ChangeDiamond(-diamond, ELRD_RandMarket, false) ) {
			packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetDiamondLow());
			break;
		}
		pUser->PBIncMarketRandNum(1);
		pUser->RandMarket(true);
	} while(0);
	LxGameHelper::MakeUserRandMarketResp(packetResponse);
}

void MiscHandler::ProcessSlotFishDrawReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	SlotFishDrawResp msg;
	msg.set_lootid(0);
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
	do {
		pUser->SendUserInfoChange(0);
		int64 curGold = pUser->PBGetSlotFishDrawCurGold();
		int32 curNum = pUser->PBGetSlotFishDrawCurNum();
		int32 lootId = (int32)sHSDFish->gamble(curNum, curGold);
		if( lootId == 0 ) {
			packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
			break;
		}
		pUser->PBSetSlotFishDrawCurGold(0);
		pUser->PBSetSlotFishDrawCurNum(0);
		pUser->GiveLoot(lootId, ELRI_SlotFishDraw, false);
		pUser->SendUserInfoChange(EPIC_SlotFishDraw);
		msg.set_lootid(lootId);
	} while(0);
	LxGameHelper::MakeSlotFishDrawResp(packetResponse, msg);
}

void MiscHandler::ProcessTodayTableRewardReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	TodayTableRewardReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
	do {
		int32 tableIndex = request.table_index();
		tagJsonGamePlay game;
		if( !JDATA->GamePlayPtr()->ByID(tableIndex, game)
			|| game._GameType != e_jsonGamePlayGameType_Classic
			|| game._RoomRewardLootID == 0 ) {
			LOGINFO("[%lu] tableIndex[%d] failed", packet.userid(), tableIndex);
			packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
			break;
		}
		if( pUser->IsTableRewarded(tableIndex) ) {
			LOGINFO("[%lu] tableIndex[%d] rewarded", packet.userid(), tableIndex);
			packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
			break;
		}
		pUser->GiveLoot(game._RoomRewardLootID, ELRI_TableReward, false);
		pUser->SetTableRewarded(tableIndex);
	} while(0);
	LxGameHelper::MakeTodayTableRewardResp(packetResponse);
	pUser->SendUserInfoChange(EPIC_TableReward);
}

void MiscHandler::ProcessBattlePassRewardReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
	do {
		vector<int32> vecLoots;
		int64 bpExp = pUser->PBGetBattlePassExp();
		int32 nowLv = pUser->PBGetBattlePassNow();
		int32 vipNowLv = pUser->PBGetBattlePassVipNow();
		JDATA->BattlePassPtr()->ForEachWithBreak([&](tagJsonBattlePass* ptr){
			if( bpExp >= ptr->_TotalExp ) {
				// 可领
				if( nowLv < ptr->_ID && ptr->_RewardLoot.size() >= 1 ) {
					if( pUser->IsSensitiveSystemBanned(EUSTF_Voucher) ) {
						// 说明禁止话费了
						if( ptr->_ChannelRewardLoot.size() >= 1 ) {
							vecLoots.push_back(ptr->_ChannelRewardLoot[0]);
						}
					}
					else {
						if( ptr->_RewardLoot.size() >= 1 ) {
							vecLoots.push_back(ptr->_RewardLoot[0]);
						}
					}
					nowLv = ptr->_ID;
				}
				if( vipNowLv != -1 && vipNowLv < ptr->_ID ) {
					if( pUser->IsSensitiveSystemBanned(EUSTF_Voucher) ) {
						// 说明禁止话费了
						if( ptr->_ChannelRewardLoot.size() >= 2 ) {
							vecLoots.push_back(ptr->_ChannelRewardLoot[1]);
						}
					}
					else {
						if( ptr->_RewardLoot.size() >= 2 ) {
							vecLoots.push_back(ptr->_RewardLoot[1]);
						}
					}
					vipNowLv = ptr->_ID;
				}
				return false;
			}
			else {
				return true;
			}
		});
		pUser->SendUserInfoChange(0);
		if( vecLoots.size() > 0 ) {
			pUser->PBSetBattlePassNow(nowLv);
			pUser->PBSetBattlePassVipNow(vipNowLv);
			for( size_t i = 0; i < vecLoots.size() ; ++i ) {
				pUser->GiveLoot(vecLoots[i], ELRI_BattlePass, false);
			}
			pUser->SendUserInfoChange(EPIC_BattlePass);
		}
	} while(0);
	LxGameHelper::MakeBattlePassRewardResp(packetResponse);
}

void MiscHandler::ProcessPassportRewardReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
	pUser->PassportReward();
	LxGameHelper::MakePassportRewardResp(packetResponse);
}

void MiscHandler::ProcessPassportBuyExpReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	PassportBuyExpReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
	packetResponse.set_errorcode(pUser->PassportBuyExp(request.levels()));
	LxGameHelper::MakePassportBuyExpResp(packetResponse);
}

void MiscHandler::ProcessTechUpgradeReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	TechUpgradeReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
	packetResponse.set_errorcode(pUser->TechUpgrade(request.tech_id()));
	LxGameHelper::MakeTechUpgradeResp(packetResponse);
}

void MiscHandler::ProcessTechAccelerateReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	TechAccelerateReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
	packetResponse.set_errorcode(pUser->TechAccelerate(request));
	LxGameHelper::MakeTechAccelerateResp(packetResponse);

}
