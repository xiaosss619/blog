#include "BombCardHandler.h"
#include "LxUser.h"
#include "DataCache/RedisData.h"
#include "GameUtils.h"
#include "ModuleHelper.h"
#include "Dispatcher.h"
#include "LxGameLogHelper.h"

void BombCardHandler::ProcessBombActCardInfoReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
	BombActCardInfoResp msg;
	do {
		pUser->GetBombActInfo(msg);
	}while(0);
	LxGameHelper::MakeBombActCardInfoResp(packetResponse, msg);
}

void BombCardHandler::ProcessBombActCardClickReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	BombActCardClickReq request;
	if(!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());

	BombActCardClickResp msg;
	do {
		if( pUser->PBGetBombActCardNum() <= 0 ) {
			packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetBombActCardNumZero());
			break;
		}
		pUser->SendUserInfoChange(0);
		if( request.pos() < 0 || request.pos() >= sHBombAct->GetMaxCardNum() ) {
			packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
			break;
		}
		int32 ret = pUser->CardClick(request.pos(), msg);
		if( ret != JDATA->ErrorCodePtr()->GetSuccess() ) {
			packetResponse.set_errorcode(ret);
			break;
		}
		pUser->PBDecBombActCardNum(1);
		pUser->SendUserInfoChange(EPIC_BombActCardRelation);
	}while(0);
	LxGameHelper::MakeBombActCardClickResp(packetResponse, msg);
}

void BombCardHandler::ProcessBombGameInfoReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
	BombGameInfoResp msg;
	do {
		pUser->GetBombGameInfo(msg);
	}while(0);
	LxGameHelper::MakeBombGameInfoResp(packetResponse, msg);
}

void BombCardHandler::ProcessBombGamePlayReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	BombGamePlayReq request;
	if(!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());

	BombGamePlayResp msg;
	do {
		int32 times = request.times();
		int32 ret = pUser->PlayBombGame(times, msg);
		if( ret != JDATA->ErrorCodePtr()->GetSuccess() ) {
			break;
		}
		pUser->SendUserInfoChange(EPIC_BombGameReward);
	}while(0);
	LxGameHelper::MakeBombGamePlayResp(packetResponse, msg);
}

void BombCardHandler::ProcessBombGamePoolListReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
	BombGamePoolListResp msg;
	do {
		sRankingList->GetBombGamePoolList(msg);
	}while(0);
	LxGameHelper::MakeBombGamePoolListResp(packetResponse, msg);
}

