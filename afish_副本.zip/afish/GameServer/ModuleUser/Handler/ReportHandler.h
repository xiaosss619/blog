#pragma once

#include "ServerDefine.h"

class LxUser;
class ReportHandler
{
public:
	ReportHandler() {};
	~ReportHandler() {};
///////////////////////////////////////////////////////////////////////////////////////
//消息处理
public:
    static void ProcessReportDeviceInfo(LxUser* pUser, WrapPacket& pkg, WrapPacket& response);
    static void ProcessReportProductStatus(LxUser* pUser, WrapPacket& pkg, WrapPacket& response);
    static void ProcessReportFrameNum(LxUser* pUser, WrapPacket& pkg, WrapPacket& response);
    static void ProcessReportGuideStep(LxUser* pUser, WrapPacket& pkg, WrapPacket& response);
    static void ProcessReportUserActList(LxUser* pUser, WrapPacket& pkg, WrapPacket& response);
    static void ProcessReportUserActSingle(LxUser* pUser, WrapPacket& pkg, WrapPacket& response);
};
