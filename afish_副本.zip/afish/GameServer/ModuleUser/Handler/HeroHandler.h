#pragma once

#include "ServerDefine.h"

class LxUser;
class HeroHandler
{
public:
	HeroHandler() {};
	~HeroHandler() {};
///////////////////////////////////////////////////////////////////////////////////////
//消息处理
public:
	static void ProcessHeroSwitchReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessHeroChangeBulletReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessHeroLevelupReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessHeroStarChargeReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessWingUpgradeReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
};
