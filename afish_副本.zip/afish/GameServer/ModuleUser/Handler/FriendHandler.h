#pragma once

#include "ServerDefine.h"

class LxUser;
class FriendHandler
{
public:
	FriendHandler() {};
	~FriendHandler() {};
///////////////////////////////////////////////////////////////////////////////////////
//消息处理
public:
    static void ProcessFriendInfoReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
    static void ProcessFriendApplyReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
    static void ProcessFriendApplyListReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
    static void ProcessFriendAcceptOneReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
    static void ProcessFriendAcceptAllReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
    static void ProcessFriendRejectOneReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
    static void ProcessFriendRejectAllReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
    static void ProcessFriendRemoveReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
    static void ProcessFriendCommentReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
    static void ProcessBlockAddReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
    static void ProcessBlockDelReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
};
