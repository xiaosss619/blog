#pragma once

#include "ServerDefine.h"

class LxUser;
class InventoryHandler
{
public:
	InventoryHandler() {};
	~InventoryHandler() {};
///////////////////////////////////////////////////////////////////////////////////////
//消息处理
public:
    static void ProcessUserItemReq(LxUser* pUser, WrapPacket& pkg, WrapPacket& response);
    static void ProcessUserItemUseReq(LxUser* pUser, WrapPacket& pkg, WrapPacket& response);
};
