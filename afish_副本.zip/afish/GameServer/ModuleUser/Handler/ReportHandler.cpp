#include "ReportHandler.h"
#include "LxUser.h"
#include "LxGameLogHelper.h"
#include "Dispatcher.h"

void ReportHandler::ProcessReportDeviceInfo(LxUser* pUser, WrapPacket& pkg, WrapPacket& packetResponse) {
    packetResponse.clear_userid();
    ReportDeviceInfo msg;
    if(!msg.ParseFromString(pkg.data())) {
        LOGINFO("parse failed [%lu]", pkg.userid());
        return;
    }
    LOG_USER_DEVICE(pUser
                    , msg.info().dev_game_id()
                    , msg.info().dev_app_id()
                    , msg.info().dev_package_name()
                    , msg.info().dev_channel_id()
                    , msg.info().dev_idfa()
                    , msg.info().dev_idfv()
                    , msg.info().dev_android_id()
                    , msg.info().dev_google_aid()
                    , msg.info().dev_oaid()
                    , msg.info().dev_language()
                    , msg.info().dev_carrier()
                    , msg.info().dev_os_type()
                    , msg.info().dev_app_version()
                    , msg.info().dev_original_app_version()
                    , msg.info().dev_type()
                    , msg.info().dev_brand()
                    , msg.info().dev_mode()
                    , msg.info().dev_adid()
                    , msg.info().dev_sdk_version());
}

void ReportHandler::ProcessReportProductStatus(LxUser* pUser, WrapPacket& pkg, WrapPacket& response) {
    response.clear_userid();
    ReportProductStatus msg;
    if(!msg.ParseFromString(pkg.data())) {
        LOGINFO("parse failed [%lu]", pkg.userid());
        return;
    }
    for( int i = 0; i < msg.products_size() ; ++i ) {
        auto prd = msg.products(i);
        LOG_PRODUCT_REPRESENT(pUser, prd.product_name(), prd.show_num());
    }
}

void ReportHandler::ProcessReportFrameNum(LxUser* pUser, WrapPacket& pkg, WrapPacket& response) {
    response.clear_userid();
    ReportFrameNum msg;
    if(!msg.ParseFromString(pkg.data())) {
        LOGINFO("parse failed [%lu]", pkg.userid());
        return;
    }
    // 防一手客户端, 30秒记录一次frame
    int64 tNow = sGameUtils->GetFakeTimeNow();
    if( tNow - pUser->GetLastLowFrameTime() >= 30 ) {
        pUser->SetLastLowFrameTime( tNow );
        LOG_FRAME_NUM(pUser, msg.frame_num());
    }
}

void ReportHandler::ProcessReportGuideStep(LxUser* pUser, WrapPacket& pkg, WrapPacket& response) {
    response.clear_userid();
    ReportGuideStep msg;
    if(!msg.ParseFromString(pkg.data())) {
        LOGINFO("parse failed [%lu]", pkg.userid());
        return;
    }
    LOG_GUIDE_STEP(pUser, msg.step());
}

void ReportHandler::ProcessReportUserActList(LxUser* pUser, WrapPacket& pkg, WrapPacket& response) {
    response.clear_userid();
    ReportUserActList msg;
    if(!msg.ParseFromString(pkg.data())) {
        LOGINFO("parse failed [%lu]", pkg.userid());
        return;
    }
    for( int32 i = 0; i < msg.act_size() ; ++i ) {
        LOG_BEFORE_CHARGE(pUser, msg.act(i), i, msg.product_name());
    }
}

void ReportHandler::ProcessReportUserActSingle(LxUser* pUser, WrapPacket& pkg, WrapPacket& response) {
    response.clear_userid();
    ReportUserActSingle msg;
    if(!msg.ParseFromString(pkg.data())) {
        LOGINFO("parse failed [%lu]", pkg.userid());
        return;
    }
    LOG_AFTER_CHARGE(pUser, msg.act());
}
