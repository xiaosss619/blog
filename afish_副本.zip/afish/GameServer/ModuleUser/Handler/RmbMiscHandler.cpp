#include "RmbMiscHandler.h"
#include "LxUser.h"

void RmbMiscHandler::ProcessNewbieFeeRewardReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
	do {
		int64 tNow = sGameUtils->GetFakeTimeNow();
		if( pUser->PBGetNewbieFeeId() == 0 || tNow >= pUser->PBGetNewbieFeeEnd() ) {
			packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetNewbieFeeEmpty());
			break;
		}
		tagJsonRedEnvelope tag;
		if( !JDATA->RedEnvelopePtr()->ByID(pUser->PBGetNewbieFeeId(), tag) ) {
			packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetNewbieFeeDone());
			break;
		}
		int32 iDrawRewardNum = pUser->PBGetNewbieFeeDraw();	// 当前领奖阶段
		if( iDrawRewardNum >= (int32)tag._TargetList.size() ) {
			packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
			break;
		}
		int64 iCurGold = pUser->PBGetNewbieFeeGold();	// 当前累计消耗金币
		if( iCurGold < tag._TargetList[iDrawRewardNum] ) {
			packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetNewbieFeeNoDraw());
			break;
		}
		int32 iVoucherLeft = tag._PhoneVoucherMax - pUser->PBGetNewbieFeeCoupon();	// 剩余话费券总量
		double mu = iVoucherLeft*1.0f/(tag._TargetList.size() - iDrawRewardNum);
		double sigma = mu / (tag._SigmaParam/100.0f);
		int32 iVoucherNum = pUser->GetNormalDistributionNumber(mu, sigma);
		if( iVoucherNum <= 0 ) {
			iVoucherNum = 1;
		}
		pUser->PBIncNewbieFeeDraw(1);
		pUser->PBIncNewbieFeeCoupon(iVoucherNum);
		if( pUser->IsSensitiveSystemBanned(EUSTF_Voucher) && tag._ChannelExchange.size() == 2 ) {
			pUser->ItemChange(tag._ChannelExchange[0], iVoucherNum*tag._ChannelExchange[1], ELRI_NewbieFee, false);
		}
		else {
			pUser->ItemChange(JDATA->SystemConstPtr()->GetPhoneVoucherItemID(), iVoucherNum, ELRI_NewbieFee, false);
		}

		pUser->SendUserInfoChange(EPIC_NewbieFee);
	} while(0);
	LxGameHelper::MakeNewbieFeeRewardResp(packetResponse);
}

void RmbMiscHandler::ProcessDrawRmbInfoReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    DrawRmbInfoResp msg;
    pUser->GetDrawRmbClientInfo(*msg.mutable_data());
    LxGameHelper::MakeDrawRmbInfoResp(packetResponse, msg);
}

void RmbMiscHandler::ProcessDrawRmbOpenReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    DrawRmbOpenResp msg;
    do {
        int32 ret = pUser->DrawOpen();
        if( ret != JDATA->ErrorCodePtr()->GetSuccess() ) {
	        packetResponse.set_errorcode(ret);
            break;
        }
        pUser->GetDrawRmbClientInfo(*msg.mutable_data());
    }while(0);
    LxGameHelper::MakeDrawRmbOpenResp(packetResponse, msg);
}

void RmbMiscHandler::ProcessDrawRmbCloseReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    DrawRmbCloseResp msg;
    do {
        int32 ret = pUser->DrawClose();
        if( ret != JDATA->ErrorCodePtr()->GetSuccess() ) {
	        packetResponse.set_errorcode(ret);
            break;
        }
        pUser->GetDrawRmbClientInfo(*msg.mutable_data());
    }while(0);
    LxGameHelper::MakeDrawRmbCloseResp(packetResponse, msg);
}

void RmbMiscHandler::ProcessDrawRmbDrawReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	DrawRmbDrawReq request;
	if(!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}

	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    DrawRmbDrawResp msg;
    do {
        int32 ret = pUser->DrawReward(request.pos(), false);
        if( ret != JDATA->ErrorCodePtr()->GetSuccess() ) {
	        packetResponse.set_errorcode(ret);
            break;
        }
        pUser->GetDrawRmbClientInfo(*msg.mutable_data());
    }while(0);
    LxGameHelper::MakeDrawRmbDrawResp(packetResponse, msg);
}

void RmbMiscHandler::ProcessRmbCardRewardReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	RmbCardRewardReq request;
	if(!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
	int64 tNow = sGameUtils->GetFakeTimeNow();
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    do {
		pUser->SendUserInfoChange(0);
		int32 lootId = JDATA->MonthCardPtr()->DailyRewardByID(request.type());
		if( lootId == 0 ) {
			packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
			break;
		}
		int32 reason = 0;
		if( request.type() == e_jsonChargeProductType_WeeklyCard ) {
			if( !pUser->IsRmbCardWeek(tNow) ) {
				packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetWeekCardInvalid());
				break;
			}
			if( pUser->IsRmbCardRewarded(EUTF_WeekCardReward) ) {
				packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetRmbCardRewarded());
				break;
			}
			pUser->SetRmbCardReward(EUTF_WeekCardReward);
			reason = ELRI_WeekCardReward;
		}
		else if( request.type() == e_jsonChargeProductType_MonthCard ) {
			if( !pUser->IsRmbCardMonth(tNow) ) {
				packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetMonthCardInvalid());
				break;
			}
			if( pUser->IsRmbCardRewarded(EUTF_MonthCardReward) ) {
				packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetRmbCardRewarded());
				break;
			}
			pUser->SetRmbCardReward(EUTF_MonthCardReward);
			reason = ELRI_MonthCardReward;
		}
		else if( request.type() == e_jsonChargeProductType_SuperMonthCard ) {
			if( !pUser->IsRmbCardSuperMonth(tNow) ) {
				packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuperMonthCardInvalid());
				break;
			}
			if( pUser->IsRmbCardRewarded(EUTF_SuperMonthCardReward) ) {
				packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetRmbCardRewarded());
				break;
			}
			pUser->SetRmbCardReward(EUTF_SuperMonthCardReward);
			reason = ELRI_SuperMonthCardReward;
		}
		pUser->GiveLoot(lootId, reason, false);
		pUser->SendUserInfoChange(EPIC_RmbCardReward);
    }while(0);
    LxGameHelper::MakeRmbCardRewardResp(packetResponse);
}
