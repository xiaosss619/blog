#include "TechHandler.h"
#include "LxUser.h"
#include "DataCache/RedisData.h"
#include "GameUtils.h"
#include "ModuleHelper.h"
#include "Dispatcher.h"
#include "LxGameLogHelper.h"
#include "LxSlot.h"

void TechHandler::ProcessTechUpgradeReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	TechUpgradeReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
	packetResponse.set_errorcode(pUser->TechUpgrade(request.tech_id()));
	LxGameHelper::MakeTechUpgradeResp(packetResponse);
}

void TechHandler::ProcessTechAccelerateReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	TechAccelerateReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
	packetResponse.set_errorcode(pUser->TechAccelerate(request));
	LxGameHelper::MakeTechAccelerateResp(packetResponse);
}

void TechHandler::ProcessTechProduceReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	TechProduceReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
	packetResponse.set_errorcode(pUser->TechProduce(request.tech_id(), request.materials()));
	LxGameHelper::MakeTechProduceResp(packetResponse);
}

void TechHandler::ProcessTechProductGetReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	TechProductGetReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
	packetResponse.set_errorcode(pUser->TechProductGet(request.tech_id()));
	LxGameHelper::MakeTechProductGetResp(packetResponse);
}

void TechHandler::ProcessTechProduceAccelerateReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	TechProduceAccelerateReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
	packetResponse.set_errorcode(pUser->TechProduceAccelerate(request));
	LxGameHelper::MakeTechProduceAccelerateResp(packetResponse);
}
