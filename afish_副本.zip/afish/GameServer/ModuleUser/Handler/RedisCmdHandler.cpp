#include "RedisCmdHandler.h"
#include "LxUser.h"
#include "GameUtils.h"
#include "ThreadUser.h"
#include "Dispatcher.h"
#include "DataCache/ProtoCmdHelper.h"
#include "LxGameLogHelper.h"

void RedisCmdHandler::ProcessCmd(RedisConnection* pConnection, LxUser* pUser) {
    bool needSync = false;
    ProtoCmdHelper::ForEachGmCmd(pConnection, pUser->GetKey(), [&](const string& strCmd){
        LOGDEBUG("CMD %s ", strCmd.c_str());
        Document doc;
        if( doc.Parse(strCmd.data()).HasParseError() ) {
            LOGERROR("FORMAT failed[%s]", strCmd.c_str());
            return;
        }
        rapidjson::Value& json_obj = doc;
        if( !json_obj.IsArray() ) {
            LOGERROR("FORMAT failed[%s]", strCmd.c_str());
            return;
        }
        for( rapidjson::SizeType i = 0 ; i < json_obj.Size() ; i++ ) {
            // 每个json_obj都是一条命令
            if( !json_obj[i].HasMember("cmd") || !json_obj[i].HasMember("param") ) {
                LOGERROR("FORMAT failed[%s][%d]", strCmd.c_str(), i);
                return;
            }
            int32 cmd = json_obj[i]["cmd"].GetInt();
            Do(pUser, cmd, json_obj[i]["param"]);
        }
        needSync = true;
    });
	{
		// 读一下系统邮件
		map<int64, tagSystemMail> mapMail;
		int64 iMaxSysMailId = sGameUtils->GetUserSystemMail(pUser->PBGetLastSysMailid(), mapMail);
		for( auto & it : mapMail ) {
            if( pUser->PBGetTimeRegister() <= it.second._timestamp ) {
                // 大于注册时间的公告才会发
                pUser->SendMail(0, 0, 0, it.second._mapItem, it.second._title, it.second._content);
                needSync = true;
            }
		}
        pUser->PBSetLastSysMailid(iMaxSysMailId);
	}
    {
        vector<string> vecMail;
        pConnection->rpop(RedisKey::MakeUserOfflineMailKey(pUser->GetKey()), 100, vecMail);
        for( size_t i = 0; i < vecMail.size(); i++ ) {
            LxMail mail;
            if(!JsonProto::ProtoFromJson(vecMail[i], mail)) {
                LOGERROR("format error [%s]", vecMail[i].data());
                continue;
            }
            pUser->SendMail(mail);
            needSync = true;
        }
    }
    {
        CheckProtoCmd(pUser, pConnection);
    }

    if( needSync ) {
        pUser->SendUserInfoChange(EPIC_FromGM);
    }
}

void RedisCmdHandler::DoCommandGMMail(LxUser* pUser, const rapidjson::Value& param) {
    //
    string title = param["title"].GetString();
    string content = param["content"].GetString();
    map<int32, int64> mapItem;
    if( param.HasMember("items") && param["items"].IsArray() ) {
        for( uint32 i = 0 ; i < param["items"].Size() ; i++ ) {
            int32 iItemId = param["items"][i]["item"].GetInt();
            int64 iItemNum = param["items"][i]["num"].GetInt64();
            if( JDATA->ItemPtr()->ContainID(iItemId) && iItemNum > 0 ) {
                auto it = mapItem.find(iItemId);
                if( it != mapItem.end() ) {
                    it->second += iItemNum;
                }
                else {
                    mapItem[iItemId] = iItemNum;
                }
            }
        }
    }
    pUser->SendMail(0, 0, 0, mapItem, title, content);
}

void RedisCmdHandler::DoCommandRewardCode(LxUser* pUser, const rapidjson::Value& param) {
    int32 nRetCode = param["retcode"].GetInt();
    if( nRetCode == 1000 ) {
        int64 iDiamond = param["diamond"].GetInt64();
        int64 iGold = param["gold"].GetInt64();
        if( param.HasMember("items") && param["items"].IsArray() ) {
            for( uint32 i = 0 ; i < param["items"].Size() ; i++ ) {
                int32 iItemId = param["items"][i]["item"].GetInt();
                int64 iItemNum = param["items"][i]["num"].GetInt64();
                pUser->ItemChange(iItemId, iItemNum, iItemNum > 0 ? (int32)ELRI_RewardCode : (int32)ELRI_RewardCode, false);
            }
            pUser->ChangeDiamond(iDiamond, iDiamond > 0 ? (int32)ELRI_RewardCode : (int32)ELRI_RewardCode, false);
            pUser->ChangeGold(iGold, iGold > 0 ? (int32)ELRI_RewardCode : (int32)ELRI_RewardCode);
            pUser->SendUserInfoChange(EPIC_ExchangeCode);
            SyncExchangeCodeResult msg;
            msg.set_result(0);// 返回错误+2000定义在ErrorCode表中
            CALL_CLIENT(pUser, SyncExchangeCodeResult, msg);
        }
    }
    else {
        SyncExchangeCodeResult msg;
        msg.set_result(nRetCode + 2000);// 返回错误+2000定义在ErrorCode表中
        CALL_CLIENT(pUser, SyncExchangeCodeResult, msg);
    }
}

void RedisCmdHandler::Do(LxUser* pUser, int32 cmd, const rapidjson::Value& param) {
    string strLog = GlobalUtils::MakeJson(param);
    vector<string> vec;
    if( param.IsString() ) {
        GlobalUtils::GetStrArray(param.GetString(), ",", vec);
    }
    LOGDEBUG("REDIS CMD user[%lu] cmd[%d] param[%s] vec[%d]", pUser->GetKey(), cmd, strLog.c_str(), vec.size());
TRYBEGIN()
    switch( cmd ) {
    case EIC_Gold: { pUser->ChangeGold(param.GetInt64(), ELRI_GM); break; }
    case EIC_Item: { pUser->ItemChange(boost::lexical_cast<int32>(vec[0]), boost::lexical_cast<int32>(vec[1]), ELRI_GM, false); break; }
    case EIC_Diamond: { pUser->ChangeDiamond(param.GetInt(), ELRI_GM, false); break; }
    case EIC_Exp: { pUser->AddExp(param.GetInt()); break; }
    case EIC_Charge:
        if( vec.size() == 3 ) {
            pUser->Charged(vec[0], vec[1], vec[2], "");
            pUser->SendUserInfoChange(EPIC_UserCharge);
        }
        else if( vec.size() == 4 ) {
            pUser->Charged(vec[0], vec[1], vec[2], vec[3]);
            pUser->SendUserInfoChange(EPIC_UserCharge);
        }
        else {
            LOGERROR("GM charge failed [%s]", param.GetString());
        }
        break;
    case EIC_Yell:
    {
        list<string> lstData;
        lstData.push_back(param.GetString());
        sDispatcher->broadcast_rolling_msg(e_jsonAnnouncementID_officialAnn, "", lstData);
        break;
    }
    case EIC_RewardCode:{ DoCommandRewardCode(pUser, param); break;}
    case EIC_GMMail:{ DoCommandGMMail(pUser, param); break;}
    case EIC_BindPhone: { pUser->BindUserPhone(vec[0]); break;}
    case EIC_BindIdCard: { pUser->BindUserIdCard(vec[0]); break;}
    case EIC_FriendNewApply: { pUser->NotifyNewFriendApply(); break;}
    case EIC_FriendApplyAccepted: { pUser->FriendApplyAccepted(boost::lexical_cast<uint64>(vec[0])); break;}
    case EIC_FriendForceRemoved: { pUser->FriendForceRemoved(boost::lexical_cast<uint64>(vec[0])); break;}
    case EIC_FriendUpdate: { pUser->UpdateFriend(boost::lexical_cast<uint64>(vec[0])); break;}
    case EIC_BindFBID: { pUser->PBSetUserFbid(vec[0]); break;}
    case EIC_GiftCode: { pUser->SetGiftCode(vec[0]); break;}
    case EIC_GiftWithdraw: { pUser->GiftWitdraw(vec[0]); break; }
    case EIC_SetPopularity: { pUser->PBIncPopularity(param.GetInt()); break; }
    case EIC_Mute: { pUser->PBSetTimeMuteEnd(boost::lexical_cast<int64>(vec[0])); break; }
    case EIC_UpdateField: {
        if( vec.size() == 1 ) {
            vector<string> field;
            GlobalUtils::GetStrArray(vec[0], "|", field);
            if( field.size() == 2 ) {
                pUser->SetFieldValue(field[0], field[1]);
            }
        }
        break;
    }
    case EIC_KickUser: { sDispatcher->kick_user(pUser->GetKey()); break; }
    case EIC_GiftRecv:
        if( vec.size() == 1 ) {
            vector<int64> items;
            GlobalUtils::GetNumArray(vec[0], "|", items);
            if( items.size() == 2 ) {
                pUser->SendUserInfoChange(0);
                pUser->ItemChange(items[0], items[1], ELRI_RecvGift, false);
                pUser->SendUserInfoChange(EPIC_GiftGet);
            }
        }
        break;
    case EIC_KickRelogin: {
        if( vec.size() == 1 ) {
            vector<int64> items;
            GlobalUtils::GetNumArray(vec[0], "|", items);
            if( items.size() == 2 ) {
                int32 serverId = items[0];
                int32 linkId = items[1];
                LOGINFO("user[%u]server[%d]link[%d] kicked by server[%d]link[%d]", pUser->GetKey(), sGameUtils->GetServerId(), pUser->GetConnectionId(), serverId, linkId);
                if( serverId != sGameUtils->GetServerId() || linkId != pUser->GetConnectionId() ) {
                    sDispatcher->kick_duplicate_user(pUser->GetKey());
                }
            }
        }
        break;
    }
    default:
        break;
    }
TRYEND(strLog)
}

void RedisCmdHandler::CheckProtoCmd(LxUser* pUser, RedisConnection* pConnection) {
    ProtoCmdHelper::ForEachUserCmd(pConnection, pUser->GetKey(), [&](const UserProtoCmd& cmd){
        switch( cmd.cmd() ) {
        case CHAT_SyncGiftStatus:
        {
            CALL_CLIENT(pUser, SyncGiftStatus, cmd.sync_gift_status());
            GiftData gift;
            if( RedisData::GetGift(pConnection, cmd.sync_gift_status().gid(), gift) ) {
                LOG_GIFT(gift);
            }
            break;
        }
        case CHAT_MsgInfoResp:
        {
            if( cmd.errorcode() != JDATA->ErrorCodePtr()->GetSuccess() ) {
                RESPONSE_WITH_CODE(pUser, cmd.requestid(), cmd.errorcode(), MsgInfoResp);
            }
            else {
                RESPONSE_WITH_DATA(pUser, cmd.requestid(), MsgInfoResp, cmd.msg_info_resp());
            }
            break;
        }
        case CHAT_ChatResp:
        {
            // 对于resp只需要一个错误码的回包, 不需要设置数据部分
            RESPONSE_EMPTY(pUser, cmd.requestid(), cmd.errorcode(), ChatResp);
            break;
        }
        case CHAT_SyncChatMessage:
        {
            CALL_CLIENT(pUser, SyncChatMessage, cmd.sync_chat_message());
            break;
        }
        case CHAT_SyncChatGroupData:
        {
            CALL_CLIENT(pUser, SyncChatGroupData, cmd.sync_chat_group_data());
            break;
        }
        case CHAT_SyncKickedByGroup:
        {
            CALL_CLIENT(pUser, SyncKickedByGroup, cmd.sync_kicked_by_group());
            break;
        }
        case CHAT_SyncChatGroupDismissed:
        {
            CALL_CLIENT(pUser, SyncChatGroupDismissed, cmd.sync_chat_group_dismissed());
            break;
        }
        case CHAT_SyncChatGroupRename:
        {
            CALL_CLIENT(pUser, SyncChatGroupRename, cmd.sync_chat_group_rename());
            break;
        }
        case CHAT_SyncChatGroupNewUser:
        {
            CALL_CLIENT(pUser, SyncChatGroupNewUser, cmd.sync_chat_group_new_user());
            break;
        }
        case CHAT_SyncChatGroupDelUser:
        {
            CALL_CLIENT(pUser, SyncChatGroupDelUser, cmd.sync_chat_group_del_user());
            break;
        }
        case CHAT_ChatGroupCreateResp:
        {
            if( cmd.errorcode() != JDATA->ErrorCodePtr()->GetSuccess() ) {
                RESPONSE_WITH_CODE(pUser, cmd.requestid(), cmd.errorcode(), ChatGroupCreateResp);
            }
            else {
                RESPONSE_WITH_DATA(pUser, cmd.requestid(), ChatGroupCreateResp, cmd.chat_group_create_resp());
            }
            break;
        }
        case CHAT_ChatGroupRenameResp:
        {
            // 对于resp只需要一个错误码的回包, 不需要设置数据部分
            RESPONSE_EMPTY(pUser, cmd.requestid(), cmd.errorcode(), ChatGroupRenameResp);
            break;
        }
        case CHAT_ChatGroupResetPwdResp:
        {
            // 对于resp只需要一个错误码的回包, 不需要设置数据部分
            RESPONSE_EMPTY(pUser, cmd.requestid(), cmd.errorcode(), ChatGroupResetPwdResp);
            break;
        }
        case CHAT_ChatGroupInviteResp:
        {
            // 对于resp只需要一个错误码的回包, 不需要设置数据部分
            RESPONSE_EMPTY(pUser, cmd.requestid(), cmd.errorcode(), ChatGroupInviteResp);
            break;
        }
        case CHAT_ChatGroupAcceptInviteResp:
        {
            // 对于resp只需要一个错误码的回包, 不需要设置数据部分
            RESPONSE_EMPTY(pUser, cmd.requestid(), cmd.errorcode(), ChatGroupAcceptInviteResp);
            break;
        }
        case CHAT_ChatGroupSearchResp:
        {
            if( cmd.errorcode() != JDATA->ErrorCodePtr()->GetSuccess() ) {
                RESPONSE_WITH_CODE(pUser, cmd.requestid(), cmd.errorcode(), ChatGroupSearchResp);
            }
            else {
                RESPONSE_WITH_DATA(pUser, cmd.requestid(), ChatGroupSearchResp, cmd.chat_group_search_resp());
            }
            break;
        }
        case CHAT_ChatGroupJoinResp:
        {
            if( cmd.errorcode() != JDATA->ErrorCodePtr()->GetSuccess() ) {
                RESPONSE_WITH_CODE(pUser, cmd.requestid(), cmd.errorcode(), ChatGroupJoinResp);
            }
            else {
                RESPONSE_WITH_DATA(pUser, cmd.requestid(), ChatGroupJoinResp, cmd.chat_group_join_resp());
            }
            break;
        }
        case CHAT_ChatGroupQuitResp:
        {
            // 对于resp只需要一个错误码的回包, 不需要设置数据部分
            RESPONSE_EMPTY(pUser, cmd.requestid(), cmd.errorcode(), ChatGroupQuitResp);
            break;
        }
        case CHAT_ChatGroupDismissResp:
        {
            // 对于resp只需要一个错误码的回包, 不需要设置数据部分
            RESPONSE_EMPTY(pUser, cmd.requestid(), cmd.errorcode(), ChatGroupDismissResp);
            break;
        }
        case CHAT_ChatGroupKickResp:
        {
            // 对于resp只需要一个错误码的回包, 不需要设置数据部分
            RESPONSE_EMPTY(pUser, cmd.requestid(), cmd.errorcode(), ChatGroupKickResp);
            break;
        }
        case CHAT_ChatGroupClearChatResp:
        {
            // 对于resp只需要一个错误码的回包, 不需要设置数据部分
            RESPONSE_EMPTY(pUser, cmd.requestid(), cmd.errorcode(), ChatGroupClearChatResp);
            break;
        }
        case CHAT_ChatGroupListResp:
        {
            if( cmd.errorcode() != JDATA->ErrorCodePtr()->GetSuccess() ) {
                RESPONSE_WITH_CODE(pUser, cmd.requestid(), cmd.errorcode(), ChatGroupListResp);
            }
            else {
                RESPONSE_WITH_DATA(pUser, cmd.requestid(), ChatGroupListResp, cmd.chat_group_list_resp());
            }
            break;
        }
        default:
            LOGERROR("unknow proto cmd[%ld]", cmd.cmd());
            break;
        }
    });
}
