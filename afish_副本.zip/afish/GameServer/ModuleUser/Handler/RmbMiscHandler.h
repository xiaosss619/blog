#pragma once

#include "ServerDefine.h"

class LxUser;
class RmbMiscHandler
{
public:
	RmbMiscHandler() {};
	~RmbMiscHandler() {};
///////////////////////////////////////////////////////////////////////////////////////
//消息处理
public:
	static void ProcessNewbieFeeRewardReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessDrawRmbInfoReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessDrawRmbOpenReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessDrawRmbCloseReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessDrawRmbDrawReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
	static void ProcessRmbCardRewardReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse);
};
