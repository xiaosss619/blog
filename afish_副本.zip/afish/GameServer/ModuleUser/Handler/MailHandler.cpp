#include "MailHandler.h"
#include "Dispatcher.h"
#include "LxUser.h"

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// 请求用户邮件列表
void MailHandler::ProcessUserMailReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	UserMailReq request;
	if(!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
	UserMailResp response;
	pUser->_mail._tpl.ForEach([&](LxMail* ptr){
		*response.add_mails() = *ptr;
	});
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
	LxGameHelper::MakeUserMailResp(packetResponse, response);
}

// 设置邮件已读
void MailHandler::ProcessUserReadMailReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	UserReadMailReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
	UserReadMailResp response;
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
	for (int n = 0; n < request.mailids_size(); n++) {
		if( pUser->MailRead(request.mailids(n)) ) {
			response.add_mailids(request.mailids(n));
		}
	}
	LxGameHelper::MakeUserReadMailResp(packetResponse, response);
	pUser->SendUserInfoChange(0);// 这里正常是不会发送到客户端的,如果发过去了,让客户端静默更新一下也可以
}

//  删除邮件
void MailHandler::ProcessUserDeleteMailReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	UserDeleteMailReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
	UserDeleteMailResp response;
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
	for (int n = 0; n < request.mailids_size(); n++) {
		pUser->MailDelete(request.mailids(n));
		response.add_mailids(request.mailids(n));
	}
	LxGameHelper::MakeUserDeleteMailResp(packetResponse, response);
	pUser->SendUserInfoChange(0);// 这里正常是不会发送到客户端的,如果发过去了,让客户端静默更新一下也可以
}

// 领取邮件奖励
void MailHandler::ProcessUserRewardMailReq(LxUser* pUser, WrapPacket& packet, WrapPacket& packetResponse) {
	UserRewardMailReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
	UserRewardMailResp response;
	packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
	for (int n = 0; n < request.mailids_size(); n++) {
		if( pUser->MailReward(request.mailids(n)) ){
			response.add_mailids(request.mailids(n));
		}
	}
	LxGameHelper::MakeUserRewardMailResp(packetResponse, response);
	pUser->SendUserInfoChange(EPIC_MailReward);
}
