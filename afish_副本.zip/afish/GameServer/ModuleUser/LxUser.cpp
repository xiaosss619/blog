#include "LxUser.h"
#include "Dispatcher.h"
#include "ThreadUser.h"
#include "Handler/MailHandler.h"
#include "Handler/InventoryHandler.h"
#include "Handler/MiscHandler.h"
#include "Handler/HeroHandler.h"
#include "Handler/RedisCmdHandler.h"
#include "Handler/RmbMiscHandler.h"
#include "Handler/ActivityHandler.h"
#include "Handler/ReportHandler.h"
#include "Handler/FriendHandler.h"
#include "Handler/BombCardHandler.h"
#include "Handler/GiftHandler.h"
#include "Handler/TechHandler.h"
#include "GameUtils.h"
#include "Include/RedisProtoHelper.h"
#include "Include/RedisKey.h"
#include "RedisManager/RedisManager.h"
#include "ThreadUser.h"
#include "ModuleHelper.h"
#include "DataCache/RedisData.h"
#include "LxGameLogHelper.h"

LxUser::LxUser()
{
    SetKey(0);
}

LxUser::~LxUser() {
}

void LxUser::OnRecycled() {
    SetKey(0);
    m_LastLowFrameTime = 0;
	sGameUtils->DecOnlineUser();
}

bool LxUser::Init(int32 connectionid, const LxUserOnline& info) {
    SetProcessingOffline(false);
    m_tmLastBoardUpdate = 0;
    m_tmLastCheckLink = 0;
    m_LastLowFrameTime = 0;
    m_nFireLastTable = 0;
    m_nFireCost = 0;
	m_nFireLastCrystalTable = 0;
	m_nFireCrystalCost = 0;
    m_bNewbieEnd = false;
    m_userInfo = info.resp().user_info();
    SetKey(PBGetUserId());
    SetConnectionId(connectionid);
    m_dirtyFields.clear();
    m_dirtyItems.clear();
    m_dirtyProducts.clear();
    m_dirtySystem.clear();
    m_dirtyExchanges.clear();
    m_dirtyBombGameRecord.clear();
    m_mapItem.clear();
    m_lstCharge.clear();
    m_lstBombGameRecord.clear();
    m_mapExchanges.clear();
    m_lstYells.clear();
    m_vecCards.clear();
    m_nTreasureRelationId = 0;
    m_treasureCards.clear();
    m_mapSkillBackup.clear();
    m_SkillSuper = 0;
    m_SkillSuperTick = 0;

    _wing.Init(this);
    _hero.Init(this);
    _mail.Init(this);
    _quest.Init(this);
    _day7.Init(this);
    _gtask.Init(this);
    _tts.Init(this);
    _market.Init(this);
    _draw.Init(this);
    _bombAct.Init(this);
    _tech.Init(this);
    _buff.Init(this);
    _treasure.Init(this);
    _counter.Init(this);
    _friend.Init(this);
    _block.Init(this);
    _frozens.Init(this);
    _gcounter.Init(this);
    _boss.Init(this);
    _hunt.Init(this);

    for( int i = 0; i < info.resp().productlist_size() ; ++i ) {
        m_lstCharge.push_back(info.resp().productlist(i));
    }
    for( int i = 0; i < info.bomb_rewards_size(); ++i ) {
        m_lstBombGameRecord.push_back(info.bomb_rewards(i));
    }
    for( int i = 0; i < info.resp().items_size() ; ++i) {
        m_mapItem[info.resp().items(i).item_id()] = info.resp().items(i).item_num();
    }
    for( int i = 0; i < info.exchanges_size() ; ++i ) {
        m_mapExchanges[info.exchanges(i).guid()] = info.exchanges(i);
    }
    for( int i = 0; i < info.mails_size() ; ++i) {
        _mail.InitMail(info.mails(i));
    }
    for( int i = 0; i < info.resp().heros_size() ; ++i) {
        _hero.InitHero(info.resp().heros(i));
    }
    for( int i = 0; i < info.resp().wings_size() ; ++i) {
        _wing.InitWing(info.resp().wings(i));
    }
    for( int i = 0; i < info.resp().quests_size() ; ++i) {
        _quest.InitQuest(info.resp().quests(i));
    }
    for( int i = 0; i < info.resp().sevendays_size() ; ++i) {
        _day7.InitDay7(info.resp().sevendays(i));
    }
    for( int i = 0; i < info.resp().gtasks_size() ; ++i) {
        _gtask.InitGTask(info.resp().gtasks(i));
    }
    for( int i = 0; i < info.resp().tts_size() ; ++i) {
        _tts.InitTurnTable(info.resp().tts(i));
    }
    for( int i = 0; i < info.resp().markets_size(); ++i ) {
        _market.InitMarket(info.resp().markets(i));
    }
    for( int i = 0; i < info.draws_size(); ++i ) {
        _draw.InitDraw(info.draws(i));
    }
    for( int i = 0; i < info.cards_size(); ++i ) {
        _bombAct.InitCard(info.cards(i));
    }
    _bombAct.InitCardRelation();

    for( int i = 0; i < info.resp().techs_size(); ++i ) {
        _tech.InitTech(info.resp().techs(i));
    }
    _tech.InitNewbie();

    for( int i = 0; i < info.resp().buffs_size(); ++i ) {
        _buff.InitBuff(info.resp().buffs(i));
    }

    for( int i = 0; i < info.resp().treasures_size(); ++i ) {
        _treasure.InitTreasure(info.resp().treasures(i));
    }

    for( int i = 0; i < info.counters_size(); ++i ) {
        _counter.InitCounter(info.counters(i));
    }
    _counter.InitNewbie();
    for( int i = 0; i < info.resp().friends_size(); ++i ) {
        _friend.InitFriend(info.resp().friends(i));
    }
    for( int i = 0; i < info.resp().blocks_size(); ++i ) {
        _block.InitBlock(info.resp().blocks(i));
    }
    for( int i = 0; i < info.resp().frozens_size(); ++i ) {
        _frozens.InitAssets(info.resp().frozens(i));
    }
    for( int i = 0; i < info.resp().gcounter_size(); ++i ) {
        _gcounter.InitCounter(info.resp().gcounter(i));
    }
    for( int i = 0; i < info.boss_size(); ++i ) {
        _boss.InitBoss(info.boss(i));
    }
    for( int i = 0; i < info.resp().hunts_size(); ++i ) {
        _hunt.InitHunt(info.resp().hunts(i));
    }

    // IsValid中用离线时间来判定是否有效,所以这里要临时设置一下离线时间为0
    m_userInfo.set_time_offline(0);

	sGameUtils->IncOnlineUser();
    LOG_USER_LOGIN(this
                    ,PBGetUserGold()
                    ,PBGetDiamondFree()
                    ,PBGetDiamondRmb()
                    ,GetCouponNum()
                    ,0
                    ,PBGetTimeGame()
                    ,PBGetTimeOnline());
    _generator.seed(time(nullptr)+GlobalUtils::GetRandNumber(1111,10000));
    return true;
}

void LxUser::GetTargetInfo(TargetInfo& lhs) {
    lhs.set_t_id(m_userInfo.user_id());
    lhs.set_t_name(m_userInfo.user_name());
    lhs.set_t_sign(m_userInfo.user_sign());
    lhs.set_t_comment("");
    lhs.set_t_pop(m_userInfo.popularity());
    lhs.set_t_level(m_userInfo.user_level());
    lhs.set_t_vip(m_userInfo.user_vip());
    lhs.set_t_head(m_userInfo.user_portrait());
    lhs.set_t_frame(m_userInfo.user_frame());
    lhs.set_t_offline(m_userInfo.time_offline());
}

void LxUser::UpdateTargetInfo() {
    FETCH_VOID();
    TargetInfo info;
    GetTargetInfo(info);
    RedisData::SetUserTargetInfo(pConnection, info);
    _friend.RefreshMe(pConnection);
}

void LxUser::OnFieldChange(E_UserInfoFieldEnum field) {
    m_dirtyFields.insert(field);
    switch(field) {
    case eUserInfo_user_name:
    case eUserInfo_user_sign:
    case eUserInfo_popularity:
    case eUserInfo_user_level:
    case eUserInfo_user_vip:
    case eUserInfo_user_frame:
    case eUserInfo_user_portrait:
    case eUserInfo_time_offline:
        UpdateTargetInfo();
        break;
    default:
        break;
    }
}

void LxUser::Offline() {
    int64 tNow = sGameUtils->GetFakeTimeNow();
    PBSetTimeOffline(tNow);
    PBIncTimeOnline(tNow-PBGetTimeLastLogin());
    UpdateTargetInfo();
    LOG_USER_LOGOUT_V2(this
                        ,PBGetUserGold()
                        ,PBGetDiamondFree()
                        ,PBGetDiamondRmb()
                        ,GetCouponNum()
                        ,GetItemNum(JDATA->SystemConstPtr()->GetPhoneVoucherItemID())
                        ,GetItemNum(11901001)
                        ,GetItemNum(11901002)
                        ,GetItemNum(11901003)
                        ,GetItemNum(11901004)
                        ,PBGetTimeGame()
                        ,PBGetTimeOnline());
    UpdateBoardData();
}

void LxUser::AfterLogin() {
    m_LastLowFrameTime = 0;

    SetSensitiveSystemBanned(EUSTF_Voucher);
    if( PBGetTimeLastLogin() == 0 ) {
        // 上次登录时间为0,说明是新账号
        LOG_USER_CREATE(this);
        // 新号直接设置成红利释放阶段, 先送一波上去
        PBSetUserChargeBonusFlag(1);
        SetNewbieProtected();
        PBSetUserValue(JDATA->SystemConstPtr()->GetUserValueInitial());
        GiveQuest(JDATA->SystemConstPtr()->GetNewbieGuideFirst());
        int32 tindex = JDATA->SystemConstPtr()->GetFirstTurretID();
        GiveHero(tindex, 1, 1, 0);
        PBSetUserHeroIndex(tindex);
        StartNewbieFee(JDATA->SystemConstPtr()->GetNewBieRedEnvelope(), JDATA->SystemConstPtr()->GetNewBieRedEnvelopeTime());
        _market.RandMarket(true);
    }
    else {
        // 登录都去尝试一下跨天,在CrossDay中会进行有效性判定
        CrossDay();
        UpdateEnergy();
    }
    int64 tNow = sGameUtils->GetFakeTimeNow();
    _tech.Update(tNow);
    PBSetTimeLastLogin(tNow);
    PBSetTimeOffline(0);
    m_bNewbieEnd = _quest.IsNewbieEnd();
    if( !IsBattlePassBought() ) {
        // 如果没买, 设置为-1, 买过了, 就不管了, 会跟着玩家领取走
        PBSetBattlePassVipNow(-1);
    }
	_mail._tpl.ForEachWithBreak([&](LxMail* ptr){
        if( !ptr->mail_read() ) {
            m_dirtySystem.insert(ERDS_Mail);
            return true;
        }
        return false;
	});
    ItemRecycle();
    SlientFix();
    if( PBGetUserProperty() == 0 ) {
        // 首次初始化资产面板
        PBSetUserProperty(JDATA->SystemConstPtr()->GetInitialPropertyBG());
    }
    if( 1 <= PBGetUserPortrait() && PBGetUserPortrait() <= 6 ) {
        // 首次初始化头像 版本迭代写死了一个头像起始id, 后续可以找机会删除, 只保留重置即可
        PBSetUserPortrait(PBGetUserPortrait()+10202000);
    }
    else if( PBGetUserPortrait() <= 10000000 ) {
        PBSetUserPortrait(JDATA->SystemConstPtr()->GetInitialHeadIcon());
    }
    if( PBGetUserFrame() == 0 ) {
        PBSetUserFrame(JDATA->SystemConstPtr()->GetInitialHeadFrame());
    }
    int64 goldValue = 0;
    for( auto & item : m_mapItem ) {
        tagJsonItem tag;
        if( JDATA->ItemPtr()->ByID(item.first, tag)
            && tag._MainType == e_jsonItemMainType_NuclearBomb ) {
            goldValue += tag._ItemParam*item.second;
        }
    }
    PBSetTotalBombValue(goldValue);
    if( PBGetUserGrowthFund() == 0 ) {
        // 没买过成长基金
        if( PBGetUserGrowthFundVersion() == 0 ) {
            PBSetUserGrowthFundVersion(1);
        }
    }
    string strBossBonus = PBGetBossBonus();
    if( !strBossBonus.empty() ) {
        set<int64> setBoss;
        GlobalUtils::GetNumSet(PBGetBossBonus(), "|", setBoss);
        for( auto & boss : setBoss ) {
            if( !_boss.IsBossBonused(boss) ) {
                _boss.OnBossKilled(boss);
            }
        }
        PBSetBossBonus("");
    }
    {
        TreasureHuntConfig conf;
        if( sHActs->GetTreasureHuntConfig(conf) && conf.act_id() != PBGetTreasureHuntId() ) {
            // 换活动了
            PBSetTreasureHuntId(conf.act_id());
            PBSetTreasureHuntNum(0);
            _treasure.Reset(true);
        }
    }
    if( m_vecCards.size() == 0 ) {
        sHBombGame->GetAllCards(m_vecCards);
    }
    if( !IsVoucherCtrlInited() ) {
        int32 ctrl = PBGetTotalCharge()*JDATA->SystemConstPtr()->GetTreasureBoxVoucherInitialRate()/10000;
        ctrl += JDATA->SystemConstPtr()->GetTreasureBoxVoucherInitial();
        PBSetVoucherControl(ctrl);
        SetVoucherCtrlInited();
    }
    if( PBGetDrawTenNextBig() == 0 ) {
        DrawTenUpdate();
    }
    _wing.CheckPower();
    _hero.CheckPower();
    InitUserAttr();
    _frozens.CheckExpired(tNow);

    UpdateTargetInfo();
}

void LxUser::SetFieldValue(const string& field, const string& value) {
    USERINFOSET(field, value);
}

void LxUser::FillLoginResp(UserLoginResp& resp) {
    // 任务部分数据只需要发送给客户端当前接的,完成的不需要发送
    *resp.mutable_user_info() = m_userInfo;
    RedisProtoHelper::ClearServerOnlyField(*resp.mutable_user_info());
    resp.clear_productlist();
    for( auto & charge : m_lstCharge ) {
        *resp.add_productlist() = charge;
    }
    resp.clear_items();
    for( auto & item : m_mapItem ) {
        auto ptr = resp.add_items();
        ptr->set_item_id(item.first);
        ptr->set_item_change(item.second);
        ptr->set_item_num(item.second);
    }
    _quest.FillLoginResp(resp);
    _day7.FillLoginResp(resp);
    _gtask.FillLoginResp(resp);
    _tts.FillLoginResp(resp);
    _hero.FillLoginResp(resp);
    _wing.FillLoginResp(resp);
    _tech.FillLoginResp(resp);
    _buff.FillLoginResp(resp);
    _treasure.FillLoginResp(resp);
    _friend.FillLoginResp(resp);
    _block.FillLoginResp(resp);
    _frozens.FillLoginResp(resp);
    _gcounter.FillLoginResp(resp);
    _hunt.FillLoginResp(resp);
}

string LxUser::GetLogAccInfoRedisJson() {
    ostringstream os;
    os << "\"event_time\":\"" << GlobalUtils::GetTimeByFormat(ETF_LOG, sGameUtils->GetFakeTimeNow()) << "\",";
    os << "\"acc_channel\":\"" << m_userInfo.client_channel() << "\",";
    os << "\"acc_open_id\":\"" << m_userInfo.user_open_id() << "\",";
    os << "\"acc_user_id\":" << m_userInfo.user_id() << ",";
    os << "\"acc_user_gold\":" << GetUserGoldProperty() << ",";
    os << "\"acc_user_win\":" << m_userInfo.fish_win_gold() - m_userInfo.fish_cost_gold() << ",";
    if( m_userInfo.passport_id() == 0 ) {
        os << "\"acc_pass_id\":" << -1 << ",";
        os << "\"acc_pass_is_vip\":" << m_userInfo.battle_pass_vip_now() << ",";
        os << "\"acc_pass_reward_level\":" << m_userInfo.battle_pass_now() << ",";
    }
    else{
        os << "\"acc_pass_id\":" << m_userInfo.passport_id() << ",";
        os << "\"acc_pass_vip_now\":" << m_userInfo.passport_vip_now() << ",";
        os << "\"acc_pass_now\":" << m_userInfo.passport_now() << ",";
    }
    os << "\"acc_poverty_total\":" << m_userInfo.total_poverty() << ",";
    os << "\"acc_user_diamond\":" << m_userInfo.diamond_free() + m_userInfo.diamond_rmb() << ",";
    os << "\"acc_total_charge\":" << m_userInfo.total_charge() << ",";
    os << "\"acc_total_fish_time\":" << m_userInfo.time_game() << ",";
    os << "\"acc_create_time\":" << m_userInfo.time_register();
    return os.str();
}

string LxUser::GetLogAccInfoJson() {
    ostringstream os;
    os << sGameUtils->GetFakeTimeNow() << ",";
    os << m_userInfo.client_channel() << ","; // 用户渠道号
	os << m_userInfo.user_open_id() << ","; // open_id
	os << m_userInfo.user_id() << ","; // 用户id
	os << GetUserGoldProperty() << ","; // 当前金币+核弹金币价值
	os << m_userInfo.fish_win_gold() - m_userInfo.fish_cost_gold() << ","; // 当前净分
    if( m_userInfo.passport_id() == 0 ) {
        os << -1 << ","; // 通行证id
        os << m_userInfo.battle_pass_vip_now() << ","; // 通行证vip已领等级
        os << m_userInfo.battle_pass_now() << ","; // 通行证免费已领等级
    }
    else {
        os << m_userInfo.passport_id() << ","; // 月度通行证id
        os << m_userInfo.passport_vip_now() << ","; // 月度通行证vip领取到的等级
        os << m_userInfo.passport_now() << ","; // 月度通行证当前领取到的等级
    }
	os << m_userInfo.total_poverty() << ","; // 破产次数
	os << m_userInfo.diamond_free() + m_userInfo.diamond_rmb() << ","; // 钻石数量
	os << m_userInfo.total_charge() << ","; // 总充值金额
	os << m_userInfo.time_game() << ","; // 累计捕鱼时长
	os << m_userInfo.time_register(); // 账号创建时间
    return os.str();
}

void LxUser::ProcessPacket(WrapPacket& pkg, WrapPacket& response) {
    switch( pkg.cmd() ) {
    case USER_LxUserOnline:
        // 用户缓存未清除,继续发送登录包,直接使用老数据即可
        break;
    case USER_SGiftSendReq:
        GiftHandler::ProcessSGiftSendReq(this, pkg, response);
        break;
    case USER_LxGiftGet:
        break;
    ///////////////////////////////////////////////////////////////
    case USER_HeroSwitchReq:
        HeroHandler::ProcessHeroSwitchReq(this, pkg, response);
        break;
    case USER_HeroChangeBulletReq:
        HeroHandler::ProcessHeroChangeBulletReq(this, pkg, response);
        break;
    case USER_HeroLevelupReq:
        HeroHandler::ProcessHeroLevelupReq(this, pkg, response);
        break;
    case USER_HeroStarChargeReq:
        HeroHandler::ProcessHeroStarChargeReq(this, pkg, response);
        break;
    case USER_WingUpgradeReq:
        HeroHandler::ProcessWingUpgradeReq(this, pkg, response);
        break;
    ///////////////////////////////////////////////////////////////
    case USER_NewbieFeeRewardReq:
        RmbMiscHandler::ProcessNewbieFeeRewardReq(this, pkg, response);
        break;
    case USER_DrawRmbInfoReq:
        RmbMiscHandler::ProcessDrawRmbInfoReq(this, pkg, response);
        break;
    case USER_DrawRmbOpenReq:
        RmbMiscHandler::ProcessDrawRmbOpenReq(this, pkg, response);
        break;
    case USER_DrawRmbCloseReq:
        RmbMiscHandler::ProcessDrawRmbCloseReq(this, pkg, response);
        break;
    case USER_DrawRmbDrawReq:
        RmbMiscHandler::ProcessDrawRmbDrawReq(this, pkg, response);
        break;
    case USER_RmbCardRewardReq:
        RmbMiscHandler::ProcessRmbCardRewardReq(this, pkg, response);
        break;
    ///////////////////////////////////////////////////////////////
    case USER_FriendInfoReq:
        FriendHandler::ProcessFriendInfoReq(this, pkg, response);
        break;
    case USER_FriendApplyReq:
        FriendHandler::ProcessFriendApplyReq(this, pkg, response);
        break;
    case USER_FriendApplyListReq:
        FriendHandler::ProcessFriendApplyListReq(this, pkg, response);
        break;
    case USER_FriendAcceptOneReq:
        FriendHandler::ProcessFriendAcceptOneReq(this, pkg, response);
        break;
    case USER_FriendRejectOneReq:
        FriendHandler::ProcessFriendRejectOneReq(this, pkg, response);
        break;
    case USER_FriendAcceptAllReq:
        FriendHandler::ProcessFriendAcceptAllReq(this, pkg, response);
        break;
    case USER_FriendRejectAllReq:
        FriendHandler::ProcessFriendRejectAllReq(this, pkg, response);
        break;
    case USER_FriendRemoveReq:
        FriendHandler::ProcessFriendRemoveReq(this, pkg, response);
        break;
    case USER_FriendCommentReq:
        FriendHandler::ProcessFriendCommentReq(this, pkg, response);
        break;
    case USER_BlockAddReq:
        FriendHandler::ProcessBlockAddReq(this, pkg, response);
        break;
    case USER_BlockDelReq:
        FriendHandler::ProcessBlockDelReq(this, pkg, response);
        break;
    ///////////////////////////////////////////////////////////////
	case USER_UserMailReq:
		MailHandler::ProcessUserMailReq(this, pkg, response);
        break;
	case USER_UserReadMailReq:
		MailHandler::ProcessUserReadMailReq(this, pkg, response);
        break;
	case USER_UserDeleteMailReq:
		MailHandler::ProcessUserDeleteMailReq(this, pkg, response);
        break;
	case USER_UserRewardMailReq:
		MailHandler::ProcessUserRewardMailReq(this, pkg, response);
        break;
    ///////////////////////////////////////////////////////////////
    case USER_UserItemReq:
        InventoryHandler::ProcessUserItemReq(this, pkg, response);
        break;
    case USER_UserItemUseReq:
        InventoryHandler::ProcessUserItemUseReq(this, pkg, response);
        break;
    ///////////////////////////////////////////////////////////////
    case USER_UserExchangeReq:
        ActivityHandler::ProcessUserExchangeReq(this, pkg, response);
        break;
    case USER_ExchangeStockReq:
        ActivityHandler::ProcessExchangeStockReq(this, pkg, response);
        break;
    case USER_ExchangeCodeReq:
        ActivityHandler::ProcessExchangeCodeReq(this, pkg, response);
        break;
    case USER_GetNewbieGiftReq:
        ActivityHandler::ProcessGetNewbieGiftReq(this, pkg, response);
        break;
    case USER_GeneralTaskRewardReq:
        ActivityHandler::ProcessGeneralTaskRewardReq(this, pkg, response);
        break;
    case USER_UserSevenDayRewardReq:
        ActivityHandler::ProcessDay7RewardReq(this, pkg, response);
        break;
    case USER_UserSevenDayExpRewardReq:
        ActivityHandler::ProcessDay7ExpRewardReq(this, pkg, response);
        break;
    case USER_TurntableBonusReq:
        ActivityHandler::ProcessTurntableBonusReq(this, pkg, response);
        break;
    case USER_TurntablePlayReq:
        ActivityHandler::ProcessTurntablePlayReq(this, pkg, response);
        break;
    case USER_UserActivityReq:
        ActivityHandler::ProcessUserActivityReq(this, pkg, response);
        break;
    case USER_MonthCardRewardReq:
        ActivityHandler::ProcessMonthCardRewardReq(this, pkg, response);
        break;
    case USER_TreasureHuntReq:
        ActivityHandler::ProcessTreasureHuntReq(this, pkg, response);
        break;
    case USER_TreasureHuntResetReq:
        ActivityHandler::ProcessTreasureHuntResetReq(this, pkg, response);
        break;
    case USER_TreasureHuntSetRewardReq:
        ActivityHandler::ProcessTreasureHuntSetRewardReq(this, pkg, response);
        break;
    case USER_DrawTenReq:
        ActivityHandler::ProcessDrawTenReq(this, pkg, response);
        break;
    case USER_DrawTenPeriodRewardReq:
        ActivityHandler::ProcessDrawTenPeriodRewardReq(this, pkg, response);
        break;
///////////////////////////////////////////////////////////////////////////////////////////
    case USER_BombActCardInfoReq:
        BombCardHandler::ProcessBombActCardInfoReq(this, pkg, response);
        break;
    case USER_BombActCardClickReq:
        BombCardHandler::ProcessBombActCardClickReq(this, pkg, response);
        break;
    case USER_BombGameInfoReq:
        BombCardHandler::ProcessBombGameInfoReq(this, pkg, response);
        break;
    case USER_BombGamePlayReq:
        BombCardHandler::ProcessBombGamePlayReq(this, pkg, response);
        break;
    case USER_BombGamePoolListReq:
        BombCardHandler::ProcessBombGamePoolListReq(this, pkg, response);
        break;
    case USER_BombGameFlipEnd:
        {
            response.clear_userid();
            if( !m_lstYells.empty() ) {
                auto data = m_lstYells.front();
                m_lstYells.pop_front();
                sDispatcher->broadcast_rolling_msg(data._yell_id, "", data._lst);
            }
            break;
        }
/////////////////////////////////////////////////////////////////////////////////////////
    case USER_TechUpgradeReq:
        TechHandler::ProcessTechUpgradeReq(this, pkg, response);
        break;
    case USER_TechAccelerateReq:
        TechHandler::ProcessTechAccelerateReq(this, pkg, response);
        break;
    case USER_TechProduceReq:
        TechHandler::ProcessTechProduceReq(this, pkg, response);
        break;
    case USER_TechProductGetReq:
        TechHandler::ProcessTechProductGetReq(this, pkg, response);
        break;
    case USER_TechProduceAccelerateReq:
        TechHandler::ProcessTechProduceAccelerateReq(this, pkg, response);
        break;
/////////////////////////////////////////////////////////////////////////////////////////
    case USER_ModifyNameReq:
        MiscHandler::ProcessModifyNameReq(this, pkg, response);
        break;
    case USER_ModifySignReq:
        MiscHandler::ProcessModifySignReq(this, pkg, response);
        break;
    case USER_UserChargeReq:
        MiscHandler::ProcessUserChargeReq(this, pkg, response);
        break;
    case USER_LxGiveQuest:
    {
        LxGiveQuest lgq;
        if(!lgq.ParseFromString(pkg.data())) {
            LOGINFO("parse failed [%lu]", pkg.userid());
            return;
        }
        GiveQuest(lgq.quest_id());
        SendUserInfoChange(0);
        break;
    }
    case USER_SignDayReq:
        MiscHandler::ProcessSignDayReq(this, pkg, response);
        break;
    case USER_SaveUserDefineDataReq:
        MiscHandler::ProcessSaveUserDefineDataReq(this, pkg, response);
        break;
    case USER_LevelRewardReq:
        MiscHandler::ProcessLevelRewardReq(this, pkg, response);
        break;
    case USER_GrowthRewardReq:
        MiscHandler::ProcessGrowthRewardReq(this, pkg, response);
        break;
    case USER_QuestRewardReq:
        MiscHandler::ProcessQuestRewardReq(this, pkg, response);
        break;
    case USER_BuyTideReq:
        MiscHandler::ProcessBuyTideReq(this, pkg, response);
        break;
    case USER_PovertyRewardReq:
        MiscHandler::ProcessPovertyRewardReq(this, pkg, response);
        break;
    case USER_UserBuyVipGiftReq:
        MiscHandler::ProcessUserBuyVipGiftReq(this, pkg, response);
        break;
    case USER_UserBuyMarketReq:
        MiscHandler::ProcessUserBuyMarketReq(this, pkg, response);
        break;
    case USER_UserRandMarketReq:
        MiscHandler::ProcessUserRandMarketReq(this, pkg, response);
        break;
    case USER_SlotFishDrawReq:
        MiscHandler::ProcessSlotFishDrawReq(this, pkg, response);
        break;
    case USER_UserExchangeListReq:
    {
        UserExchangeListResp msg;
        for( auto & data : m_mapExchanges ) {
            *msg.add_products() = data.second;
        }
        response.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
        LxGameHelper::MakeUserExchangeListResp(response, msg);
        break;
    }
    case USER_UserBuyEnergyReq:
    {
        response.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
        auto data = sGameUtils->GetBuyEnergyData(PBGetBuyEnergyNum()+1);
        int32 diamond = TUPLE0(data);
        int32 energy = TUPLE1(data);
        UserBuyEnergyResp msg;
        if( diamond > 0 && ChangeDiamond(-diamond, ELRD_BuyEnergy, false) ) {
            PBIncBuyEnergyNum(1);
            ChangeCurEnergy(energy);
            msg.set_energy_num(energy);
        }
        else {
            response.set_errorcode(JDATA->ErrorCodePtr()->GetDiamondLow());
        }
        LxGameHelper::MakeUserBuyEnergyResp(response, msg);
        SendUserInfoChange(0);
        break;
    }
    case USER_TodayTableRewardReq:
        MiscHandler::ProcessTodayTableRewardReq(this, pkg, response);
        break;
    case USER_BattlePassRewardReq:
        MiscHandler::ProcessBattlePassRewardReq(this, pkg, response);
        break;
    case USER_PassportRewardReq:
        MiscHandler::ProcessPassportRewardReq(this, pkg, response);
        break;
    case USER_PassportBuyExpReq:
        MiscHandler::ProcessPassportBuyExpReq(this, pkg, response);
        break;
    case USER_RoomGoldPoolInfoReq:
    {
        response.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
        RoomGoldPoolInfoResp msg;
        {
            auto info = msg.add_gold_info();
            info->set_room_id(104);
            info->set_gold(sRankingList->GetTableSummonPool(104));
        }
        {
            auto info = msg.add_gold_info();
            info->set_room_id(105);
            info->set_gold(sRankingList->GetTableSummonPool(105));
        }
        {
            auto info = msg.add_gold_info();
            info->set_room_id(106);
            info->set_gold(sRankingList->GetTableSummonPool(106));
        }
        {
            auto info = msg.add_gold_info();
            info->set_room_id(999);
            info->set_gold(sRankingList->GetBombGamePoolGold());
        }
        LxGameHelper::MakeRoomGoldPoolInfoResp(response, msg);
        break;
    }
/////////////////////////////////////////////////////////////////////////////////////////
    case USER_ReportDeviceInfo:
        ReportHandler::ProcessReportDeviceInfo(this, pkg, response);
        break;
    case USER_ReportProductStatus:
        ReportHandler::ProcessReportProductStatus(this, pkg, response);
        break;
    case USER_ReportFrameNum:
        ReportHandler::ProcessReportFrameNum(this, pkg, response);
        break;
    case USER_ReportGuideStep:
        ReportHandler::ProcessReportGuideStep(this, pkg, response);
        break;
    case USER_ReportUserActList:
        ReportHandler::ProcessReportUserActList(this, pkg, response);
        break;
    case USER_ReportUserActSingle:
        ReportHandler::ProcessReportUserActSingle(this, pkg, response);
        break;
    case USER_LxCheckLoginLock:
        // 如果是有效连接, 则需要刷新一下LoginLock情况
        if( !IsProcessingOffline() ) {
            FETCH_VOID();
            SeverIdAndLinkId tag;
            if( pConnection->get(RedisKey::MakeUserLoginLockKey(GetKey()), tag._data) ) {
                if( tag._serverId != sGameUtils->GetServerId() || tag._linkId != GetConnectionId() ) {
                    // 本逻辑发生几率不高
                    // 两个登录包被不同的游戏进程同时处理, 该情况只会发生在单个登录超过10秒才成功, 导致后一个登录对于setnx的判定有误
                    SetProcessingOffline(true);
                    sDispatcher->kick_duplicate_user(GetKey());
                }
                else {
                    // 相同则刷新一下到期时间
                    pConnection->expire(RedisKey::MakeUserLoginLockKey(GetKey()), 20);
                }
            }
            else {
                // 某些原因导致服务器非常卡, 10秒还没执行过一次update, 导致redis中数据超时删除
                pConnection->setex(RedisKey::MakeUserLoginLockKey(GetKey()), tag._data, 20);
            }
        }
        break;
    default:
        LOGERROR("UnHandled command [%d]", pkg.cmd());
        break;
    }
}

void LxUser::ChangeCurEnergy(int32 chg) {
    int32 cur = PBGetUserCurEnergy();
    int32 now = cur + chg;
    if( now < 0 ) {
        return;
    }
    PBSetUserCurEnergy(now);
    if( chg < 0 ) {
        // 从满的扣到不满,要重置一下能量恢复时间
        int32 maxEnergy = GetMaxEnergy();
        if( cur >= maxEnergy && now < maxEnergy ) {
            PBSetUserEnergyTime(sGameUtils->GetFakeTimeNow());
        }
    }
}

void LxUser::LogExchange(int64 guid, const string& product, int64 tNow, int32 status) {
    auto it = m_mapExchanges.find(guid);
    if( it == m_mapExchanges.end() ) {
        UserExchangeData data;
        data.set_guid(guid);
        data.set_product(product);
        data.set_status(status);
        data.set_exchange_time(tNow);
        m_mapExchanges[guid] = data;
    }
    else {
        it->second.set_status(status);
    }
    m_dirtyExchanges.insert(guid);
}

void LxUser::OnChangeHero(int32 tid) {
    PBSetUserHeroIndex(tid);
    PBSetUserPower(_hero.HeroGetPower(tid));
}

void LxUser::SlientFix() {
    int32 fixId = PBGetFixId();
    JDATA->ServerFixPtr()->ForEach([&](tagJsonServerFix* ptr){
        if( ptr->_ID > fixId ) {
            if( ptr->_user_id == 0 || (uint64)ptr->_user_id == GetKey() ) {
                ChangeGold(ptr->_gold, ELRI_Other);
                ChangeDiamond(ptr->_diamond, ELRI_Other, false);
                if(ptr->_field.size() > 0 && ptr->_field.size() % 2 == 0 ) {
                    for( size_t n = 0 ; n < ptr->_field.size() ; n+=2 ) {
                        SetFieldValue(ptr->_field[n], ptr->_field[n+1]);
                    }
                }
                if(ptr->_items.size() > 0 && ptr->_items.size() % 2 == 0 ) {
                    for( size_t n = 0 ; n < ptr->_items.size() ; n+=2 ) {
                        ItemChange(ptr->_items[n], ptr->_items[n+1], ELRI_Other, false);
                    }
                }
                PBSetFixId(ptr->_ID);
            }
        }
    });
}

void LxUser::OnItemChange(const ItemPair& item) {
    auto it = m_dirtyItems.find(item.item_id());
    if( it == m_dirtyItems.end() ) {
        m_dirtyItems[item.item_id()] = item;
    }
    else {
        it->second.set_item_change(it->second.item_change() + item.item_change());
        it->second.set_item_num(item.item_num());// 每次更新后的item_num才是当前的数量,这里不需要做计算,直接取值
    }
}

void LxUser::ItemRecyclePayPrice(int64 itemNum, const vector<int64>& vecPrice) {
    if( vecPrice.size() == 2 ) {
        switch( vecPrice[0] ) {
        case e_jsonItemRecyclePrice_Gold:
            ChangeGold(itemNum * vecPrice[1], ELRI_ItemRecycle);
            break;
        case e_jsonItemRecyclePrice_Diamond:
            ChangeDiamond(itemNum * vecPrice[1], ELRI_ItemRecycle, false);
            break;
        default:
            if( JDATA->ItemPtr()->ContainID(vecPrice[0]) ) {
                ItemChange(vecPrice[0], itemNum * vecPrice[1], ELRI_ItemRecycle, false);
            }
            break;
        }
    }
}

void LxUser::ItemRecycle() {
    int64 tNow = sGameUtils->GetFakeTimeNow();
    JDATA->ItemRecyclePtr()->ForEach([&](tagJsonItemRecycle* ptr){
        if( ptr->_Channel.size() > 0 && GlobalUtils::SearchItem(ptr->_Channel, PBGetClientChannel()) == -1 ) {
            // 有渠道判定, 并且用户渠道不在回收渠道内, 不需要回收
            return;
        }
        int64 end = GlobalUtils::MakeTime(ptr->_RecycleTime);
        if( tNow >= end ) {
            int64 itemNum = GetItemNum(ptr->_ID);
            if( itemNum > 0 ) {
                if( !ItemChange(ptr->_ID, -itemNum, ELRD_ItemRecycle, false) ) {
                    LOGERROR("RECYCLE user[%lu] recycle item failed[%d][%ld]", GetKey(), ptr->_ID, itemNum);
                }
                else {
                    if( ptr->_MailID > 0 ) {
                        int64 gold = 0;
                        int64 diamond = 0;
                        map<int32, int64> mapItem;
                        if( ptr->_Price.size() == 2 ) {
                            switch( ptr->_Price[0] ) {
                            case e_jsonItemRecyclePrice_Gold:
                                gold = itemNum * ptr->_Price[1];
                                break;
                            case e_jsonItemRecyclePrice_Diamond:
                                diamond = itemNum * ptr->_Price[1];
                                break;
                            default:
                                if( JDATA->ItemPtr()->ContainID(ptr->_Price[0]) ) {
                                    mapItem[ptr->_Price[0]] = itemNum * ptr->_Price[1];
                                }
                                break;
                            }
                        }
                        SendMail(ptr->_MailID, diamond, gold, mapItem, "", GlobalUtils::ToString(ptr->_ID));
                    }
                }
            }
        }
    });
}

bool LxUser::ChangeGold(int64 iChange, int32 reason, bool fireCost) {
    if( iChange == 0 ) {
        return true;
    }
    int64 iBeforeChange = PBGetUserGold();
    int64 iFinalNum = PBGetUserGold() + iChange;
    if( iFinalNum < 0 ) {
        return false;
    }
    ItemPair itemGold;
    itemGold.set_item_id(JDATA->SystemConstPtr()->GetGold());
    itemGold.set_item_change(iChange);
    itemGold.set_item_num(iFinalNum);
    PBSetUserGold(iFinalNum);
    OnItemChange(itemGold);

    if( fireCost ) {
        // 只会是渔场内开炮
        if( m_nFireLastTable == 0 ) {
            m_nFireLastTable = reason;
            m_nFireCost = iChange; // 是个负值
        }
        else if( m_nFireLastTable == reason ) {
            // 同一张桌子
            m_nFireCost += iChange; // 是个负值
        }
        else {
            // 本次开炮换了桌子了, 要记录之前开炮的累计值
            // iBeforeChange才是本次开炮扣除之前的金币数量, 即累计开炮之后的金币值
            LOG_GOLD_FLOW(this, iBeforeChange-m_nFireCost, iBeforeChange, m_nFireCost, m_nFireLastTable);
            m_nFireCost = iChange;
            m_nFireLastTable = reason;
        }
    }
    else {
        if( m_nFireCost != 0 ) {
            // 清空开炮的数据
            LOG_GOLD_FLOW(this, iBeforeChange-m_nFireCost, iBeforeChange, m_nFireCost, m_nFireLastTable);
            m_nFireCost = 0;
            m_nFireLastTable = 0;
        }
        // 渔场内开炮的金币变化不记录在gold_flow中
        LOG_GOLD_FLOW(this, iFinalNum-iChange, iFinalNum, iChange, reason);
    }

    if( iChange > 0 ) {
        if( iFinalNum > PBGetMaxGold() ) {
            GTaskSet(e_jsonGeneralTaskCondition_Gold_Max, 0, iFinalNum);
            PBSetMaxGold(iFinalNum);
        }
        if( reason != ELRI_RecvGift
            && reason != 100000+JDATA->SystemConstPtr()->GetGiftForceCloseMail()
            && reason != 100000+JDATA->SystemConstPtr()->GetSendExpiredOrderMail()
            && reason != 100000+JDATA->SystemConstPtr()->GetAcceptCancelOrderMail()
            && reason != 100000+JDATA->SystemConstPtr()->GetSendCancelOrderMail()
            && reason != 100000+JDATA->SystemConstPtr()->GetAcceptExpiredOrderMail() ) {
            PBIncWeekGoldWin(iChange);
        }

        if( reason == ELRI_Charge ) {
            ItemPair item;
            item.set_item_id(JDATA->SystemConstPtr()->GetGold());
            item.set_item_change(iChange);
            item.set_item_num(iChange);
            _frozens.Charged(item);
        }
    }
    else {
        if( reason != ELRD_SendGift ) {
            PBIncWeekGoldCost(-iChange);
        }
    }
    return true;
}

bool LxUser::ChangeCrystal(int64 iChange, int32 reason, bool fireCost) {
    if( iChange == 0 ) {
        return true;
    }
    int64 iBeforeChange = PBGetUserCrystal();
    int64 iFinalNum = PBGetUserCrystal() + iChange;
    if( iFinalNum < 0 ) {
        return false;
    }
    ItemPair itemCrystal;
    itemCrystal.set_item_id(JDATA->SystemConstPtr()->GetCrystal());
    itemCrystal.set_item_change(iChange);
    itemCrystal.set_item_num(iFinalNum);
    PBSetUserCrystal(iFinalNum);
    OnItemChange(itemCrystal);
    if( fireCost ) {
        // 只会是渔场内开炮
        if( m_nFireLastCrystalTable == 0 ) {
            m_nFireLastCrystalTable = reason;
            m_nFireCrystalCost = iChange; // 是个负值
        }
        else if( m_nFireLastCrystalTable == reason ) {
            // 同一张桌子
            m_nFireCrystalCost += iChange; // 是个负值
        }
        else {
            // 本次开炮换了桌子了, 要记录之前开炮的累计值
            // iBeforeChange才是本次开炮扣除之前的金币数量, 即累计开炮之后的金币值
            LOG_CRYSTAL_FLOW(this, iBeforeChange-m_nFireCrystalCost, iBeforeChange, m_nFireCrystalCost, m_nFireLastCrystalTable);
            m_nFireCrystalCost = iChange;
            m_nFireLastCrystalTable = reason;
        }
    }
    else {
        if( m_nFireCrystalCost != 0 ) {
            // 清空开炮的数据
            LOG_CRYSTAL_FLOW(this, iBeforeChange-m_nFireCrystalCost, iBeforeChange, m_nFireCrystalCost, m_nFireLastCrystalTable);
            m_nFireCrystalCost = 0;
            m_nFireLastCrystalTable = 0;
        }
        // 渔场内开炮的金币变化不记录在gold_flow中
        LOG_CRYSTAL_FLOW(this, iFinalNum-iChange, iFinalNum, iChange, reason);
    }
    if( iChange > 0 ) {
        PBIncWeekCrystalWin(iChange);
    }
    else {
        PBIncWeekCrystalCost(-iChange);
    }
    return true;
}

bool LxUser::CanChangeDiamond(int64 iChange) {
    return iChange > 0 || PBGetDiamondFree() + PBGetDiamondRmb() + iChange >= 0;
}

bool LxUser::ChangeDiamond(int64 iChange, int32 reason, bool isChargeLoot) {
    if( iChange == 0 ) {
        return true;
    }
    int64 iFreeDiamond = PBGetDiamondFree();
    int64 iRmbDiamond = PBGetDiamondRmb();
    if( iChange > 0 ) {
        if( isChargeLoot ) {
            PBIncDiamondRmb(iChange);
        }
        else {
            PBIncDiamondFree(iChange);
        }
    }
    else {
        if( iFreeDiamond + iRmbDiamond + iChange < 0 ) {
            return false;
        }
        // 先扣付费钻石
        iRmbDiamond += iChange;
        if( iRmbDiamond < 0 ) {
            PBSetDiamondRmb(0);
            iFreeDiamond += iRmbDiamond;
            PBSetDiamondFree(iFreeDiamond);
        }
        else {
            PBSetDiamondRmb(iRmbDiamond);
        }
    }
    int64 iFinalNum = PBGetDiamondRmb() + PBGetDiamondFree();
    ItemPair itemDiamond;
    itemDiamond.set_item_id(JDATA->SystemConstPtr()->GetDiamond());
    itemDiamond.set_item_change(iChange);
    itemDiamond.set_item_num(iFinalNum);
    PBSetUserDiamond(iFinalNum);
    OnItemChange(itemDiamond);
    if( iChange < 0 ) {
        GTaskInc(e_jsonGeneralTaskCondition_Diamond_Cost, 0, abs(iChange));
    }
    else {
        PBIncTotalSpent(iChange);
    }

    LOG_DIAMOND_FLOW(this, PBGetUserDiamond()-iChange, PBGetUserDiamond(), iChange, reason);
    return true;
}

////////////////////////////////////////////////////////////////////////////////////////////////
int32 LxUser::ItemUse(const UserItemUseReq& req) {
    int32 iItemId = req.item().item_id();
    int64 iNum = req.item().item_num();
    if( iNum < 0 ) {
        return JDATA->ErrorCodePtr()->GetItemUseNumFail();
    }
    if( !CanChangeItem(iItemId, -iNum) ) {
        return JDATA->ErrorCodePtr()->GetItemUseNumLow();
    }
    tagJsonItem tagItem;
    if( !JDATA->ItemPtr()->ByID(iItemId, tagItem) ) {
        return JDATA->ErrorCodePtr()->GetItemUseNoItem();
    }
    bool bNeedDel = true;
    switch(tagItem._MainType) {
    case e_jsonItemMainType_Gold:
        ChangeGold(tagItem._Misc, ELRI_ItemGiftBag);
        break;
    case e_jsonItemMainType_HeadFrame:
        bNeedDel = false;
        PBSetUserFrame(iItemId);
        break;
    case e_jsonItemMainType_SuperWeaponSkin:
        bNeedDel = false;
        PBSetUserSweapon(iItemId);
        // 同步一个换武器给渔场
        CALL_THREAD_SIMPLE(this, LxUserChangeWeapon);
        break;
    case e_jsonItemMainType_HeadIcon:
        bNeedDel = false;
        PBSetUserPortrait(iItemId);
        break;
    case e_jsonItemMainType_Property:
        bNeedDel = false;
        PBSetUserProperty(iItemId);
        break;
    case e_jsonItemMainType_DiamondBag:
        break;
    case e_jsonItemMainType_Energy:
        {
            PBIncUserCurEnergy((int32)iNum*tagItem._Misc);
            break;
        }
    case e_jsonItemMainType_TurretPart:
        {
            if( HasHero(tagItem._Misc) ) {
                LOGERROR("user[%lu] hero got item[%d] misc[%d]", GetKey(), iItemId, tagItem._Misc);
                return JDATA->ErrorCodePtr()->GetItemUseTurretFailed();
            }
            tagJsonHeroSet tag;
            if( !JDATA->HeroSetPtr()->ByID(tagItem._Misc, tag) ) {
                LOGERROR("user[%lu] hero config error item[%d] misc[%d]", GetKey(), iItemId, tagItem._Misc);
                return JDATA->ErrorCodePtr()->GetItemUseTurretFailed();
            }
            if( tag._CombinationNum == 0 ) {
                return JDATA->ErrorCodePtr()->GetItemUseTurretFailed();
            }
            if( !CanChangeItem(iItemId, -tag._CombinationNum) ) {
                return JDATA->ErrorCodePtr()->GetItemUseTurretFailed();
            }
            if( !GiveHero(tagItem._Misc, 1, 1, ELTBT_Combine) ) {
                return JDATA->ErrorCodePtr()->GetItemUseTurretFailed();
            }
            ItemChange(iItemId, -tag._CombinationNum, ELRD_ItemUse, false);
            bNeedDel = false;
            break;
        }
    case e_jsonItemMainType_SwingPart:
        {
            if( HasWing(tagItem._Misc) ) {
                LOGERROR("user[%lu] wing got item[%d] misc[%d]", GetKey(), iItemId, tagItem._Misc);
                return JDATA->ErrorCodePtr()->GetItemUseSwingFailed();
            }
            tagJsonWingData tag;
            if( !JDATA->WingDataPtr()->ByID(tagItem._Misc, tag) ) {
                LOGERROR("user[%lu] wing config error item[%d] misc[%d]", GetKey(), iItemId, tagItem._Misc);
                return JDATA->ErrorCodePtr()->GetItemUseSwingFailed();
            }
            if( tag._CombinationNum == 0 ) {
                return JDATA->ErrorCodePtr()->GetItemUseSwingFailed();
            }
            if( !CanChangeItem(iItemId, -tag._CombinationNum) ) {
                return JDATA->ErrorCodePtr()->GetItemUseSwingFailed();
            }
            if( !GiveWing(tagItem._Misc, 1, ELRI_ItemUse) ) {
                return JDATA->ErrorCodePtr()->GetItemUseSwingFailed();
            }
            ItemChange(iItemId, -tag._CombinationNum, ELRD_ItemUse, false);
            bNeedDel = false;
            break;
        }
    case e_jsonItemMainType_ItemPart:
        {
            if( tagItem._ItemParam <= 0 || !JDATA->ItemPtr()->ContainID(tagItem._Misc) ) {
                return JDATA->ErrorCodePtr()->GetSystemError();
            }
            int64 newItemNum = iNum / tagItem._ItemParam;
            if( newItemNum <= 0 ) {
                return JDATA->ErrorCodePtr()->GetSystemError();
            }
            if( !ItemChange(iItemId, -newItemNum*tagItem._ItemParam, ELRD_ItemUse, false) ) {
                return JDATA->ErrorCodePtr()->GetSystemError();
            }
            ItemChange(tagItem._Misc, newItemNum, ELRI_ItemUse, false);
            bNeedDel = false;
            break;
        }
    case e_jsonItemMainType_CustomPack:
        {
            // 自选礼包
            int32 loots = 0;
            for( int32 i = 0; i < req.choices_size(); i++ ) {
                int32 lootId = req.choices(i).loot_id();
                int32 num = req.choices(i).num();
                // 检查loot是否在道具配置中存在
                if( !GlobalUtils::InVector(lootId, tagItem._SelectLootID) ) {
                    return JDATA->ErrorCodePtr()->GetSystemError();
                }
                loots += num;
            }
            if( loots != iNum ) {
                return JDATA->ErrorCodePtr()->GetItemUseNumFail();
            }
            for( int32 i = 0; i < req.choices_size(); i++ ) {
                int32 lootId = req.choices(i).loot_id();
                int32 num = req.choices(i).num();
                for( int32 n = 0 ; n < num ; ++n ) {
                    GiveLoot(lootId, ELRI_CustomPack, false);
                }
            }
            break;
        }
    default:
        return JDATA->ErrorCodePtr()->GetItemUseTypeFail();
    }
    if( tagItem._LotteryID != 0 ) {
        for( int32 i = 0 ; i < iNum ; ++i ) {
            GiveLottery(tagItem._LotteryID, ELRI_ItemUse);
        }
    }
    if( bNeedDel ) {
        ItemChange(iItemId, -iNum, ELRD_ItemUse, false);
    }
    SendUserInfoChange(EPIC_ItemUse);
    return JDATA->ErrorCodePtr()->GetSuccess();
}

bool LxUser::CanRemoveItem(const map<int32, int64>& mapItem) {
    for( auto & item : mapItem ) {
        if( !CanChangeItem(item.first, -item.second) ) {
            return false;
        }
    }
    return true;
}

void LxUser::RemoveItem(const map<int32, int64>& mapItem, int32 reason) {
    for( auto & item : mapItem ) {
        ItemChange(item.first, -item.second, reason, false);
    }
}

bool LxUser::CanChangeItem(int32 iItemId, int64 iChangeNum) {
    if( iItemId == JDATA->SystemConstPtr()->GetGold() ) {
        return CanChangeGold(iChangeNum);
    }
    else if( iItemId == JDATA->SystemConstPtr()->GetDiamond() ) {
        return CanChangeDiamond(iChangeNum);
    }
    else if( iItemId == JDATA->SystemConstPtr()->GetCrystal() ) {
        return CanChangeCrystal(iChangeNum);
    }
    if( !JDATA->ItemPtr()->ContainID(iItemId) ) {
        return false;
    }
    if( iChangeNum >= 0 ) {
        return true;
    }

    auto item = m_mapItem.find(iItemId);
    if( item == m_mapItem.end() ) { return false; }
    if( item->second + iChangeNum < 0 ) { return false; }
    return true;
}

// 修改用户道具数量
bool LxUser::ItemChange(int32 iItemId, int64 iChangeNum, int32 reason, bool isChargeLoot)
{
	if( iChangeNum == 0 ) {
		return true;
	}
    if( iItemId == JDATA->SystemConstPtr()->GetGold() ) {
        return ChangeGold(iChangeNum, reason);
    }
    else if( iItemId == JDATA->SystemConstPtr()->GetDiamond() ) {
        return ChangeDiamond(iChangeNum, reason, isChargeLoot);
    }
    else if( iItemId == JDATA->SystemConstPtr()->GetCrystal() ) {
        return ChangeCrystal(iChangeNum, reason);
    }
    tagJsonItem itemConfig;
    if( !JDATA->ItemPtr()->ByID(iItemId, itemConfig) ) {
        return false;
    }
    if( iChangeNum > 0 ) {
        tagJsonItemRecycle tag;
        if( JDATA->ItemRecyclePtr()->ByID(iItemId, tag) ) {
            bool bNeedRecycle = tag._Channel.empty();// 不填肯定要回收
            for( size_t i = 0 ; i < tag._Channel.size() ; ++i ) {
                if( PBGetClientChannel() == tag._Channel[i] ) {
                    bNeedRecycle = true;    // 填了的上面会是false, 这里渠道相同了就回收
                    break;
                }
            }
            if( bNeedRecycle ) {
                // 超时物品, 直接回收
                int64 end = GlobalUtils::MakeTime(tag._RecycleTime);
                if( sGameUtils->GetFakeTimeNow() >= end ) {
                    ItemRecyclePayPrice(iChangeNum, tag._Price);
                    return true;
                }
            }
        }

        switch(itemConfig._MainType) {
        case e_jsonItemMainType_ResetItem:
            if( sGameUtils->IsTestServer() ) {
                PBSetTimeLastLogin(sGameUtils->GetFakeTimeNow() - TIME_DAY);
                CrossDay();
            }
            return true;
        case e_jsonItemMainType_CardDrawPoint:
            PBIncBombActCardNum(iChangeNum);
            return true;
        case e_jsonItemMainType_CollectionCard:
            PBIncBombTableCardNum(iChangeNum);
            return true;
        case e_jsonItemMainType_ResetCardDraw:
            // 重置核弹抽卡活动牌面数据
            _bombAct.ResetCards();
            return true;
        case e_jsonItemMainType_InstitutionLevel:
        {
            ItemPair itemShow;
            itemShow.set_item_id(iItemId);
            itemShow.set_item_change(1);
            itemShow.set_item_num(1);
            OnItemChange(itemShow);
            _tech.RmbUpgrade(itemConfig._Misc, itemConfig._ItemParam);
            return true;
        }
        case e_jsonItemMainType_AdditionLootCard:
            BuffActivate(itemConfig._Misc);
            return true;
        case e_jsonItemMainType_ResetGeneralTask:
            GTaskReset(e_jsonGeneralTaskCondition_Charge_Daily);
            GTaskReset(e_jsonGeneralTaskCondition_Sign_Up_Daily);
            GTaskReset(e_jsonGeneralTaskCondition_Skill_Release_Daily);
            GTaskReset(e_jsonGeneralTaskCondition_Kill_Fish_Daily);
            GTaskReset(e_jsonGeneralTaskCondition_Skill_Type_Daily);
            GTaskReset(e_jsonGeneralTaskCondition_Nuclear_Draw_Daily);
            GTaskReset(e_jsonGeneralTaskCondition_Use_Item_Daily);
            return true;
        case e_jsonItemMainType_ResetHeroUse:
            _hero.HeroAllResetTime();
            return true;
        case e_jsonItemMainType_UnlockInstitute:
        {
            ItemPair itemShow;
            itemShow.set_item_id(iItemId);
            itemShow.set_item_change(1);
            itemShow.set_item_num(1);
            OnItemChange(itemShow);
            _tech.Unlock(itemConfig._Misc);
            if( itemConfig._Misc == e_jsonInstituteID_SuperWeapon ) {
                // 如果是购买超级武器, 要设置一下超级武器默认皮肤
                PBSetUserSweapon(JDATA->SystemConstPtr()->GetSuperWeaponInitialSkinItemID());
                // 同步一个换武器给渔场
                CALL_THREAD_SIMPLE(this, LxUserChangeWeapon);
            }
            return true;
        }
        case e_jsonItemMainType_OpenClientLog:
        {
            PBSetShowLog(!PBGetShowLog());
            return true;
        }
        case e_jsonItemMainType_SetSendGiftPassword:
        {
            if( PBGetGiftCode().empty() ) {
                SetGiftCode("123456");
            }
            else {
                SetGiftCode("");
            }
            return true;
        }
        case e_jsonItemMainType_SetSendGiftPhoneNum:
        {
            if( PBGetUserPhone().empty() ) {
                PBSetUserPhone("+86-18001645279");
            }
            else {
                PBSetUserPhone("");
            }
            return true;
        }
        case e_jsonItemMainType_ResetGrowFund:
        {
            PBSetUserGrowthFundVersion(1);
            PBSetUserGrowthFlag(0);
            PBSetUserGrowthFund(0);
            return true;
        }
        case e_jsonItemMainType_ResetDoubleDiamond:
        {
            PBIncDoubleDiamond(1);
            return true;
        }
        default:
            break;
        }
    }
    bool needNotifyRedDot = false;
    int64 iFinalNum = 0;
    auto item = m_mapItem.find(iItemId);
    if( item == m_mapItem.end() ) {
        // 没有
        if( iChangeNum <= 0 ) {
            return false;
        }
        // 新获得的道具才会加红点
        needNotifyRedDot = true;
        m_mapItem[iItemId] = iChangeNum;
        iFinalNum = iChangeNum;
    }
    else {
        iFinalNum = iChangeNum + item->second;
        if( iFinalNum < 0 ) {
            return false;
        }
        if( iFinalNum == 0 ) {
            m_mapItem.erase(iItemId);
        }
        else {
            item->second = iFinalNum;
        }
    }

    ItemPair pair;
    pair.set_item_id(iItemId);
    pair.set_item_num(iFinalNum);
    pair.set_item_change(iChangeNum);
    OnItemChange(pair);

    bool isBombChange = (iItemId == JDATA->SystemConstPtr()->GetCardDrawNuclearID());
    if( needNotifyRedDot ) {
        m_dirtySystem.insert(ERDS_Inventory);
    }
    if( iChangeNum > 0 ) {
        if( iItemId == JDATA->SystemConstPtr()->GetCoupon() ) {
            // 获得礼券
            PBIncTotalCoupon(iChangeNum);
        }
        GTaskInc(e_jsonGeneralTaskCondition_Item_Collection, iItemId, iChangeNum);
        if( isBombChange ) {
            if( reason != ELRI_RecvGift
                && reason != 100000+JDATA->SystemConstPtr()->GetGiftForceCloseMail()
                && reason != 100000+JDATA->SystemConstPtr()->GetSendExpiredOrderMail()
                && reason != 100000+JDATA->SystemConstPtr()->GetAcceptCancelOrderMail()
                && reason != 100000+JDATA->SystemConstPtr()->GetSendCancelOrderMail()
                && reason != 100000+JDATA->SystemConstPtr()->GetAcceptExpiredOrderMail() ) {
                PBIncWeekBombWin(iChangeNum);
            }
            if( reason == ELRI_Charge ) {
                ItemPair item;
                item.set_item_id(iItemId);
                item.set_item_change(iChangeNum);
                item.set_item_num(iChangeNum);
                _frozens.Charged(item);
            }
        }
    }
    else {
        Day7Inc(e_jsonNewBieCarnivalCondition_Item_Use, iItemId, -iChangeNum);
        GTaskInc(e_jsonGeneralTaskCondition_Use_Item_Daily, iItemId, -iChangeNum);
        if( isBombChange && reason != ELRD_SendGift ) {
            // 送礼扣除不算消耗
            PBIncWeekBombCost(-iChangeNum);
        }
    }
    LOG_ITEM_FLOW(this, iItemId, iFinalNum-iChangeNum, iFinalNum, iChangeNum, reason);

    // 计算核弹总价值
    if( itemConfig._MainType == e_jsonItemMainType_NuclearBomb ) {
        PBIncTotalBombValue(itemConfig._ItemParam*iChangeNum);
    }
	return true;
}

void LxUser::SendSystemHint(const string& strMsg) {
    UserSystemMsg msg;
    msg.set_msg(strMsg);

    CALL_CLIENT(this, UserSystemMsg, msg);
}

void LxUser::AddExp(int32 iAddExp) {
	if( iAddExp <= 0 ) {
		return;
	}
	int32 curLevel = PBGetUserLevel();
	int32 maxLevel = sHExps->GetMaxLevel();
	// 满级了
	if( curLevel >= maxLevel ) {
		return;
	}
    int32 nTotalExp = iAddExp + PBGetUserExp(); // 当前可以到达的最高经验
    auto data = sHExps->GetUserLevelExpByTotalExp(curLevel, nTotalExp);
    int32 newLevel = TUPLE0(data);
    PBSetUserExp(TUPLE1(data));
	if( newLevel != curLevel ) {
        PBSetUserLevel(newLevel);
        LOG_USER_LEVELUP(this, curLevel, newLevel);
        OnQuestUserLevelup(newLevel);
        GTaskSet(e_jsonGeneralTaskCondition_User_Level, 0, newLevel);
	}
}

// 加vip经验
void LxUser::AddVipExp(int32 iAddExp) {
	if( iAddExp <= 0 ) {
		return;
	}
	int32 curLevel = PBGetUserVip();
	int32 maxLevel = sHExps->GetMaxVipLevel();
	// 满级了
	if( curLevel >= maxLevel ) {
		return;
	}
    int32 nTotalExp = iAddExp + PBGetVipExp(); // 当前可以到达的最高经验
    auto data = sHExps->GetVipLevelExpByTotalExp(curLevel, nTotalExp);
    int32 newLevel = TUPLE0(data);
    PBSetVipExp(TUPLE1(data));
	if( newLevel != curLevel ) {
        PBSetUserVip(newLevel);
        LOG_USER_VIP_LEVELUP(this, curLevel, newLevel);
        for( int32 i = curLevel + 1 ; i <= newLevel ; i++ ) {
            int32 lootId = JDATA->VIPPtr()->LootIDByID(i);
            int32 mailType = JDATA->VIPPtr()->MailTypeByID(i);
            map<int32, int64> mapItem;
            if( lootId != 0 && sHLottery->GetLootItem(lootId, mapItem) ) {
                SendMail(mailType, 0, 0, mapItem, "", "");
            }
        }
        Day7Set(e_jsonNewBieCarnivalCondition_VIP_Level, 0, newLevel);
        GTaskSet(e_jsonGeneralTaskCondition_VIP_Level, 0, newLevel);
	}
}

void LxUser::AddBattlePassExp(int64 iExp) {
    if( PBGetPassportId() != 0 ) {
        PBIncPassportExp(iExp);
    }
    else {
        PBIncBattlePassExp(iExp);
    }
}

void LxUser::GiveLottery(int32 lotteryId, int32 reason) {
    sHLottery->ForEachLotteryLoot(lotteryId, [&](int32 lootId) {
        GiveLoot(lootId, reason, false);
    });
}

void LxUser::GiveLoot(int32 iLoot, int32 reason, bool isChargeLoot, bool isVipBonus) {
    if( iLoot == 0 ) {
        return;
    }
    tagJsonLoot tagLoot;
    if( !JDATA->LootPtr()->ByID(iLoot, tagLoot) ) {
        LOGERROR("lootid[%d] failed user[%lu]", iLoot, GetKey());
        return;
    }
    int32 goldItemId = JDATA->SystemConstPtr()->GetGold();
    int32 diamondItemId = JDATA->SystemConstPtr()->GetDiamond();
    int32 goldBonus = 1;
    if( isVipBonus ) {
        goldBonus = max(1, JDATA->VIPPtr()->GoldBonusByID(PBGetUserVip()));
    }
    map<int32, int64> mapItem;
    map<int32, int32> mapTurret;
    map<int32, int32> mapSwing;
    sHLottery->GetLootItem(iLoot, mapItem, mapTurret, mapSwing);
    for( auto & it : mapItem ) {
        if( it.second <= 0 ) {
            continue;
        }
        if( !JDATA->ItemPtr()->ContainID(it.first) ) {
            continue;
        }
        int64 realNum = it.second;
        if( it.first == goldItemId ) {
            // 如果是受vipbonus影响的, 只影响到金币
            realNum *= goldBonus;
        }
        switch(reason) {
            case ELRI_WeekCardReward:
                if( it.first == goldItemId ) {
                    realNum += realNum*GetHeroRelationAttr(e_jsonHeroRelationAllAttribute_WeeklyCardGold)/1000;
                }
                break;
            case ELRI_MonthCardReward:
                if( it.first == diamondItemId ) {
                    realNum += realNum*GetHeroRelationAttr(e_jsonHeroRelationAllAttribute_MonthCardDiamond)/1000;
                }
                if( it.first == goldItemId ) {
                    realNum += realNum*GetHeroRelationAttr(e_jsonHeroRelationAllAttribute_MonthCardGold)/1000;
                }
                break;
            case ELRI_SuperMonthCardReward:
                if( it.first == diamondItemId ) {
                    realNum += realNum*GetHeroRelationAttr(e_jsonHeroRelationAllAttribute_SuperMonthCardDiamond)/1000;
                }
                if( it.first == goldItemId ) {
                    realNum += realNum*GetHeroRelationAttr(e_jsonHeroRelationAllAttribute_SuperMonthCardGold)/1000;
                }
                break;
            case ELRI_DailyDiscount:
                if( it.first == diamondItemId ) {
                    realNum += realNum*GetHeroRelationAttr(e_jsonHeroRelationAllAttribute_DailyPackDiamond)/1000;
                }
                if( it.first == goldItemId ) {
                    realNum += realNum*GetHeroRelationAttr(e_jsonHeroRelationAllAttribute_DailyPackGold)/1000;
                }
                break;
            default:
                break;
        }
        ItemChange(it.first, realNum, reason, isChargeLoot);
    }
    for( auto & it : mapTurret ) {
        for( int i = 0 ; i < it.second ; ++i ) {
            GiveHero(it.first, 1, 1, reason);
        }
    }
    for( auto & it : mapSwing ) {
        for( int i = 0 ; i < it.second ; ++i ) {
            GiveWing(it.first, 1, reason);
        }
    }
}

bool LxUser::CrossDay() {
    int64 tNow = sGameUtils->GetFakeTimeNow();
    if( !GlobalUtils::InSameWeek(tNow, PBGetTimeLastLogin()) ) {
        PBSetWeekGoldWin(0);
        PBSetWeekGoldCost(0);
        PBSetWeekBombWin(0);
        PBSetWeekBombCost(0);
        PBSetWeekCrystalWin(0);
        PBSetWeekCrystalCost(0);
        PBSetWeekVipScore(0);
    }
    if( !GlobalUtils::InSameDay(tNow, PBGetTimeLastLogin()) ) {
        _counter.CrossDay();
        PBSetTodayPovertyNum(0);
        PBSetTodayChargeBonus(0);
        PBSetTodayBrokenBonus(0);
        PBSetUserCurTide(0);
        PBIncLoginNum(1);
        PBSetTimeLastLogin(tNow);
        PBSetTodayCoupon(0);
        PBSetTodayDiamond(0);
        PBSetMarketRandNum(0);
        PBSetUserArenaNum(0);
        PBSetTodayOnlineTime(0);
        PBSetTodayFishTime(0);
        PBSetSignedToday(0);
        PBSetTodayFlag(0);
        PBSetTodayCharge(0);
        PBSetBombActCardNum(0);
        GTaskReset(e_jsonGeneralTaskCondition_Charge_Daily);
        GTaskReset(e_jsonGeneralTaskCondition_Sign_Up_Daily);
        GTaskReset(e_jsonGeneralTaskCondition_Skill_Release_Daily);
        GTaskReset(e_jsonGeneralTaskCondition_Kill_Fish_Daily);
        GTaskReset(e_jsonGeneralTaskCondition_Skill_Type_Daily);
        GTaskReset(e_jsonGeneralTaskCondition_Nuclear_Draw_Daily);
        GTaskReset(e_jsonGeneralTaskCondition_Use_Item_Daily);
        if( !JDATA->SignRewardPtr()->ContainSignNums(PBGetSignDayNum()+1) ) {
            PBSetSignDayNum(0);
        }
        _tts.CrossDay();
        _bombAct.CrossDay();
        _market.RandMarket(true);
        _frozens.CheckExpired(tNow);
        _gcounter.CrossDay();
        PBSetMcardToday(0);
        int64 mCardEnd = PBGetMcardEnd();
        if( mCardEnd > 0 && mCardEnd < tNow && !GlobalUtils::InSameDay(mCardEnd, tNow) ) {
            // 如果结束时间时昨天以前, 置0
            PBSetMcardEnd(0);
        }
        if( PBGetTotalCharge() == 0 ) {
            PBDecUserValue(JDATA->SystemConstPtr()->GetUserValueMinusForFree());
        }
        else {
            PBDecUserValue(JDATA->SystemConstPtr()->GetUserValueMinusForVIP());
        }
        if( PBGetUserValue() < 0 ) {
            PBSetUserValue(0);
        }
        FishPoolShrink();
        ItemRecycle();
        SlientFix();
        LOG_USER_LOGIN(this
                    ,PBGetUserGold()
                    ,PBGetDiamondFree()
                    ,PBGetDiamondRmb()
                    ,GetCouponNum()
                    ,0
                    ,PBGetTimeGame()
                    ,PBGetTimeOnline());
        DoVipDailyFix();
        _gtask.CheckExpired();
        return true;
    }
    return false;
}

void LxUser::DoVipDailyFix() {
    // vip每日补足
    tagJsonVIP tag;
    if( !JDATA->VIPPtr()->ByID(PBGetUserVip(), tag) || tag._Replenish.size() == 0 || tag._Replenish.size() % 2 != 0 ) {
        return;
    }
    SyncVipReplenish msg;
    int32 goldItemId = JDATA->SystemConstPtr()->GetGold();
    for( size_t i = 0; i+1 < tag._Replenish.size() ; i+= 2 ) {
        if( goldItemId == tag._Replenish[i] ) {
            // 补足钱
            if( PBGetUserGold() < tag._Replenish[i+1] ) {
                msg.set_gold(tag._Replenish[i+1]-PBGetUserGold());
                ChangeGold(tag._Replenish[i+1]-PBGetUserGold(), ELRI_VipDailyFix);
            }
        }
        else {
            int64 num = GetItemNum(tag._Replenish[i]);
            if( num < tag._Replenish[i+1] ) {
                auto ptr = msg.add_items();
                ptr->set_item_id(tag._Replenish[i]);
                ptr->set_item_change(tag._Replenish[i+1] - num);
                ptr->set_item_num(tag._Replenish[i+1] - num);
                ItemChange(tag._Replenish[i], tag._Replenish[i+1] - num, ELRI_VipDailyFix, false);
            }
        }
    }
    CALL_CLIENT(this, SyncVipReplenish, msg);
}

int32 LxUser::GetMaxEnergy() {
    int32 maxEnergy = JDATA->SystemConstPtr()->GetInitialEnergyMax();
    int32 vip = PBGetUserVip();
    if( vip > 0 ) {
        tagJsonVIP tag;
        if( JDATA->VIPPtr()->ByID(vip, tag) && tag._CustomTimes.size() >= 1 ) {
            maxEnergy += tag._CustomTimes[0];
        }
    }
    return maxEnergy;
}

void LxUser::UpdateEnergy() {
    int64 tNow = sGameUtils->GetFakeTimeNow();
    int32 maxEnergy = GetMaxEnergy();
    int32 curEnergy = PBGetUserCurEnergy();
    if( curEnergy < maxEnergy ){
        // 按时间加能量值
        int32 seconds = JDATA->SystemConstPtr()->GetEnergyRecoveryTime();
        if( seconds > 0 ) {
            int32 energy = (tNow - PBGetUserEnergyTime())/seconds;
            if( energy > 0 ) {
                curEnergy = min(maxEnergy, energy + curEnergy);
                PBSetUserCurEnergy(curEnergy);
                PBSetUserEnergyTime(tNow);
                SendUserInfoChange(0);
            }
        }
    }
}

bool LxUser::IsValid() {
    if( GetKey() == 0 ) {
        return false;
    }
    int64 tOffline = PBGetTimeOffline();
    if( tOffline > 0 && sGameUtils->GetFakeTimeNow() - tOffline >= 60 ) {
        return false;
    }
    return true;
}

// 实际是一个1秒的时钟
void LxUser::Update(int32 dt) {
    FETCH_VOID();
    int64 tNow = sGameUtils->GetFakeTimeNow();
    bool isCrossDay = CrossDay();
    RedisCmdHandler::ProcessCmd(pConnection, this);
    UpdateEnergy();
    PBIncTodayOnlineTime(dt/1000);
    // 在3秒时钟里检查一下新手7日话费红包活动是否过期,如果过期了,设置id为0, 但是不重置其他数据, 用于后续查询
    // 在这里设置的原因: 开炮中会根据id是否为0来判定是否需要累计金币消耗, 如果同时也判定是否过期,会需要高频调用GetFakeTimeNow(), 效率上不太友好
    if( PBGetNewbieFeeId() != 0 ) {
        if( tNow >= PBGetNewbieFeeEnd() ) {
            PBSetNewbieFeeId(0);
        }
    }
    int32 pid = 0;
    if( PBGetPassportId() == 0 ) {
        // 看看战令的vip 是否领完, 如果领完了, 就切换到新的月度通行证体系
        if( PBGetBattlePassVipNow() > 0 && !JDATA->BattlePassPtr()->ContainID(PBGetBattlePassVipNow()+1) ) {
            // 相当于战令已经领完了
            pid = JDATA->SystemConstPtr()->GetPeriodPassID();
        }
    }
    else {
        tagJsonPeriodPassControl tag;
        if( JDATA->PeriodPassControlPtr()->ByID(PBGetPassportId(), tag) ) {
            if( PBGetPassportExpire() <= tNow || PBGetPassportVipNow() >= sHPass->GetGroupMaxLevel(tag._ContentID) ) {
                // 当前的已经过期了, 或者vip最大等级已经领取了, 切换到新的通行证
                pid = tag._DirectionID;
            }
        }
    }

    if( pid != 0 ) {
        tagJsonPeriodPassControl tag;
        if( JDATA->PeriodPassControlPtr()->ByID(pid, tag) ) {
            // 重置到下一个新的月度通行证
            PBSetPassportId(pid);
            PBSetPassportExpire(tNow + JDATA->PeriodPassControlPtr()->LastingTimeByID(tag._DirectionID));
            PBSetPassportVipNow(-1);
            PBSetPassportExp(0);
            PBSetPassportNow(0);
        }
    }
    bool bTechChanged = _tech.Update(tNow);
    bool bHuntChanged = _hunt.Update(tNow);
    if( isCrossDay || bTechChanged || bHuntChanged ) {
        SendUserInfoChange(-2);
    }

    if( tNow - m_tmLastBoardUpdate > TIME_MIN ) {
        m_tmLastBoardUpdate = tNow;
        UpdateBoardData();
    }
    _friend.Update(pConnection);
}

void LxUser::UpdateBoardData() {
    // 在线时每5分钟更新, 离线时实时刷新一下
    LxUserBoardData msg;
    auto ptr = msg.mutable_user();
    ptr->set_user_id(GetKey());
    ptr->set_user_vip(PBGetUserVip());
    ptr->set_user_name(PBGetUserName());
    ptr->set_user_head(PBGetUserPortrait());
    ptr->set_user_frame(PBGetUserFrame());
    ptr->set_user_gold_win(PBGetWeekGoldWin());
    ptr->set_user_gold_cost(PBGetWeekGoldCost());
    ptr->set_user_bomb_win(PBGetWeekBombWin());
    ptr->set_user_bomb_cost(PBGetWeekBombCost());
    ptr->set_user_crystal_win(PBGetWeekCrystalWin());
    ptr->set_user_crystal_cost(PBGetWeekCrystalCost());
    ptr->set_user_vip_score(PBGetWeekVipScore());
    CALL_THREAD(this, LxUserBoardData, msg);

    PBSetWeekGoldWin(0);
    PBSetWeekGoldCost(0);
    PBSetWeekBombWin(0);
    PBSetWeekBombCost(0);
    PBSetWeekCrystalWin(0);
    PBSetWeekCrystalCost(0);
    PBSetWeekVipScore(0);
}

int32 LxUser::GetChargeTimes(const string& strProductName) {
    int32 chargeTimes = 0;
    for( auto& product : m_lstCharge ) {
        if( product.product() == strProductName ) {
            chargeTimes++;
        }
    }
    return chargeTimes;
}

int32 LxUser::Day7ExpReward() {
    if( PBGetSevenDayRewarded() != 0 ) {
        return JDATA->ErrorCodePtr()->GetSevenDayExpRewarded();
    }
    if( PBGetSevenDayExp() < JDATA->SystemConstPtr()->GetNewBieCarnivalExp() ) {
        return JDATA->ErrorCodePtr()->GetSevenDayExpLow();
    }
    int32 lootId = JDATA->SystemConstPtr()->GetNewBieCarnivalLoot();
    if( lootId == 0 ) {
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    GiveLoot(lootId, ELRI_SevenDayExp, false);
    PBSetSevenDayRewarded(1);
    return JDATA->ErrorCodePtr()->GetSuccess();
}

void LxUser::GTaskInc(int32 type, int64 param, int64 value) {
    list<GeneralTaskInfo> lst;
    sHGTask->GetGeneralTasks(type, param, lst);
    for( auto& info : lst ) {
        _gtask.GTaskInc(info, value);
    }
}

void LxUser::GTaskSet(int32 type, int64 param, int64 value) {
    list<GeneralTaskInfo> lst;
    sHGTask->GetGeneralTasks(type, param, lst);
    for( auto& info : lst ) {
        _gtask.GTaskSet(info, value);
    }
}

void LxUser::GTaskReset(int32 type) {
    list<GeneralTaskInfo> lst;
    sHGTask->GetGeneralTasks(type, lst);
    for( auto& info : lst ) {
        // 根据昨日完成度和昨日活跃数值计算任务
        auto data = GTaskInfo(info.task_id());
        bool doneYesterday = TUPLE0(data);
        int32 t1 = TUPLE1(data);
        int32 target = JDATA->GeneralTaskPtr()->DynamicTargetByID(info.task_id());
        if( target != 0 ) {
            int32 a1 = _counter.GetYesterday(target);
            int32 t2 = 0;
            if( doneYesterday ) {
                t2 = GlobalUtils::GetRandNumber(t1, (int32)(2*sqrt(a1)));
            }
            else {
                t2 = GlobalUtils::GetRandNumber(t1, (int32)(sqrt(a1)));
            }
            info.set_task_target_need( max(info.task_target_need(), (int64)t2) );
        }
        _gtask.GTaskReset(info);
    }
}

void LxUser::GTaskOnQuestFishKilled(const set<int32>& setTaskGroup) {
    for( auto & gid : setTaskGroup ) {
        GTaskInc(e_jsonGeneralTaskCondition_Kill_Fish, gid, 1);
        GTaskInc(e_jsonGeneralTaskCondition_Kill_Fish_Daily, gid, 1);
    }
}

void LxUser::Day7Inc(int32 type, int32 param, int64 value) {
    list<SevenDayInfo> lst;
    sHDay7->GetSevenDayQuests(type, param, GetRegDays(), lst);
    for( auto& info : lst ) {
        _day7.Day7Inc(info, value);
    }
}

void LxUser::Day7Set(int32 type, int32 param, int64 value) {
    list<SevenDayInfo> lst;
    sHDay7->GetSevenDayQuests(type, param, GetRegDays(), lst);
    for( auto& info : lst ) {
        _day7.Day7Set(info, value);
    }
}

int32 LxUser::GetRegDays() {
    return GlobalUtils::GetDayDiff(sGameUtils->GetFakeTimeNow(), PBGetTimeRegister())+1;
}

void LxUser::Day7OnQuestFishKilled(const set<int32>& setTaskGroup) {
    for( auto & gid : setTaskGroup ) {
        Day7Inc(e_jsonNewBieCarnivalCondition_Kill_Fish, gid, 1);
    }
}

bool LxUser::IsBattlePassBought() {
    // 由于老账户存在, 默认值需要设置成-1, 在ThreadData那边已经处理过, 这里再防一手
    // 玩家充值的订单数量不会太多, 登陆的时候处理一下不太影响效率
    for( auto & data : m_lstCharge ) {
        if( JDATA->ChargePtr()->ProductTypeByProductName(data.product()) == e_jsonChargeProductType_BattlePass ) {
            return true;
        }
    }
    return false;
}

void LxUser::Charged(const string& product, const string& orderNo, const string& tpOrderNo, const string& src) {
    for( auto & data : m_lstCharge ) {
        if( data.sdk_order_number() == orderNo || data.thirdparty_order_number() == tpOrderNo ) {
            LOGERROR("user[%lu] product[%s], orderNo[%s] tpOrderNo[%s] duplicated", GetKey(), product.data(), orderNo.data(), tpOrderNo.data());
            return;
        }
    }
   	tagJsonCharge rhs;
    if( !JDATA->ChargePtr()->ByProductName(product, rhs) ) {
        LOGERROR("user[%lu] Charge product not found[%s]", GetKey(), product.c_str());
        return;
    }
    int64 tNow = sGameUtils->GetFakeTimeNow();
    SendUserInfoChange(0);// 先同步一次, 保证本次金额不会受到开炮影响
    int32 nLootId = rhs._LootID;
    int32 nExtraLoot = 0;
    if( GetChargeTimes(rhs._ProductName) < PBGetDoubleDiamond() ) {
        nExtraLoot = rhs._ExtraLootId;
    }
    // 首冲奖励
    int32 nFirstLoot = JDATA->SystemConstPtr()->GetfirstLoot();
    // 先增加一次充值列表
    UserChargeData data;
    data.set_thirdparty_order_number(tpOrderNo);
    data.set_sdk_order_number(orderNo);
    data.set_product(product);
    data.set_buy_time(tNow);
    m_lstCharge.push_back(data);
    m_dirtyProducts.push_back(data);

    int32 reason = ELRI_Charge;
    switch( rhs._ProductType ) {
    case e_jsonChargeProductType_MemberCard:
        {
            if( PBGetMcardEnd() == 0 ) {
                PBSetMcardEnd(tNow+29*TIME_DAY);
            }
            else {
                PBIncMcardEnd(30*TIME_DAY);
            }
        }
        break;
    case e_jsonChargeProductType_OneYuan:
        // 1元奖励无法获得首充奖励
        nFirstLoot = 0;
        break;
    case e_jsonChargeProductType_CouponDraw:
        nFirstLoot = 0;
        _draw.DrawReward(product);
        break;
    case e_jsonChargeProductType_GrowthFund:
    {
        PBSetUserGrowthFund(1);

        ItemPair gf;
        gf.set_item_id(JDATA->SystemConstPtr()->GetGrownFundItemID());
        gf.set_item_change(1);
        gf.set_item_num(1);
        OnItemChange(gf);
        break;
    }
    case e_jsonChargeProductType_BattlePass:
        if( PBGetBattlePassVipNow() < 0 ) {
            PBSetBattlePassVipNow(0);
        }
        break;
    case e_jsonChargeProductType_BattlePass2:
        if( PBGetPassportId() != 0 && PBGetPassportVipNow() < 0 ) {
            PBSetPassportVipNow(0);
        }
        break;
    case e_jsonChargeProductType_WeeklyCard:
        if( PBGetTimeWeek() <= tNow ) {
            PBSetTimeWeek(tNow + 7*TIME_DAY + GetHeroRelationAttr(e_jsonHeroRelationAllAttribute_WeeklyCardTime)*TIME_HOUR/1000);
        }
        else {
            PBIncTimeWeek(7*TIME_DAY + GetHeroRelationAttr(e_jsonHeroRelationAllAttribute_WeeklyCardTime)*TIME_HOUR/1000);
        }
        break;
    case e_jsonChargeProductType_MonthCard:
        if( PBGetTimeMonth() <= tNow ) {
            PBSetTimeMonth(tNow + 30*TIME_DAY + GetHeroRelationAttr(e_jsonHeroRelationAllAttribute_MonthCardTime)*TIME_HOUR/1000);
        }
        else {
            PBIncTimeMonth(30*TIME_DAY + GetHeroRelationAttr(e_jsonHeroRelationAllAttribute_MonthCardTime)*TIME_HOUR/1000);
        }
        break;
    case e_jsonChargeProductType_SuperMonthCard:
        if( PBGetTimeMonthSuper() <= tNow ) {
            PBSetTimeMonthSuper(tNow + 30*TIME_DAY + GetHeroRelationAttr(e_jsonHeroRelationAllAttribute_SuperMonthCardTime)*TIME_HOUR/1000);
        }
        else {
            PBIncTimeMonthSuper(30*TIME_DAY + GetHeroRelationAttr(e_jsonHeroRelationAllAttribute_SuperMonthCardTime)*TIME_HOUR/1000);
        }
        break;
    case e_jsonChargeProductType_DailyLimit:
        reason = ELRI_DailyDiscount;
        break;
    }
    GiveLoot(nLootId, reason, true, rhs._VIPBonus);
    GiveLoot(nExtraLoot, ELRI_Charge, false);
    SendMail(rhs._MailType);
    if( m_userInfo.user_charge_loot() == 0 && nFirstLoot != 0 ) {
        PBSetUserChargeLoot(1);
        // 1元充值无法获得首充礼包
        GiveLoot(nFirstLoot, ELRI_Charge, false);
        // 首冲邮件
        SendMail(e_jsonMailType_firstChargeMail);
    }
    AddVipExp(rhs._Price);
    PBIncTotalCharge(rhs._Price);
    if( rhs._FeelingBonus > 0 ) {
        // User类操作m_userInfo字段, 捕鱼的发送消息给捕鱼线程处理, 因为有可能当时并不在捕鱼
        PBIncTodayChargeBonus(rhs._FeelingBonus);
        PBIncTotalChargeBonus(rhs._FeelingBonus);
        FishPoolOnCharge(rhs._FeelingBonus);
    }
    PBIncTodayCharge(rhs._Price);
    GTaskInc(e_jsonGeneralTaskCondition_Charge, 0, rhs._Price);
    GTaskSet(e_jsonGeneralTaskCondition_Charge_Daily, 0, PBGetTodayCharge());
    PBSetUserValue(JDATA->SystemConstPtr()->GetUserValueInitial());
    PBIncVoucherControl(rhs._Price*JDATA->SystemConstPtr()->GetTreasureBoxVoucherChargeRate()/10000);
    PBDecSummonBossPoint(rhs._BossFeelingBonus);
    LOG_PURCHASE(this, product, orderNo, tpOrderNo, PBGetClientChannel(), src, rhs._Price);

    PBIncWeekVipScore(rhs._Price*100);
}

void LxUser::BindUserIdCard(const string& idcard) {
    PBSetUserIdcard(idcard);
    GiveLoot(JDATA->SystemConstPtr()->GetBindIdentityLootID(), ELRI_IdCard, false);
    SendMail(JDATA->SystemConstPtr()->GetBindIdentityMailID());
    SendUserInfoChange(EPIC_BindIdCard);
}

void LxUser::BindUserPhone(const string& phone) {
    PBSetUserPhone(phone);
    PBIncPopularity(JDATA->SystemConstPtr()->GetBindPhoneAddPopularity());
    SendUserInfoChange(EPIC_BindPhone);
}

bool LxUser::SendMail(int32 nMailType, int64 iDiamond, int64 iGold, const map<int32, int64>& mapItem, const string& title, const string& content) {
    LxMail mail;
    if( !sDispatcher->make_mail(GetKey(), nMailType, iDiamond, iGold, mapItem, title, content, mail) ) {
        return false;
    }
    return SendMail(mail);
}

bool LxUser::SendMail(LxMail& mail) {
    m_dirtySystem.insert(ERDS_Mail);
    PBIncAutoid(1);
    mail.set_mail_id(PBGetAutoid());
    _mail.NewMail(mail);
    LOG_USER_MAIL(this, mail.mail_id(), mail.mail_read()*10+mail.mail_rewarded(), mail.mail_type());
    return true;
}

int32 LxUser::GetCurWingIndex() {
    HeroInfo ti;
    if( !GetCurHero(ti) ) {
        return 0;
    }
    return ti.hero_wing_index();
}

int32 LxUser::GetCurHeroStar() {
    HeroInfo ti;
    if( !GetCurHero(ti) ) {
        return 0;
    }
    return ti.hero_star();
}

void LxUser::StartNewbieFee(int32 id, int32 seconds) {
    // 开启新手领取话费红包
    if( PBGetNewbieFeeId() == 0 ) {
        PBSetNewbieFeeId(id);
        PBSetNewbieFeeEnd(sGameUtils->GetFakeTimeNow() + seconds);
        PBSetNewbieFeeDraw(0);
        PBSetNewbieFeeGold(0);
        PBSetNewbieFeeCoupon(0);
    }
}

int32 LxUser::SignDay() {
    if( PBGetSignedToday() != 0 ) {
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    int32 nSignDayNum = PBGetSignDayNum() + 1;
    tagJsonSignReward reward;
    if( !JDATA->SignRewardPtr()->BySignNums(nSignDayNum, reward) ) {
        nSignDayNum = 1;
        if( !JDATA->SignRewardPtr()->BySignNums(nSignDayNum, reward) ) {
            return JDATA->ErrorCodePtr()->GetSystemError();
        }
    }
    int32 vipBonus = max(1, JDATA->VIPPtr()->SignRewardByID(PBGetUserVip()));
    int64 gold = reward._DiamondDay * vipBonus;
    ChangeGold(gold, ELRI_Sign);
    PBSetSignDayNum(nSignDayNum);
    PBSetSignedToday(1);
    LOG_SIGN_UP(this, 0, 0, nSignDayNum, 0);
    Day7Inc(e_jsonNewBieCarnivalCondition_Sign_Up_Days, 0, 1);
    GTaskInc(e_jsonGeneralTaskCondition_Sign_Up_Days, 0, 1);
    GTaskInc(e_jsonGeneralTaskCondition_Sign_Up_Daily, 0, 1);

    SendUserInfoChange(EPIC_SignDay);

    return JDATA->ErrorCodePtr()->GetSuccess();
}

int64 LxUser::GetUserGoldProperty() {
    return PBGetUserGold() + PBGetTotalBombValue();
}

void LxUser::RewardPoverty(int64 iGold) {
    // 玩家当天首次领取破产补助时，若玩家当前金币数量+弹头金币总价值小于 1亿(配置)，则把净分重置为0。
    // 玩家当天非首次领取破产补助时，若玩家当前金币数量+弹头金币总价值小于 1亿(配置)，则20%几率(配置)把净分重置为0。
    int64 goldValue = GetUserGoldProperty();
    if( goldValue < JDATA->SystemConstPtr()->GetUserTotalGoldValue() ) {
        if( PBGetTodayPovertyNum() == 0 || GlobalUtils::GetRandNumber(0,10000) < JDATA->SystemConstPtr()->GetPovertyResetRate() ) {
            // 当日首次破产, 或者20%几率, 重置净分
            PBSetFishWinGold(0);
            PBSetFishCostGold(0);
            PBSetUserChargeBonus(0);
            PBSetUserChargeBonusFlag(1);// 进入释放阶段
        }
    }
    if( GlobalUtils::GetRandNumber(0,100) < JDATA->SystemConstPtr()->GetUserValueAddForPovertyRate() ) {
        PBIncUserValue(JDATA->SystemConstPtr()->GetUserValueAddForPoverty());
    }

    ChangeGold(iGold, ELRI_Poverty);
    PBIncTodayPovertyNum(1);
    PBIncTotalPoverty(1);
}

void LxUser::TideCompleted(int32 tideId) {
    int32 preTide = JDATA->GamePlayPtr()->PreRoomIDByID(tideId);
    if( preTide != PBGetUserCurTide() ) {
        // 说明是跨天结束的场次 此时当前关卡应该是被重置成0了, 这里不做更新
    }
    else {
        PBSetUserCurTide(tideId);
    }
    // 2021/07/02 lastTide修改为最大tideid
    int32 maxTide = PBGetUserLastTide();
    if( tideId > maxTide ) {
        PBSetUserLastTide(tideId);
    }
}

int32 LxUser::CheckEnterRoom(const tagJsonGamePlay& rhs) {
    int64 now = sGameUtils->GetFakeTimeNow();
    // 判断金币上下限
    if( rhs._GameType == e_jsonGamePlayGameType_Classic ) {
        if( PBGetUserGold() < rhs._MinGoldPlay) {
            return JDATA->ErrorCodePtr()->GetFishEnterGoldLow();
        }
        if( rhs._MaxGoldPlay > 0 && PBGetUserGold() >= rhs._MaxGoldPlay) {
            return JDATA->ErrorCodePtr()->GetFishEnterGoldHigh();
        }
    }
    else if( rhs._GameType == e_jsonGamePlayGameType_Tower ) {
        if( rhs._PreRoomID != 0 && rhs._PreRoomID != PBGetUserCurTide() ) {
            // 进入的不是初始鱼潮关卡,并且上一关没通关
            return JDATA->ErrorCodePtr()->GetFishEnterWrongTower();
        }
    }
    else if( rhs._GameType == e_jsonGamePlayGameType_Arena ) {
        int32 vipNums = 0;
        int32 vip = PBGetUserVip();
        if( vip > 0 ) {
            tagJsonVIP tag;
            if( JDATA->VIPPtr()->ByID(vip, tag) && tag._CustomTimes.size() >= 2 ) {
                vipNums = tag._CustomTimes[1];
            }
        }
        if( PBGetUserArenaNum() >= rhs._DailyTimes + vipNums ) {
            return JDATA->ErrorCodePtr()->GetFishEnterArenaNumLow();
        }
        // 竞技场要判断炮台今日是否使用过了
        HeroInfo ti;
        if( !GetCurHero(ti) || GlobalUtils::InSameDay(now, ti.hero_arena_time()) ) {
            return JDATA->ErrorCodePtr()->GetFishEnterTurretFail();
        }
    }
    else if( rhs._GameType == e_jsonGamePlayGameType_Custom_Gold
            || rhs._GameType == e_jsonGamePlayGameType_Custom_Stone
            || rhs._GameType == e_jsonGamePlayGameType_Custom_Feather ) {
        if( PBGetUserCurEnergy() < rhs._EnergyCost ) {
            return JDATA->ErrorCodePtr()->GetFishEnterLowEnergy();
        }
        if( !sHActs->IsCustomActivityOpen(rhs._GameType) ) {
            return JDATA->ErrorCodePtr()->GetSystemError();
        }
        // 休闲场场要判断炮台今日是否使用过了
        HeroInfo ti;
        if( !GetCurHero(ti) || GlobalUtils::InSameDay(now, ti.hero_casual_time()) ) {
            return JDATA->ErrorCodePtr()->GetFishEnterTurretFail();
        }
    }
    return JDATA->ErrorCodePtr()->GetSuccess();
}

void LxUser::SetFishTableInfo(int32 tid, int32 tindex, int64 endTime) {
    PBSetFishTableId(tid);
    PBSetFishTableIndex(tindex);
    PBSetFishTableEndTime(endTime);
}

int32 LxUser::GetFishTableId() {
    return PBGetFishTableId();
}

bool LxUser::CanKillByBrokenBonus(int64 tableMax) {
    if( PBGetTotalBrokenBonus() >= JDATA->SystemConstPtr()->GetPovertyProtectHistoryTotal() + PBGetTotalChargeBonus() ) {
        return false;
    }
    if( PBGetTodayBrokenBonus() >= tableMax + PBGetTodayChargeBonus() ) {
        return false;
    }
    return GlobalUtils::GetRandNumber(0,10000) < JDATA->SystemConstPtr()->GetPovertyProtectRate();
}

void LxUser::KillByBrokenBonus(int64 gold) {
    PBIncTodayBrokenBonus(gold);
    PBIncTotalBrokenBonus(gold);
}

void LxUser::IncGameTime(int32 gameTime) {
    PBIncTodayFishTime(gameTime);
    PBIncTimeGame(gameTime);
    // 7日任务的游戏时长按分钟计时, 渔场内按分钟同步数据
    GTaskInc(e_jsonGeneralTaskCondition_Game_Time, 0, gameTime/60);
}

int64 LxUser::GetCouponNum() {
    return GetItemNum(JDATA->SystemConstPtr()->GetCoupon());
}

////////////////////////////////////////////////////////////////////////////////////////////
void LxUser::SendUserInfoChange(int32 reason) {
    if( GetKey() == 0 ) {
        LOGERROR("FATAL SendUserInfoChange called after OnRecycled");
        return;
    }
    // NOTICE: 本函数是同时处理更新和删除
    // 如果出现在一个协议里删除和增加同一个id的对象,这里会出现逻辑错误
    // 所以这种情况下,在删除和增加两项操作当中要插入一个SendUserInfoChange
    bool bNeedSyncClient = false;
    bool bNeedSave = false;
	SyncUserInfoChange info;
    LxSaveData saveData;
    info.set_reason(reason);
    for(auto& key : m_dirtyFields) {
        auto pField = saveData.add_fields();
        RedisProtoHelper::UserInfoGetFieldPair(key, m_userInfo, *pField);
        bNeedSave = true;

        if( !RedisProtoHelper::IsServerOnlyField(key) ) {
            *info.add_fields() = *pField;
            bNeedSyncClient = true;
        }
    }
    int32 iGoldItem = JDATA->SystemConstPtr()->GetGold();
    int32 iDiamondItem = JDATA->SystemConstPtr()->GetDiamond();
    for( auto& it : m_dirtyItems ) {
        *info.add_items() = it.second;
        if( it.second.item_num() == 0 ) {
            saveData.add_del_items(it.second.item_id());
        }
        else {
            int32 itemId = it.second.item_id();
            int32 itemType = JDATA->ItemPtr()->MainTypeByID(itemId);
            if( itemId != iGoldItem && itemId != iDiamondItem
                && itemType != e_jsonItemMainType_InstitutionLevel
                && itemType != e_jsonItemMainType_GrownFund
                && itemType != e_jsonItemMainType_UnlockInstitute ) {
                *saveData.add_items() = it.second;
            }
        }
        bNeedSyncClient = true;
        bNeedSave = true;
    }
    for( auto& sys : m_dirtySystem ) {
        info.add_systems(sys);
    }

    if( _hero.FillProto(info, saveData) ) {
        bNeedSyncClient = true;
        bNeedSave = true;
    }
    if( _wing.FillProto(info, saveData) ) {
        bNeedSyncClient = true;
        bNeedSave = true;
    }
    if( _quest.FillProto(info, saveData) ) {
        bNeedSyncClient = true;
        bNeedSave = true;
    }
    if( _day7.FillProto(info, saveData) ) {
        bNeedSyncClient = true;
        bNeedSave = true;
    }
    if( _gtask.FillProto(info, saveData) ) {
        bNeedSyncClient = true;
        bNeedSave = true;
    }
    if( _tts.FillProto(info, saveData) ) {
        bNeedSyncClient = true;
        bNeedSave = true;
    }
    if( _market.FillProto(info, saveData) ) {
        bNeedSyncClient = true;
        bNeedSave = true;
    }
    if( _mail.FillProto(info, saveData) ) {
        bNeedSave = true;
    }
    if( _draw.FillProto(info, saveData) ) {
        bNeedSave = true;
    }
    if( _bombAct.FillProto(saveData) ) {
        bNeedSave = true;
    }
    if( _tech.FillProto(info, saveData) ) {
        bNeedSyncClient = true;
        bNeedSave = true;
    }
    if( _buff.FillProto(info, saveData) ) {
        bNeedSyncClient = true;
        bNeedSave = true;
    }
    if( _treasure.FillProto(info, saveData) ) {
        bNeedSyncClient = true;
        bNeedSave = true;
    }
    if( _counter.FillProto(saveData) ) {
        bNeedSave = true;
    }
    if( _boss.FillProto(saveData) ) {
        bNeedSave = true;
    }
    if( _hunt.FillProto(info, saveData) ) {
        bNeedSyncClient = true;
        bNeedSave = true;
    }
    if( _friend.FillProto(info, saveData) ) {
        bNeedSyncClient = true;
        bNeedSave = true;
    }
    if( _block.FillProto(info, saveData) ) {
        bNeedSyncClient = true;
        bNeedSave = true;
    }
    // 充值商品
    for( auto& product : m_dirtyProducts ) {
        *saveData.add_products() = product;
        *info.add_charges() = product;
        bNeedSave = true;
        bNeedSyncClient = true;
    }
    // 抽卡中奖记录
    for( auto& rec : m_dirtyBombGameRecord ) {
        *saveData.add_bomb_rewards() = rec;
        bNeedSave = true;
    }
    // 兑换
    for( auto& guid : m_dirtyExchanges ) {
        *saveData.add_exchanges() = m_mapExchanges[guid];
        bNeedSave = true;
    }
    if( m_nTreasureRelationId != 0 ) {
        info.set_treasure_relation_id( m_nTreasureRelationId );
        for( auto & card : m_treasureCards ) {
            info.add_treasure_cards(card);
        }
        m_nTreasureRelationId = 0;
        m_treasureCards.clear();
    }
    if( _frozens.FillProto(info, saveData) ) {
        bNeedSyncClient = true;
        bNeedSave = true;
    }
    if( _gcounter.FillProto(info, saveData) ) {
        bNeedSyncClient = true;
        bNeedSave = true;
    }

    m_dirtyItems.clear();
    m_dirtyFields.clear();
    m_dirtyProducts.clear();
    m_dirtySystem.clear();
    m_dirtyExchanges.clear();
    m_dirtyBombGameRecord.clear();

    if( bNeedSyncClient ) {
        CALL_CLIENT(this, SyncUserInfoChange, info);
    }
    if( bNeedSave ) {
        CALL_THREAD(this, LxSaveData, saveData);
    }
}

///////////////////////////////////////////////////////////////////////////////////////////
// 捕鱼个人奖池+输赢分处理部分

// 进入桌面时初始化个人奖池信息
void LxUser::ResetFishPool(const vector<int64>& vecPersonalFund) {
    PBSetFishPoolInUse(0);
    if( vecPersonalFund.size() == 3 ) {
        PBSetFishPoolRate(vecPersonalFund[0]);
        PBSetFishPoolStart(vecPersonalFund[1]);
        PBSetFishPoolEnd(vecPersonalFund[2]);
    }
}

void LxUser::FishPoolOnFire(int64 gold) {
    PBIncFishCostGold(gold);
    FishPoolCheck();
}

void LxUser::FishPoolKillFish(int64 gold) {
    // 玩家击杀鱼, 获得金币
    PBIncFishWinGold(gold);
    if( IsFishPoolInUse() ) {
        PBDecFishPoolGold(gold);
    }
    // 获得金币时,有部分进入奖池
    if( PBGetFishPoolGold() < PBGetFishPoolStart() ) {
        int64 tax = (int64)(gold * (PBGetFishPoolRate()*1.0f/100.0f));
        PBIncFishPoolGold(tax);
    }
    FishPoolCheck();
}

void LxUser::FishPoolCheck() {
    if( PBGetFishPoolGold() < PBGetFishPoolEnd() ) {
        PBSetFishPoolInUse(0);
    }
    if( PBGetFishPoolGold() >= PBGetFishPoolStart() ) {
        PBSetFishPoolInUse(1);
    }
    if( IsUserInChargeBonus() ) {
        // 如果处于充值红利阶段
        // 判断一下净分是否超过了阈值
        int64 fishWinMax = 0;
        if( IsInNewbieProtect() ) {
            fishWinMax = JDATA->SystemConstPtr()->GetNewBieNetScoreRange();
        }
        else {
            fishWinMax = JDATA->SystemConstPtr()->GetRegularNetScoreRange();
        }
        if( PBGetFishWinGold() - PBGetFishCostGold() >= max(PBGetUserChargeBonus(), fishWinMax) ) {
            PBSetUserChargeBonusFlag(0);
            PBSetUserChargeBonus(0);
            PBSetFishWinGold(0);
            PBSetFishCostGold(0);
            RemoveNewbieProtect();
        }
    }
}

// return true用户处于充值后的红利阶段
bool LxUser::IsUserInChargeBonus() {
    return PBGetUserChargeBonusFlag() > 0;
}

bool LxUser::IsFishPoolInUse()
{
    return PBGetFishPoolInUse() > 0;
}

float LxUser::GetFishPoolRate()
{
    return PBGetFishPoolRate()*1.0/100.0f;
}

void LxUser::FishPoolOnCharge(int64 bonus) {
    if( IsUserInChargeBonus() ) {
        // 如果当前用户还处于充值红利阶段, 直接增加p值
        PBIncUserChargeBonus(bonus);
    }
    else {
        // 设置成进入红利阶段
        PBSetUserChargeBonusFlag(1);
        // 增加p值
        PBSetUserChargeBonus(bonus);
        // 重置净分
        PBSetFishWinGold(0);
        PBSetFishCostGold(0);
    }
}

void LxUser::FishPoolShrink() {
    int64 win = PBGetFishWinGold();
    int64 lose = PBGetFishCostGold();
    if( PBGetFishWinGold() > PBGetFishCostGold() ) {
        PBDecFishWinGold(lose);
        PBSetFishCostGold(0);
    }
    else {
        PBSetFishWinGold(0);
        PBDecFishCostGold(win);
    }
}

int64 LxUser::GetUserWin(int64 m, bool inFast, bool inFury) {
    int64 win = PBGetFishWinGold();
    int64 lose = PBGetFishCostGold();
    if( IsUserInChargeBonus() ) {
        return win-lose*(m*1.0/10000.0);
    }
    else {
        if( inFast && inFury ) {
            return win-lose;
        }
        else {
            return win-lose*(m*1.0/10000.0);
        }
    }
}

///////////////////////////////////////////////////////////////////////////////////////////
void LxUser::PassportReward() {
	do {
		vector<int32> vecLoots;
		int32 pid = PBGetPassportId();
		int64 bpExp = PBGetPassportExp();
		int32 nowLv = PBGetPassportNow();
		int32 vipNowLv = PBGetPassportVipNow();
		for( int32 lv = 1; ; lv++ ) {
			tagJsonPeriodPass tag;
			if( !sHPass->GetGroupLevelData(pid, lv, tag) ) {
				break;
			}
			if( bpExp < tag._TotalExp ) {
				break;
			}
			// 可领
			if( nowLv < lv && tag._RewardLoot.size() >= 1 ) {
				if( IsSensitiveSystemBanned(EUSTF_Voucher) ) {
					// 说明禁止话费了
					if( tag._ChannelRewardLoot.size() >= 1 ) {
						vecLoots.push_back(tag._ChannelRewardLoot[0]);
					}
				}
				else {
					if( tag._RewardLoot.size() >= 1 ) {
						vecLoots.push_back(tag._RewardLoot[0]);
					}
				}
				nowLv = lv;
			}
			if( vipNowLv != -1 && vipNowLv < lv ) {
				if( IsSensitiveSystemBanned(EUSTF_Voucher) ) {
					// 说明禁止话费了
					if( tag._ChannelRewardLoot.size() >= 2 ) {
						vecLoots.push_back(tag._ChannelRewardLoot[1]);
					}
				}
				else {
					if( tag._RewardLoot.size() >= 2 ) {
						vecLoots.push_back(tag._RewardLoot[1]);
					}
				}
				vipNowLv = lv;
			}
		}
		SendUserInfoChange(0);
		if( vecLoots.size() > 0 ) {
			PBSetPassportNow(nowLv);
			PBSetPassportVipNow(vipNowLv);
			for( size_t i = 0; i < vecLoots.size() ; ++i ) {
				GiveLoot(vecLoots[i], ELRI_PeriodPass, false);
			}
			SendUserInfoChange(EPIC_PeriodPass);
		}
	} while(0);
}

int32 LxUser::PassportBuyExp(int32 levels) {
    int32 pid = PBGetPassportId();
    if( pid == 0 ) {
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    int32 diamond = 0;
    int64 maxExp = 0;
    int32 curLv = sHPass->GetGroupLevelByExp(pid, PBGetPassportExp());
    for( int32 num = 0 ; num < levels ; num++ ) {
        int32 lv = curLv + num;
        tagJsonPeriodPass tag;
        if( !sHPass->GetGroupLevelData(pid, lv, tag) ) {
            break;
        }
        diamond += tag._DiamondPrice;
        maxExp = tag._TotalExp;
    }
    if( diamond > 0 ) {
        if( !ChangeDiamond(-diamond, ELRD_PeriodPassBuyExp, false) ) {
            return JDATA->ErrorCodePtr()->GetDiamondLow();
        }
        PBSetPassportExp(maxExp);
    }
    PassportReward();
    return JDATA->ErrorCodePtr()->GetSuccess();
}

void LxUser::GetBombGameInfo(BombGameInfoResp& resp) {
    sHBombGame->GetGameConfig(*resp.mutable_config());
    resp.set_pool(sRankingList->GetBombGamePoolGold());
    for( auto & data : m_lstBombGameRecord ) {
        *resp.add_datas() = data;
    }
}

int32 LxUser::CheckCardsRewards(int32 bombId, int32 times, const set<int32>& userCards, set<int32>& relations) {
    // 检查卡组的奖励数量, 返回实际核弹数量
    map<int32, int32> campRelations; // 数量对应relationId
    // 卡牌组合类羁绊
    sHBombGame->ForEachRelation([&](int32 rid, const set<int32>& cards){
        bool bComplete = true;
        for( auto& card : cards ) {
            if( userCards.find(card) == userCards.end() ) {
                bComplete = false;
                break;
            }
        }
        if( bComplete ) {
            if( relations.find(rid) == relations.end() ) {
                relations.insert(rid);
            }
        }
    });
    int32 maxCampNum = 0;
    {
        map<int32, int32> mapCampCount;
        for( auto& card : userCards ) {
            int32 camp = JDATA->CardPtr()->CampByID(card);
            if( camp != 0 ) {
                int32 campNum = 0;
                auto it = mapCampCount.find(camp);
                if( it == mapCampCount.end() ) {
                    mapCampCount[camp] = 1;
                    campNum = 1;
                }
                else {
                    it->second++;
                    campNum = it->second;
                }
                if( maxCampNum < campNum ) {
                    maxCampNum =campNum;
                }
            }
        }
    }
    sHBombGame->ForCampNum(maxCampNum, [&](int32 rid){
        if( relations.find(rid) == relations.end() ) {
            relations.insert(rid);
        }
    });

    int64 nums = 0;
    for( auto& rid : relations ) {
        int32 loot = JDATA->CardRelationPtr()->RewardByID(rid);
        int64 num = sHLottery->GetBombGameLootItemNum(loot, bombId)*times;
        if( num > 0 ) {
            nums += num;
        }
    }
    return nums;
}

void LxUser::BombGameNewRecord(const BombGameRecord& info) {
    m_lstBombGameRecord.push_back(info);
    m_dirtyBombGameRecord.push_back(info);
    while( m_lstBombGameRecord.size() > BOMB_GAME_REWARD_LIST_MAX_NUM ) {
        m_lstBombGameRecord.pop_front();
    }
    while( m_dirtyBombGameRecord.size() > BOMB_GAME_REWARD_LIST_MAX_NUM ) {
        m_dirtyBombGameRecord.pop_front();
    }
}

bool LxUser::IsBombLimit(int32 bombId) {
    int64 num = GetItemNum(bombId);
    int32 rate = 0;
    JDATA->NuclearFixPtr()->ForEachWithBreak([&](tagJsonNuclearFix* ptr) {
        if( num >= ptr->_nuclear ) {
            rate = ptr->_rate;
            return true;
        }
        return false;
    });
    return GlobalUtils::GetRandNumber(0,100) < rate;
}

int32 LxUser::PlayBombGame(int32 times, BombGamePlayResp& resp) {
    BombGameInfo conf;
    sHBombGame->GetGameConfig(conf);
    bool isTimeValid = false;
    for( int32 i = 0; i < conf.times_size(); i++ ) {
        if( times == conf.times(i) ) {
            isTimeValid = true;
            break;
        }
    }
    if( !isTimeValid ) {
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    if( times > JDATA->VIPPtr()->NuclearTimesByID(PBGetUserVip()) ) {
        return JDATA->ErrorCodePtr()->GetBombGameVipLow();
    }
    if( !ItemChange(conf.bomb_item_id(), -times*1*conf.card_num(), ELRD_PlayBombGame, false) ) {
        return JDATA->ErrorCodePtr()->GetItemUseNumLow();
    }
    GTaskInc(e_jsonGeneralTaskCondition_Nuclear_Draw_Daily, times, 1);
    CounterAdd(e_jsonGeneralTaskDynamicTarget_Nuclear_Draw, 1);

    // 本次抽卡的部分金币价值加入到奖池里
    int64 goldValue = JDATA->ItemPtr()->ItemParamByID(conf.bomb_item_id())*times*1*conf.card_num();
    sRankingList->BombGamePoolInc(goldValue*conf.pool_rate()/1000);
    resp.set_times(times);

    std::shuffle(m_vecCards.begin(), m_vecCards.end(), _generator);
    set<int32> userCard;
    for( int32 i = 0; i < conf.card_num() ; i++ ) {
        userCard.insert( m_vecCards[i] );
    }

    set<int32> relations;
    int32 bombRewardNum = CheckCardsRewards(conf.bomb_item_id(), times, userCard, relations);
    if( PBGetBombGamePoint() < JDATA->SystemConstPtr()->GetNuclearDrawScoreParamM1()*times*1*conf.card_num() ) {
        /*
        	控分过低保护
        同时满足以下条件是，触发保底。
        	控分N< m1 * 本次抽奖消耗的核弹数，
        	本次抽卡奖励低于平均控分奖励
        	未触发奖池
        */
       if( bombRewardNum < times*JDATA->SystemConstPtr()->GetNuclearDrawAverageScore()
            && relations.find(conf.pool_relation_id()) == relations.end()
            && GlobalUtils::GetRandNumber(0,1000) < JDATA->SystemConstPtr()->GetNuclearDrawGuaranteeRate() ) {
            userCard.clear();
            sHBombGame->RandWhenNeed(userCard);
            relations.clear();
            bombRewardNum = CheckCardsRewards(conf.bomb_item_id(), times, userCard, relations);
        }
    }
    else if( PBGetBombGamePoint() > JDATA->SystemConstPtr()->GetNuclearDrawScoreParamM2()*times*1*conf.card_num() ) {
        /*
        	控分过高控制 控分 N > m2 * 本次抽奖消耗的核弹数，
        中了“桃园结义”或者“5同阵营”，按身上的核弹数量读表进行二次随机
        */
        if( relations.find(conf.high_relation1()) != relations.end() || relations.find(conf.high_relation2()) != relations.end() ) {
            if( IsBombLimit(conf.bomb_item_id()) ) {
                userCard.clear();
                sHBombGame->RandWhenLimit(userCard);
                relations.clear();
                bombRewardNum = CheckCardsRewards(conf.bomb_item_id(), times, userCard, relations);
            }
        }
    }

    vector<int32> vecLogRelation;
    vector<int32> vecLogCard;
    for( auto& card: userCard ) {
        resp.add_cards(card);
        vecLogCard.push_back(card);
    }
    int64 tNow = sGameUtils->GetFakeTimeNow();
    if( relations.find(conf.pool_relation_id()) != relations.end() ) {
        // 中奖了
        resp.set_pool_relation(conf.pool_relation_id());
        int64 poolReward = sRankingList->BombGamePoolReward(conf.pool_reward()*times);
        resp.set_pool_reward(poolReward);
        ChangeGold(poolReward, ELRI_PlayBombGame);

        relations.erase(conf.pool_relation_id());
        vecLogRelation.push_back(conf.pool_relation_id());

        auto ptr = resp.add_bomb_rewards();
        ptr->set_relation_id(conf.pool_relation_id());
        ptr->set_bomb_item_id(0);
        ptr->set_bomb_item_num(0);
        ptr->set_gold(poolReward);
        ptr->set_times(times);
        ptr->set_timestamp(tNow);

        BombGameNewRecord(*ptr);
        BombGamePushYell(conf.yell_pool_id(), GlobalUtils::GetStarName(PBGetUserName()), GlobalUtils::GetNumberString(poolReward));
        sRankingList->PushBombGamePoolList(GlobalUtils::GetStarName(PBGetUserName()), poolReward);
    }
    else {
        resp.set_pool_relation(0);
        resp.set_pool_reward(0);
    }
    resp.set_pool_gold(sRankingList->GetBombGamePoolGold());

    int64 nums = 0;
    for( auto& rid : relations ) {
        vecLogRelation.push_back(rid);
        int32 loot = JDATA->CardRelationPtr()->RewardByID(rid);
        int64 num = sHLottery->GetBombGameLootItemNum(loot, conf.bomb_item_id())*times;
        if( num > 0 ) {
            nums += num;
            auto ptr = resp.add_bomb_rewards();
            ptr->set_relation_id(rid);
            ptr->set_bomb_item_id(conf.bomb_item_id());
            ptr->set_bomb_item_num(num);
            ptr->set_gold(0);
            ptr->set_times(times);
            ptr->set_timestamp(tNow);
            BombGameNewRecord(*ptr);
        }
    }
    ItemChange(conf.bomb_item_id(), nums, ELRI_PlayBombGame, false);
    resp.set_bombs(nums);
    int64 bombGamePoint = PBGetBombGamePoint();

    PBIncBombGamePoint(nums*(1000+JDATA->SystemConstPtr()->GetNuclearDrawFee())/1000 - times*1*conf.card_num());

    string strCards = GlobalUtils::JoinArray(vecLogCard, "|");
    string strRelations = GlobalUtils::JoinArray(vecLogRelation, "|");
    LOG_BOMB_GAME_PLAY(this, times, strCards, strRelations, nums, resp.pool_reward(), bombGamePoint, PBGetBombGamePoint());

    UpdateBulletinData(JDATA->SystemConstPtr()->GetNuclearDrawRankFishID(), 0, 0, nums);

    return JDATA->ErrorCodePtr()->GetSuccess();
}

void LxUser::UpdateBulletinData(int32 fishIndex, int32 kill, int32 rate, int32 bomb) {
    LxUserBulletinData msg;
    msg.set_boss_index(fishIndex);
    msg.mutable_user()->set_user_id(GetKey());
    msg.mutable_user()->set_user_vip(PBGetUserVip());
    msg.mutable_user()->set_user_name(GlobalUtils::GetStarName(PBGetUserName()));
    msg.mutable_user()->set_user_head(PBGetUserPortrait());
    msg.mutable_user()->set_user_frame(PBGetUserFrame());
    msg.mutable_user()->set_user_weapon(PBGetUserSweapon());
    msg.mutable_user()->set_user_kill(kill);
    msg.mutable_user()->set_user_max_rate(rate);
    msg.mutable_user()->set_user_bomb(bomb);
    msg.mutable_user()->set_user_turret(PBGetUserHeroIndex());
    msg.mutable_user()->set_user_turret_star(GetCurHeroStar());
    msg.mutable_user()->set_user_swing(GetCurWingIndex());
    CALL_THREAD(this, LxUserBulletinData, msg);
}

void LxUser::UpdateArenaData(int32 rank, int32 score) {
    LxArenaUserInfo msg;
    auto ptr = msg.mutable_user();
    ptr->set_user_id(GetKey());
    ptr->set_user_name(PBGetUserName());
    ptr->set_user_portrait(PBGetUserPortrait());
    ptr->set_user_frame(PBGetUserFrame());
    ptr->set_user_weapon(PBGetUserSweapon());
    ptr->set_user_vip(PBGetUserVip());
    ptr->set_user_score(score);
    ptr->set_user_rank(rank);
    ptr->set_user_time(sGameUtils->GetFakeTimeNow());
    ptr->set_user_turret(PBGetUserHeroIndex());
    msg.mutable_user()->set_user_turret_star(GetCurHeroStar());
    ptr->set_user_swing(GetCurWingIndex());
    CALL_THREAD(this, LxArenaUserInfo, msg);
}

void LxUser::RewardCards(int32 gid, const set<int32>& cards) {
    SendUserInfoChange(0);
    vector<int32> loots;
    vector<ItemPair> items; // 受控奖励, 钻石, 兑换券, 话费
    int32 relationId = sHTreasure->GetRewards(gid, cards, IsSensitiveSystemBanned(EUSTF_Voucher), loots, items);
    if( relationId == 0 ) {
        LOGERROR("Treasure card no relation[%lu] [%d] [%s]", GetKey(), gid, GlobalUtils::JoinSet(cards, "|").c_str());
        return;
    }
    SendUserInfoChange(0);
    m_nTreasureRelationId = relationId;
    m_treasureCards = cards;
    for( size_t i = 0; i < loots.size(); i++ ) {
        GiveLoot(loots[i], ELRI_TreasureFishKilled, false);
    }
    int32 couponItemId = JDATA->SystemConstPtr()->GetCoupon();
    int32 diamondItemId = JDATA->SystemConstPtr()->GetDiamond();
    int32 voucherItemId = JDATA->SystemConstPtr()->GetPhoneVoucherItemID();
    int32 num = JDATA->CouponPtr()->Size();
    if( num > 0 ) {
        int32 loginNum = PBGetLoginNum()%num + 1;
        for( size_t i = 0; i < items.size(); i++ ) {
            if( items[i].item_id() == couponItemId ) {
                int32 totalCoupon = JDATA->CouponPtr()->CouponByID(loginNum) - PBGetTodayCoupon();
                int32 couponNum = 1;
                if( totalCoupon > 0 ) {
                    couponNum = GlobalUtils::GetRandNumber(1, min((int32)items[i].item_num(), totalCoupon));
                }
                ItemChange(couponItemId, couponNum, ELRI_TreasureFishKilled, false);
                PBIncTodayCoupon(couponNum);
            }
            else if( items[i].item_id() == diamondItemId ) {
                int32 totalDiamond = JDATA->CouponPtr()->DiamondByID(loginNum) - PBGetTodayDiamond();
                int32 diamondNum = 1;
                if( totalDiamond > 0 ) {
                    diamondNum = GlobalUtils::GetRandNumber(1, min((int32)items[i].item_num(), totalDiamond));
                }
                ItemChange(diamondItemId, diamondNum, ELRI_TreasureFishKilled, false);
                PBIncTodayDiamond(diamondNum);
            }
            else if( items[i].item_id() == voucherItemId ) {
                int32 voucherNum = 0;
                int32 B = PBGetVoucherControl();
                int32 Q = (int32)items[i].item_num();
                if( B <= 0 ) {
                    voucherNum = 1;
                }
                else {
                    if( sqrt(B) >= Q ) {
                        voucherNum = Q;
                    }
                    else {
                        voucherNum = GlobalUtils::GetRandNumber(sqrt(B), Q);
                        if( voucherNum > B ) {
                            voucherNum = B;
                        }
                    }
                }
                ItemChange(diamondItemId, voucherNum, ELRI_TreasureFishKilled, false);
                PBDecVoucherControl(voucherNum);
            }
        }
    }
    SendUserInfoChange(EPIC_TreasureFishKilled);
}

void LxUser::DrawTenUpdate() {
    DrawTenConfig dtc;
    if( !sHActs->GetDrawTenConfig(dtc) ) {
        return;
    }
    // 初始化一下
    int32 nextBig = GetDrawTenBigNum(dtc.lottery_big_mu(), dtc.lottery_big_sigma());
    PBIncDrawTenNextBig(nextBig);

    if( PBGetDrawTenPeriodLoot() == 0 ) {
        // 阶段奖励也要初始化一下
        PBSetDrawTenPeriodIdx(0);
        PBSetDrawTenPeriodNum(0);
        PBSetDrawTenPeriodMax(dtc.loots(0).key());
        PBSetDrawTenPeriodLoot(dtc.loots(0).value());
    }
}

int32 LxUser::DrawTen(int32 type, DrawTenResp& resp) {
    DrawTenConfig dtc;
    if( !sHActs->GetDrawTenConfig(dtc) ) {
        LOGERROR("user[%lu] draw ten no act", GetKey());
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    int32 times = 0;
    int32 incReason = 0;
    int32 reason = 0;
    switch(type) {
    case EDTT_DrawOneUseItem:
        if( !ItemChange(dtc.item_id(), -1, ELRD_DrawOneUseItem, false) ) {
            LOGERROR("user[%lu] item[%d] not enough 1", GetKey(), dtc.item_id());
            return JDATA->ErrorCodePtr()->GetSystemError();
        }
        times = 1;
        incReason = ELRI_DrawOneUseItem;
        reason = EPIC_DrawOneUseItem;
        break;
    case EDTT_DrawTenUseItem:
        if( !ItemChange(dtc.item_id(), -10, ELRD_DrawTenUseItem, false) ) {
            LOGERROR("user[%lu] item[%d] not enough 10", GetKey(), dtc.item_id());
            return JDATA->ErrorCodePtr()->GetSystemError();
        }
        times = 10;
        incReason = ELRI_DrawTenUseItem;
        reason = EPIC_DrawTenUseItem;
        break;
    case EDTT_DrawOneUseDiamond:
        if( !ChangeDiamond(-dtc.diamond_price1(), ELRD_DrawOneUseDiamond, false) ) {
            LOGERROR("user[%lu] diamond[%d] not enough", GetKey(), dtc.diamond_price1());
            return JDATA->ErrorCodePtr()->GetSystemError();
        }
        times = 1;
        incReason = ELRI_DrawOneUseDiamond;
        reason = EPIC_DrawOneUseDiamond;
        break;
    case EDTT_DrawTenUseDiamond:
        if( !ChangeDiamond(-dtc.diamond_price10(), ELRD_DrawTenUseDiamond, false) ) {
            LOGERROR("user[%lu] diamond10[%d] not enough", GetKey(), dtc.diamond_price10());
            return JDATA->ErrorCodePtr()->GetSystemError();
        }
        times = 10;
        incReason = ELRI_DrawTenUseDiamond;
        reason = EPIC_DrawTenUseDiamond;
        break;
    default:
        LOGERROR("user[%lu] type[%d] failed", GetKey(), type);
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    SendUserInfoChange(0);
    bool bPurpleItemGot = false;
    for( int32 n = 0 ; n < times ; ++n ) {
        int32 curNum = PBGetDrawTenNum();
        int32 lotteryId = dtc.lottery_id();
        if( curNum + 1 == PBGetDrawTenNextBig() ) {
            lotteryId = dtc.lottery_big_id();
            DrawTenUpdate();
        }
        else {
            if( !bPurpleItemGot && times == 10 && n == 9 ) {
                // 十连抽的保底要给一个紫色
                lotteryId = dtc.lottery_ten_base_id();
            }
        }
        PBIncDrawTenNum(1);
        PBIncDrawTenPeriodNum(1);
        // 要给客户端构造一个10连的物品列表, 所以这里不能合并给予
        map<int32, int64> tempItem;
        sHLottery->GetLotteryItem(lotteryId, tempItem);
        for( auto& item : tempItem ) {
            if( !bPurpleItemGot && JDATA->ItemPtr()->RarityByID(item.first) >= e_jsonItemRarity_Uncommon ) {
                bPurpleItemGot = true;
            }
            auto ptr = resp.add_items();
            ptr->set_item_id(item.first);
            ptr->set_item_change(item.second);
            ptr->set_item_num(item.second);
            ItemChange(item.first, item.second, incReason, false);
        }
    }
    SendUserInfoChange(reason);
    return JDATA->ErrorCodePtr()->GetSuccess();
}

int32 LxUser::DrawTenPeriodReward() {
    DrawTenConfig dtc;
    if( !sHActs->GetDrawTenConfig(dtc) ) {
        LOGERROR("user[%lu] draw ten period no act", GetKey());
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    if( PBGetDrawTenPeriodLoot() == 0 ) {
        LOGERROR("user[%lu] draw ten period config failed", GetKey());
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    if( PBGetDrawTenPeriodNum() < PBGetDrawTenPeriodMax() ) {
        LOGERROR("user[%lu] draw ten period num[%d] max[%d] failed", GetKey(), PBGetDrawTenPeriodNum(), PBGetDrawTenPeriodMax());
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    SendUserInfoChange(0);
    GiveLoot(PBGetDrawTenPeriodLoot(), ELRI_DrawTenNumReward, false);
    PBDecDrawTenPeriodNum(PBGetDrawTenPeriodMax());// 可能抽了很多次才领, 直接减掉当前max剩下的就是多余的次数

    PBIncDrawTenPeriodIdx(1);// 奖励索引号+1
    // 阶段奖励是循环的, 所以这里索引直接取模即可
    int32 idx = PBGetDrawTenPeriodIdx() % dtc.loots_size();
    PBSetDrawTenPeriodMax(dtc.loots(idx).key());
    PBSetDrawTenPeriodLoot(dtc.loots(idx).value());

    SendUserInfoChange(EPIC_DrawTenNumReward);
    return JDATA->ErrorCodePtr()->GetSuccess();
}

void LxUser::InitUserAttr() {
    m_setHeroRelation.clear();
    m_mapHeroRelationAttr.clear();
    _hero.ForEachHero([&](int32 hid){
        set<int32> relas;
        if( sHero->GetHeroUserRelationSet(hid, relas) ) {
            for( auto & rela : relas ) {
                TryActivateRelation(rela);
            }
        }
    });
}

void LxUser::OnHeroRelationChange(int32 hid) {
    set<int32> relas;
    if( sHero->GetHeroUserRelationSet(hid, relas) ) {
        for( auto & rela : relas ) {
            TryActivateRelation(rela);
        }
    }
}

void LxUser::TryActivateRelation(int32 rid) {
    if( m_setHeroRelation.find(rid) != m_setHeroRelation.end() ) {
        // 已经激活
        return;
    }
    tagHeroRelation tag;
    if( !sHero->GetHeroRelationData(rid, tag) ) {
        LOGERROR("user[%lu] relation[%d] not found", GetKey(), rid);
        return;
    }
    for( auto& hero : tag._heros ) {
        if( tag._level > 0 ) {
            if( tag._level > _hero.GetHeroLevel(hero) ) {
                return;
            }
        }
        if( tag._star > 0 ) {
            if( tag._star > _hero.GetHeroStar(hero) ) {
                return;
            }
        }
    }
    m_setHeroRelation.insert(rid);
    auto it = m_mapHeroRelationAttr.find(tag._attr);
    if( it == m_mapHeroRelationAttr.end() ) {
        m_mapHeroRelationAttr[tag._attr] = tag._value;
    }
    else {
        it->second += tag._value;
    }
}

void LxUser::SetGiftCode(const string& code) {
    PBSetGiftCode(code);
    if( code.empty() ) {
        int32 flag = EUSTF_GiftCodeSet;
        int32 ss = PBGetSensitiveFlag();
        ss &= ~flag;
        PBSetSensitiveFlag(ss);
    }
    else {
        PBSetSensitiveFlag(PBGetSensitiveFlag()|EUSTF_GiftCodeSet);
    }
}
