#include "GameUtils.h"
#include "ModuleHelper.h"
#include "Include/RedisKey.h"
#include "DataCache/RedisData.h"
#include "Dispatcher.h"
#include "LxGameLogHelper.h"

GameUtils::GameUtils() {
    m_i64MaxSystemMailId = 0;
    m_bTestServer = false;
    m_mapTableUserNum.clear();
    m_filterInited = false;
    m_nOnlineUserNum = 0;
    m_globalBuffs.clear();
}

GameUtils::~GameUtils() {
}

bool GameUtils::Init() {
    if( !sHero->Init() ) {
        LOGERROR("sHero failed");
        return false;
    }
    if( !sHItem->Init() ) {
        LOGERROR("sHItem failed");
        return false;
    }
    if( !sHExps->Init() ) {
        LOGERROR("sHExps failed");
        return false;
    }
    if( !sHRoute->Init() ) {
        LOGERROR("sHRoute failed");
        return false;
    }
    if( !sHFish->Init() ) {
        LOGERROR("sHFish failed");
        return false;
    }
    if( !sHLottery->Init() ) {
        LOGERROR("sHLottery failed");
        return false;
    }
    if( !sHArena->Init() ) {
        LOGERROR("sHArena failed");
        return false;
    }
    if( !sHMarket->Init() ) {
        LOGERROR("sHMarket failed");
        return false;
    }
    sHTax->Init();
    sHDay7->Init();
    sHPass->Init();
    sHTech->Init();
    sHBuff->Init();
    sHTreasure->Init();
    if( !m_filterInited )
    {
        writeLock wl(_word_mutex);
        JDATA->DirtyWordsPtr()->ForEach([&](tagJsonDirtyWords* ptr){
            m_Filter.InsertFilterWord(ptr->_WordList);
        });
        m_filterInited = true;
    }
    {
        writeLock wl(_name_mutex);
        m_vecNames.clear();
        JDATA->NickNamePtr()->ForEach([&](tagJsonNickName* ptr){
            m_vecNames.push_back(ptr->_Name);
        });
        m_vecRobotNames.clear();
        JDATA->RobotNickNamePtr()->ForEach([&](tagJsonRobotNickName* ptr){
            m_vecRobotNames.push_back(ptr->_NameLocalization);
        });
    }
    {
        map< string, map<int32, int32> > mapData;
        JDATA->QuestRouterPtr()->ForEach([&](tagJsonQuestRouter* ptr){
            for( size_t n = 0 ; n < ptr->_Channel.size() ; ++n ) {
                auto it = mapData.find(ptr->_Channel[n]);
                if( it == mapData.end() ) {
                    map<int32, int32> data;
                    mapData[ptr->_Channel[n]] = data;
                    it = mapData.find(ptr->_Channel[n]);
                }
                for( size_t i = 0; i < ptr->_OldQuestID.size() ; ++i ) {
                    it->second[(int32)ptr->_OldQuestID[i]] = ptr->_NewQuestID;
                }
            }
        });
        writeLock wl(_chn_quest_mutex);
        m_mapChannelQuest.swap(mapData);
    }
    return true;
}

void GameUtils::InsertFilterWord(const string& word) {
    writeLock wl(_word_mutex);
    m_Filter.InsertFilterWord(word);
}

bool GameUtils::IsDirtyWord(const string& word) {
    readLock rl(_word_mutex);
    return m_Filter.IsWordContainsFilterWords(word);
}

bool GameUtils::IsChatGroupNameValid(const string& strName) {
    string strNewName = GlobalUtils::ReplaceAll(strName, " ", "");
    if( strNewName.size() >= MAX_CHAT_GROUP_NAME_LEN ) {
        return false;
    }
    if( strNewName.size() <= 0 ) {
        return false;
    }

    if( strNewName.find("'") != string::npos
        || strNewName.find("\"") != string::npos
        || strNewName.find("\\") != string::npos
        || strNewName.find(",") != string::npos
        || strNewName.find(";") != string::npos
        || strNewName.find("%") != string::npos
        || strNewName.find("|") != string::npos
        || sGameUtils->IsDirtyWord(strNewName) ) {
        return false;
    }
    return true;
}

string GameUtils::ToValidWord(const string& word) {
    readLock rl(_word_mutex);
    return m_Filter.ToValidWord(word);
}

string GameUtils::GetRandName() {
    readLock rl(_name_mutex);
    if( m_vecNames.size() == 0 ) {
        return "Fisher";
    }
    return m_vecNames[GlobalUtils::GetRandNumber(0,(int32)m_vecNames.size()-1)];
}

std::tuple<bool, int64> GameUtils::GetTideDiamond(int32 curTide, int32 maxTide, list<int32>& lstLoot) {
    int64 totalDiamond = 0;
    int32 tideId = maxTide;
    bool bFind = (curTide == 0);
    while( true ) {
        tagJsonGamePlay data;
        if( JDATA->GamePlayPtr()->ByID(tideId, data) ) {
            totalDiamond += data._SkipDiamondBase;
            lstLoot.push_back(data._RoomRewardLootID);
            if( curTide == data._PreRoomID ) {
                bFind = true;
                break;
            }
            if( data._PreRoomID == 0 ) {
                break;
            }
            tideId = data._PreRoomID;
        }
        else {
            break;
        }
    }
    return std::make_tuple(bFind, totalDiamond);
}

// 可以击杀大群鱼的逻辑是,玩家身上有一个buffid
// buff表查找Param字段,表示炮台id
// TurretSet表查找SelfBulletID[0],表示子弹id
// FishBullet表找到HitCount,表示击中次数,即可击杀鱼的数量
int32 GameUtils::GetBulletMaxKill(int32 buffId) {
    int32 turretId = JDATA->BuffPtr()->ParamByID(buffId);
    if( turretId == 0 ) {
        return 0;
    }
    tagJsonHeroSet data;
    if( !JDATA->HeroSetPtr()->ByID(turretId, data) ) {
        return 0;
    }
    if( data._SelfBulletID.size() == 0 ) {
        return 0;
    }
    int32 bulletId = data._SelfBulletID[0];
    return JDATA->FishBulletPtr()->HitCountByID(bulletId);
}

// TurretSet表查找SelfBulletID[0],表示子弹id
// FishBullet表找到HitCount,表示击中次数,即可击杀鱼的数量
int32 GameUtils::GetBulletMaxKillByTurretIndex(int32 turretId) {
    tagJsonHeroSet data;
    if( !JDATA->HeroSetPtr()->ByID(turretId, data) ) {
        return 1;// 至少杀一条
    }
    if( data._SelfBulletID.size() == 0 ) {
        return 1;
    }
    int32 bulletId = data._SelfBulletID[0];
    return JDATA->FishBulletPtr()->HitCountByID(bulletId);
}

int32 GameUtils::GetMarketTimesDiamond(int32 num) {
    tagJsonDiamondTimes tag;
    if( JDATA->DiamondTimesPtr()->ByTimes(num, tag) ) {
        return tag._MarketPrice;
    }
    int32 diamond = 0;
    JDATA->DiamondTimesPtr()->ForEach([&](tagJsonDiamondTimes* ptr){
        if( ptr->_MarketPrice > diamond ) {
            diamond = ptr->_MarketPrice;
        }
    });
    return diamond;
}

// 返回值为 < 本次购买需要的钻石数量, 购买的能量点数 >
std::tuple<int32, int32> GameUtils::GetBuyEnergyData(int32 num) {
    tagJsonDiamondTimes tag;
    if( JDATA->DiamondTimesPtr()->ByTimes(num, tag) && tag._EnergyKeyPrice.size() == 2) {
        return std::make_tuple(tag._EnergyKeyPrice[0], tag._EnergyKeyPrice[1]);
    }
    int32 times = 0;
    int32 diamond = 0;
    int32 energy = 0;
    JDATA->DiamondTimesPtr()->ForEach([&](tagJsonDiamondTimes* ptr){
        // 取最大次数的花费
        if( ptr->_EnergyKeyPrice.size() == 2 && ptr->_Times > times ) {
            times = ptr->_Times;
            diamond = ptr->_EnergyKeyPrice[0];
            energy = ptr->_EnergyKeyPrice[1];
        }
    });
    return std::make_tuple(diamond, energy);
}

void GameUtils::LogOnlineNum() {
    readLock rl(_online_mutex);
    int32 table101 = m_mapTableUserNum[101];
    int32 table102 = m_mapTableUserNum[102];
    int32 table104 = m_mapTableUserNum[104];
    int32 table105 = m_mapTableUserNum[105];
    int32 table106 = m_mapTableUserNum[106];
    int32 others = 0;
    for( auto & it : m_mapTableUserNum ) {
        if( it.first != 101 && it.first != 102 && it.first != 104 && it.first != 105 && it.first != 106 ) {
            others += it.second;
        }
    }
    LOG_ONLINE_NUM(sGameUtils->GetFakeTimeNow(),
                    m_nOnlineUserNum,
                    others,
                    table101,table102,table106,table104,table105);
}

// 查找指定渠道对应的主线任务是否有不同的任务链配置
int32 GameUtils::GetPostQuestId(const string& chn, int32 qid) {
    readLock rl(_chn_quest_mutex);
    auto it = m_mapChannelQuest.find(chn);
    if( it == m_mapChannelQuest.end() ) {
        return 0;
    }
    auto it2 = it->second.find(qid);
    if( it2 == it->second.end() ) {
        return 0;
    }
    return it2->second;
}

bool GameUtils::GetChannelItemRecycle(const string& chn, int32 itemId, ItemPair& newItem) {
    int64 now = GetFakeTimeNow();
    tagJsonItemRecycle tag;
    if( JDATA->ItemRecyclePtr()->ByID(itemId, tag) && tag._Price.size() == 2 && tag._Price[0] > 10000000/*是兑换回道具*/) {
        bool bNeedRecycle = tag._Channel.empty();// 不填肯定要回收
        for( size_t i = 0 ; i < tag._Channel.size() ; ++i ) {
            if( chn == tag._Channel[i] ) {
                bNeedRecycle = true;    // 填了的上面会是false, 这里渠道相同了就回收
                break;
            }
        }
        if( bNeedRecycle ) {
            // 超时物品, 直接回收
            int64 end = GlobalUtils::MakeTime(tag._RecycleTime);
            if( now >= end ) {
                newItem.set_item_id(tag._Price[0]);
                newItem.set_item_num(tag._Price[1]);
                return true;
            }
        }
    }
    return false;
}

// 根据渠道和版本号获取渠道开关
// 0表示无变化,不需要更新
// -1表示无对应配置,客户端使用本地配置
// >0 返回的是本次有更新, 用更新数据进行
int64 GameUtils::ForEachSystem(const string& chn, const string& ver, int64 lastTime, std::function<void(const string&, int32)> func) {
    tagSS ss;
    {
        ostringstream oss;
        oss << chn << "_" << ver;
        readLock rl(_ss_mutex);
        auto it = m_mapSS.find(oss.str());
        if( it != m_mapSS.end() ) {
            ss = it->second;
        }
        else {
            return -1;
        }
    }
    if( ss._update_time != lastTime ) {
        for( auto & it : ss._ss ) {
            func(it.first, it.second);
        }
        return ss._update_time;
    }
    return 0;
}

int64 GameUtils::GetUserSystemMail(int64 iLastMailId, map<int64, tagSystemMail>& mapMail) {
    map<int64, tagSystemMail> mapSystemMail;
    {
        readLock rl(_sys_mail_mutex);
        if( iLastMailId >= m_i64MaxSystemMailId ) {
            return iLastMailId;
        }
        mapSystemMail = m_mapSystemMail;
    }
    for( auto & it : mapSystemMail ) {
        if( it.first > iLastMailId ) {
            mapMail[it.first] = it.second;
        }
    }
    return m_i64MaxSystemMailId;
}

int64 GameUtils::GetMaxSystemMailId() {
    readLock rl(_sys_mail_mutex);
    return m_i64MaxSystemMailId;
}

void GameUtils::UpdateSystemMail(int64 maxMailId, const map<int64, tagSystemMail>& mapMail) {
    writeLock wl(_sys_mail_mutex);
    m_i64MaxSystemMailId = maxMailId;
    m_mapSystemMail.clear();
    m_mapSystemMail = mapMail;
}

// 本次服务器运行期间, 持久化桌面奖池
void GameUtils::OnTableClosed(int32 tableIndex, const tagGoldPool& pool) {
    writeLock wl(_sys_mutex);
    auto it = m_mapTablePool.find(tableIndex);
    if( it == m_mapTablePool.end() ) {
        list<tagGoldPool> lst;
        lst.push_back(pool);
        m_mapTablePool[tableIndex] = lst;
    }
    else {
        it->second.push_back(pool);
    }
}

bool GameUtils::GetAvaliableTablePool(int32 tableIndex, tagGoldPool& pool) {
    writeLock wl(_sys_mutex);
    auto it = m_mapTablePool.find(tableIndex);
    if( it == m_mapTablePool.end() ) {
        return false;
    }
    if( it->second.empty() ) {
        return false;
    }
    pool = it->second.front();
    it->second.pop_front();
    return true;
}

void GameUtils::AddGlobalBuff(int32 buffId) {
    writeLock wl(_sys_mutex);
    tagJsonBuff tag;
    if( JDATA->BuffPtr()->ByID(buffId, tag) ) {
        m_globalBuffs[buffId] = tag;
    }
}

void GameUtils::RemoveGlobalBuff(int32 buffId) {
    writeLock wl(_sys_mutex);
    m_globalBuffs.erase(buffId);
}

int32 GameUtils::GetItemExtraDropRate(int32 itemId) {
    readLock rl(_sys_mutex);
    for( auto & it : m_globalBuffs ) {
        if( it.second._Type == e_jsonBuffType_AdditionLoot && it.second._LootParam.size() % 2 == 0 ) {
            for( size_t i = 0; i < it.second._LootParam.size(); i += 2 ) {
                if( itemId == it.second._LootParam[i] ) {
                    return it.second._LootParam[i+1];
                }
            }
        }
    }
    return 0;
}

