#pragma once
#include "ServerDefine.h"
#include "io_service_pool.h"

class NetLink;
using NetLinkPtr = std::shared_ptr<NetLink>;
class NetServer : public Poolize
{
public:
	NetServer();
	~NetServer();
public:
	void start_accept();
	void handle_accept(boost::beast::error_code ec, tcp::socket socket);
	void start(const string& strAddr, int32 nPort);
private:
	/// Acceptor used to listen for incoming connections.
	tcp::acceptor _acceptor;
	/// The next connection to be accepted.
public:
	void AddUserLinkWithLock(uint64 userid, NetLinkPtr conn);
	bool DelUserLinkWithLock(uint64 userid, NetLinkPtr conn);
	NetLinkPtr GetUserLinkWithLock(uint64 userid);
	void AddLinkWithLock(int32 linkId, NetLinkPtr conn);
	void DelLinkWithLock(int32 linkId);
	NetLinkPtr GetLinkWithLock(int32 linkId);
private:
	int32 m_nLinkId;
	int32 m_nPoolSize;
	//stores player global position information on this NetServer process
	//used for broadcast, single point login, IAP etc.
	std::unordered_map<uint64, NetLinkPtr> m_mapUserLinks;
	//map<connection unique id, connection pointer>
	std::unordered_map<int32, NetLinkPtr> m_mapLinks;
	boost::shared_mutex _connection_mutex;
	boost::shared_mutex _player_mutex;
public:
	void KickOnlineUser(uint64 userid);
    void KickDuplicateUser(uint64 userid);
	void KickAll();
///////////////////////////////////////////////////////////////////////////////////////////////
// 消息处理
public:
	void PostPacket(WrapPacket& packet);
	void Broadcast(int32 cmd, const string& strMessage);
};

#define sNetServer Singleton<NetServer>::Instance()
