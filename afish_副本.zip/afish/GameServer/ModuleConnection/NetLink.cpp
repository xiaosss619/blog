/**
 * TODO list
 * 用户发送进入游戏后,可能没有立即进入,如果多次重发,需要在UserConnection上记录一个发送时间,保证多次发送不会出问题
 * 原本的逻辑是在本gate记录一个map,两秒清理一次,为了防止2秒内在本gate短线重连,然后重新再发进入游戏,看起来似乎没有必要,在链接上加一个即可
 * 如果上次的进入游戏请求一直被挂起没处理,第二次的连接完成后应该会把他T掉了,这部分的逻辑需要再斟酌一下
 */
#include "NetLink.h"
#include "NetServer.h"
#include "Include/RedisKey.h"
#include "DataCache/RedisData.h"
#include "Dispatcher.h"
#include "GameUtils.h"
#include "memorypool.hpp"

NetLink::NetLink(tcp::socket&& socket, int32 connection_id)
  : _webSocket(std::move(socket)),
	m_nLinkId(connection_id),
	m_bClosed(false),
	m_bKickedByServer(false),
	_send_buffer(NULL),
    _timer(_webSocket.get_executor()),
	m_uUserId(0),
	m_iLastReceiveMessageTime(0),
	m_iSameTimeReceiveMessageCount(0)
{
	// setup_stream(_webSocket);
	_recv_buffer.clear();
	_tx_queue.clear();
	m_lLastManualFireTick = 0;
	m_lLastHitFishTick = 0;
	m_lLastLoginReq = 0;
	m_lLastEnterFishRoom = 0;
	_sending = false;
    _timer.expires_from_now(boost::posix_time::seconds(50));
    _timer.async_wait(boost::bind(&NetLink::OnTimerSeconds50, this, boost::asio::placeholders::error));
}

NetLink::~NetLink()
{
	_recv_buffer.clear();
	_tx_queue.clear();

	if (_send_buffer != NULL)
	{
		memory_pool_64k::free(_send_buffer);
		_send_buffer = NULL;
	}
	LOGINFO("connection[%p] user[%lu] link[%lu] destroyed", this, m_uUserId, m_nLinkId);
}

// Adjust settings on the stream
template<class NextLayer>
void NetLink::setup_stream(boost::beast::websocket::stream<NextLayer>& ws)
{
    // These values are tuned for Autobahn|Testsuite, and
    // should also be generally helpful for increased performance.
    boost::beast::websocket::permessage_deflate pmd;
    pmd.client_enable = true;
    pmd.server_enable = true;
    pmd.compLevel = 3;
    ws.set_option(pmd);
    ws.auto_fragment(false);
}

void NetLink::OnTimerSeconds50(const boost::system::error_code& ec) {
    if( !ec ) {
        if( time(nullptr) - m_iLastReceiveMessageTime > 50 ) {
            LOGERROR("connection[%p], user[%lu] [%d:%s]", this, m_uUserId, ec.value(), ec.message().c_str());
            close();
            return;
        }
        _timer.expires_from_now(boost::posix_time::seconds(50));
        _timer.async_wait(boost::bind(&NetLink::OnTimerSeconds50, this, boost::asio::placeholders::error));
    }
    else {
		LOGERROR("connection[%p], user[%lu] timer failed[%d:%s]", this, m_uUserId, ec.value(), ec.message().c_str());
		close();
    }
}

void NetLink::start()
{
	sNetServer->AddLinkWithLock(m_nLinkId, shared_from_this());
	// Set suggested timeout settings for the websocket
	_webSocket.set_option(
		beast::websocket::stream_base::timeout::suggested(
			beast::role_type::server));
	// Set a decorator to change the Server of the handshake
	_webSocket.set_option(beast::websocket::stream_base::decorator(
		[](beast::websocket::response_type& res)
		{
			res.set(beast::http::field::server,
				std::string(BOOST_BEAST_VERSION_STRING) +
					" websocket-server-async");
		}));
	// Accept the websocket handshake
	_webSocket.async_accept(boost::beast::bind_front_handler(&NetLink::onAccept, shared_from_this()));
}

void NetLink::onAccept(boost::beast::error_code ec)
{
	if(ec) {
		LOGERROR("connection[%p], user[%lu] accept failed[%d:%s]", this, m_uUserId, ec.value(), ec.message().c_str());
		close();
		return;
	}
	_webSocket.async_read(_recv_buffer, boost::beast::bind_front_handler(&NetLink::onData, shared_from_this()));
}

void NetLink::onData(boost::beast::error_code ec, std::size_t bytes_transferred )
{
	if( ec ) {
		LOGERROR("connection[%p], user[%lu] read data failed[%d:%s]", this, m_uUserId, ec.value(), ec.message().c_str());
		close();
		return;
	}
	if( m_bKickedByServer || m_bClosed ) {
		// 被同账号登录kick的连接, 后续所有的read, 都被抛弃掉
		LOGINFO("user[%lu] connection[%p] read blocked kicked[%d] closed[%d]", m_uUserId, this, m_bKickedByServer, m_bClosed);
		close();
		return;
	}

	onPacket((char*)(_recv_buffer.data().data()), _recv_buffer.size());
	// 完整包
	_recv_buffer.consume(_recv_buffer.size());

	_webSocket.async_read(_recv_buffer, boost::beast::bind_front_handler(&NetLink::onData, shared_from_this()));
}

void NetLink::onPacket(char* data, size_t size)
{
	WrapPacket packet;
	if (!packet.ParseFromArray(static_cast<const void*>(&data[0]), size)) {
		LOGERROR( "user[%lu], connection id[%lu] (parse failed)", m_uUserId, m_nLinkId);
		return;
	}
	int64 lNow = GlobalUtils::GetTickCount();
	if( packet.cmd() == FISH_InputManualFire ) {
		if( lNow - m_lLastManualFireTick < 10 ) {
			return;
		}
		m_lLastManualFireTick = lNow;
	}
	else if( packet.cmd() == FISH_InputHitFish ) {
		if( lNow - m_lLastHitFishTick < 10 ) {
			return;
		}
		m_lLastHitFishTick = lNow;
	}
	int64 iCurrentTime = time(nullptr);
	if (iCurrentTime != m_iLastReceiveMessageTime) {
		m_iLastReceiveMessageTime = iCurrentTime;
		m_iSameTimeReceiveMessageCount = 0;
	}

	m_iSameTimeReceiveMessageCount++;
	if (m_iSameTimeReceiveMessageCount > 100) {
		LOGERROR("user[%lu] connection[%p] too many msg[%d] cmd[%d]", this, m_nLinkId, m_uUserId, m_iSameTimeReceiveMessageCount, packet.cmd());
		if( packet.cmd() == FISH_InputManualFire || packet.cmd() == FISH_InputHitFish ) {
			return;
		}
	}
	if( packet.cmd() == USER_UserHeartBeatReq ) {
		// 心跳包直接回
		int64 now = sGameUtils->GetFakeTimeNow();
		UserHeartBeatResp msg;
		msg.set_server_time(now);

		WrapPacket pkg = packet;
		pkg.clear_data();
		LxGameHelper::MakeUserHeartBeatResp(pkg, msg);
		_tx_queue.push_back(pkg);
		send_next();

        if( m_uUserId != 0 ) {
            // 说明是已经登录的用户
            // 被踢用户的心跳包会被 m_bKickedByServer 屏蔽
            // 发一个登录锁的校验包
            WrapPacket packet;
            packet.set_userid(m_uUserId);
            LxGameHelper::MakeLxCheckLoginLock(packet);
            sDispatcher->dispatch(packet);
        }
        return;
	}

	if ( m_uUserId == 0) {
		// 这里只接受登录包了
		if (packet.cmd() != DATA_UserLoginReq) {
			LOGERROR("user[%lu] connection[%p] cmd[%ld] before login", m_uUserId, this, packet.cmd());
			close();
			return;
		}
		if( iCurrentTime - m_lLastLoginReq < 3 ) {
			// 上次的登录还没结束
			LOGERROR("user[%lu] connection[%p] login too fast", m_uUserId, this);
			return;
		}
		m_lLastLoginReq = iCurrentTime;
	}
	else {
		if( packet.cmd() == FISH_FishEnterRoomReq ) {
			if( iCurrentTime - m_lLastEnterFishRoom < 3 ) {
				LOGERROR("user[%lu] connection[%p] enter fish room too fast", m_uUserId, this);
				return;
			}
			m_lLastEnterFishRoom = iCurrentTime;
		}
		if (packet.cmd() == DATA_UserLoginReq) {
			LOGDEBUG("user[%lu] link[%d] [%p] recv UserLoginReq reqid[%d]", m_uUserId, m_nLinkId, this, packet.requestid());
		}
	}
    packet.set_connectionid(m_nLinkId);	// 所有的包都记录一下connectionid
    packet.set_userid(m_uUserId);		// 所有包都设置userid
    packet.set_starttick(lNow);
    sDispatcher->dispatch(packet);
}

void NetLink::send_prepare(const WrapPacket& packet) {
	_tx_queue.push_back(packet);
	send_next();
}

void NetLink::send_next() {

	if( m_bKickedByServer || m_bClosed ) {
		// 被同账号登录kick的连接, 后续所有的Post包, 都被抛弃掉
		LOGINFO("user[%lu] connection[%p] write blocked kiked[%d] closed[%d] queue[%ld]", m_uUserId, this, m_bKickedByServer, m_bClosed, _tx_queue.size());
		return;
	}
	if( _tx_queue.empty() || _sending ) {
		return;
	}
	auto& packet = _tx_queue.front();
	switch (packet.cmd())
	{
	case DATA_UserLoginResp:
		if( packet.errorcode() == 0 ) {
			LOGDEBUG("user[%lu][%lu] [%p] Login Success", m_uUserId, packet.userid(), this);
			m_uUserId = packet.userid();
			sNetServer->AddUserLinkWithLock(m_uUserId, shared_from_this());
		}
		break;
	case USER_SyncLoginKick:
        clear_link_data();
		m_bKickedByServer = true;
        // 清理相关数据, 这之后就只能
		LOGDEBUG("user[%lu] [%p] SendLoginKick", m_uUserId, this);
		break;
	}
	packet.clear_connectionid();
	packet.clear_userid();
	packet.clear_version();
	packet.clear_starttick();

	if(_send_buffer == NULL)
	{
		_send_buffer = (char *)memory_pool_64k::malloc();
	}
	if( _send_buffer != NULL ) {
		_sending = true;
		_webSocket.binary(true);
		packet.SerializeToArray(_send_buffer, packet.ByteSize());
		_webSocket.async_write(net::buffer(_send_buffer, packet.ByteSize()),
			beast::bind_front_handler( &NetLink::handle_deliver, shared_from_this()));
	}
}

void NetLink::handle_deliver(boost::beast::error_code ec, std::size_t bytes)
{
	if (!ec && !m_bClosed)
	{
		_tx_queue.pop_front();
		_sending = false;
		send_next();
	}
	else
	{
		LOGINFO( "connection[%p], user[%lu] (deliver msg failed)[%d:%s]", this, m_uUserId, ec.value(), ec.message().c_str());
		close();
	}
}

// 重复登录踢人流程:
// 发送踢人包以后,老的连接并不关闭, 设置m_bKickedByDuplicate标记,
// 等待下一次读取或者定时器的超时来再次调用close,保证连接释放
void NetLink::kickUser(int32 reason)
{
	LOGDEBUG( "NetLink [%p] will kick user[%lu] due to [%d]", this, m_uUserId, reason);
	SyncLoginKick msg;
	msg.set_reason(reason);
	WrapPacket packet;
	packet.set_packtype(EPT_Sync);
	LxGameHelper::MakeSyncLoginKick(packet, msg);
	PostPacket(packet);
}

void NetLink::PostPacket(WrapPacket packet)
{
	if( packet.ByteSize() >= MEMORY_BUFFER_MAX_SIZE ) {
		LOGERROR("user[%lu] connection[%p] packet[%ld] too big[%ld]", m_uUserId, this, packet.cmd(), packet.ByteSize());
		return;
	}
	net::post(_webSocket.get_executor(), boost::bind(&NetLink::send_prepare, shared_from_this(), packet));
}

void NetLink::onClosed(boost::beast::error_code ec) {
	if( ec ) {
		LOGERROR("user[%lu] connection[%p] close failed [%d:%s]", m_uUserId, this, ec.value(), ec.message().c_str());
		return;
	}
	LOGINFO("user[%lu] connection[%p] closed gracefully", m_uUserId, this);
}

void NetLink::close()
{
	LOGINFO( "user[%lu], connection[%p] try close[%d]", m_uUserId, this, m_bClosed);
	if (m_bClosed) {
		return;
	}
    clear_link_data();
    _timer.cancel();
	m_bClosed = true;
	_webSocket.async_close(boost::beast::websocket::close_code::normal, boost::beast::bind_front_handler(&NetLink::onClosed, shared_from_this()));
}

void NetLink::clear_link_data() {
    if( m_bKickedByServer || m_bClosed ) {
        return;
    }
	sNetServer->DelUserLinkWithLock(m_uUserId, shared_from_this());
	sNetServer->DelLinkWithLock(m_nLinkId);
    WrapPacket packet;
    packet.set_userid(m_uUserId);
    LxGameHelper::MakeLxFishUserOffline(packet);
    sDispatcher->dispatch(packet);

    m_uUserId = 0;
}