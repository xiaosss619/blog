#pragma once

#include "ServerDefine.h"
#include <boost/beast/core.hpp>
#include <boost/beast/core/detail/stream_traits.hpp>
#include <boost/beast/websocket.hpp>
#include <deque>

namespace net = boost::asio;            // from <boost/asio.hpp>
using tcp = boost::asio::ip::tcp;       // from <boost/asio/ip/tcp.hpp>

/// Represents a single connection from a client.
class NetLink : public std::enable_shared_from_this<NetLink>
{
public:
	/// Construct a connection with the given io_service.
	explicit NetLink(tcp::socket&& socket, int32 connection_id);
	~NetLink();
	/// Start the first asynchronous operation for the connection.
	void start();
	void close();
private:
	template<class NextLayer>
	void setup_stream(boost::beast::websocket::stream<NextLayer>& ws);

	void onAccept(boost::beast::error_code ec);
	void onData(boost::beast::error_code ec, std::size_t bytes_transferred);
	//store incoming data for parsing
	void onPacket(char* data, size_t size);
	void onClosed(boost::beast::error_code ec);

    void OnTimerSeconds50(const boost::system::error_code& error);
private:
	/// Socket for the connection.
	boost::beast::websocket::stream<tcp::socket> _webSocket;
	// 在SERVER中记录连接map
	int32 m_nLinkId;
	bool m_bClosed;
	bool m_bKickedByServer;
    boost::beast::flat_buffer _recv_buffer;
	std::deque<WrapPacket> _tx_queue;
	char* _send_buffer;
	bool _sending;
	boost::asio::deadline_timer _timer;
public:
	void kickUser(int32 reason);
private:
	uint64 m_uUserId;
public:
	// 向线程发送消息
	void PostPacket(WrapPacket packet);
protected:
	void send_prepare(const WrapPacket& packet);
	void send_next();
	void handle_deliver(boost::beast::error_code ec, std::size_t bytes);

    // 清理连接与用户之间的对照数据, 仅仅保持连接, 等客户端主动断开或者超时断开
    void clear_link_data();

	int64 m_iLastReceiveMessageTime;
	int32 m_iSameTimeReceiveMessageCount;
	// 记录link建立的时间
	int64 m_lLastManualFireTick;
	int64 m_lLastHitFishTick;
	int64 m_lLastLoginReq;
	int64 m_lLastEnterFishRoom;
};
