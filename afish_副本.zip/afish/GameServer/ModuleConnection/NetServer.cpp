/**
 * 对于用户连接线程,使用Manager中的connectionid作为线程索引,保证同一个连接的数据在同一个用户线程中处理,用来确保用户数据有序发送
 *
 * 广播消息有两个方案:
 * 	1.在TcpServer中记录一个消息队列,给当前所有在线的用户挂一个当前
 */
#include "NetServer.h"
#include "NetLink.h"

NetServer::NetServer() : Poolize(5),
						_acceptor(get_io_service(0)),
						m_nLinkId(1)
{
}

NetServer::~NetServer()
{
}

void NetServer::start_accept()
{
	//>= 2^ 30
	++m_nLinkId;
	if (m_nLinkId >= 2000000000 || m_nLinkId <= 0)
	{
		m_nLinkId = 1;
	}
	_acceptor.async_accept(get_io_service((m_nLinkId%4)+1), boost::beast::bind_front_handler(&NetServer::handle_accept, this));
}

void NetServer::handle_accept(boost::beast::error_code ec, tcp::socket socket)
{
	if ( !ec )
	{
		auto ptr = std::make_shared<NetLink>(std::move(socket), m_nLinkId);
		ptr->start();
	}

	start_accept();
}

void NetServer::start(const string& strAddr, int32 nPort)
{
	LOGINFO( "bind address[%s], port[%d]", strAddr.c_str(), nPort);
	auto const address = boost::asio::ip::make_address(strAddr);
	auto const port = static_cast<unsigned short>(nPort);

	boost::beast::error_code ec;
	tcp::endpoint endpoint(address, port);
	_acceptor.open(endpoint.protocol(), ec);
	if( ec ) {
		LOGERROR("open failed[%s]", ec.message());
		return;
	}

	_acceptor.set_option(net::socket_base::reuse_address(true), ec);
	if( ec ) {
		LOGERROR("set_option failed[%s]", ec.message());
		return;
	}
	//_acceptor.set_option(boost::asio::ip::tcp::acceptor::reuse_address(true));
	_acceptor.bind(endpoint, ec);
	if( ec ) {
		LOGERROR("bind failed[%s]", ec.message());
		return;
	}

	_acceptor.listen(net::socket_base::max_listen_connections, ec);
	if( ec ) {
		LOGERROR("listen failed[%s]", ec.message());
		return;
	}

	start_accept();
	Poolize::start();
}

void NetServer::AddUserLinkWithLock(uint64 userid, NetLinkPtr conn)
{
	writeLock w(_player_mutex);
	auto itPlayer = m_mapUserLinks.find(userid);
	if (itPlayer != m_mapUserLinks.end()) {
		if( conn == itPlayer->second ) {
			// 客户端在连接未中断的情况下, 如果某个Resp没收到, 会进入一个重新登录(为了保持数据同步)的流程,
			// 此时会在当前已经连接登录成功的包上再次发送登录包, 这时候就不能去执行KickUser, 并且也不需要移除映射表
			return;
		}
		LOGINFO( "user[%lu] will remove connection[%p] replace into[%p]", userid, itPlayer->second.get(), conn.get());
		if (nullptr != itPlayer->second) {
			itPlayer->second->kickUser(EKUR_Duplicate);
		}
		m_mapUserLinks.erase(itPlayer);
	}
	m_mapUserLinks[userid] = conn;
}

bool NetServer::DelUserLinkWithLock(uint64 userid, NetLinkPtr conn)
{
	writeLock w(_player_mutex);
	auto itPlayer = m_mapUserLinks.find(userid);
	// 在重登录踢人时会使用 AddUserLinkWithLock 增加新的 userid对应TcpLink 到映射表
	// 此时这里就仍旧能找到 userid对应的连接,但是指针指向的是新登录的用户,所以这里判断一下指针是否相同,相同再进行删除
	if( itPlayer == m_mapUserLinks.end() ) {
		LOGINFO("user[%lu] has no connection in map but try to remove[%p]", userid, conn.get());
		return false;
	}
	if( itPlayer->second != conn ) {
		LOGINFO( "user[%lu] connected at[%p], old connection[%p] should be useless now", userid, itPlayer->second.get(), conn.get());
		return false;
	}
	LOGINFO( "user[%lu] connection[%p] removed", userid, conn.get());
	m_mapUserLinks.erase(itPlayer);
	return true;
}

NetLinkPtr NetServer::GetUserLinkWithLock(uint64 userid) {
	readLock r(_player_mutex);

	auto itConnection = m_mapUserLinks.find(userid);
	if (itConnection != m_mapUserLinks.end()) {
		return itConnection->second;
	}

	return NetLinkPtr();
}

void NetServer::AddLinkWithLock(int32 linkId, NetLinkPtr conn)
{
	writeLock write(_connection_mutex);
	m_mapLinks[linkId] = conn;
}

void NetServer::DelLinkWithLock(int32 linkId)
{
	writeLock write(_connection_mutex);
	auto itConnection = m_mapLinks.find(linkId);
	if (itConnection != m_mapLinks.end())
	{
		m_mapLinks.erase(itConnection);
	}
}

NetLinkPtr NetServer::GetLinkWithLock(int32 linkId) {
	readLock r(_connection_mutex);

	auto itConnection = m_mapLinks.find(linkId);
	if (itConnection != m_mapLinks.end()) {
		return itConnection->second;
	}

	return NetLinkPtr();
}

void NetServer::KickOnlineUser(uint64 userid)
{
	writeLock wl(_player_mutex);
	auto itPlayer = m_mapUserLinks.find(userid);
	//avoid same user login delete crash
	if (itPlayer != m_mapUserLinks.end())
	{
		itPlayer->second->kickUser(EKUR_SystemKick);
	}
}

void NetServer::KickDuplicateUser(uint64 userid)
{
	writeLock wl(_player_mutex);
	auto itPlayer = m_mapUserLinks.find(userid);
	//avoid same user login delete crash
	if (itPlayer != m_mapUserLinks.end())
	{
		itPlayer->second->kickUser(EKUR_Duplicate);
	}
}

void NetServer::KickAll()
{
	writeLock rl(_player_mutex);
	for( auto& it : m_mapUserLinks) {
		it.second->kickUser(EKUR_ServerDown);
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void NetServer::PostPacket(WrapPacket& packet)
{
	NetLinkPtr link = nullptr;
	if( packet.has_connectionid() ) {
		link = GetLinkWithLock(packet.connectionid());
	}
	if( link == nullptr ) {
		if( packet.has_userid() ) {
			link = GetUserLinkWithLock(packet.userid());
		}
	}
	if( link != nullptr ) {
		link->PostPacket(packet);
	}
}

void NetServer::Broadcast(int32 cmd, const string& strMessage) {
	WrapPacket packet;
	packet.set_cmd(cmd);
	packet.set_packtype(EPT_Sync);
	*packet.mutable_data() = strMessage;
	readLock wl(_player_mutex);
	for( auto & it : m_mapLinks) {
		it.second->PostPacket(packet);
	}
}
