#include "Dispatcher.h"
#include "DataCache/RedisData.h"
#include "FishUtils.h"
#include "ModuleHelper.h"
#include "Include/RedisKey.h"

Dispatcher::Dispatcher()
	: Poolize(THREAD_TOTAL)
{
	for( int n = 0 ; n < DATA_THREAD_NUM ; ++n ) {
		_datas[n] = new ThreadData(get_io_service(ETR_DataStart+n));
	}
	for( int n = 0 ; n < USER_THREAD_NUM ; ++n ) {
		_users[n] = new ThreadUser(get_io_service(ETR_UserStart+n), n);
	}
	_timer = new ThreadTimer(get_io_service(ETR_TimerStart));
	_arena = new ThreadArena(get_io_service(ETR_ArenaStart));
	_board = new ThreadBoard(get_io_service(ETR_BoardStart));
	_logger = new ThreadEventLog(get_io_service(ETR_LoggerStart));
	_chat = new ThreadChat(get_io_service(ETR_ChatStart));
}

Dispatcher::~Dispatcher() {

}

bool Dispatcher::init_sql(const string& strUrl, const string& strUserName, const string& strPassword) {
	for( int n = 0 ; n < DATA_THREAD_NUM; ++n ) {
		_datas[n]->InitSqlLink(strUrl, strUserName, strPassword);
	}
    if( !_datas[0]->InitDatabases() ) {
		LOGINFO("failed to init databases");
        return false;
    }
	return true;
}

void Dispatcher::notify_all_fish_room(WrapPacket& pkg) {
	for( int32 i = 0 ; i < USER_THREAD_NUM ; ++i ) {
		_users[i]->NotifyAll(pkg);
	}
}

// 通过命令字在后台派发
void Dispatcher::dispatch(WrapPacket& pkg) {
	int32 serviceId = GlobalUtils::GetServiceId(pkg.cmd());
	switch( serviceId ) {
	case ESID_data:
	{
		int32 nThreadId = pkg.connectionid()%DATA_THREAD_NUM;
		_datas[nThreadId]->PostPacket(pkg);
		break;
	}
	case ESID_user:
	case ESID_fish:
	{
		int32 nThreadId = pkg.userid()%USER_THREAD_NUM;
		if( sGameUtils->IsTestServer() ) {
			nThreadId = 0;
		}
		_users[nThreadId]->PostPacket(pkg);
		break;
	}
	case ESID_arena:
	{
		_arena->PostPacket(pkg);
		break;
	}
	case ESID_board:
	{
		_board->PostPacket(pkg);
		break;
	}
	case ESID_chat:
	{
		_chat->PostPacket(pkg);
		break;
	}
	default:
		LOGERROR("unknown service idx: %d", serviceId);
		break;
	}
}

void Dispatcher::kick_user(uint64 userId) {
	sNetServer->KickOnlineUser(userId);
}

void Dispatcher::kick_duplicate_user(uint64 userId) {
	sNetServer->KickDuplicateUser(userId);
}

void Dispatcher::broadcast_rolling_msg(int32 msgId, const string& strBonusId, const list<string>& lstData) {
	RollingMsg msg;
	msg.set_type(msgId);
	if( !strBonusId.empty() ) {
		msg.set_bonusid(strBonusId);
	}
	for( auto it = lstData.begin(); it != lstData.end(); ++it ) {
		msg.add_datas(*it);
	}
	string strMessage;
	msg.SerializeToString(&strMessage);
	sNetServer->Broadcast(USER_RollingMsg, strMessage);
}

void Dispatcher::chat_public(const TargetInfo& src, const string& content) {
	SyncChatPublic msg;
	*msg.mutable_src() = src;
	msg.set_content(content);
	string strMsg;
	msg.SerializeToString(&strMsg);
	sNetServer->Broadcast(CHAT_SyncChatPublic, strMsg);
}

void Dispatcher::broadcast(int32 cmd, const string& strMsg) {
	sNetServer->Broadcast(cmd, strMsg);
}

void Dispatcher::broadcast_channel_msg(const string& chn, const string& content) {
	RollingMsg msg;
	msg.set_type(e_jsonAnnouncementID_officialAnn);
	msg.add_datas(content);
	string strMessage;
	msg.SerializeToString(&strMessage);
	for( int32 i = 0 ; i < USER_THREAD_NUM ; ++i ) {
		_users[i]->NotifyChannel(chn, USER_RollingMsg, strMessage);
	}
}

bool Dispatcher::make_mail(uint64 uUserId, int32 nMailType, int64 iDiamond, int64 iGold, const map<int32, int64>& mapItem, const string& title, const string& content, LxMail& mail) {
	if( iDiamond < 0 || iGold < 0 ) {
		return false;
	}
	for( auto & item : mapItem ) {
		if( item.second < 0 ) {
			return false;
		}
	}
	mail.set_mail_id(0);
	mail.set_mail_type(nMailType);
	mail.set_mail_time(time(nullptr));
	mail.set_mail_read(0);
	mail.set_mail_diamond(iDiamond);
	mail.set_mail_gold(iGold);
	mail.set_mail_title(title);
	mail.set_mail_content(content);
	if( mapItem.size() == 0 && iDiamond == 0 && iGold == 0 ) {
		mail.set_mail_rewarded(1);
	}
	else {
		mail.set_mail_rewarded(0);
	}
	for( auto& item : mapItem ) {
		auto pItem = mail.add_mail_items();
		pItem->set_item_id(item.first);
		pItem->set_item_change(item.second);
		pItem->set_item_num(item.second);
	}
	return true;
}

bool Dispatcher::send_mail(uint64 uUserId, int32 nMailType, int32 itemId, int64 itemNum) {
	map<int32, int64> mapItem;
	mapItem[itemId] = itemNum;
	return send_mail(uUserId, nMailType, 0, 0, mapItem, "", "");
}

bool Dispatcher::send_mail(uint64 uUserId, int32 nMailType, int64 iDiamond, int64 iGold, const map<int32, int64>& mapItem, const string& title, const string& content) {
	LxMail mail;
	if( !make_mail(uUserId, nMailType, iDiamond, iGold, mapItem, title, content, mail) ) {
		return false;
	}

	FETCH_RETURN(false);
	if( pConnection->lpush(RedisKey::MakeUserOfflineMailKey(uUserId), JsonProto::ProtoToJson(mail)) ) {
		pConnection->expire(RedisKey::MakeUserOfflineMailKey(uUserId), TIME_DAY*30);
		return true;
	}
	return false;
}
