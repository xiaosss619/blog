#pragma once

#include "ServerDefine.h"
#include "Include/RedisKey.h"
#include "RankingList.h"

struct tagRobotConfig {
	int32 _turret_index;
	int32 _turret_star;
	int32 _turret_level;
	int32 _robot_head;
	int32 _robot_frame;
	int32 _robot_property;
	tagRobotConfig() {
		memset(this, 0, sizeof(tagRobotConfig));
	}
	tagRobotConfig& operator=(tagRobotConfig const& rhs) {
		memcpy(this, &rhs, sizeof(tagRobotConfig));
		return *this;
	}
};

class GameUtils {
// 启动时设置, 只读, 不加锁
GETSET(int32, ServerId);
GETSET_BOOL(WriteRedisLog)
public:
	GameUtils();
	~GameUtils();
//////////////////////////////////////////////////////////////////////////
public:
	bool Init();
	// 获取服务器虚拟的当前时间
	int64 GetFakeTimeNow() { return time(nullptr); }
	// 获取当前时间的yyyy-mm-dd-hh-mm-ss
	string GetFakeTimeFormatString() { return GlobalUtils::GetTimeByFormat(ETF_YMDHMS, GetFakeTimeNow()); }
	void InsertFilterWord(const string& word);
	bool IsDirtyWord(const string& word);
	bool IsChatGroupNameValid(const string& strName);
	string ToValidWord(const string& word);
	string GetRandName();
	std::tuple<bool, int64> GetTideDiamond(int32 curTide, int32 maxTide, list<int32>& lstLoot);
	// 可以击杀大群鱼的逻辑是,玩家身上有一个buffid
	// buff表查找Param字段,表示炮台id
	// TurretSet表查找SelfBulletID[0],表示子弹id
	// FishBullet表找到HitCount,表示击中次数,即可击杀鱼的数量
	int32 GetBulletMaxKill(int32 buffId);
	// TurretSet表查找SelfBulletID[0],表示子弹id
	// FishBullet表找到HitCount,表示击中次数,即可击杀鱼的数量
	int32 GetBulletMaxKillByTurretIndex(int32 turretId);

	int32 GetMarketTimesDiamond(int32 num);
	// 返回值为 < 本次购买需要的钻石数量, 购买的能量点数 >
	std::tuple<int32, int32> GetBuyEnergyData(int32 num);
private:
	boost::shared_mutex _word_mutex;
	FilterWordHelper m_Filter;
	bool m_filterInited;

	boost::shared_mutex _name_mutex;
	vector<string> m_vecNames;
	vector<string> m_vecRobotNames;
public:
	// 根据渠道和版本号获取渠道开关
	// 0表示无变化,不需要更新
	// -1表示无对应配置,客户端使用本地配置
	// >0 返回的是本次有更新, 用更新数据进行
	int64 ForEachSystem(const string& chn, const string& ver, int64 lastTime, std::function<void(const string&, int32)> func);
private:
	// 系统开关
	boost::shared_mutex _ss_mutex;
	map<string, tagSS> m_mapSS;
public:
	int64 GetUserSystemMail(int64 iLastMailId, map<int64, tagSystemMail>& mapMail);
	int64 GetMaxSystemMailId();
	void UpdateSystemMail(int64 maxMailId, const map<int64, tagSystemMail>& mapMail);
private:
	boost::shared_mutex _sys_mail_mutex;
	int64 m_i64MaxSystemMailId;
	map<int64, tagSystemMail> m_mapSystemMail;
public:
	// 查找指定渠道对应的主线任务是否有不同的任务链配置
	int32 GetPostQuestId(const string& chn, int32 qid);
	bool GetChannelItemRecycle(const string& chn, int32 itemId, ItemPair& newItem);
private:
	boost::shared_mutex _chn_quest_mutex;
	map<string, map<int32, int32> > m_mapChannelQuest;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////
public:
	bool IsTestServer() { return m_bTestServer; }
	void SetTestServer(bool b) { m_bTestServer = b; }
	// 该表只有一条数据,目前写死id=1
    bool GetCouponDrawData(tagJsonCouponDraw& lhs) { return JDATA->CouponDrawPtr()->ByID(1, lhs); }
	// 本次服务器运行期间, 持久化桌面奖池
	void OnTableClosed(int32 tableIndex, const tagGoldPool& pool);
	bool GetAvaliableTablePool(int32 tableIndex, tagGoldPool& pool);
	void AddGlobalBuff(int32 buffId);
	void RemoveGlobalBuff(int32 buffId);
	int32 GetItemExtraDropRate(int32 itemId);
	double GetGiftFee(int32 itemId, int64 num) {
		readLock rl(_sys_mutex);
		auto it = m_mapGiftFee.find(itemId);
		if( it == m_mapGiftFee.end() ) {
			return 0;
		}
		int64 now = GetFakeTimeNow();
		if( it->second.start_time() > now || it->second.end_time() < GetFakeTimeNow() ) {
			return num*it->second.fee()/10000.0f;
		}
		return num*it->second.fee()*it->second.discount()/1000000.0f;
	}
	void SetGiftFee(int32 itemId, int32 fee, int32 discount, int64 startTime, int64 endTime) {
		writeLock rl(_sys_mutex);
		GiftFeeData data;
		data.set_item_id(itemId);
		data.set_fee(fee);
		data.set_discount(discount);
		data.set_start_time(startTime);
		data.set_end_time(endTime);
		m_mapGiftFee[itemId] = data;
	}
    void GetGiftFee(GiftListResp& resp) {
		readLock rl(_sys_mutex);
        for( auto & it : m_mapGiftFee ) {
            *resp.add_fee() = it.second;
        }
    }
private:
	boost::shared_mutex _sys_mutex;
	bool m_bTestServer;
	map< int32, list<tagGoldPool> > m_mapTablePool;
	map<int32, tagJsonBuff> m_globalBuffs;
	map<int32, GiftFeeData> m_mapGiftFee;
public:
	void IncOnlineUser() {
		writeLock wl(_online_mutex);
		++m_nOnlineUserNum;
	}
	void DecOnlineUser() {
		writeLock wl(_online_mutex);
		--m_nOnlineUserNum;
	}
	void IncTableUser(int32 tableIndex) {
		writeLock wl(_online_mutex);
		GlobalUtils::SimpleMapAdd(m_mapTableUserNum, tableIndex, (int64)1);
	}
	void DecTableUser(int32 tableIndex) {
		writeLock wl(_online_mutex);
		GlobalUtils::SimpleMapAdd(m_mapTableUserNum, tableIndex, (int64)(-1));
	}
	void LogOnlineNum();
private:
	boost::shared_mutex _online_mutex;
	map<int32, int64> m_mapTableUserNum;
	int32 m_nOnlineUserNum;
};

#define sGameUtils Singleton<GameUtils>::Instance()
