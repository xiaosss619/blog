#include "FishGame.h"
#include "Entity/FishTable.h"
#include "Entity/FishFish.h"
#include "Entity/FishShoal.h"
#include "Entity/FishRoute.h"
#include "Dispatcher.h"
#include "FishUtils.h"
#include "ModuleUser/LxUser.h"
#include "LxGameLogHelper.h"

FishGame::FishGame()
{
	m_Tables.Init("FishTable", 100, 10);
    m_TideDelay.Init("TideDelay", 50, 10);
    m_TideCircleScatter.Init("TideCircleScatter", 100, 10);
    m_TideCircle.Init("TideCircle", 10, 10);
    m_TideCircleRotate.Init("TideCircleRotate", 10, 10);
    m_TideCircleRandom.Init("TideCircleRandom", 10, 10);
    m_TideLine.Init("TideLine", 10, 10);
    m_TideLineDelay.Init("TideLineDelay", 10, 10);
    m_TideFix.Init("TideFix", 10, 10);
    m_TideOffset.Init("TideOffset", 10, 10);

    m_SimpleLineRoutes.Init("SimpleLineRoute", 1000, 10);
    m_AdvanceRoutes.Init("AdvanceRoute", 1000, 10);
    m_RotationRoutes.Init("RotationRoute", 20, 10);
    m_SpecialRoutes.Init("SpecialRoute", 20, 10);
    m_OffsetRoutes.Init("OffsetRoute", 100, 10);

    _generator.seed(time(nullptr)+GlobalUtils::GetRandNumber(1234,10000));
}

FishGame::~FishGame()
{
}

void FishGame::Update(int32 dt) {
	m_Tables.Update(dt);
}

void FishGame::OnTimer5m(int32 idx) {
    int64 tNow = sGameUtils->GetFakeTimeNow();
    {
        auto data = m_Tables.DebugInfo();
        LOG_MEMPOOL_INFO(tNow,idx,std::get<0>(data),std::get<1>(data),std::get<2>(data),std::get<3>(data));
    }

    map<string, tagPoolLog> mapLog;
    m_Tables.ForEachEntity([&](FishTable* ptr){
        ptr->BuildPoolLog(mapLog);
    });
    int64 now = sGameUtils->GetFakeTimeNow();
    for( auto& it : mapLog ) {
        LOG_MEMPOOL_INFO(now,
                        idx,
                        it.first,
                        it.second._cur_num,
                        it.second._free_num,
                        it.second._used_num);
    }
}

void FishGame::NotifyAllRoom(WrapPacket& packet) {
    switch( packet.cmd() ) {
    case FISH_LxActivityOpen:
    {
        LxActivityOpen request;
        if( request.ParseFromString(packet.data()) ) {
            tagJsonActivities act;
            if( JDATA->ActivitiesPtr()->ByID(request.id(), act) ) {
                switch(act._Type) {
                case e_jsonActivitiesType_FishPoolSwitch:
                    if( act._ACTParam.size() == 4 ) {
                        m_Tables.ForEachEntity([&](FishTable* ptr){
                            if( ptr->GetGamePlay()._ID == act._ACTParam[0] ) {
                                ptr->FishPoolLinePtr()->AddFishPool(request.start(), request.end(), act._ACTParam[1], act._ACTParam[2], act._ACTParam[3]);
                            }
                        });
                    }
                    break;
                default:
                    break;
                }
            }
        }
        break;
    }
    default:
        break;
    }
}

void FishGame::UserClearFishTable(LxUser* pUser, int32 tableId) {
    FishTable* pTable = GetTable(tableId);
    if( pTable != nullptr ) {
        pTable->ClearUser(pUser);
    }
}

void FishGame::ProcessFishEnterRoomReq(LxUser* pUser, WrapPacket& packet) {
    FishEnterRoomReq request;
    if( !request.ParseFromString(packet.data()) ) {
        LOGINFO("parse failed[%s]", packet.DebugString());
        return;
    }
    // 进入桌子
    FishEnterRoomResp resp;
    WrapPacket pkg = packet;
    pkg.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    do {
        int32 tableId = pUser->GetFishTableId();
        FishTable* pTable = nullptr;
        bool isReconnect = false;
        if( tableId == 0 ) {
            // 重新进入一个房间
            pTable = GetActiveTable(request.room_index(), pUser->GetUserGoldProperty(), GlobalUtils::InSameDay(pUser->PBGetTimeRegister(), sGameUtils->GetFakeTimeNow()));
            if( pTable == nullptr ) {
                pkg.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
                break;
            }
        }
        else {
            isReconnect = true;
            // 说明用户是重连进桌子的
            pTable = GetTable(tableId);
            if( pTable == nullptr || pTable->IsFull(pUser->GetKey()) ) {
                // 用户切换到后台时间过久,已经离开房间,并且房间已经关闭 或者原本的房间已经满员了
                pUser->SetFishTableInfo(0,0,0);
                pTable = GetActiveTable(request.room_index(), pUser->GetUserGoldProperty(), GlobalUtils::InSameDay(pUser->PBGetTimeRegister(), sGameUtils->GetFakeTimeNow()));
                if( pTable == nullptr ) {
                    pkg.set_errorcode(JDATA->ErrorCodePtr()->GetSystemNoted());
                    break;
                }
            }
        }
        int32 nRet = pTable->OnPlayerJoin(pUser, isReconnect, resp);
        if( nRet != JDATA->ErrorCodePtr()->GetSuccess() ) {
            LOGERROR("user[%lu] failed to enter table[%d] due to[%d]", packet.userid(), pTable->GetTableIndex(), nRet);
            pkg.set_errorcode(nRet);
            break;
        }
        // 经典场,并且前置任务都完成了,进桌子要随机一个任务
        if( pTable->IsClassic() && pUser->IsNewbieEnd() ) {
            CALL_THREAD_SIMPLE(pUser, LxRandQuest);
        }
        if( pTable->IsFull() ) {
            // 如果人满了
            RemoveTableIndex(pTable->GetTableIndex(), pTable->GetKey());
        }
        else {
            // 人没满
            RecordTableIndex(pTable->GetTableIndex(), pTable->GetKey());
        }
    } while(0);
    LxGameHelper::MakeFishEnterRoomResp(pkg, resp);
	sDispatcher->call_client(pkg);
    pUser->SendUserInfoChange(0);
}

void FishGame::ProcessPacket(LxUser* pUser, WrapPacket& packet) {
    if( packet.cmd() == FISH_FishEnterRoomReq ) {
        ProcessFishEnterRoomReq(pUser, packet);
        return;
    }
	int32 tableId = pUser->GetFishTableId();// 优先获取玩家身上的,还没有超时的桌子id
    if( tableId == 0 ) {
        return;
    }
	FishTable* pTable = GetTable(tableId);
	if( pTable == nullptr ) {
		LOGERROR("[%lu]failed to get room[%d][%d]", pUser->GetKey(), tableId, packet.cmd());
		return;
	}
    WrapPacket response = packet;
    response.clear_data();
    pTable->OnPlayerCommand(packet, response);
    if( response.has_userid() ) {
        // 有用户id,返回给客户端
        sDispatcher->call_client(response);
    }
    if( !pTable->IsFull() ) {
        RecordTableIndex(pTable->GetTableIndex(), pTable->GetKey());
    }
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void FishGame::RecordTableIndex(int32 index, int32 tableid) {
	auto it = m_mapRoomTables.find(index);
	if( it == m_mapRoomTables.end() ) {
		set<int32> rooms;
		rooms.insert(tableid);
		m_mapRoomTables[index] = rooms;
	}
	else {
		it->second.insert(tableid);
	}
}

void FishGame::RemoveTableIndex(int32 index, int32 tableid) {
	auto it = m_mapRoomTables.find(index);
	if( it != m_mapRoomTables.end() ) {
		it->second.erase(tableid);
	}
}

FishTable* FishGame::GetEmptyTable(int32 nIndex) {
	tagJsonGamePlay data;
	if( !JDATA->GamePlayPtr()->ByID(nIndex, data) ) {
		LOGERROR("Failed to find room index %d", nIndex);
		return nullptr;
	}
	return m_Tables.CreateEntity(this, _tableId.incryby(1), data);
}

FishTable* FishGame::GetActiveTable(int32 nIndex, int64 gold, bool isNewbie) {
    int64 goldMax = JDATA->GamePlayPtr()->NewTableConditionByID(nIndex);
    if( goldMax > 0 ) {
        // 可以进行新桌判定
        if( isNewbie || gold < goldMax ) {
            return GetEmptyTable(nIndex);
        }
    }
	auto it = m_mapRoomTables.find(nIndex);
	if( it == m_mapRoomTables.end() || it->second.empty() ) {
		return GetEmptyTable(nIndex);
	}
	int32 tid = *(it->second.begin());
    auto table = GetTable(tid);
    if( table != nullptr && table->IsFull() ) {
        // 机器人把桌子塞满了
        RemoveTableIndex(nIndex, tid);
        return GetActiveTable(nIndex, gold, isNewbie);
    }
	return GetTable(tid);
}

////////////////////////////////////////////////////////////////////////////////////////////////
TideBase* FishGame::BuildTide(FishShoal* pShoal, int32 tideIndex, int32 routeId)
{
    tagJsonFishGenerator gen;
    if( !JDATA->FishGeneratorPtr()->ByID(tideIndex, gen) ) {
        LOGERROR("generator not found %d", tideIndex);
        return nullptr;
    }
    FishTable* pTable = pShoal->GetTable();

    int32 tideId = pTable->GetGame()->FetchTideId(1);
    TideBase* tide = nullptr;
    switch (gen._Type)
    {
        case e_jsonFishGeneratorType_Delayed:
            tide = m_TideDelay.CreateEntity(tideId, pTable, pShoal, gen._Param);
            break;
        case e_jsonFishGeneratorType_CircleSpread:
            tide = m_TideCircleScatter.CreateEntity(tideId, pTable, pShoal, gen._Param);
            break;
        case e_jsonFishGeneratorType_Circle:
            tide = m_TideCircle.CreateEntity(tideId, pTable, pShoal, gen._Param);
            break;
        case e_jsonFishGeneratorType_CircleRotation:
            tide = m_TideCircleRotate.CreateEntity(tideId, pTable, pShoal, gen._Param);
            break;
        case e_jsonFishGeneratorType_Line:
            tide = m_TideLine.CreateEntity(tideId, pTable, pShoal, gen._Param);
            break;
        case e_jsonFishGeneratorType_LineInterval:
            tide = m_TideLineDelay.CreateEntity(tideId, pTable, pShoal, gen._Param);
            break;
        case e_jsonFishGeneratorType_CircleRandom:
            tide = m_TideCircleRandom.CreateEntity(tideId, pTable, pShoal, gen._Param);
            break;
        case e_jsonFishGeneratorType_Statics:
            tide = m_TideFix.CreateEntity(tideId, pTable, pShoal, gen._Param);
            break;
        case e_jsonFishGeneratorType_Trajectory:
            tide = m_TideOffset.CreateEntity(tideId, pTable, pShoal, gen._Param);
            break;
        default:
            break;
    }
    if (tide != nullptr)
    {
        if( tide->GetRouteId() == 0 ) {
            tide->SetRouteId(routeId);
        }
    }
    else {
        LOGERROR("failed to create tide[%s]", gen.GetDebugString().data());
    }
    return tide;
}

TideBase* FishGame::CreateTide(FishShoal* pShoal, int32 tideIndex, int32 routeId, bool isFlash)
{
    auto pTide = BuildTide(pShoal, tideIndex, routeId);
    if( pTide == nullptr ) {
        return nullptr;
    }

    SyncCreateGenerator msg;
    msg.set_generatorid(tideIndex);
    msg.set_startid(pTide->GetFishStartId());
    msg.set_routeid(routeId);
    msg.set_isflash(isFlash);
    pShoal->GetTable()->PushGenerator(msg);
    return pTide;
}

TideBase* FishGame::CreateTide(FishShoal* pShoal, int32 tideIndex, const Vec2& pos)
{
    auto pTide = BuildTide(pShoal, tideIndex, -1);
    pTide->SetPosition(pos);

    SyncCreateGenerator msg;
    msg.set_generatorid(tideIndex);
    msg.set_startid(pTide->GetFishStartId());
    msg.set_isred(true);
    msg.set_posx((int32)pos.x);
    msg.set_posy((int32)pos.y);
    pShoal->GetTable()->PushGenerator(msg);
    return pTide;
}

void FishGame::RemoveTide(TideBase* pTide) {
    switch( pTide->GetType() ) {
        case e_jsonFishGeneratorType_Delayed:
            m_TideDelay.RemoveEntity((TideDelay*)(pTide));
            break;
        case e_jsonFishGeneratorType_CircleSpread:
            m_TideCircleScatter.RemoveEntity((TideCircleScatter*)(pTide));
            break;
        case e_jsonFishGeneratorType_Circle:
            m_TideCircle.RemoveEntity((TideCircle*)(pTide));
            break;
        case e_jsonFishGeneratorType_CircleRotation:
            m_TideCircleRotate.RemoveEntity((TideCircleRotate*)(pTide));
            break;
        case e_jsonFishGeneratorType_Line:
            m_TideLine.RemoveEntity((TideLine*)(pTide));
            break;
        case e_jsonFishGeneratorType_LineInterval:
            m_TideLineDelay.RemoveEntity((TideLineDelay*)(pTide));
            break;
        case e_jsonFishGeneratorType_CircleRandom:
            m_TideCircleRandom.RemoveEntity((TideCircleRandom*)(pTide));
            break;
        case e_jsonFishGeneratorType_Statics:
            m_TideFix.RemoveEntity((TideFix*)(pTide));
            break;
        case e_jsonFishGeneratorType_Trajectory:
            m_TideOffset.RemoveEntity((TideOffset*)(pTide));
            break;
        default:
            break;
    }
}

////////////////////////////////////////////////////////////////////////////////////////////////
void FishGame::RemoveRoute(FishRoute* route) {
    switch(route->GetRouteType()) {
    case RouteType_Base:
        m_SimpleLineRoutes.RemoveEntity((SimpleLineRoute*)route);
        break;
    case RouteType_Advanced:
        m_AdvanceRoutes.RemoveEntity((AdvanceRoute*)route);
        break;
    case RouteType_Rotate:
        m_RotationRoutes.RemoveEntity((RotationRoute*)route);
        break;
    case RouteType_Special:
        m_SpecialRoutes.RemoveEntity((SpecialRoute*)route);
        break;
    case RouteType_Offset:
        m_OffsetRoutes.RemoveEntity((OffsetRoute*)route);
        break;
    }
}

SimpleLineRoute* FishGame::CreateSimpleLine(int32 fishCfgID, Vec2 position, Vec2 speed)
{
    float lifeTime = 60.0f;
    tagJsonFishData data;
    if( JDATA->FishDataPtr()->ByID(fishCfgID, data) ) {
        lifeTime = FishMath::GetMoveTime(position, speed, data._Radius);
    }
    BaseRouteParam proto;
    FishMath::ToFishVector(position, *proto.mutable_position());
    FishMath::ToFishVector(speed, *proto.mutable_velocity());

    return m_SimpleLineRoutes.CreateEntity(FetchRouteId(1), proto, position, speed, lifeTime);
}

RotationRoute* FishGame::CreateRotationRoute(int32 fishCfgID, Vec2 center, Vec2 startPos, float angleSpeed, float duration, float moveSpeed)
{
    RotateRouteParam proto;
    proto.set_fishcfgid(fishCfgID);
    FishMath::ToFishVector(center, *proto.mutable_centerpos());
    FishMath::ToFishVector(startPos, *proto.mutable_position());
    proto.set_rotation(angleSpeed);
    proto.set_rotatetime(duration);
    proto.set_movespeed(moveSpeed);

    auto velocity = startPos - center;
    velocity.rotate(Vec2::ZERO, - PI / 2.0f);

    float initRotation = FishMath::FishVelocityToRotation(velocity);

    float speed = velocity.length() * PI * angleSpeed / 180.0f;

    tagRoutePoint point1(speed, initRotation + angleSpeed * duration, duration, duration);
    tagRoutePoint point2(moveSpeed, initRotation + angleSpeed * duration, 0, 0);
    auto dir = startPos - center;
    float angle = FishMath::FishLineDirToRad(dir);
    Vec2 realPos = center + FishMath::AngleDirection(angle) * dir.length();
    Vec2 moveSpeed2 = FishMath::GetRotateDirection(initRotation + angleSpeed * duration) * moveSpeed;
    float lifeTime = duration;
    tagJsonFishData xml;
    if( JDATA->FishDataPtr()->ByID(fishCfgID, xml) ) {
        lifeTime += FishMath::GetMoveTime(realPos, moveSpeed2, xml._Radius);
    }
    else {
        lifeTime += 60.0f;
    }

    auto ptr = m_RotationRoutes.CreateEntity(FetchRouteId(1), proto, lifeTime);
    ptr->AddRoutePoint(point1);
    ptr->AddRoutePoint(point2);
    return ptr;
}

SpecialRoute* FishGame::CreateSpecialRoute(int32 fishCfgID, Vec2 startPos, Vec2 speedVector, float delayTime, float moveTime, float waitTime)
{
    SpecialRouteParam proto;
    FishMath::ToFishVector(startPos, *proto.mutable_position());
    FishMath::ToFishVector(speedVector, *proto.mutable_velocity());
    proto.set_delaytime(delayTime);
    proto.set_movetime(moveTime);
    proto.set_waittime(waitTime);
    proto.set_fishcfgid(fishCfgID);

    float initRotation = FishMath::FishVelocityToRotation(speedVector);
    tagRoutePoint point1(0, initRotation, 0, delayTime);
    tagRoutePoint point2(speedVector.length(), initRotation, 0, moveTime);
    tagRoutePoint point3(0, initRotation, 0, waitTime);

    float lifeTime = delayTime + waitTime;
    tagJsonFishData data;
    if( JDATA->FishDataPtr()->ByID(fishCfgID, data) ) {
        lifeTime += FishMath::GetMoveTime(startPos, speedVector, data._ShowRadius);
    }
    else {
        lifeTime += 60.0f;
    }

    auto ptr = m_SpecialRoutes.CreateEntity(FetchRouteId(1), proto, lifeTime);
    if( ptr == nullptr ) {
        return nullptr;
    }
    ptr->AddRoutePoint(point1);
    ptr->AddRoutePoint(point2);
    ptr->AddRoutePoint(point3);
    return ptr;
}

OffsetRoute* FishGame::CreateOffsetRoute(int32 routeID, Vec2 initOffset, int32 randOffset, int32 randSeed)
{
    OffsetRouteParam proto;
    proto.set_routeid(routeID);
    FishMath::ToFishVector(initOffset, *proto.mutable_initoffset());
    proto.set_randoffset(randOffset);
    proto.set_randseed(randSeed);

    return m_OffsetRoutes.CreateEntity(FetchRouteId(1), proto, routeID, initOffset, randOffset, randSeed);
}

AdvanceRoute* FishGame::CreateAdvanceRoute(int32 routeID)
{
    return m_AdvanceRoutes.CreateEntity(FetchRouteId(1), routeID);
}
