﻿#pragma once

#include "ServerDefine.h"

static const int32 SkillID_Lock = 1; //锁定
static const int32 SkillID_Freeze = 2; //冰冻
static const int32 SkillID_Fast = 3; //急速
static const int32 SkillID_Fury = 4; // 狂暴
static const int32 SkillID_Summon = 5; // 召唤
static const int32 SkillID_SuperWeapon = 6; // 超级武器

struct tagFreezeTimeSpan {
    int64 _begin;
    int64 _end;
    tagFreezeTimeSpan(int64 begin, int64 end) {
        _begin = begin;
        _end = end;
    }
    int64 span() { return _end - _begin; }
};

/// 捕鱼房间时间线, 用于组件计算生存时间，不必每帧刷新LiftTime
struct tagFishTimeLine
{
    int64 _freezeEnd;
    int64 _startTick;
    list<tagFreezeTimeSpan> _freezeTimes;
    tagFishTimeLine() {
        reset();
    }
    void reset() {
        _startTick = GlobalUtils::GetTickCount();
        _freezeEnd = 0;
        _freezeTimes.clear();
    }
    int64 TimeStamp() { return GlobalUtils::GetTickCount(); }
    bool IsFreeze() { return TimeStamp() < _freezeEnd; }
    int64 CalcEndTime(int64 duration) { return TimeStamp() + duration; }
    /// 记录冰冻时间线
    void SetFreeze(int32 freezeMS)
    {
        tagFreezeTimeSpan ft(TimeStamp(), TimeStamp() + freezeMS);
        //刷新冰冻结束时间戳
        if (ft._end > _freezeEnd) {
            _freezeEnd = ft._end;
        }
        //消除冰冻时间线重合
        for( auto & freeze : _freezeTimes ) {
            if (ft._begin >= freeze._begin && ft._begin < freeze._end)
            {
                if (ft._end <= freeze._end)
                {
                    return;
                }
                else
                {
                    freeze._end = ft._end;
                    return;
                }
            }
        }
        _freezeTimes.push_back(ft);
    }
};


#define PI 3.14159

#define BounceL -60
#define BounceR 1340
#define BounceT 750
#define BounceB -30

class FishMath
{
public:
    static Vec2 AngleDirection(float radian)
    {
        return Vec2(std::cos(radian), std::sin(radian));
    }

    // 与客户端匹配路线 角度与方向转换
    static Vec2 GetRotateDirection(float angle)
    {
        return AngleDirection(AngleToRadian(90 - angle));
    }

    static float BulletDirToAngle(const Vec2& dir)
    {
        return -std::atan2(dir.y,dir.x) / PI * 180.0f + 90.0f;
    }

    static float FishLineDirToAngle(const Vec2& dir)
    {
        auto radian = std::atan2(dir.y, dir.x);

        //弧段转角度，再加90度(切线方向 换 围绕圆心的方向)
        return radian / PI * 180.0f + 90.0f;
    }

    static float FishLineDirToRad(const Vec2& dir)
    {
        return std::atan2(dir.y, dir.x);
    }

    // 鱼的线性数度转圆周运动的角度;
    static float FishVelocityToRotation(const Vec2& velocity)
    {
        auto radian = std::atan2(velocity.y, velocity.x);

        //弧段转角度，再加90度(切线方向 换 围绕圆心的方向)
        return radian / PI * 180.0f + 90.0f;
    }

    // 角度转弧度
    static float AngleToRadian(float angle)
    {
        return angle * PI / 180.0f;
    }

    // 弧度转角度
    static float RadianToAngle(float radian)
    {
        return radian * 180.0f / PI;
    }

    static float GetMoveTime(const Vec2& pos, const Vec2& speed, float radius)
    {
        float minX = BounceL-radius;
        float maxX = BounceR + radius;
        float minY = BounceB- radius;
        float maxY = BounceT + radius;

        float moveX = 60.0f;
	    if (speed.x > 0 && pos.x < maxX)
	    {
		    moveX = (maxX - pos.x)/speed.x;
	    }
	    else if (speed.x< 0 && pos.x> minX)
	    {
		    moveX = (minX - pos.x)/speed.x;
	    }

	    float moveY = 60.0f;
	    if (speed.y > 0 && pos.y < maxY)
	    {
		    moveY = (maxY - pos.y)/speed.y;
	    }
	    else if (speed.y< 0 && pos.y> minY)
	    {
		    moveY = (minY - pos.y)/speed.y;
	    }

	    return moveX<moveY? moveX : moveY;
    }

    static bool CheckInScene(const Vec2& pos, float radius)
    {
        if (pos.x < BounceL-radius || pos.x > BounceR + radius)
        {
            return false;
        }
        if (pos.y < BounceB-radius || pos.y > BounceT + radius)
        {
            return false;
        }
        return true;
    }

    static void ToFishVector(const Vec2& v, FishVector& fv) {
        fv.set_x(v.x);
        fv.set_y(v.y);
    }

    static float Distance(const Vec2& v1, const Vec2& v2) {
        return sqrt((v1.x - v2.x)*(v1.x - v2.x)+(v1.y - v2.y)*(v1.y - v2.y));
    }
};

// vc c随机代码 0~1
class MyRandom
{
public:
    static int64 holdrand;
    static void Srand(uint32 seed)
    {
        holdrand = seed;
    }

    static double Rand()
    {
        return (((holdrand = holdrand * 214013L + 2531011L) >> 16) & 0x7fff) / (double)0x7fff;
    }
};

// 与客户端同步，JS指定随机数 0~233280
class ClientRandom
{
public:
    uint32 holdrand = 1;
    void SetSeed(int seed)
    {
        holdrand = (uint32)seed;
    }
    int Random()
    {
        holdrand = (holdrand * 9301 + 49297) % 233280;
        return (int)holdrand;
    }
};

class RandomMath
{
public:
    static int32 Rand1W()
    {
        return GlobalUtils::GetRandNumber(0, 10000);
    }

    static int32 Rand100()
    {
        return (int32)(MyRandom::Rand() * 100);
    }

    static int RandInt(int32 min, int32 max)
    {
        return (int32)(MyRandom::Rand() * (max-min) + min);
    }

    static float RandFloat(double min, double max)
    {
        return (float)RandDouble(min, max);
    }

    static double RandDouble(double min, double max)
    {
        return MyRandom::Rand()*(max - min) + min;
    }
};

struct tagPlayerDamage {
    // 物理攻击
    int32 _patk;
    // 物理攻击加成百分比
    float _patkr;
    // 魔法攻击
    int32 _matk;
    // 魔法攻击加成百分比
    float _matkr;
    // 物理穿透
    int32 _pp;
    // 物理穿透百分比
    float _ppr;
    // 魔法穿透
    int32 _mp;
    // 魔法穿透百分比
    float _mpr;
    // 暴击率
    float _cr;
    // 暴击伤害加成
    float _ctdr;
    // 真实伤害
    int32 _rd;
    tagPlayerDamage() {
        memset(this,0,sizeof(tagPlayerDamage));
    }
    tagPlayerDamage& operator=(tagPlayerDamage& other) {
        memcpy(this, &other, sizeof(tagPlayerDamage));
        return *this;
    }
};

struct tagFishBuff {
    int32 _index;       // buffId
    int32 _fishIndex;   // 来自于哪条鱼
    int64 _gold;        // buff击杀获得的金币总数
    tagFishBuff() { memset(this, 0, sizeof(tagFishBuff)); }
    tagFishBuff& operator=(const tagFishBuff& other) { memcpy(this, &other, sizeof(tagFishBuff)); return *this; }
};

enum E_RobotStatus {
    ERS_Lock    = 1,    // 锁定阶段
    ERS_Fast    = 2,    // 急速阶段
};

struct tagRobotData {
    int32 _stat;
    int64 _updateFrame;
    int64 _lastFireTick;    // 上次开火的tick
    int64 _endTime;         // 本阶段结束时间
    int64 _lifeTime;    // 寿命
    FishPlayerProto _data;
    int32 _bulletId;

    tagRobotData() {
        Init();
    }
    void Init() {
        _stat = ERS_Lock;
        _endTime = 0;
        _updateFrame = 0;
        _lastFireTick = 0;
        _lifeTime = 0;
        _data.Clear();
        _bulletId = 1;
    }
    tagRobotData& operator=(const tagRobotData& rhs) {
        _stat = rhs._stat;
        _endTime = rhs._endTime;
        _updateFrame = rhs._updateFrame;
        _lastFireTick = rhs._lastFireTick;
        _lifeTime = rhs._lifeTime;
        _data = rhs._data;
        _bulletId = rhs._bulletId;
        return *this;
    }
    void Update(int64 tNow, int32 dt) {
        _lifeTime -= dt;
        _updateFrame++;
        if( _endTime == 0 || _endTime < tNow ) {
            _stat = GlobalUtils::GetRandNumber(1,2);
            _endTime = tNow + 20;
        }
    }
    int64 GetCurGold() { return _data.user_gold(); }
    void ChangeGold(int64 gold) {
        _data.set_user_gold(_data.user_gold() + gold);
    }
    bool CanFire(int32 bulletSpeed) {
        if( bulletSpeed == 0 ) {
            LOGERROR("SPEED failed");
            return false;
        }
        return (_updateFrame - _lastFireTick)*100 >= 1000/bulletSpeed;
    }
    void OnFire() {
        _lastFireTick = _updateFrame;
        _bulletId++;
    }
};

#define SKILL_ID_LOCK 1

struct tagSkillStep {
    int32 _skillId;
    // 当前阶段
    int32 _curStep;
    // 累计获得金币
    int64 _totalGold;
    // 配置中的最大阶段
    int32 _maxStep;
    // 配置中的最大击杀数
    int32 _maxKill;
    // 核弹的使用个数
    int32 _useCount;
    tagSkillStep() {
        _skillId = 0;
        _curStep = 0;
        _totalGold = 0;
        _maxStep = 0;
        _maxKill = 0;
        _useCount = 0;
    }
    tagSkillStep& operator=(const tagSkillStep& rhs) {
        _skillId = rhs._skillId;
        _curStep = rhs._curStep;
        _totalGold = rhs._totalGold;
        _maxStep = rhs._maxStep;
        _maxKill = rhs._maxKill;
        _useCount = rhs._useCount;
        return *this;
    }
    void Init(int32 skillId, int32 maxStep, int32 maxKill, int32 useCount) {
        _skillId = skillId;
        _curStep = 0;
        _totalGold = 0;
        _maxStep = maxStep;
        _maxKill = maxKill;
        _useCount = useCount;
    }
    // 根据_curStep获得本次能够击杀的鱼数量
    int32 GetMaxKill() {
        if( _maxKill == 0 || _maxStep == 0 ) {
            return 0;
        }
        int32 killPerStep = _maxKill/_maxStep;
        if( _curStep >= _maxStep ) {
            // 最后一步
            return _maxKill - (_maxStep-1)*killPerStep;
        }
        else {
            return killPerStep;
        }
    }
};

struct tagCommonSkill {
    bool _in_use;
    bool _halt;
    int32 _cur_tick;
    int32 _max_tick;
    int32 _atk_left;
    int32 _skill_id;
    tagCommonSkill() {
        clear();
    }
    void clear() {
        _in_use = false;
        _halt = false;
        _cur_tick = 0;
        _max_tick = 0;
        _atk_left = 0;
        _skill_id = 0;
    }
    void init(int32 skillId, int32 maxTick) {
        clear();
        _skill_id = skillId;
        _in_use = true;
        _max_tick = maxTick;
        _atk_left = maxTick/200;
    }
    tagCommonSkill& operator=(const tagCommonSkill & rhs) {
        _in_use = rhs._in_use;
        _halt = rhs._halt;
        _cur_tick = rhs._cur_tick;
        _max_tick = rhs._max_tick;
        _atk_left = rhs._atk_left;
        _skill_id = rhs._skill_id;
        return *this;
    }
    void halt() {
        if( _in_use ) {
            _halt = true;
        }
    }
    void resume() {
        if( _in_use ) {
            _halt = false;
        }
    }
    void update(int32 dt) {
        if( _in_use && !_halt ) {
            _cur_tick += dt;
            if( _cur_tick >= _max_tick ) {
                clear();
            }
        }
    }
    // 超级武器使用
    void fire() { --_atk_left; }
    bool empty() { return _atk_left <= 0; }
};

// 召唤boss
// 在击杀时直接随机两次, 第一次是普通随机, 然后根据需要随机一次重置后的倍率
// 后续玩家消息上来会确定是使用了重置倍率卡领奖还是正常领奖
//
struct tagSummonBossData {
    int32 _fish_index;  // 对应的鱼配置id
    int64 _maxB;        // 击杀时的房间最大炮倍
    int64 _curB;        // 击杀时使用的炮倍
    int64 _rate1;       // 第一次随机
    int64 _rate2;       // 第二次随机
    int64 _total_gold;  // 凶手花费的金币
    int32 _expect_num;  // 预期击中次数
    int32 _fish_score;  // 击杀时对应玩家应该得到的鱼分
    int32 _pool_yell_id;    // 分奖池的公告id
    int32 _pool_min_rate;   // 分奖池的最小倍数
    int32 _pool_bonus_rate;   // 分奖池的比例
    int32 _normal_yell_id;      // 正常击杀公告id
    int32 _normal_yell_rate;    // 正常击杀公告需求的倍数
    int32 _avg_reset_tax;       // 重置卡平均收益倍数
    list<int32> _lst_door_normal;   // 八门玩法的普通顺序
    list<int32> _lst_door_reset;    // 八门玩法的重置后顺序
    int32 _jar_reset_rate;              // 砸罐子重置线
    vector<BossJarInfo> _lst_jar_normal;  // 砸罐子的普通顺序
    vector<BossJarInfo> _lst_jar_reset;   // 砸罐子的重置后顺序
    bool _is_bonus_boss;
    int32 _boss_point_param;
    tagSummonBossData() {
        reset();
    }
    tagSummonBossData& operator=(const tagSummonBossData& rhs) {
        _fish_index = rhs._fish_index;
        _maxB = rhs._maxB;
        _curB = rhs._curB;
        _rate1 = rhs._rate1;
        _rate2 = rhs._rate2;
        _total_gold = rhs._total_gold;
        _expect_num = rhs._expect_num;
        _fish_score = rhs._fish_score;
        _pool_yell_id = rhs._pool_yell_id;
        _pool_min_rate = rhs._pool_min_rate;
        _pool_bonus_rate = rhs._pool_bonus_rate;
        _normal_yell_id = rhs._normal_yell_id;
        _normal_yell_rate = rhs._normal_yell_rate;
        _avg_reset_tax = rhs._avg_reset_tax;
        _lst_door_normal = rhs._lst_door_normal;
        _lst_door_reset = rhs._lst_door_reset;
        _jar_reset_rate = rhs._jar_reset_rate;
        _lst_jar_normal = rhs._lst_jar_normal;
        _lst_jar_reset = rhs._lst_jar_reset;
        _is_bonus_boss = rhs._is_bonus_boss;
        _boss_point_param = rhs._boss_point_param;
        return *this;
    }
    void reset() {
        _fish_index = 0;
        _maxB = 0;
        _curB = 0;
        _rate1 = 0;
        _rate2 = 0;
        _total_gold = 0;
        _expect_num = 0;
        _fish_score = 0;
        _pool_yell_id = 0;
        _pool_min_rate = 0;
        _pool_bonus_rate = 0;
        _normal_yell_id = 0;
        _normal_yell_rate = 0;
        _avg_reset_tax = 0;
        _lst_door_normal.clear();
        _lst_door_reset.clear();
        _jar_reset_rate = 0;
        _lst_jar_normal.clear();
        _lst_jar_reset.clear();
        _is_bonus_boss = 0;
        _boss_point_param = 0;
    }
    void ForEachDoorNormal(boost::function<void(int32)> func) const {
        for( auto& num : _lst_door_normal) {
            func(num);
        }
    }
    void ForEachDoorReset(boost::function<void(int32)> func) const {
        for( auto& num : _lst_door_reset) {
            func(num);
        }
    }
    void ForEachJarNormal(boost::function<void(const BossJarInfo& info)> func) const {
        for( auto& jar : _lst_jar_normal ) {
            func(jar);
        }
    }
    void ForEachJarReset(boost::function<void(const BossJarInfo& info)> func) const {
        for( auto& jar : _lst_jar_reset ) {
            func(jar);
        }
    }
    // 获取孟获奖励
    // @param isReset 是否使用了重置卡
    // @param hammerNormal 第一轮是否使用了锤子
    // @param hammerReset 第二轮是否使用了锤子
    // @param goldLine 金孟获的最低倍数
    // @param items 获得的道具奖励
    //
    // @return 实际倍数, 金孟获个数
    std::tuple<int64, int32> GetMenghuoReward(bool isReset, bool hammerNormal, bool hammerReset, int32 goldLine, map<int32, int64>& items) {
        if( isReset ) {
            return DoMenghuoReward(hammerReset, goldLine, _lst_jar_reset, items);
        }
        else {
            return DoMenghuoReward(hammerNormal, goldLine, _lst_jar_normal, items);
        }
    }
private:
    // 获取孟获罐子奖励
    // @param useHammer 是否使用了锤子
    // @param goldLine 金孟获的最低倍数
    // @param items 获得的道具奖励
    //
    // @return 实际倍数, 金孟获个数
    std::tuple<int64, int32> DoMenghuoReward(bool useHammer, int32 mhGoldLine, const vector<BossJarInfo>& jars, map<int32, int64>& items) {
        int64 rate = 0;
        int32 mhGold = 0;
        int32 mhNum = 0;
        for( auto & jar : jars ) {
            if( jar.type() == EBJT_empty ) {
                // 空罐子, 判断一下是否用了锤子, 用了就继续
                if( !useHammer ) {
                    break;
                }
            }
            else if( jar.type() == EBJT_numbers ) {
                rate += jar.value();
                if( jar.value() >= mhGoldLine ) {
                    ++mhGold;
                }
                ++mhNum;
                if( mhNum >= 7 ) {
                    break;
                }
            }
            else { // EBJT_items
                GlobalUtils::SimpleMapAdd(items, jar.key(), (int64)jar.value());
            }
        }
        return std::make_tuple(rate, mhGold);
    }
};

enum E_BossSlotParamRandMethod {
    EBSPRM_Digit4       = 1,    // 4个不同的数字
    EBSPRM_Multiply100  = 2,    // 结果数字*100
    EBSPRB_JARS         = 3,    // 敲罐子
};

struct tagBossSlotParam {
    bool _valid;
    int32 _yellId;          // 公告id
    int32 _rateCanReset;    // <该倍数可以随机
    int32 _rateRandMax;     // 当倍率重置后仍旧 <_rateCanReset 则最终倍数按照 _rateCanReset ~ _rateRandMax 为区间做随机
    int32 _rateCanBonus;    // >该倍数可以分享boss奖池
    int64 _rateBonus;       // 奖池分享比例,要除以100 再除以 房间最高炮倍/当前炮倍
    int32 _normalNoticeId;      // 普通击杀公告
    int32 _normalNoticeRate;    // 超过该倍数后, 发普通击杀公告
    int32 _nRandMethod;         // 1表示随机一个四位数,每个位置数字都不同 2表示随机一个值,返回*100后的值
    int32 _avgResetTax;         // 重置卡平均收益, 如果使用重置卡,要用该数值*炮倍加入到净分
    Roll _dice;
    map< int32, std::tuple<int32,int32> > _mapRange;
    tagBossSlotParam() {
        reset();
    }
    void init(const vector<int64>& vecParam) {
        reset();
        size_t paramNum = 9;
        if( vecParam.size() <= paramNum ) {
            return;
        }
        if( ((vecParam.size()-paramNum) % 3) != 0 ) {
            return;
        }
        _rateCanReset = vecParam[0];
        _rateRandMax = vecParam[1];
        _rateCanBonus = vecParam[2];
        _rateBonus = vecParam[3];
        _yellId = vecParam[4];
        _normalNoticeRate = vecParam[5];
        _normalNoticeId = vecParam[6];
        _nRandMethod = vecParam[7];
        _avgResetTax = vecParam[8];
        for( size_t i = paramNum ; i < vecParam.size() ; i+=3 ) {
            _dice.push_value(vecParam[i], i);
            _mapRange[i] = make_tuple((int32)vecParam[i+1], (int32)vecParam[i+2]);
        }
        _valid = true;
    }
    void reset() {
        _valid = false;
        _yellId = 0;
        _rateCanReset = 0;
        _rateRandMax = 0;
        _rateCanBonus = 0;
        _rateBonus = 20;
        _normalNoticeRate = 0;
        _normalNoticeId = 0;
        _nRandMethod = 0;
        _avgResetTax = 0;
        _dice.clear();
        _mapRange.clear();
    }
    tagBossSlotParam& operator=(const tagBossSlotParam& rhs) {
        _valid = rhs._valid;
        _yellId = rhs._yellId;
        _rateCanReset = rhs._rateCanReset;
        _rateRandMax = rhs._rateRandMax;
        _rateCanBonus = rhs._rateCanBonus;
        _valid = rhs._valid;
        _normalNoticeRate = rhs._normalNoticeRate;
        _normalNoticeId = rhs._normalNoticeId;
        _nRandMethod = rhs._nRandMethod;
        _dice = rhs._dice;
        _avgResetTax = rhs._avgResetTax;
        _mapRange = rhs._mapRange;
        return *this;
    }
    // 50%几率加 500&-500 50%几率加 100&-100
    void AddMinusGroup(Roll* dice) {
        if( GlobalUtils::GetRandNumber(0,100) <= 50 ) {
            dice->push_value(10, 500);
            dice->push_value(10, -500);
        }
        else {
            dice->push_value(10, 100);
            dice->push_value(10, -100);
        }
    }
    void AddMinusDoor(Roll* dice, int32 num) {
        int32 ret = GlobalUtils::GetRandNumber(0,100);
        switch(num) {
        case 1:
        case 2:
            if( ret <= 50 ) {
                AddMinusGroup(dice);
                AddMinusGroup(dice);
                AddMinusGroup(dice);
            }
            else if( ret <= 30 ) {
                AddMinusGroup(dice);
                AddMinusGroup(dice);
            }
            else {
                AddMinusGroup(dice);
            }
            break;
        case 3:
        case 4:
            if( ret <= 50 ) {
                AddMinusGroup(dice);
                AddMinusGroup(dice);
            }
            else {
                AddMinusGroup(dice);
            }
            break;
        case 5:
        case 6:
            if( ret <= 80 ) {
                AddMinusGroup(dice);
            }
            break;
        default:
            break;
        }
    }
    int32 AddDoorNumber(int32 rate, int32 doorNum, Roll* dice) {
        while( rate >= doorNum ) {
            dice->push_value(10, doorNum);
            rate -= doorNum;
        }
        return rate;
    }
    // 把一个倍数拆解成7个小的倍数
    void RandJars(int32 rate, int32 minR, int32 maxR, vector<BossJarInfo>& jars) {
        for( int i = 7 ; i > 0 ; --i ) {
            BossJarInfo jar;
            jar.set_type(EBJT_numbers);
            jar.set_key(0);
            if( i == 1 ) {
                jar.set_value(rate);
                jars.push_back(jar);
                break;
            }
            int32 rangeMin = max(minR, rate - (i-1)*maxR);
            int32 rangeMax = min(maxR, rate - (i-1)*minR);
            int32 thisTime = GlobalUtils::GetRandNumber(rangeMin, rangeMax);
            rate -= thisTime;

            jar.set_value(thisTime);
            jars.push_back(jar);
        }
    }
    int32 RandRate(int32 iMin, int32 iMax, bool needBossFix, int32 canBonus, int32 iFixMin, int32 iFixMax, list<int32>& lst, int32 mhMin, int32 mhMax, const map<int32, int64>& items, vector<BossJarInfo>& jars) {
        lst.clear();
        switch( _nRandMethod ) {
        case EBSPRM_Multiply100:
            {
                Roll dice;
                dice.set_extra(true, 0);
                int32 rate = GlobalUtils::GetRandNumber(iMin, iMax)*100;
                if( needBossFix && rate >= canBonus*100 ) {
                    rate = GlobalUtils::GetRandNumber2(iFixMin, iFixMax)*100;
                }
                int32 result = rate;
                rate = AddDoorNumber(rate, 2000, &dice);
                rate = AddDoorNumber(rate, 1000, &dice);
                rate = AddDoorNumber(rate, 500, &dice);
                rate = AddDoorNumber(rate, 200, &dice);
                rate = AddDoorNumber(rate, 100, &dice);
                AddMinusDoor(&dice, dice.size());

                int32 totalNow = 0;
                while(!dice.empty()) {
                    int32 num = dice.roll();
                    if( totalNow + num < 0 ) {
                        // 顺位相加不能为负,所以塞回去
                        dice.push_value(10, num);
                    }
                    else {
                        totalNow += num;
                        lst.push_back(num);
                    }
                }
                if( lst.size() < 8 ) {
                    lst.push_back(0);
                }
                return result;
            }
        case EBSPRB_JARS:
            {
                jars.clear();
                int32 rate = GlobalUtils::GetRandNumber(iMin, iMax);
                if( needBossFix && rate >= canBonus ) {
                    rate = GlobalUtils::GetRandNumber2(iFixMin, iFixMax);
                }
                RandJars(rate, mhMin, mhMax, jars);    // 7个孟获
                // 理论上这里填表的, 应该是3个道具
                for( auto & it : items ) {
                    if( jars.size() >= 10 ) {
                        break;
                    }
                    BossJarInfo info;
                    info.set_type(EBJT_items);
                    info.set_key(it.first);
                    info.set_value(it.second);
                    jars.push_back(info);
                }
                // 补齐到10个
                while( jars.size() < 10) {
                    BossJarInfo info;
                    info.set_type(EBJT_items);
                    info.set_key(JDATA->SystemConstPtr()->GetCardDrawNuclearID());
                    info.set_value(10);
                    jars.push_back(info);
                }
                GlobalUtils::ShuffleVector(jars);

                int32 emptyPos = GlobalUtils::GetRandNumber(4, 10);
                if( emptyPos == 10 ) {
                    BossJarInfo emptyJar;
                    emptyJar.set_type(EBJT_empty);
                    emptyJar.set_key(0);
                    emptyJar.set_value(0);
                    jars.push_back(emptyJar);
                }
                else {
                    jars.push_back(jars[emptyPos]);

                    jars[emptyPos].set_type(EBJT_empty);
                    jars[emptyPos].set_key(0);
                    jars[emptyPos].set_value(0);
                }
                {
                    BossJarInfo emptyJar;
                    emptyJar.set_type(EBJT_empty);
                    emptyJar.set_key(0);
                    emptyJar.set_value(0);
                    jars.push_back(emptyJar);
                }
                
                rate = 0;   // 实际倍率和空罐子位置相关
                for( auto& jar : jars) {
                    if( jar.type() == EBJT_empty ) {
                        break;
                    }
                    else if( jar.type() == EBJT_numbers ) {
                        rate += jar.value();
                    }
                }
                return rate;
            }
        default:    // EBSPRM_Digit4
            {
                int32 rate = GlobalUtils::GetRandDigit(iMin, iMax, false);
                if( needBossFix && rate >= canBonus ) {
                    rate = GlobalUtils::GetRandDigit(iFixMin, iFixMax, true);
                }
                return rate;
            }
        }
    }
    // 随机倍率
    // curB 当前炮倍
    // maxB 房间最大炮倍
    // mapItem 孟获砸罐子小游戏的额外道具
    bool RandSummonBossRate(int32 fishIndex, int64 curB, int64 maxB, bool needBossFix, int32 mhMin, int32 mhMax, const map<int32, int64>& mapItem, tagSummonBossData& lhs) {
        if( !_valid ) {
            return false;
        }
        int32 multiply = 1;
        if( _nRandMethod == EBSPRM_Multiply100 ) {
            multiply = 100;
        }

        lhs._fish_index = fishIndex;
        lhs._curB = curB;
        lhs._maxB = maxB;
        auto range = _mapRange[_dice.roll()];
        auto fixRange = _mapRange[_dice.roll()];
        lhs._jar_reset_rate = _rateCanReset;
        lhs._rate1 = RandRate(TUPLE0(range), TUPLE1(range), needBossFix, _rateCanBonus, TUPLE0(fixRange), TUPLE1(fixRange), lhs._lst_door_normal, mhMin, mhMax, mapItem, lhs._lst_jar_normal);
        // <_rateCanReset 可以进行概率重置
        if( lhs._rate1 <= _rateCanReset*multiply ) {
            // 做一次重新随机
            range = _mapRange[_dice.roll()];
            fixRange = _mapRange[_dice.roll()];
            int32 rate = RandRate(TUPLE0(range), TUPLE1(range), needBossFix, _rateCanBonus, TUPLE0(fixRange), TUPLE1(fixRange), lhs._lst_door_reset, mhMin, mhMax, mapItem, lhs._lst_jar_reset);
            if( rate < _rateCanReset*multiply ) {
                // 当倍率重置后仍旧 <_rateCanReset 则最终倍数按照 _rateCanReset ~ _rateRandMax 为区间做随机
                lhs._rate2 = RandRate(_rateCanReset, _rateRandMax, needBossFix, _rateCanBonus, _rateCanReset, _rateRandMax, lhs._lst_door_reset, mhMin, mhMax, mapItem, lhs._lst_jar_reset);
            }
            else {
                lhs._rate2 = rate;
            }
        }
        lhs._pool_yell_id = _yellId;
        lhs._pool_bonus_rate = _rateBonus;
        lhs._pool_min_rate = _rateCanBonus*multiply;
        lhs._normal_yell_rate = _normalNoticeRate*multiply;
        lhs._normal_yell_id = _normalNoticeId;
        lhs._avg_reset_tax = _avgResetTax;
        return true;
    }
};
