﻿#include "FishUtils.h"
#include "Entity/FishTable.h"
#include "Entity/FishPlayer.h"
#include "Entity/FishFish.h"
#include "Entity/FishRoute.h"
#include "Entity/FishShoal.h"

int64 MyRandom::holdrand = GlobalUtils::GetTickCount();
