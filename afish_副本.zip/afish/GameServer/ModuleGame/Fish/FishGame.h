/**
 * 捕鱼游戏主入口
 * 暂时只开启1条线程,所有捕鱼相关逻辑均为单线程处理
 *
 * 游戏房间管理,仅处理房间进出,存储用户所在位置等数据,不涉及游戏实际逻辑
 */
#pragma once
#include "ServerDefine.h"
#include "io_service_pool.h"
#include "EntityPool.h"
#include "FishTide/TideBase.h"
#include "FishTide/TideCircle.h"
#include "FishTide/TideCircleRandom.h"
#include "FishTide/TideCircleRotate.h"
#include "FishTide/TideCircleScatter.h"
#include "FishTide/TideLine.h"
#include "FishTide/TideDelay.h"
#include "FishTide/TideLineDelay.h"
#include "FishTide/TideOffset.h"
#include "FishTide/TideFix.h"

class FishRoute;
class SimpleLineRoute;
class RotationRoute;
class SpecialRoute;
class OffsetRoute;
class AdvanceRoute;
class FishShoal;
class FishTable;
class LxUser;
class FishGame
{
public:
	FishGame();
	virtual ~FishGame();
public:
	void ProcessPacket(LxUser* pUser, WrapPacket& packet);
    void ProcessFishEnterRoomReq(LxUser* pUser, WrapPacket& packet);
    void NotifyAllRoom(WrapPacket& packet);
public:
	void Update(int32 dt);
    void OnTimer5m(int32 idx);
    void UserClearFishTable(LxUser* pUser, int32 tableId);
/////////////////////////////////////////////////////////////////////////////////////////////////////
// 路线部分
public:
    SimpleLineRoute* CreateSimpleLine(int32 fishCfgID, Vec2 position, Vec2 speed);
    RotationRoute* CreateRotationRoute(int32 fishCfgID, Vec2 center, Vec2 startPos, float angleSpeed, float duration, float moveSpeed);
    SpecialRoute* CreateSpecialRoute(int32 fishCfgID, Vec2 startPos, Vec2 speedVector, float delayTime, float moveTime, float waitTime);
    OffsetRoute* CreateOffsetRoute(int32 routeID, Vec2 initOffset, int32 randOffset, int32 randSeed);
    AdvanceRoute* CreateAdvanceRoute(int32 routeID);
    void RemoveRoute(FishRoute* route);
private:
    EntityDriver<int32, SimpleLineRoute> m_SimpleLineRoutes;
    EntityDriver<int32, RotationRoute> m_RotationRoutes;
    EntityDriver<int32, SpecialRoute> m_SpecialRoutes;
    EntityDriver<int32, OffsetRoute> m_OffsetRoutes;
    EntityDriver<int32, AdvanceRoute> m_AdvanceRoutes;
/////////////////////////////////////////////////////////////////////////////////////////////////////
// 鱼阵部分
public:
    TideBase* BuildTide(FishShoal* pShoal, int32 tideIndex, int32 routeId);
    // 根据鱼阵id刷新一个鱼阵
    TideBase* CreateTide(FishShoal* pShoal, int32 tideIndex, int32 routeId, bool isFlash = false);
    // 在指定点刷新一个鱼阵,一般在鱼死亡时调用
    TideBase* CreateTide(FishShoal* pShoal, int32 tideIndex, const Vec2& pos);
    void RemoveTide(TideBase* pTide);
private:
    EntityDriver<int32, TideDelay> m_TideDelay;
    EntityDriver<int32, TideCircleScatter> m_TideCircleScatter;
    EntityDriver<int32, TideCircle> m_TideCircle;
    EntityDriver<int32, TideCircleRotate> m_TideCircleRotate;
    EntityDriver<int32, TideLine> m_TideLine;
    EntityDriver<int32, TideLineDelay> m_TideLineDelay;
    EntityDriver<int32, TideCircleRandom> m_TideCircleRandom;
    EntityDriver<int32, TideFix> m_TideFix;
    EntityDriver<int32, TideOffset> m_TideOffset;
/////////////////////////////////////////////////////////////////////////////////////////////////////
//id 相关
public:
	int32 FetchTableId(int32 num) { return _tableId.incryby(num); }
	int32 FetchFishId(int32 num) { return _fishId.incryby(num); }
	int32 FetchRouteId(int32 num) { return _routeId.incryby(num); }
	int32 FetchTideId(int32 num) { return _tideId.incryby(num); }
protected:
	tagMemoryId _tableId;
	tagMemoryId _fishId;
	tagMemoryId _routeId;
	tagMemoryId _tideId;
/////////////////////////////////////////////////////////////////////////////////////////////////////
// 房间相关
public:
    void OnTableRecycled(int32 tableIndex, int32 tableId) {
        auto it = m_mapRoomTables.find(tableIndex);
        if( it != m_mapRoomTables.end() ) {
            it->second.erase(tableId);
        }
    }
  	// 获得0-10000之间的随机数, stdev为方差 结果符合正态分布
    int32 GetRandNumber(int32 stdev) {
        std::normal_distribution<double> distribution( 5000, stdev );
        while (true) {
            int32 number = distribution(_generator);
            if (number >= 0 && number <= 10000)
                return number;
        }
        return GlobalUtils::GetRandNumber(stdev);
    }
    int32 GetExpectHitNum(int32 mu, int32 sigma, int32 rate) {
        if( rate <= 0 ) {
            return 10000;
        }
        if( rate >= 1000000 ) {
            return 10;
        }
        int32 expect = (int32)(1000000.0f/rate);
        int32 expectNum = (int32)((1000000.0f/rate)*(mu/1000.0f));
        double stdev = (1000000.0f/rate) * (sigma/1000.0f);
        std::normal_distribution<double> distribution( expectNum, stdev );
        while (true) {
            int32 number = distribution(_generator);
            if (number >= 1 && number <= expect * 2)
                return number;
        }
        return expectNum;
    }
    int32 GetExpectHitNum(double mu, double sigma) {
        std::normal_distribution<double> distribution( mu, sigma );
        while (true) {
            int32 number = distribution(_generator);
            if (number >= 1 && number <= mu * 2)
                return number;
        }
        return mu;
    }
protected:
	// 获取一个空房间
	FishTable* GetEmptyTable(int32 nIndex);
	// 获取一个有人的房间,如果所有房间都满员,则取一个空房间 查表获得是否判定金币来默认开新桌
	FishTable* GetActiveTable(int32 nIndex, int64 gold, bool isNewbie);
	FishTable* GetTable(int32 tableid) { return m_Tables.GetEntity(tableid); }
	// 记录一下对应类型房间id
	void RecordTableIndex(int32 index, int32 tableid);
	void RemoveTableIndex(int32 index, int32 tableid);
private:
    EntityDriver<uint64, FishTable> m_Tables;
	// 记录指定配置房间的id列表,用于匹配未满人的房间
	map< int32, set<int32> > m_mapRoomTables;
    std::default_random_engine _generator;
};
