﻿#pragma once

#include "ServerDefine.h"
#include "FishUtils.h"

class FishRoute;
class FishTable;
class FishShoal;
class TideBase
{
GETSET_PTR(FishTable, Table);
GETSET_PTR(FishShoal, Shoal);

GETSET(int32, Key);
GETSET(int32, GeneratorId);
GETSET(int32, FishCount);
GETSET(int32, RouteId);
// 使用的routeid,释放时归还
GETSET(int32, UsedTableRouteId);
GETSET(int32, Type);
public:
    int32 GetFishStartId() { return m_FishStartId; }
    void CalFishStartId();
    virtual void SetFishStartId(int32 value) { m_FishStartId = value; }
    const Vec2& GetPosition() const { return m_Position; }
    virtual void SetPosition(const Vec2& position) { m_Position = position; }
    float GetElapsedTime() { return m_ElapsedTime; };
protected:
    Vec2 m_Position;
    int32 m_FishStartId;
    float m_ElapsedTime;
public:
    TideBase() {
        m_UsedTableRouteId = 0;
        m_ElapsedTime = 0;
    }
    ~TideBase() {}
    void Update(int dt);
    virtual void UpdateTime(float dt)
    {
        m_ElapsedTime += dt;
        UpdateRun(dt);
    }
    // 子类需重写此方法
    virtual bool Init(int32 tideId, FishTable* pTable, FishShoal* pShoal, const vector<int64>& param) = 0;
    virtual void UpdateRun(float dt) = 0;
    virtual void SetElapsedTime(float dTime)
    {
        m_ElapsedTime = dTime;
        m_FishCount = 0;
    }
    virtual bool IsValid()
    {
        return m_FishCount > 0;
    }
    void CreateFish(int fishCfgId, FishRoute* baseRoute);
    void OnRecycled() {};
};

