﻿#pragma once

#include "TideBase.h"

struct DelayData
{
    int32 _fishCfgId;
    float _interval;
    int32 _fishCount;
};

struct tagDelayFish : public DelayData {
    float _delay;
};

class TideDelay : public TideBase
{
protected:
    Vec2 startPos;
    Vec2 speed;
    list<tagDelayFish> _delayFishs;
public:
    TideDelay() {}
    virtual ~TideDelay() {}
    virtual bool Init(int32 tideId, FishTable* pTable, FishShoal* pShoal, const vector<int64>& param);
    virtual void UpdateRun(float dt);
    virtual void SetElapsedTime(float eTime);
};
