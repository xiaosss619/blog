﻿#pragma once

#include "TideBase.h"

class TideLine : public TideBase
{
protected:
    float m_initDelay;    //第一次出发延时
    int m_totalCount;   //一共可触发次数
    float m_interval;   //两次触发时间间隔
    int m_triggerCount = 0;   //当前已触发次数

    Vec2 m_startPos;
    Vec2 m_endPos;

    int m_fishCfgId;
    //每条鱼数量
    int m_lineFishCount;
    Vec2 m_speed;
public:
    TideLine() {}
    virtual ~TideLine() {}

    virtual bool Init(int32 tideId, FishTable* pTable, FishShoal* pShoal, const vector<int64>& param);
    virtual void UpdateRun(float dt);
    virtual void SetElapsedTime(float eTime);
};
