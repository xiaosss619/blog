﻿#include "TideCircleScatter.h"
#include "Entity/FishTable.h"
#include "Entity/FishFish.h"
#include "Entity/FishShoal.h"
#include "Entity/FishRoute.h"
#include "FishGame.h"

bool TideCircleScatter::Init(int32 tideId, FishTable* pTable, FishShoal* pShoal, const vector<int64>& param)
{
    if( param.size() != 8 ) {
        LOGERROR("invalid tide param");
        return false;
    }
    m_pTable = pTable;
    m_pShoal = pShoal;
    m_Key = tideId;
    m_Type = e_jsonFishGeneratorType_CircleSpread;
    m_ElapsedTime = 0;

    m_Position.x = boost::lexical_cast<float>(param[0]);
    m_Position.y = boost::lexical_cast<float>(param[1]);

    m_radius = max((int32)param[2],10);

    m_fishCfgId = param[3];
    m_circleFishCount = max((int32)param[4],1);
    m_redFishIndex = param[5];
    m_redFishId = param[6];
    m_moveSpeed = param[7];
    m_FishCount = m_circleFishCount;
    CalFishStartId();
    return true;
}

void TideCircleScatter::UpdateRun(float dt)
{
    float startRotation = 0.0f;
    float addRotation = PI * 2 / m_circleFishCount;
    if (m_redFishIndex == -10)
    {
        float curRotation = startRotation;
        float angle = FishMath::FishLineDirToRad(Vec2(640, 360) - m_Position);
        if (angle < 0)
        {
            angle += PI * 2;
        }

        for (int32 i = 0; i < m_circleFishCount; i++)
        {
            if (angle >= curRotation && angle < curRotation + addRotation)
            {
                m_redFishIndex = i;
                break;
            }
            curRotation += addRotation;
        }
    }

    for (int32 i = 0; i < m_circleFishCount; i++)
    {
        Vec2 direction = FishMath::AngleDirection(startRotation + addRotation * i);
        Vec2 pos = m_Position + direction * m_radius;

        int32 cfgId = m_fishCfgId;
        if (m_redFishId != -1 && m_redFishIndex == i)
        {
            cfgId = m_redFishId;
        }
        auto route = m_pTable->GetGame()->CreateSimpleLine(cfgId, pos, direction * m_moveSpeed);
        CreateFish(cfgId, route);
    }
}
