#include "TideBase.h"
#include "Entity/FishTable.h"
#include "Entity/FishFish.h"
#include "Entity/FishShoal.h"
#include "Entity/FishRoute.h"
#include "FishGame.h"

void TideBase::CalFishStartId() {
    m_FishStartId = m_pTable->GetGame()->FetchFishId(m_FishCount);
}

void TideBase::Update(int deltaMS) {
    if( !IsValid() ) {
        return;
    }
    if (m_pTable->InFreeze())
    {
        return;
    }
    float dt = deltaMS * 0.001f;
    UpdateTime(dt);
}

void TideBase::CreateFish(int fishCfgId, FishRoute* baseRoute)
{
    m_pTable->TideCreateFish(m_pShoal, m_FishStartId++, fishCfgId, baseRoute);
    m_FishCount--;
}
