﻿#pragma once

#include "ServerDefine.h"
#include "TideBase.h"

class TideOffset : public TideBase
{
    int m_fishCfgID;
    int m_randOffset;

    list<Vec2> m_offsets;
public:
    TideOffset() {}
    virtual ~TideOffset() {}

    virtual bool Init(int32 tideId, FishTable* pTable, FishShoal* pShoal, const vector<int64>& param);
    virtual void UpdateRun(float dt);
};
