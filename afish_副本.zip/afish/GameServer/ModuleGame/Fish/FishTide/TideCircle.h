﻿#pragma once

#include "ServerDefine.h"
#include "TideBase.h"

class FishTable;
class TideCircle : public TideBase
{
    //每圈鱼数量
GETSET(int32, FishCfgId);
GETSET(int32, Radius);
GETSET(int32, RedFishIndex);
GETSET(int32, RedFishId);
GETSET(int32, CircleFishCount);
GETSET(Vec2, Speed);
public:
    TideCircle() {}
    virtual ~TideCircle() {}
    virtual bool Init(int32 tideId, FishTable* pTable, FishShoal* pShoal, const vector<int64>& params);
    virtual void UpdateRun(float dt);
};
