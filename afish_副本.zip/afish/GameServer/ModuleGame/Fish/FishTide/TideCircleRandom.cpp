﻿#include "TideCircleRandom.h"
#include "Entity/FishTable.h"
#include "Entity/FishFish.h"
#include "Entity/FishShoal.h"
#include "Entity/FishRoute.h"
#include "FishGame.h"

bool TideCircleRandom::Init(int32 tideId, FishTable* pTable, FishShoal* pShoal, const vector<int64>& param)
{
    if( param.size() != 9 ) {
        LOGERROR("invalid tide param");
        return false;
    }
    m_pTable = pTable;
    m_pShoal = pShoal;
    m_Key = tideId;
    m_Type = e_jsonFishGeneratorType_CircleRandom;
    m_ElapsedTime = 0;

    m_initDelay = 0;
    m_Position.x = (float)(param[0]);
    m_Position.y = (float)(param[1]);
    m_dirCount = param[2];
    m_randDir = param[3];
    m_interval = (float)(param[4]) / 1000.0f;
    m_outCount = param[5];
    m_totalCount = param[6];
    m_moveSpeed = param[7];
    m_fishCfgId = param[8];
    m_FishCount = m_dirCount * m_outCount * m_totalCount;

    CalFishStartId();
    return true;
}

void TideCircleRandom::SetElapsedTime(float eTime)
{
    m_ElapsedTime = eTime;

    int shouldTriggerCount = 0;
    if (m_ElapsedTime > m_initDelay)
    {
        shouldTriggerCount = 1 + (int)((m_ElapsedTime - m_initDelay) / m_interval);
    }

    if (shouldTriggerCount > m_triggerCount)
    {
        int passTrigger = shouldTriggerCount - m_triggerCount;
        m_FishCount -= m_dirCount * m_outCount * passTrigger;
        m_FishStartId += m_dirCount * m_outCount * passTrigger;
    }
}

void TideCircleRandom::UpdateRun(float dt)
{
    random.SetSeed(m_FishStartId); // 用鱼阵开始的ID做为随机数种子，这样可以与客户端同步，且有一定的随机性

    //下次触发时间点
    float triggerElapse = m_initDelay + m_triggerCount * m_interval;

    if (triggerElapse < m_ElapsedTime)
    {
        m_triggerCount++;

        //触发动作
        float startRotation = 0.0f;
        float addRotation = 2 * PI / m_dirCount;

        if( m_randDir == 0 ) {
            m_randDir = 15;// 给个0保护
        }

        float randRotation = m_randDir / 180.0f * PI;
        for (int i = 0; i < m_dirCount; i++)
        {
            for (int j = 0; j < m_outCount; j++)
            {
                Vec2 direction = FishMath::AngleDirection(startRotation + addRotation * i + fmod(random.Random(), (randRotation * 2)) - randRotation);
                auto route = m_pTable->GetGame()->CreateSimpleLine(m_fishCfgId, m_Position, direction * m_moveSpeed);
                CreateFish(m_fishCfgId, route);
            }
        }
    }
}
