﻿#include "TideCircle.h"
#include "Entity/FishTable.h"
#include "Entity/FishFish.h"
#include "Entity/FishShoal.h"
#include "Entity/FishRoute.h"
#include "FishGame.h"

bool TideCircle::Init(int32 tideId, FishTable* pTable, FishShoal* pShoal, const vector<int64>& param)
{
    if( param.size() != 10 ) {
        LOGERROR("invalid tide param");
        return false;
    }
    m_Type = e_jsonFishGeneratorType_Circle;
    m_pTable = pTable;
    m_pShoal = pShoal;
    m_Key = tideId;
    m_ElapsedTime = 0;

    m_Position.x = (float)param[0];
    m_Position.y = (float)param[1];
    m_Radius = param[2];
    m_FishCfgId = param[3];
    m_CircleFishCount = param[4];
    m_RedFishIndex = param[5];
    m_RedFishId = param[6];
    m_RouteId = param[7];
    m_Speed.x = (float)param[8];
    m_Speed.y = (float)param[9];
    m_FishCount = m_CircleFishCount;
    CalFishStartId();
    return true;
}

void TideCircle::UpdateRun(float dt)
{
    float startRotation = 0.0f;
    float addRotation = PI * 2 / m_CircleFishCount;

    for (int32 i = 0; i < m_CircleFishCount; i++)
    {
        auto direction = FishMath::AngleDirection(startRotation + addRotation * i);
        Vec2 pos = m_Position + direction * m_Radius;
        int32 cfgId = m_FishCfgId;
        if (m_RedFishId != -1 && m_RedFishIndex == i)
        {
            cfgId = m_RedFishId;
        }
        if (m_RouteId == 0)
        {
            auto route = m_pTable->GetGame()->CreateSimpleLine(cfgId, pos, m_Speed);
            CreateFish(cfgId, route);
        }
        else
        {
            auto route = m_pTable->GetGame()->CreateAdvanceRoute(m_RouteId);
            CreateFish(cfgId, route);
        }
    }
}

