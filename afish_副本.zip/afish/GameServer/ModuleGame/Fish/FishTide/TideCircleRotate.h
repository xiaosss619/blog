﻿#pragma once

#include "ServerDefine.h"
#include "TideBase.h"

class TideCircleRotate : public TideBase
{
    int32 radius;
    int32 fishCfgId;
    //每圈鱼数量
    int32 circleFishCount;

    int32 redFishIndex;
    int32 redFishId;

    float rotation;
    float rotateTime;
    float moveSpeed;
public:
    TideCircleRotate() {}
    virtual ~TideCircleRotate() {}

    virtual bool Init(int32 tideId, FishTable* pTable, FishShoal* pShoal, const vector<int64>& param);
    virtual void UpdateRun(float dt);
};
