﻿#include "TideLineDelay.h"
#include "Entity/FishTable.h"
#include "Entity/FishFish.h"
#include "Entity/FishShoal.h"
#include "Entity/FishRoute.h"
#include "FishGame.h"

bool TideLineDelay::Init(int32 tideId, FishTable* pTable, FishShoal* pShoal, const vector<int64>& param)
{
    if( param.size() != 12 ) {
        LOGERROR("invalid tide param");
        return false;
    }
    m_pTable = pTable;
    m_pShoal = pShoal;
    m_Key = tideId;
    m_Type = e_jsonFishGeneratorType_LineInterval;
    m_ElapsedTime = 0;

    startPos.x = boost::lexical_cast<float>(param[0]);
    startPos.y = boost::lexical_cast<float>(param[1]);
    endPos.x = boost::lexical_cast<float>(param[2]);
    endPos.y = boost::lexical_cast<float>(param[3]);
    blockCount = param[4];
    fishCfgId = param[5];
    lineFishCount = param[6];
    speed.x = boost::lexical_cast<float>(param[7]);
    speed.y = boost::lexical_cast<float>(param[8]);
    delayTime = boost::lexical_cast<float>(param[9])/1000.0f;
    moveTime = boost::lexical_cast<float>(param[10])/1000.0f;
    waitTime = boost::lexical_cast<float>(param[11])/1000.0f;
    m_FishCount = blockCount*lineFishCount;
    CalFishStartId();
    return true;
}

void TideLineDelay::UpdateRun(float dt)
{
    Vec2 blockOffset = (endPos - startPos) / blockCount;
    Vec2 offset = blockOffset / lineFishCount;

    for (int i = 0; i < lineFishCount; i++)
    {
        for (int j = 0; j < blockCount; j++)
        {
            Vec2 pos = startPos + blockOffset * j + offset * i;
            float dTime = 0.1f + delayTime * i;
            auto route = m_pTable->GetGame()->CreateSpecialRoute(fishCfgId, pos, speed, dTime, moveTime, waitTime);
            CreateFish(fishCfgId, route);
        }
    }
}
