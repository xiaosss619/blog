﻿#pragma once

#include "ServerDefine.h"
#include "TideBase.h"

class TideCircleScatter : public TideBase
{
protected:
    int32 m_radius;
    int32 m_fishCfgId;
    //每圈鱼数量
    int32 m_circleFishCount;

    int32 m_redFishIndex;
    int32 m_redFishId;
    //移动速度
    float m_moveSpeed;
public:
    TideCircleScatter() {}
    virtual ~TideCircleScatter() {}
    virtual bool Init(int32 tideId, FishTable* pTable, FishShoal* pShoal, const vector<int64>& param);
    virtual void UpdateRun(float dt);
};
