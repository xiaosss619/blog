#include "TideDelay.h"
#include "Entity/FishTable.h"
#include "Entity/FishFish.h"
#include "Entity/FishShoal.h"
#include "Entity/FishRoute.h"
#include "FishGame.h"

bool TideDelay::Init(int32 tideId, FishTable* pTable, FishShoal* pShoal, const vector<int64>& param) {
    if( param.size() < 5 ) {
        LOGERROR("invalid tide param");
        return false;
    }
    m_pTable = pTable;
    m_pShoal = pShoal;
    m_Key = tideId;
    m_Type = e_jsonFishGeneratorType_Delayed;
    m_ElapsedTime = 0;

    m_RouteId = (param[0]);
    startPos.x = boost::lexical_cast<float>(param[1]);
    startPos.y = boost::lexical_cast<float>(param[2]);
    speed.x = boost::lexical_cast<float>(param[3]);
    speed.y = boost::lexical_cast<float>(param[4]);

    _delayFishs.clear();
    int32 totalCount = 0;
    list<DelayData> lst;
    for (size_t i = 5; i + 2 < param.size();)
    {
        DelayData delay;
        delay._fishCfgId = (param[i]);
        delay._interval = boost::lexical_cast<float>(param[i+1]) / 1000.0f;
        delay._fishCount = (param[i+2]);
        lst.push_back(delay);
        totalCount += delay._fishCount;
        i += 3;
    }
    m_FishCount = totalCount;

    float delay = -1.0f;
    for (auto & delayData : lst)
    {
        for (int i = 0; i < delayData._fishCount; i++)
        {
            if (delay < 0)
                delay = 0;
            else
                delay += delayData._interval;
            tagDelayFish fishDelay;
            fishDelay._fishCfgId = delayData._fishCfgId;
            fishDelay._interval = delayData._interval;
            fishDelay._fishCount = delayData._fishCount;
            fishDelay._delay = delay;
            _delayFishs.push_back(fishDelay);
        }
    }

    CalFishStartId();
    return true;
}

void TideDelay::UpdateRun(float dt) {
    list<tagDelayFish> lstTrigger;
    for( auto it = _delayFishs.begin(); it != _delayFishs.end(); ) {
        if( (*it)._delay <= m_ElapsedTime ) {
            lstTrigger.push_back(*it);
            _delayFishs.erase(it++);
        }
        else {
            ++it;
        }
    }

    for( auto& delay : lstTrigger ) {
        if (m_RouteId != 0)
        {
            auto route = m_pTable->GetGame()->CreateAdvanceRoute(m_RouteId);
            if( route == nullptr ) {
                LOGERROR("null route found [%d]", m_RouteId);
            }
            else {
                CreateFish(delay._fishCfgId, route);
            }
        }
        else
        {
            //auto route = RouteMgr::getSingleton()->createRoute(it->mFishCfgID, mStartPos, mSpeed);
            auto route = m_pTable->GetGame()->CreateSimpleLine(delay._fishCfgId, startPos, speed);
            if( route == nullptr ) {
                LOGERROR("null route found [%d]", m_RouteId);
            }
            else {
                CreateFish(delay._fishCfgId, route);
            }
        }
    }
}

void TideDelay::SetElapsedTime(float eTime)
{
    m_ElapsedTime = eTime;
    int triggerCount = 0;
    for( auto it = _delayFishs.begin(); it != _delayFishs.end(); ) {
        if( (*it)._delay <= m_ElapsedTime ) {
            triggerCount++;
            _delayFishs.erase(it++);
        }
        else {
            ++it;
        }
    }
    m_FishStartId += triggerCount;
    m_FishCount -= triggerCount;
}

