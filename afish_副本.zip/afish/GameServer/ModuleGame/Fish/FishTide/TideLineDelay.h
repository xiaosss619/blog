﻿#pragma once

#include "TideBase.h"

class TideLineDelay : public TideBase
{
    Vec2 startPos;
    Vec2 endPos;
    int blockCount;
    int fishCfgId;
    int lineFishCount;
    Vec2 speed;
    float delayTime;
    float moveTime;
    float waitTime;
public:
    TideLineDelay() {}
    virtual ~TideLineDelay() {}

    virtual bool Init(int32 tideId, FishTable* pTable, FishShoal* pShoal, const vector<int64>& param);
    virtual void UpdateRun(float dt);
};
