﻿#include "TideFix.h"
#include "Entity/FishTable.h"
#include "Entity/FishFish.h"
#include "Entity/FishShoal.h"
#include "Entity/FishRoute.h"
#include "FishGame.h"

bool TideFix::Init(int32 tideId, FishTable* pTable, FishShoal* pShoal, const vector<int64>& param)
{
    if( param.size() < 2 ) {
        LOGERROR("invalid tide param");
        return false;
    }
    m_pTable = pTable;
    m_pShoal = pShoal;
    m_Key = tideId;
    m_Type = e_jsonFishGeneratorType_Statics;
    m_ElapsedTime = 0;

    m_speed.x = boost::lexical_cast<float>(param[0]);
    m_speed.y = boost::lexical_cast<float>(param[1]);

    m_fixFishDatas.clear();
    for (size_t i = 2; i + 2 < param.size();)
    {
        FixFishData fixData;
        fixData.position.x = boost::lexical_cast<float>(param[i]);
        fixData.position.y = boost::lexical_cast<float>(param[i + 1]);
        fixData.fishCfgId = param[i + 2];

        m_fixFishDatas.push_back(fixData);
        i += 3;
    }
    m_FishCount = m_fixFishDatas.size();

    CalFishStartId();
    return true;
}

void TideFix::UpdateRun(float dt)
{
    for(auto& fish : m_fixFishDatas)
    {
        auto route = m_pTable->GetGame()->CreateSimpleLine(fish.fishCfgId, fish.position, m_speed);
        CreateFish(fish.fishCfgId, route);
    }
}
