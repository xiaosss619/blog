﻿#pragma once

#include "ServerDefine.h"
#include "TideBase.h"
#include "FishUtils.h"

class TideCircleRandom : public TideBase
{
protected:
    float m_initDelay;    //第一次出发延时
    int32 m_totalCount;   //一共可触发次数
    float m_interval;   //两次触发时间间隔
    int32 m_triggerCount = 0;   //当前已触发次数

    int32 m_dirCount;
    int32 m_randDir;
    int32 m_outCount;
    int32 m_moveSpeed;
    int32 m_fishCfgId;

    ClientRandom random;
public:
    TideCircleRandom() {}
    virtual ~TideCircleRandom() {}
    virtual bool Init(int32 tideId, FishTable* pTable, FishShoal* pShoal, const vector<int64>& param);

    virtual void SetElapsedTime(float eTime);
    virtual void UpdateRun(float dt);
};
