﻿#pragma once

#include "ServerDefine.h"
#include "TideBase.h"

struct FixFishData
{
    Vec2 position;
    int32 fishCfgId;
};

class TideFix : public TideBase
{
protected:
    Vec2 m_speed;
    list<FixFishData> m_fixFishDatas;
public:
    TideFix() {};
    virtual ~TideFix() {};

    virtual bool Init(int32 tideId, FishTable* pTable, FishShoal* pShoal, const vector<int64>& param);
    virtual void UpdateRun(float dt);
};
