﻿#include "TideOffset.h"
#include "Entity/FishTable.h"
#include "Entity/FishFish.h"
#include "Entity/FishShoal.h"
#include "Entity/FishRoute.h"
#include "FishGame.h"

bool TideOffset::Init(int32 tideId, FishTable* pTable, FishShoal* pShoal, const vector<int64>& param)
{
    if( param.size() < 2 ) {
        LOGERROR("invalid tide param");
        return false;
    }
    m_pTable = pTable;
    m_pShoal = pShoal;
    m_Key = tideId;
    m_Type = e_jsonFishGeneratorType_Trajectory;
    m_ElapsedTime = 0;

    m_fishCfgID = param[0];
    m_randOffset = param[1];

    m_offsets.clear();
    for (size_t i = 2; i + 1 < param.size();)
    {
        m_offsets.push_back(Vec2(boost::lexical_cast<float>(param[i]), boost::lexical_cast<float>(param[i + 1])));
        i += 2;
    }
    m_FishCount = m_offsets.size();
    CalFishStartId();
    return true;
}

void TideOffset::UpdateRun(float dt)
{
    for( auto & pos : m_offsets ) {
        auto route = m_pTable->GetGame()->CreateOffsetRoute(m_RouteId, pos, m_randOffset, m_FishStartId);
        if( route != nullptr ) {
            CreateFish(m_fishCfgID, route);
            route->ResetRandOffset();
        }
        else {
            LOGERROR("failed to create offset route");
        }
    }
}
