#include "TideLine.h"
#include "Entity/FishTable.h"
#include "Entity/FishFish.h"
#include "Entity/FishShoal.h"
#include "Entity/FishRoute.h"
#include "FishGame.h"

bool TideLine::Init(int32 tideId, FishTable* pTable, FishShoal* pShoal, const vector<int64>& param) {
    if( param.size() != 10 ) {
        LOGERROR("invalid tide param");
        return false;
    }
    m_pTable = pTable;
    m_pShoal = pShoal;
    m_Key = tideId;
    m_Type = e_jsonFishGeneratorType_Line;
    m_ElapsedTime = 0;

    m_initDelay = 0;
    m_startPos.x = boost::lexical_cast<float>(param[0]);
    m_startPos.y = boost::lexical_cast<float>(param[1]);
    m_endPos.x = boost::lexical_cast<float>(param[2]);
    m_endPos.y = boost::lexical_cast<float>(param[3]);
    m_fishCfgId = param[4];
    m_lineFishCount = param[5];
    m_totalCount = param[6];
    m_interval = boost::lexical_cast<float>(param[7]);
    m_speed.x = boost::lexical_cast<float>(param[8]);
    m_speed.y = boost::lexical_cast<float>(param[9]);
    m_FishCount = m_lineFishCount*m_totalCount;
    CalFishStartId();
    return true;
}

void TideLine::UpdateRun(float dt) {
    //下次触发时间点
    float triggerElapse = m_initDelay + m_triggerCount * m_interval;
    if (triggerElapse < m_ElapsedTime)
    {
        m_triggerCount++;

        Vec2 offset = (m_endPos - m_startPos) / m_lineFishCount;
        for (int i = 0; i < m_lineFishCount; i++)
        {
            Vec2 pos = m_startPos + offset * i;
            auto route = m_pTable->GetGame()->CreateSimpleLine(m_fishCfgId, pos, m_speed);
            CreateFish(m_fishCfgId, route);
        }
    }
}

void TideLine::SetElapsedTime(float eTime)
{
    m_ElapsedTime = eTime;

    int shouldTriggerCount = 0;
    if (m_ElapsedTime > m_initDelay)
    {
        shouldTriggerCount = 1 + (int)((m_ElapsedTime - m_initDelay) / m_interval);
    }

    if (shouldTriggerCount > m_triggerCount)
    {
        int passTrigger = shouldTriggerCount - m_triggerCount;
        m_FishCount -= m_lineFishCount * passTrigger;
        m_FishStartId += m_lineFishCount * passTrigger;
    }
}
