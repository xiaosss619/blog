﻿#include "TideCircleRotate.h"
#include "Entity/FishTable.h"
#include "Entity/FishFish.h"
#include "Entity/FishShoal.h"
#include "Entity/FishRoute.h"
#include "FishGame.h"

bool TideCircleRotate::Init(int32 tideId, FishTable* pTable, FishShoal* pShoal, const vector<int64>& param)
{
    if( param.size() != 10 ) {
        LOGERROR("invalid tide param");
        return false;
    }
    m_pTable = pTable;
    m_pShoal = pShoal;
    m_Key = tideId;
    m_Type = e_jsonFishGeneratorType_CircleRotation;
    m_ElapsedTime = 0;

    m_Position.x = (float)(param[0]);
    m_Position.y = (float)(param[1]);

    radius = param[2];
    fishCfgId = param[3];
    circleFishCount = param[4];
    redFishIndex = param[5];
    redFishId = param[6];
    rotation = param[7];
    rotateTime = param[8];
    moveSpeed = param[9];
    m_FishCount = circleFishCount;
    CalFishStartId();
    return true;
}

void TideCircleRotate::UpdateRun(float dt)
{
    float startRotation = 0.0f;
    float addRotation = PI * 2 / circleFishCount;
    for (int32 i = 0; i < circleFishCount; i++)
    {
        Vec2 direction = FishMath::AngleDirection(startRotation + addRotation * i);
        Vec2 pos = m_Position + direction * radius;

        int32 cfgId = fishCfgId;
        if (redFishId != -1 && redFishIndex == i)
        {
            cfgId = redFishId;
        }
        auto route = m_pTable->GetGame()->CreateRotationRoute(cfgId, m_Position, pos, rotation, rotateTime, moveSpeed);
        CreateFish(cfgId, route);
    }
}
