﻿#include "FishRoute.h"
#include "Entity/FishFish.h"

float FishRoute::GetCurLifeTime() {
    if( m_pFish == nullptr ) {
        return 0.0f;
    }
    return (m_pFish->GetCurLifeTick()*1.0f)/1000.0f;
}

Vec2 FishRoute::GetPosition()
{
    float curLifeTime = GetCurLifeTime();
    float dt = 0;
    if (m_LastPosTime == -1)
    {
        dt = curLifeTime;
        m_LastPosTime = curLifeTime;
    }
    else
    {
        if(curLifeTime - m_LastPosTime > m_UpdatePositionTime)
        {
            dt = curLifeTime - m_LastPosTime;
            m_LastPosTime = curLifeTime;
        }
    }

    if (dt > 0)
        UpdatePosition(dt);

    return m_Position;
}
