#include "FishBullet.h"
#include "FishPlayer.h"

string FishBullet::MakePlayerBulletKey(FishPlayer* player, int32 bulletId) {
    ostringstream os;
    os << player->GetKey() << "_" << bulletId;
    return os.str();
}

bool FishBullet::Init(FishPlayer* player, int32 bulletId) {
    m_pPlayer = player;
    m_Key = MakePlayerBulletKey(player, bulletId);
    m_nCurLifeTick = 0;
    m_nHitNum = 0;
    m_MaxHitNum = 1;
    return true;
}
