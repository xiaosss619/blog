﻿#pragma once

#include "ServerDefine.h"
#include "GameUtils.h"
#include "FishUtils.h"
#include "ModuleHelper.h"

enum FishRouteType
{
    RouteType_Base = 1,     //一条直线
    RouteType_Advanced,     //完全按照配置表路线
    RouteType_Rotate,       //动态构造一条圆弧或者螺旋线
    RouteType_Special,      //停留 -> 圆周 -> 停留
    RouteType_Offset,       //在Advanced的基础上增加一个偏移
};

class FishFish;
class FishRoute
{
GETSET(int32, Key);
GETSET(Vec2, Velocity);
// 总存活时间
GETSET(float, LifeTime);
// 上次更新位置时间
GETSET(float, LastPosTime);

GETSET_BOOL(Valid);
// 对应的鱼
GETSET_PTR(FishFish, Fish);
protected:
    Vec2 m_Position;
public:
    FishRoute() {
        m_pFish = nullptr;
    };
    virtual ~FishRoute() {};
    void Update(int32 dt) {}
public:
    // 返回秒的浮点数
    float GetCurLifeTime();
    const float m_UpdatePositionTime = 0.1f;     // 位置间隔更新时间
    virtual Vec2 GetPosition();
    void SetPosition(const Vec2& pos) { m_Position = pos; };
    virtual void UpdatePosition(float dt) = 0;
    virtual int32 GetRouteType() = 0;
    virtual void GetRouteParamProto(FishRouteParamProto& param) = 0;
    virtual void OnRecycled() {
        m_Key = 0;
        m_pFish = nullptr;
    };
};

class SimpleLineRoute : public FishRoute
{
GETSET(BaseRouteParam, BaseRouteParam);
public:
    SimpleLineRoute() {}
    virtual ~SimpleLineRoute() {}
public:
    virtual void UpdatePosition(float dt)
    {
        m_Position += m_Velocity * dt;
    }
    bool Init(int32 key, const BaseRouteParam& proto, const Vec2& position, const Vec2& speed, float lifetime) {
        m_Key = key;
        m_Valid = true;
        m_BaseRouteParam = proto;
        m_Position = position;
        m_Velocity = speed;
        m_LifeTime = lifetime;
        return true;
    }
    virtual int32 GetRouteType() { return RouteType_Base; };

    virtual void GetRouteParamProto(FishRouteParamProto& param)
    {
        param.set_routetype(RouteType_Base);
        *param.mutable_baseroute() = m_BaseRouteParam;
    }
};

/// 根据配置路线走
class AdvanceRoute : public FishRoute
{
GETSET(int32, PointIndex);
GETSET(float, Rotation);
GETSET(float, CurSpeed);
GETSET(float, CurRotation);
GETSET(float, AccSpeed);
GETSET(float, AccRotation);
GETSET(float, GradientTime);
GETSET(float, Duration);
GETSET(float, R);
GETSET(float, R0);
GETSET(Vec2, O);
GETSET(AdvancedRouteParam, AdvancedRouteParam);
protected:
    vector<tagRoutePoint> m_RoutePoints;
public:
    AdvanceRoute() {}
    virtual ~AdvanceRoute() {}

    void AddRoutePoint(const tagRoutePoint& routePoint)
    {
        m_RoutePoints.push_back(routePoint);
    }

    bool Init(int32 key, int32 routeId)
    {
        m_Key = key;
        m_Valid = true;
        tagRouteData data;
        sHRoute->GetRouteData(routeId, data);
        m_RoutePoints.assign(data._points.begin(), data._points.end());

        m_Position.x = data._startPosX;
        m_Position.y = data._startPosY;
        m_CurRotation = 0;
        m_CurSpeed = 0;
        m_LifeTime = data._lifeTime;
        SetRoutePoint(0);
        m_AdvancedRouteParam.set_routeid(data._id);
        return true;
    }

    void SetRoutePoint(int index)
    {
        m_PointIndex = index;
        if (m_PointIndex >= (int32)m_RoutePoints.size())
        {
            m_Valid = false;
        }
        else
        {
            auto& routePoint = m_RoutePoints[m_PointIndex];
            m_GradientTime = routePoint._gradient;
            m_Duration = routePoint._duration;

            if (routePoint._gradient > 0)
            {
                m_AccRotation = (routePoint._rotation - m_CurRotation) / m_GradientTime;
                m_AccSpeed = (routePoint._speed - m_CurSpeed) / m_GradientTime;

                m_R = m_CurSpeed * routePoint._gradient / FishMath::AngleToRadian(routePoint._rotation - m_CurRotation);
                m_R0 = m_R;

                if (m_R < 0)
                    m_O = FishMath::GetRotateDirection(m_CurRotation - 90)*(-m_R) + m_Position;
                else
                    m_O = FishMath::GetRotateDirection(m_CurRotation + 90)*(m_R) + m_Position;
            }
            else
            {
                m_AccRotation = 0;
                m_AccSpeed = 0;
                m_CurSpeed = routePoint._speed;
                m_CurRotation = routePoint._rotation;

                m_Velocity = m_CurSpeed * FishMath::GetRotateDirection(m_CurRotation);
                m_Rotation = m_CurRotation;
            }
        }
    }

    virtual void UpdatePosition(float dt)
    {
        if (m_PointIndex == -1)
            SetRoutePoint(0);

        if ( !m_Valid )
            return;

        float useTime = 0;
        //渐变时间
        if (m_GradientTime > 0.0f)
        {
            m_GradientTime -= dt;
            if (m_GradientTime <= 0.0f)
            {
                useTime = dt + m_GradientTime;

                auto& routePoint = m_RoutePoints[m_PointIndex];
                m_CurSpeed = routePoint._speed;
                m_CurRotation = routePoint._rotation;

                m_R = m_R0 + m_AccSpeed * routePoint._gradient;
            }
            else
            {
                useTime = dt;

                m_CurSpeed += m_AccSpeed * dt;
                m_CurRotation += m_AccRotation * dt;

                m_R += m_AccSpeed * dt;
            }

            m_Velocity = m_CurSpeed * FishMath::GetRotateDirection(m_CurRotation);
            m_Rotation = m_CurRotation;

            if (m_R < 0)
                m_Position = m_O -(FishMath::GetRotateDirection(m_CurRotation - 90)*(-m_R));
            else
                m_Position = m_O -(FishMath::GetRotateDirection(m_CurRotation + 90)*(m_R));
        }

        if (m_Duration > 0.0f)
        {
            if (m_Duration > dt)
            {
                if (m_GradientTime <= 0)
                    m_Position += m_Velocity * (dt-useTime);

                m_Duration -= dt;
            }
            else
            {
                if (m_GradientTime <= 0)
                    m_Position += m_Velocity * (m_Duration- useTime);

                dt -= m_Duration;
                SetRoutePoint(++m_PointIndex);
                UpdatePosition(dt);
            }
        }
        else
        {
            m_Position += m_Velocity * dt;
        }
    }
    virtual int32 GetRouteType() { return RouteType_Advanced; };
    virtual void GetRouteParamProto(FishRouteParamProto& param)
    {
        param.set_routetype((int32)RouteType_Advanced);
        *param.mutable_advancedroute() = m_AdvancedRouteParam;
    }
};

//手动配置弧形路线,对应客户端CustomRoute
class RotationRoute : public AdvanceRoute
{
GETSET(RotateRouteParam, RotateRouteParam);
public:
    RotationRoute() {}
    virtual ~RotationRoute() {}

    bool Init(int32 key, const RotateRouteParam& proto, float lifeTime)
    {
        m_Key = key;
        m_Valid = true;
        m_RotateRouteParam = proto;
        m_LifeTime = lifeTime;
        return true;
    }

    virtual int32 GetRouteType() { return RouteType_Rotate; };
    virtual void GetRouteParamProto(FishRouteParamProto& param)
    {
        param.set_routetype((int32)RouteType_Rotate);
        *param.mutable_rotateroute() = m_RotateRouteParam;
    }
};

/// 手动配置一条 停留 -> 圆弧 -> 停留 的路线
class SpecialRoute : public AdvanceRoute
{
GETSET(SpecialRouteParam, SpecialRouteParam);
public:
    SpecialRoute() {}
    virtual ~SpecialRoute() {}

    bool Init(int32 key, const SpecialRouteParam& proto, float lifeTime) {
        m_Key = key;
        m_Valid = true;
        m_SpecialRouteParam = proto;
        m_LifeTime = lifeTime;
        return true;
    }

    virtual int32 GetRouteType() { return RouteType_Special; };
    virtual void GetRouteParamProto(FishRouteParamProto& param)
    {
        param.set_routetype((int32)RouteType_Special);
        *param.mutable_specialroute() = m_SpecialRouteParam;
    }
};

/// 配置路线的基础上，加上随机偏移量
class OffsetRoute : public FishRoute
{
GETSET(Vec2, CurOffset);
GETSET(Vec2, NextOffset);
GETSET(float, Rotation);
GETSET(float, MoveDistance);
GETSET(float, Distance);
GETSET(float, AccTime);
GETSET(int32, Offset);
GETSET(int32, State);
GETSET(OffsetRouteParam, OffsetRouteParam);
protected:
    AdvanceRoute m_Route;
public:
    OffsetRoute() {}
    virtual ~OffsetRoute() {}
    ClientRandom random;
    bool Init(int32 key, const OffsetRouteParam& proto, int32 routeId, Vec2 initOffset, int randOffset, int randSeed)
    {
        m_Key = key;
        m_Valid = true;
        m_OffsetRouteParam = proto;
        random.SetSeed(randSeed);
        m_CurOffset = initOffset;
        m_Offset = randOffset;
        m_Route.Init(0, routeId);// TODO 这里是个对象,管理方不是RouteMgr,暂时id先为0,后续再看会有什么问题
        m_LifeTime = m_Route.GetLifeTime();
        m_Rotation = m_Route.GetRotation();
        m_Position = m_Route.GetPosition() + m_CurOffset;
        if (m_Rotation < 0)
            m_Rotation += 360;
        return true;
    }

    void ResetRandOffset()
    {
        Vec2 tmp = m_NextOffset-m_CurOffset;

        m_NextOffset = FishMath::AngleDirection(90- random.Random() % 360) * m_Offset;
        m_Distance = tmp.length();
        m_MoveDistance = 0;
        m_Velocity = tmp.getNormalized();
        m_State = 1;
        m_AccTime = 0;
    }

    virtual void UpdatePosition(float dt)
    {
        if (dt == 0.0f)
            return;

        // 刷新Route
        // TODO 这里应该传递生存时间过去,否则这句话没用
        m_Route.GetPosition();
        m_Valid = m_Route.IsValid();

        //固定偏移
        if(m_Offset == 0)
        {
            m_Position = m_Route.GetPosition() + m_CurOffset;
            m_Rotation = m_Route.GetRotation();
        }
        else
        {
            float moveDis = m_Route.GetCurSpeed() * 0.5f * dt;

            if(m_State == 1)
            {
                m_AccTime += dt * 2;
                if(m_AccTime>=1.0f)
                {
                    m_State = 2;
                    m_AccTime = 1;
                }
                moveDis *= m_AccTime;
            }
            else if(m_State == 3)
            {
                m_AccTime -= dt * 2;
                if(m_AccTime < 0)
                {
                    m_AccTime = 0;
                }

                moveDis *= m_AccTime;
            }

            m_MoveDistance += moveDis;
            if(m_MoveDistance >= m_Distance)
            {
                m_CurOffset = m_NextOffset;
                ResetRandOffset();
            }
            else
            {
                m_CurOffset += (m_Velocity * moveDis);
                if(m_State==1 || m_State == 2)
                {
                    if(m_Distance - m_MoveDistance < m_Route.GetCurSpeed() * 0.25f)
                    {
                        m_State = 3;
                    }
                }
            }

            auto oldPosition = m_Position;
            // TOODO 这里也要传递CurLifeTime过去才能计算
            m_Position = m_Route.GetPosition() + m_CurOffset;
            auto rotation = FishMath::FishLineDirToAngle(m_Position-oldPosition);
            if (rotation < 0)
                rotation += 360.0f;

            m_Rotation = rotation;
        }
    }
    virtual int32 GetRouteType() { return RouteType_Offset; };
    virtual void GetRouteParamProto(FishRouteParamProto& param)
    {
        param.set_routetype((int32)RouteType_Offset);
        *param.mutable_offsetroute() = m_OffsetRouteParam;
    }
};
