﻿#pragma once

#include "ServerDefine.h"
#include "FishUtils.h"
#include "LxSlotTableBoss.h"


class FishTable;
class FishShoal;
class FishRoute;
class FishFish
{
GETSET(int32, Key);
GETSET(float, LifeTime);
GETSET(int32, CurLifeTick);
GETSET_PTR(FishRoute, Route);
GETSET_PTR(FishTable, Table);
GETSET_PTR(FishShoal, Shoal);
GETSET(tagJsonFishData, FishData);
GETSET(tagJsonFishFunction, FishFunction);
GETSET(tagTableBoss, TableBoss);
GETSET(tagBossSlotParam, BossSlotParam);    // 召唤boss倍率
// 使用的routeid,释放时归还
GETSET(int32, UsedTableRouteId);
//刷新时确定owner,增加对应的玩家在击杀阶段的概率
GETSET(uint64, Owner);
// 谁召唤的, 该鱼的数据不同步给其他人, 只给单个用户
GETSET(uint64, Summoner);
// 鱼分,用来计算金币场的金币掉落;经典场的小游戏数值;经典场的击杀概率计算
GETSET(float, Score);
GETSET(int32, TurnTableN);
GETSET(int32, TurnTableM);
// 击杀者花费的金币
GETSET(int64, KillerCost);
// 击杀者的预期击杀炮数
GETSET(int32, KillerExpectNum);
GETSET(int32, KillerSummonBossScore);
GETSET_BOOL(BonusBoss);
GETSET(int32, BossPointParam);
GETSET(int64, BossGuid);
public:
    FishFish() {}
    ~FishFish() {}
    bool Init(FishTable* pTable, FishShoal* pShoal, int32 fishId, int fishCfgId, FishRoute* route);
    void Update(int deltaMS);
    bool IsValid() { return m_CurLifeTick < m_LifeTime*1000; };
    void OnRecycled();

    void OnDead();

    int32 GetFishFunctionId() { return m_FishData._FunctionID; }
    // 判断是否是翻牌鱼 最大值是3个99
    bool IsTortoiseFish() { return m_FishData._FunctionID != 0 && m_Score < 298 && m_FishFunction._Type == e_jsonFishFunctionType_Card; }
    // 判断是否是八卦转盘鱼
    bool IsTurnTableFish() { return m_FishData._FunctionID != 0 && m_FishFunction._Type == e_jsonFishFunctionType_TurnTable; }
    bool IsSmallFish() { return m_FishData._Type == e_jsonFishDataType_Small; }
    bool IsGameBoss() { return m_FishData._Type == e_jsonFishDataType_Special; }
    bool IsRoomBoss() { return m_FishData._Type == e_jsonFishDataType_Boss; }
    bool IsSlotFish() { return m_FishData._FundAddType != 0; }
    bool IsSlotTableBoss() { return m_FishData._FundAddType == e_jsonFishDataFundAddType_Table; }
    tuple<bool, int64> SlotTableBossOnHit(int64 gold);
    int32 GetFishType() { return m_FishData._Type; }
    int32 GetFishHeritageGroup() { return m_Key; }
    bool CanKillByFunctions() { return m_FishData._CanBeKilledByFuncion; }
    // 是否是特殊的鱼,死亡时自身的金币时不奖励玩家的
    bool IsSpecialFishWithNoGold() {
        return m_FishData._FunctionID != 0 && m_FishFunction._GoldReturn == 0;
    }
    int32 GetIndex() { return m_FishData._ID; }
    int32 GetArenaPoint() { return m_FishData._ArenaPoint; }
    int32 GetEnergy() { return m_FishData._FishEnergy; }
    int32 GetType() { return m_FishData._Type; }
    int32 GetTreasureBoxParam() { return m_FishData._TreasureBoxParam; }
    bool GetDeathBuff(int32& buffId, int32& duration);
    void DoLoot(int32 iTurretIndex, bool isSwingBond, map<int32, int64>& mapItem);
    static void DoAdditionLoot(int32 fishIndex, map<int32, int64>& mapItem);
    bool RandSummonBossRate(int64 curB, int64 maxB, bool needBossFix, int32 mhMin, int32 mhMax, tagSummonBossData& lhs) {
        map<int32, int64> mapItem;
        if( GetIndex() == JDATA->SystemConstPtr()->GetMenghuoBossID() ) {
            DoAdditionLoot(GetIndex(), mapItem);
        }
        return m_BossSlotParam.RandSummonBossRate(GetIndex(), curB, maxB, needBossFix, mhMin, mhMax, mapItem, lhs);
    }
    bool IsSummonBoss() { return m_BossSlotParam._valid; }
    bool IsBombCardFish() { return m_FishData._Type == e_jsonFishDataType_Card; }
    bool IsTreasureBoxFish() { return m_FishData._Type == e_jsonFishDataType_TreasureBox; }
    bool IsEscaped() { return m_bEscaped; }
public:
    void FillProto(uint64 userId, FishInfoProto& proto);
    void GetHpInfo(uint64 userId, FishHpInfo& info) {
        auto it = m_mapPlayerFish.find(userId);
        if( it == m_mapPlayerFish.end() ) {
            InitPlayerFish(userId);
            // 初始化的值就是m_hpInfo的值
            info = m_hpInfo;
        }
        else {
            info = it->second;
        }
    }
    int32 GetCurHp(uint64 userId) {
        auto it = m_mapPlayerFish.find(userId);
        if( it == m_mapPlayerFish.end() ) {
            InitPlayerFish(userId);
            // 初始化的值就是m_hpInfo的值
            return m_hpInfo.curhp();
        }
        return it->second.curhp();
    }
    int32 GetMaxHp(uint64 userId) {
        auto it = m_mapPlayerFish.find(userId);
        if( it == m_mapPlayerFish.end() ) {
            InitPlayerFish(userId);
            // 初始化的值就是m_hpInfo的值
            return m_hpInfo.maxhp();
        }
        return it->second.maxhp();
    }
    void InitPlayerFish(uint64 userId) {
        m_mapPlayerFish[userId] = m_hpInfo;
    }
    void OnDamagePct(uint64 userId, int32 rate);
    void OnDamage(uint64 userId, int32 nDamage);
    std::tuple<int32, int32> GetDefence() {
        return std::make_tuple(_pd, _md);
    }
    void ForEachQuestGroup(std::function<void(int32)> func) {
        for( auto& tg : m_setQuestGroup ) {
            func(tg);
        }
    }
    set<int32> m_setQuestGroup;

    void AddPlayerCost(uint64 userId, int64 gold) {
        m_mapPlayerCost[userId] += gold;
    }
    int64 GetPlayerCost(int64 userId) {
        auto it = m_mapPlayerCost.find(userId);
        if( it != m_mapPlayerCost.end() ) {
            return it->second;
        }
        return 0;
    }
    int64 GetGoldCost() {
        int64 gold = 0;
        for( auto& it : m_mapPlayerCost ) {
            gold += it.second;
        }
        return gold;
    }
private:
    int32 initLastReward(int64 cur, const vector<int64>& period) {
        int32 last = -1;
        for( size_t i = 0; i < period.size() ; i += 2 ) {
            if( cur >= period[i] ) {
                last = i;
            }
        }
        return last;
    }
private:
    int32 _pd;  // 物防
    int32 _md;  // 魔防
    FishHpInfo m_hpInfo;    // 配置的值
    // 每人一根血条
    map<uint64, FishHpInfo> m_mapPlayerFish;
    bool m_bEscaped;
    map<uint, int64> m_mapPlayerCost;
};
