#pragma once
/**
 * LogicShoal由  FishPart管理,初始化后生成,不会被析构
 */

#include "ServerDefine.h"

// 刷普通鱼群帧数间隔
#define REFRESH_FRAME_COUNT 10
// 鱼路径的CD时间,用来防止同一个路径被多条鱼使用造成画面不协调
#define FISH_ROUTE_LIFE_TICK 3000
#define TIDE_ROUTE_LIFE_TICK 10000

struct tagDelayTide {
    int32 _tideId;   // tideid
    int32 _delayTick;   // 延迟的毫秒值
    int32 _lifeTick;    // 距离刷新起始点的tick,当_lifeTick >= _delayTick时,刷新_tideId
    tagDelayTide(int32 tid, int32 delay) {
        _tideId = tid;
        _delayTick = delay;
        _lifeTick = 0;
    }
    tagDelayTide& operator=(const tagDelayTide& rhs) {
        memcpy(this, &rhs, sizeof(tagDelayTide));
        return *this;
    }
    void Update(int32 dt) {
        _lifeTick += dt;
    }
    bool CanCreate() { return _lifeTick >= _delayTick; }
};

class LogicGroup;
class TideBase;
class FishTable;
class FishShoal {
GETSET(int32, Key);
GETSET_BOOL(Valid);
GETSET_PTR(FishTable, Table);
GETSET_PTR(LogicGroup, LogicGroup);
GETSET(tagJsonFishShoal, Shoal);
GETSETCHG(int32, CurFishNum);  // 普通鱼组当前数量,如果是鱼阵刷鱼,这个数量一直为0
protected:
    // 初始化时从配置中获取路线池
    Roll m_fishRoute;
    // 每次需要路径从该变量中去,为空时重新从m_fishRoute赋值
    // 获取时从桌子判定该路径当前是否可以使用,如果不能用,则另取一条,如果本路径池一条都用不了,则刷鱼延迟
    Roll m_curFishRoute;
    Roll m_fishGroup;        // fishGroupID => FishGroup.xlsx
    bool m_bOnce;
    // 按间隔刷新鱼群使用的间隔时长tick
    int64 m_lifeTickForInterval;
    list<int32> m_lstNormalFish;
    map<int32, TideBase*> m_mapTides;
    list<tagDelayTide> m_lstDelayTides;
public:
    FishShoal() {}
    ~FishShoal() {}
    bool Init(FishTable* pTable, int32 shoalId, const tagJsonFishShoal& rhs);
    void Update(int32 dt);
    void OnRecycled();

    void FillTideProto(FishRoomProto& roomProto);
private:
    void DoTideUpdate(int32 dt);
    void DoNormalUpdate(int32 dt);
    bool CheckRefreshRule();
    int32 GetFishRoute();
    void GenerateDelayTide(int32 genId, int32 delay);
};
