﻿#pragma once

#include "ServerDefine.h"
#include "FishUtils.h"

struct tagSpeedCheck {
    int64 _lastTick;        // 上次击中的时间
    int32 _actPerSecond;    // 每秒累计的次数
    tagSpeedCheck() {
        memset(this, 0, sizeof(tagSpeedCheck));
    }
    tagSpeedCheck& operator=(const tagSpeedCheck& rhs) {
        memcpy(this, &rhs, sizeof(tagSpeedCheck));
        return *this;
    }
    bool IsTooFast(int32 actMax) {
        int64 nowTick = GlobalUtils::GetTickCount();
        if( nowTick/1000 == _lastTick / 1000 ) {
            // 同一秒内的包
            // 这一秒内收到的子弹数量超过了炮台的发射速度
            if( _actPerSecond + 1 > actMax ) {
                return false;
            }
            ++_actPerSecond;
            return true;
        }
        else {
            _actPerSecond = 0;
            _lastTick = nowTick;
            return IsTooFast(actMax);
        }
    }
    void reset() {
        _lastTick = 0;
        _actPerSecond = 0;
    }
};

struct tagTreasureFishData {
    int32 _groupId;     // 羁绊的组id
    set<int32> _cards;  // 抽到的卡片
    tagTreasureFishData() {
        _groupId = 0;
        _cards.clear();
    }
    tagTreasureFishData& operator=(const tagTreasureFishData& rhs) {
        _groupId = rhs._groupId;
        _cards = rhs._cards;
        return *this;
    }
};

class FishFish;
class LxUser;
class FishTable;
class FishPlayer
{
GETSET_PTR(LxUser, User);
GETSET_PTR(FishTable, Table);
GETSET(tagSummonBossData, SummonBossData);
GETSET(int32, SeatId);
// 当前锁定的鱼id
GETSET(int32, LockFishId);
// 当前选择的炮倍
GETSET(int32, TurretRate);
GETSET(int32, TurretAngle);
// 上次发包时间
GETSET(int64, LastActTick);
GETSET(int64, LastLogTime);
// 金币超过限制后累计发送子弹数量
GETSETCHG(int32, InValidBulletDueToGold);
GETSETCHG(int64, BulletTax);
GETSETCHG(int64, KillTax);
GETSET(int32, FuryRate);
public:
    FishPlayer() { m_pUser = nullptr;};
    ~FishPlayer() {};
    bool Init(FishTable* pTable, LxUser* pUser);
    void Update(int64 tNow, int32 dt);
    void UpdateUser(int64 tNow, int32 dt);
    bool IsValid() { return IsUser(); };
    bool IsUser() { return m_pUser != nullptr; };
    void OnRecycled();
    void OnFire(int64 gold);
    void FillFishPlayerProto(FishPlayerProto& proto);
    int64 GetCurGold();
    uint64 GetKey();
    int32 GetUserLevel();
    int32 GetUserVip();
    string GetUserName();
    string GetUserStarName();
    int32 GetUserPortrait();
    int32 GetUserFrame();
    int32 PlayerCastSkill(InputUserCastSkill& req);
    bool CheckSkillStep(const tagJsonSkill& rhs, int32 skillStep, int32 useCount);
    bool KillNow(FishFish* fish, int32 hitLeft);
    void SummonBossReward(bool resetRate, bool hammerNormal, bool hammerReset, bool byMail, SyncSummonBossReward& msg);
    void TryKillSummonBoss(FishFish* fish, ActHitFish& msg);
    void SyncUserInfo(int32 dt);
    void LogGoldStatus(int64 tNow);
public:
    bool IsTimeout();
    void Touch() { m_LastActTick = GlobalUtils::GetTickCount(); };
    // 获取捕鱼相关计算值 0感受值 1友好度 2抽水值
    std::tuple<int64, int64, int64, float> GetFeelingAndRoomFAndTaxAndAlpha();
public:
    int32 GetTurretIndex() { return m_Turret.hero_index(); }
    int32 GetTurretStar() { return m_Turret.hero_star(); }
    int32 GetTurretLevel() { return m_Turret.hero_level(); }
    int32 GetTurretFrozenTime() { return m_attrHeroStar[e_jsonHeroSetAllAttribute_SkillFrozen]; }
    int32 GetTurretLockTime() { return m_attrHeroStar[e_jsonHeroSetAllAttribute_SkillLock]; }
    int32 GetTurretRapidTime() { return m_attrHeroStar[e_jsonHeroSetAllAttribute_SkillRapid]; }
    int32 GetTurretSweaponTime() { return m_attrHeroStar[e_jsonHeroSetAllAttribute_SuperWeaponLast]; }
    int32 GetTurretDiamondLoot() { return m_attrHeroStar[e_jsonHeroSetAllAttribute_DiamondLoot]; }
    int32 GetTurretStarAttr(int32 attr) {
        if( attr >= e_jsonHeroSetAllAttribute_start && attr < e_jsonHeroSetAllAttribute_end ) {
            return m_attrHeroStar[attr];
        }
        return 0;
    }

    int32 GetTurretSpeed() { return m_attrHeroLevel[e_jsonHeroAttributeAttributeType_BulletSpeed]; }
    int32 GetTurretPointCr() { return m_attrHeroStar[e_jsonHeroSetAllAttribute_ArenaPointCritical]; }
    int32 GetTurretPointExtra() { return m_attrHeroStar[e_jsonHeroSetAllAttribute_ArenaPoint]; }
    int32 GetTurretBulletIndex() { return m_Turret.hero_bullet_index(); }
    // 获取子弹威力
    double GetBulletPower();

    int32 GetWingIndex() { return m_Turret.hero_wing_index(); }

    // 根据鱼的物防和魔防计算伤害
    int32 CalculateDamage(int32 pd, int32 md);
    // 奖金鱼有部分金币奖励会放到捕鱼奖池中, 返回当前实际获得的金币
    int64 OnUserKillFish(FishFish* pFish, int64 gold, ItemPair& bombItem);
    // 检查是否击中了桌面boss
    bool HitTableBoss(FishFish* fish);

    void OnFishDead(FishFish* fish);
    void ReloadTurret();
    // 检查身上的金币
    bool CheckTablePlayGold();

    bool HasBuff(int32 buffId) { return m_buffs.Contains(buffId); }
    // lifeTick为寿命,单位毫秒
    void AddBuff(int32 buffId, int32 fishIndex, int64 lifeTick);
    void DelBuff(int32 buffId);
    bool GetBuff(int32 buffId, tagFishBuff& lhs) { return m_buffs.Get(buffId, lhs); }
    tagFishBuff* GetBuffPtr(int32 buffId) { return m_buffs.GetPtr(buffId); }
private:
    void CalcHeroAttr();
private:
    HeroInfo m_Turret;
    LifeObj<int32, tagFishBuff> m_buffs;
    // 等级属性
    int32 m_attrHeroLevel[e_jsonHeroAttributeAttributeType_end];
    // 星级属性
    int32 m_attrHeroStar[e_jsonHeroSetAllAttribute_end];
public:
    // 检查子弹发射速度
    bool CheckBulletSpeed();
    void CreateBullet(int32 bulletId);
    bool InLockStatus() { return m_SkillLock._in_use; }
    bool InFastStatus() { return m_SkillFast._in_use; }
    bool InFuryStatus() { return m_SkillFury._in_use; }
    bool InSuperStatus() { return !m_SkillSuper.empty(); }
    int32 GetSuperWeaponSkillId() { return m_SkillSuper._skill_id; }
    void SuperFire() { m_SkillSuper.fire(); }
    void SaveUserSkill();
    void LoadUserSkill();
    void OnBroken() {
        m_SkillLock.clear();
        m_SkillFast.clear();
        m_SkillFury.clear();
        m_SkillSuper.clear();
    }
protected:
    tagSpeedCheck m_tagBulletCheck; // 开炮速度检查
    int64 m_lGameTick;
    tagCommonSkill m_SkillLock;
    tagCommonSkill m_SkillFast;
    tagCommonSkill m_SkillFury;
    tagCommonSkill m_SkillSuper;    // 超级武器
public:
    void RegisterSkill(int32 skillId, int32 useCount);
protected:
    map<int32, tagSkillStep> m_mapSkillStep;
protected:
    bool UserInitPlayer();
public:
    int32 GetUserPlayTime();
    int32 GetSummonBossIndex();
protected:
    int64 m_tmUserEnter;
    void CheckTaxRate(int64 now);
    double m_fTaxRate;
public:
    void GetFishParam(FishFish* fish, double bulletPower, tagFishHitParam& param);
    bool PushOneSkill(const InputUserCastSkill& req);
    bool PopOneSkill(int32 skillId, InputUserCastSkill& req);
    void OnKillTreasureFish(int32 fishId, int32 gid, set<int32>& cards);
    int32 RewardTreasureFish(int32 fishId);
    void GetExtraDrop(int32 fishIndex, map<int32, int64>& mapItem);
protected:
    map<int32, tagFishHitParam> m_mapFishHitParam;
    map<int32, list<InputUserCastSkill> > m_mapSkillQueue;
    // 鱼id 对应的卡牌列表
    map<int32, tagTreasureFishData > m_mapTreasureFishData;
};
