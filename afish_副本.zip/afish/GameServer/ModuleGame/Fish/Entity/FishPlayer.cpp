#include "FishPlayer.h"
#include "Entity/FishTable.h"
#include "Entity/FishFish.h"
#include "Entity/FishShoal.h"
#include "Entity/FishRoute.h"
#include "Entity/FishBullet.h"
#include "Dispatcher.h"
#include "ModuleUser/LxUser.h"
#include "ModuleHelper.h"
#include "LxGameLogHelper.h"

bool FishPlayer::Init(FishTable* pTable, LxUser* pUser)
{
    m_pUser = pUser;
    m_pTable = pTable;
    m_SeatId = -1;
    m_LockFishId = 0;
    m_TurretRate = 0;
    m_TurretAngle = 30;
    m_LastActTick = 0;
    m_lGameTick = 0;
    m_FuryRate = DEFAULT_FURY_RATE;
    m_tagBulletCheck.reset();
    m_tmUserEnter = sGameUtils->GetFakeTimeNow();
    m_LastLogTime = 0;
    m_Turret.Clear();
    m_InValidBulletDueToGold = 0;
    m_BulletTax = 0;
    m_KillTax = 0;
    m_mapSkillStep.clear();
    m_mapSkillQueue.clear();
    LoadUserSkill();

    Touch();
    m_buffs.Clear();
    m_mapFishHitParam.clear();
    UserInitPlayer();
    // 玩家在重连进入房间时,会调用FishTable::PlayerSitDown
    // 此时会进行重新Init, 这里防一手上次boss倍率重置期间断线重连
    if( m_SummonBossData._fish_index != 0 ) {
        SyncSummonBossReward msg;
        SummonBossReward(false, false, false, true, msg);
    }
    m_SummonBossData.reset();
    m_mapTreasureFishData.clear();

    return true;
}

void FishPlayer::CheckTaxRate(int64 now) {
    if( m_pUser->PBGetTimeTax() <= now ) {
        m_pUser->PBSetTimeTax(now+GlobalUtils::GetRandNumber(JDATA->SystemConstPtr()->GetFishTaxChangeIntervalMin(), JDATA->SystemConstPtr()->GetFishTaxChangeIntervalMax()));
        int32 rmbCardParam = 0;
        if( m_pUser->IsRmbCardSuperMonth(now) ) {
            rmbCardParam += JDATA->MonthCardPtr()->ExtraFishGoldBonusByID(e_jsonChargeProductType_SuperMonthCard);
        }
        if( m_pUser->IsRmbCardMonth(now) ) {
            rmbCardParam += JDATA->MonthCardPtr()->ExtraFishGoldBonusByID(e_jsonChargeProductType_MonthCard);
        }
        if( m_pUser->IsRmbCardWeek(now) ) {
            rmbCardParam += JDATA->MonthCardPtr()->ExtraFishGoldBonusByID(e_jsonChargeProductType_WeeklyCard);
        }
        int32 tax = (int32)(sHTax->GetTaxRate(m_pUser->GetUserGoldProperty(), 0, rmbCardParam)*10000);
        m_pUser->PBSetCurFishTax(GlobalUtils::GetRandNumber(tax-JDATA->SystemConstPtr()->GetFishTaxRange(), tax+JDATA->SystemConstPtr()->GetFishTaxRange()));
        m_fTaxRate = m_pUser->PBGetCurFishTax()*1.0f/10000;
    }
}

uint64 FishPlayer::GetKey() {
    if( IsUser() ) {
        return m_pUser->GetKey();
    }
    return 0;
}

int32 FishPlayer::GetUserLevel() {
    if( IsUser() ) {
        return m_pUser->PBGetUserLevel();
    }
    else {
        return 0;
    }
}

int32 FishPlayer::GetUserVip() {
    if( IsUser() ) {
        return m_pUser->PBGetUserVip();
    }
    else {
        return 0;
    }
}

int64 FishPlayer::GetCurGold() {
    if( IsUser() ) {
        return m_pUser->PBGetUserGold();
    }
    return 0;
}

string FishPlayer::GetUserStarName() {
    return GlobalUtils::GetStarName(GetUserName());
}

string FishPlayer::GetUserName() {
    if( IsUser() ) {
        return m_pUser->PBGetUserName();
    }
    else {
        return "";
    }
}

int32 FishPlayer::GetUserPortrait() {
    if( IsUser() ) {
        return m_pUser->PBGetUserPortrait();
    }
    else {
        return 0;
    }
}

int32 FishPlayer::GetUserFrame() {
    if( IsUser() ) {
        return m_pUser->PBGetUserFrame();
    }
    else {
        return 0;
    }
}

void FishPlayer::CalcHeroAttr() {
    for( int32 attr = e_jsonHeroSetAllAttribute_start ; attr < e_jsonHeroSetAllAttribute_end ; ++attr ) {
        if( IsUser() ) {
            m_attrHeroStar[attr] = m_pUser->GetHeroStarAttrValue(attr);
        }
        else {
            m_attrHeroStar[attr] = sHero->GetHeroStarAttrValue(m_Turret.hero_index(), m_Turret.hero_star(), attr);
        }
    }
    for( int32 attr = e_jsonHeroAttributeAttributeType_start ; attr < e_jsonHeroAttributeAttributeType_end ; ++attr ) {
        m_attrHeroLevel[attr] = sHero->GetHeroLevelAttrValue(m_Turret.hero_index(), m_Turret.hero_level(), attr);
    }
}

bool FishPlayer::UserInitPlayer() {
    // 对于奖池来说,玩家的收入等于奖池的产出,玩家的支出等于奖池的收入
    m_LastLogTime = 0;
    m_pUser->GetCurHero(m_Turret);
    CalcHeroAttr();

    m_TurretRate = 0;
    m_TurretRate = m_pTable->GetMaxTurretRate();
    m_TurretAngle = 30;
    m_pUser->ResetFishPool(m_pTable->GetGamePlay()._PersonalRefund);
    m_tmUserEnter = sGameUtils->GetFakeTimeNow();
    m_fTaxRate = m_pUser->PBGetCurFishTax()*1.0f/10000;
    return true;
}

int32 FishPlayer::GetUserPlayTime() {
    return (int32)(sGameUtils->GetFakeTimeNow() - m_tmUserEnter);
}

void FishPlayer::ReloadTurret() {
    m_Turret.Clear();
    m_pUser->GetCurHero(m_Turret);
    CalcHeroAttr();
}

bool FishPlayer::IsTimeout() {
    if( IsUser() && m_pTable->GetGamePlay()._KickOutTime > 0 ) {
        return GlobalUtils::GetTickCount() - m_LastActTick >= m_pTable->GetGamePlay()._KickOutTime;
    }
    return false;
}

void FishPlayer::UpdateUser(int64 tNow, int32 dt) {
    if( m_pUser == nullptr ) {
        return;
    }
    m_buffs.Update(dt);
    // 如果buff自己消失,说明客户端没及时发送UserBuffEndReq,此时会让锁定和急速一直中断,直到下次使用,客户端的子弹会无法进入急速状态
    // 这种情况的发生,要么是bug,要么是断网了, 总共也就20秒, 就不纠结了
    m_SkillLock.update(dt);
    m_SkillFast.update(dt);
    m_SkillFury.update(dt);
    m_SkillSuper.update(dt);

    SyncUserInfo(dt);
    LogGoldStatus(tNow);
    CheckTaxRate(tNow);
}

void FishPlayer::LogGoldStatus(int64 tNow) {
    if( tNow == 0 || tNow - m_LastLogTime >= 10 ) {
        m_LastLogTime = tNow;
        auto data = GetFeelingAndRoomFAndTaxAndAlpha();
        // 每10秒记录一次玩家相关状态
        LOG_GOLD_STATUS_V2(m_pUser,
                            m_pUser->PBGetUserGold(),
                            TUPLE0(data),
                            TUPLE1(data),
                            TUPLE3(data)*100,
                            m_pUser->IsUserInChargeBonus(),
                            m_pUser->PBGetUserChargeBonus(),
                            m_pUser->PBGetFishWinGold(),
                            m_pUser->PBGetFishCostGold(),
                            m_BulletTax,
                            m_KillTax);
        sRankingList->TableSummonPoolIncrby(m_pTable->GetTableIndex(), m_BulletTax);
        m_BulletTax = 0;
        m_KillTax = 0;
    }
}

void FishPlayer::Update(int64 tNow, int32 dt)
{
    if( IsUser() ) {
        UpdateUser(tNow, dt);
    }
}

void FishPlayer::SyncUserInfo(int32 dt) {
    m_lGameTick += dt;
    if( dt == 0 || m_lGameTick > 60*1000) {
        // 1分钟同步一次
        m_pUser->IncGameTime((int32)(m_lGameTick/1000));
        m_lGameTick = m_lGameTick%1000;
    }
}

void FishPlayer::OnRecycled() {
    // 保证IsValid返回的是false
    if( m_pUser != nullptr ) {
        sGameUtils->DecTableUser(m_pTable->GetTableIndex());
        if( m_SummonBossData._fish_index != 0 ) {
            SyncSummonBossReward msg;
            SummonBossReward(false, false, false, true, msg);
        }
        SyncUserInfo(0);
        SaveUserSkill();
        LogGoldStatus(0);
        m_pUser->SendUserInfoChange(0);
        m_pUser = nullptr;
    }
}

void FishPlayer::SaveUserSkill() {
    int64 lNow = GlobalUtils::GetTickCount();
    if( m_SkillLock._skill_id != 0 ) {
        m_pUser->SetSkill(m_SkillLock._skill_id, lNow + m_SkillLock._max_tick - m_SkillLock._cur_tick);
    }
    if( m_SkillFast._skill_id != 0 ) {
        m_pUser->SetSkill(m_SkillFast._skill_id, lNow + m_SkillFast._max_tick - m_SkillFast._cur_tick);
    }
    if( m_SkillFury._skill_id != 0 ) {
        m_pUser->SetSkill(m_SkillFury._skill_id, lNow + m_SkillFury._max_tick - m_SkillFury._cur_tick);
    }
    if( m_SkillSuper._skill_id != 0 ) {
        m_pUser->SetSkillSuper(m_SkillSuper._skill_id);
        m_pUser->SetSkillSuperTick(lNow + m_SkillSuper._max_tick - m_SkillSuper._cur_tick);
    }
}

void FishPlayer::LoadUserSkill() {
    if( m_pUser == nullptr ) {
        return;
    }
    int64 lNow = GlobalUtils::GetTickCount();
    int64 tick = 0;
    m_SkillLock.clear();
    tick = m_pUser->GetSkill(SkillID_Lock) - lNow;
    if( tick > 0 && tick < 180 ) {
        m_SkillLock.init(SkillID_Lock, tick);
    }
    m_SkillFast.clear();
    tick = m_pUser->GetSkill(SkillID_Fast) - lNow;
    if( tick > 0 && tick < 180 ) {
        m_SkillFast.init(SkillID_Fast, tick);
    }

    m_SkillFury.clear();
    tick = m_pUser->GetSkill(SkillID_Fury) - lNow;
    if( tick > 0 && tick < 180 ) {
        m_SkillFury.init(SkillID_Fury, tick);
    }

    m_SkillSuper.clear();
    int32 skl = m_pUser->GetSkillSuper();
    tick = m_pUser->GetSkillSuperTick() - lNow;
    if( skl != 0 && tick > 0 && tick < 180 ) {
        m_SkillSuper.init(skl, tick);
    }
}

std::tuple<int64, int64, int64, float> FishPlayer::GetFeelingAndRoomFAndTaxAndAlpha() {
    float alpha = 1.0f;
    int64 iFriendly = 100;
    int64 iFeeling = 0;
    auto gamePlay = m_pTable->GetGamePlay();
    int64 iCost = gamePlay._RoomTax;
    if( gamePlay._MinusParam.size() != 7 ) {
        return std::make_tuple(iFeeling, iFriendly, iCost, alpha);
    }
    int64 k1 = gamePlay._MinusParam[1];
    int64 k2 = gamePlay._MinusParam[5];
    int64 n1 = gamePlay._MinusParam[0];
    int64 m = gamePlay._MinusParam[4];
    int64 U = m_pUser->GetUserWin(m, InFastStatus(), InFuryStatus());
    if( m_pUser->IsUserInChargeBonus() ) {
        if( gamePlay._MinusRangeParam.size() > 1 && (gamePlay._MinusRangeParam.size() - 1 ) % 2 == 0) {
            alpha = gamePlay._MinusRangeParam[0]*1.0f/100.0f;
            for( size_t i=1; i < gamePlay._MinusRangeParam.size() ; i+=2 ) {
                if( U <= gamePlay._MinusRangeParam[i] ) {
                    alpha = gamePlay._MinusRangeParam[i+1]*1.0f/100.0f;
                    break;
                }
            }
        }
        return std::make_tuple(0, 0, iCost, alpha);
    }
    {
        if( U > 0 ) {
            iFeeling = -(int64)(k2 * pow(abs(U), 1.0/n1));
        }
        else {
            iFeeling = (int64)(k1 * pow(abs(U), 1.0/n1));
        }
    }
    {
        int64 T = m_pTable->GetTablePoolInfo()._win - m_pTable->GetTablePoolInfo()._lose;
        if( T > 0 ) {
            iFriendly = gamePlay._MinusParam[3]*pow(abs(T),1.0/gamePlay._MinusParam[2]);
        }
        else {
            iFriendly = -1*gamePlay._MinusParam[6]*pow(abs(T),1.0/gamePlay._MinusParam[2]);
        }
    }
    return std::make_tuple(iFeeling, iFriendly, iCost, alpha);
}

int32 FishPlayer::CalculateDamage(int32 pd, int32 md) {
    tagPlayerDamage dmg;
    dmg._patk = m_attrHeroLevel[e_jsonHeroAttributeAttributeType_PhysicalAttack]*(1000+m_attrHeroStar[e_jsonHeroSetAllAttribute_PhysicalAttack])/1000;
    dmg._matk = m_attrHeroLevel[e_jsonHeroAttributeAttributeType_MagicAttack]*(1000+m_attrHeroStar[e_jsonHeroSetAllAttribute_MagicAttack])/1000;
    dmg._pp = m_attrHeroLevel[e_jsonHeroAttributeAttributeType_PhysicalPenetration]*(1000+m_attrHeroStar[e_jsonHeroSetAllAttribute_PhysicalPenetration])/1000;
    dmg._mp = m_attrHeroLevel[e_jsonHeroAttributeAttributeType_MagicPenetration]*(1000+m_attrHeroStar[e_jsonHeroSetAllAttribute_MagicPenetration])/1000;
    dmg._rd = m_attrHeroLevel[e_jsonHeroAttributeAttributeType_RealDamage]*(1000+m_attrHeroStar[e_jsonHeroSetAllAttribute_RealDamage])/1000;
    dmg._cr = m_attrHeroStar[e_jsonHeroSetAllAttribute_HeroCritical]*1.0f/1000.0f;
    dmg._ctdr = m_attrHeroStar[e_jsonHeroSetAllAttribute_HeroCriticalDamage]*1.0f/1000.0f;

    int32 K = JDATA->SystemConstPtr()->GetDefenseConst();

    int32 pp = dmg._pp*(1.0+dmg._ppr);
    int32 mp = dmg._mp*(1.0+dmg._mpr);

    // 物理减伤
    float plow = max(0,pd-pp)*1.0f/(max(0,pd-pp)+K);
    float mlow = max(0,md-mp)*1.0f/(max(0,md-mp)+K);

    int32 patk = dmg._patk*(1.0+dmg._patkr)*(1.0-plow);
    int32 matk = dmg._matk*(1.0+dmg._matkr)*(1.0-mlow);

    int32 atk = patk + matk + dmg._rd;
    float cr = (JDATA->SystemConstPtr()->GetBasicCritical()*1.0f/100)*(1.0+dmg._cr);
    float ctdr = (JDATA->SystemConstPtr()->GetBasicCriticalDamage()*1.0f/100)*(1.0+dmg._ctdr);

    return atk + atk*cr*ctdr;
}

void FishPlayer::OnFire(int64 gold)
{
    if( gold == 0 ) {
        return;
    }
    if( IsUser() ) {
        if( m_pTable->GetGamePlay()._GameRefund.size() >= 1 ) {
            float rate = m_pTable->GetGamePlay()._GameRefund[0]*1.0f/1000.0f;
            ChangeBulletTax(gold*rate);
        }
        m_pUser->FishPoolOnFire(gold);
    }
}

void FishPlayer::OnFishDead(FishFish* fish) {
    if( m_LockFishId == fish->GetKey() ) {
        m_LockFishId = 0;
    }
    m_mapFishHitParam.erase(fish->GetFishHeritageGroup());
}

int64 FishPlayer::OnUserKillFish(FishFish* pFish, int64 gold, ItemPair& bombItem) {
    int64 realGold = gold;
    if( gold > 0 ) {
        m_pTable->LogDataPtr()->LogPlayerKillFish(gold);
        // 捕鱼奖池累计
        if( pFish->GetFishData()._SlotDrawRate > 0 ) {
            float rate = pFish->GetFishData()._SlotDrawRate*1.0f/100.0f;
            m_pUser->PBIncSlotFishDrawCurNum(1);
            m_pUser->PBIncSlotFishDrawCurGold(gold*rate);
            realGold = gold - gold*rate;
        }
        int64 summonTax = 0;
        // 召唤boss奖池累计 指定鱼都抽指定比例到奖池
        if( pFish->GetFishData()._SummonBossPool > 0 ) {
            // 普通鱼抽水是统一的 所以鱼id填0即可
            float rate = 0.0f;
            if( m_pTable->GetGamePlay()._GameRefund.size() >= 4 ) {
                // 106房间放在第四位
                rate = m_pTable->GetGamePlay()._GameRefund[3]*1.0f/1000;
            }
            else {
                rate = m_fTaxRate;
            }
            summonTax = realGold*rate;
            ChangeKillTax(summonTax);
            realGold -= summonTax;
        }
        auto data = m_pTable->SplitGold(realGold, pFish->GetIndex());
        realGold = TUPLE0(data);
        bombItem.set_item_id(TUPLE1(data));
        bombItem.set_item_num(TUPLE2(data));

        m_pTable->RoomTargetGetGold(realGold);
        m_pUser->ChangeGold(realGold, m_pTable->GetLogIncReason());
        m_pTable->LogDataPtr()->LogBombGot(bombItem.item_id(), bombItem.item_num());
        // 捕鱼获得金币/10000 折算成通行证经验
        m_pUser->AddBattlePassExp(gold/10000);
        if( m_pTable->IsClassic() ) {
            // 经典场才会算奖池
            // 召唤boss的抽水, 不计入到赢分
            m_pUser->FishPoolKillFish(gold);
        }
        int32 iExp = pFish->GetFishData()._FishEXP;
        m_pUser->AddExp(iExp);
    }
    m_pUser->OnQuestFishKilled(pFish->GetIndex(), pFish->m_setQuestGroup, gold);
    m_pUser->Day7OnQuestFishKilled(pFish->m_setQuestGroup);
    m_pUser->GTaskOnQuestFishKilled(pFish->m_setQuestGroup);
    // 某些鱼的死亡需要世界广播做表现
    if( pFish->GetFishData()._KillNoticeTipID != 0 ) {
        SyncSpecialFishKill msg;
        msg.set_user_name(GetUserStarName());
        msg.set_user_portrait(GetUserPortrait());
        msg.set_user_frame(GetUserFrame());
        msg.set_user_vip(GetUserVip());
        msg.set_fish_index(pFish->GetIndex());
        msg.set_rate(GetTurretRate());
        msg.set_gold(gold);
        string strMsg;
        msg.SerializeToString(&strMsg);
        sDispatcher->broadcast(FISH_SyncSpecialFishKill, strMsg);
    }

    // 死亡后会放技能的鱼,都要在死亡时注册一下
    int32 functionId = pFish->GetFishFunctionId();
    if( functionId != 0 ) {
        int32 skillId = JDATA->FishFunctionPtr()->SkillIDByID(functionId);
        if( skillId != 0 ) {
            RegisterSkill(skillId, 1);
        }
    }
    return realGold;
}

bool FishPlayer::CheckBulletSpeed() {
    int32 maxNum = GetTurretSpeed();
    if( InFastStatus() ) {
        maxNum = 12;    // 急速时间内,一秒12发
    }
    return m_tagBulletCheck.IsTooFast(maxNum);
}

bool FishPlayer::CheckTablePlayGold() {
    if( IsUser() ) {
        if( m_pTable->IsClassic() && m_pTable->GetGamePlay()._SkipGold > 0 ) {
            int64 curGold = m_pUser->PBGetUserGold();
            if( curGold >= m_pTable->GetGamePlay()._SkipGold ) {
                return false;
            }
        }
    }
    return true;
}

void FishPlayer::CreateBullet(int32 bulletId) {
    FishBullet* bullet = m_pTable->CreateBullet(this, bulletId);
    if( bullet != nullptr ) {
        bool isBuffBullet = false;
        m_buffs.ForEachWithBreak([&](LifeObj<int32, tagFishBuff>::tagLifeObj* ptr){
            int32 maxKill = sGameUtils->GetBulletMaxKill(ptr->_key);
            if( maxKill > 0 ){
                bullet->SetMaxHitNum(maxKill);
                isBuffBullet = true;
                return true;
            }
            return false;
        });
        if( !isBuffBullet ) {
            bullet->SetMaxHitNum(sGameUtils->GetBulletMaxKillByTurretIndex(m_Turret.hero_index()));
        }
    }
}

void FishPlayer::FillFishPlayerProto(FishPlayerProto& proto)
{
    proto.set_user_id(GetKey());
    proto.set_user_name(m_pUser->PBGetUserName());
    proto.set_user_sign(m_pUser->PBGetUserSign());
    proto.set_user_portrait(m_pUser->PBGetUserPortrait());
    proto.set_user_frame(m_pUser->PBGetUserFrame());
    proto.set_user_weapon(m_pUser->PBGetUserSweapon());
    proto.set_user_property(m_pUser->PBGetUserProperty());
    proto.set_user_vip(m_pUser->PBGetUserVip());
    proto.set_user_level(m_pUser->PBGetUserLevel());
    proto.set_user_gender(m_pUser->PBGetUserGender());
    proto.set_user_gold(m_pUser->PBGetUserGold());
    proto.set_user_diamond(m_pUser->PBGetUserDiamond());
    proto.set_user_seat(GetSeatId());
    proto.set_boss_index(GetSummonBossIndex());
    proto.set_turretindex(GetTurretIndex());   // 炮台配置id
    if( m_pTable->IsClassic() ) {
        proto.set_turretrate(GetTurretRate());   // 炮倍
    }
    proto.set_turretangle(GetTurretAngle());
    proto.set_turretstar(GetTurretStar());
    proto.set_turretbulletindex(GetTurretBulletIndex());
    proto.set_swing_index(GetWingIndex());

    int64 tNow = sGameUtils->GetFakeTimeNow();
    m_buffs.ForEach([&](LifeObj<int32, tagFishBuff>::tagLifeObj* ptr){
        auto buff = proto.add_buffs();
        buff->set_buff_id(ptr->_key);
        buff->set_end_time(tNow + (ptr->_lifeTick - ptr->_curTick)/1000);
    });
    if( m_SkillLock._skill_id != 0 ) {
        auto skl = proto.add_skills();
        skl->set_key(m_SkillLock._skill_id);
        skl->set_value(m_SkillLock._max_tick - m_SkillLock._cur_tick);
    }
    if( m_SkillFast._skill_id != 0 ) {
        auto skl = proto.add_skills();
        skl->set_key(m_SkillFast._skill_id);
        skl->set_value(m_SkillFast._max_tick - m_SkillFast._cur_tick);
    }
    if( m_SkillFury._skill_id != 0 ) {
        auto skl = proto.add_skills();
        skl->set_key(m_SkillFury._skill_id);
        skl->set_value(m_SkillFury._max_tick - m_SkillFury._cur_tick);
    }
    if( m_SkillSuper._skill_id != 0 ) {
        auto skl = proto.add_skills();
        skl->set_key(m_SkillSuper._skill_id);
        skl->set_value(m_SkillSuper._max_tick - m_SkillSuper._cur_tick);
    }
}

void FishPlayer::AddBuff(int32 buffId, int32 fishIndex, int64 lifeTick)
{
    tagFishBuff buf;
    buf._index = buffId;
    buf._fishIndex = fishIndex;
    buf._gold = 0;
    m_buffs.Add(buffId, buf, lifeTick);

    int32 type = JDATA->BuffPtr()->TypeByID(buffId);
    if( type == e_jsonBuffType_Drill || type == e_jsonBuffType_Laser ) {
        m_SkillLock.halt();
        m_SkillFast.halt();
        m_SkillFury.halt();
        m_SkillSuper.halt();
    }
}

void FishPlayer::DelBuff(int32 buffId)
{
    m_buffs.Remove(buffId);
    int32 type = JDATA->BuffPtr()->TypeByID(buffId);
    if( type == e_jsonBuffType_Drill || type == e_jsonBuffType_Laser ) {
        m_SkillLock.resume();
        m_SkillFast.resume();
        m_SkillFury.resume();
        m_SkillSuper.resume();
    }
}

void FishPlayer::RegisterSkill(int32 skillId, int32 useCount) {
    tagJsonSkill tag;
    if( !JDATA->SkillPtr()->ByID(skillId, tag) ) {
        return;
    }
    tagSkillStep ss;
    if( tag._HitCount.size() == 2 ) {
        if( m_pTable->IsClassic() ) {
            ss.Init(skillId, tag._Step, tag._HitCount[0], useCount);
        }
        else {
            ss.Init(skillId, tag._Step, tag._HitCount[1], useCount);
        }
        m_mapSkillStep[skillId] = ss;
    }
}

bool FishPlayer::CheckSkillStep(const tagJsonSkill& rhs, int32 skillStep, int32 useCount) {
    if( skillStep == 0 ) {
        switch(rhs._ID) {
        case SkillID_SuperWeapon:
            // 超级武器要检查科技是否解锁
            if( rhs._Param.size() != 3 ) {
                LOGERROR("user[%lu] super weapon config error", GetKey());
                return false;
            }
            if( m_pUser->TechIsLocked(rhs._Param[1]) ) {
                LOGERROR("user[%lu] super weapon tech locked error", GetKey(), rhs._Param[1]);
                return false;
            }
            break;
        case SkillID_Summon:
            if( !m_pTable->CanSummonBoss() ) {
                LOGERROR("user[%lu] summon boss when exist", GetKey());
                return false;
            }
            // 召唤技能,要判断一下对应的房间能不能放
            if( !m_pTable->CanUseSummonSkill() ) {
                LOGERROR("user[%lu] skill[%d] can not summon in table[%d]", GetKey(), rhs._ID, m_pTable->GetTableIndex());
                return false;
            }
            break;
        case SkillID_Lock:
            if( InLockStatus() ) {
                return false;
            }
            break;
        case SkillID_Fast:
            if( InFastStatus() ) {
                return false;
            }
            break;
        case SkillID_Fury:
            if( InFuryStatus() ) {
                return false;
            }
            break;
        }
        if( rhs._CostItem.size() == 2 && rhs._CostDiamond > 0 ) {
            // 道具和钻石都填了,是先扣道具,不成功再扣钻石
            int32 itemId = rhs._CostItem[0];
            int32 itemNum = rhs._CostItem[1]*useCount;
            if( !m_pUser->ItemChange(itemId, -itemNum, ELRD_TableSkillBase + rhs._ID, false) ) {
                if( !m_pUser->ChangeDiamond(-rhs._CostDiamond*useCount, ELRD_TableSkillBase + rhs._ID, false) ) {
                    LOGERROR("user[%lu] skill[%d] step[%d] item or diamond low", GetKey(), rhs._ID, skillStep);
                    return false;
                }
                else {
                    m_pTable->LogDataPtr()->LogDiamondCost(itemId, rhs._CostDiamond*useCount);
                }
            }
            else {
                m_pTable->LogDataPtr()->LogItemCost(itemId, itemNum);
            }
        }
        else {
            // 道具,钻石,能量,只生效一项
            // 按顺序扣,扣到了就成功了
            if( rhs._CostItem.size() == 2 ) {
                int32 itemId = rhs._CostItem[0];
                int32 itemNum = rhs._CostItem[1]*useCount;
                if( !m_pUser->ItemChange(itemId, -itemNum, ELRD_TableSkillBase + rhs._ID, false) ) {
                    LOGERROR("user[%lu] skill[%d] step[%d] item low", GetKey(), rhs._ID, skillStep);
                    return false;
                }
                else {
                    m_pTable->LogDataPtr()->LogItemCost(itemId, itemNum);
                }
            }
            else{
                if( rhs._CostDiamond > 0 ) {
                    if( !m_pUser->ChangeDiamond(-rhs._CostDiamond*useCount, ELRD_TableSkillBase + rhs._ID, false) ) {
                        LOGERROR("user[%lu] skill[%d] step[%d] diamond low", GetKey(), rhs._ID, skillStep);
                        return false;
                    }
                }
            }
        }
        switch(rhs._Type) {
        case e_jsonSkillType_Swing:
            break;
        case e_jsonSkillType_Fish:
            {
                auto it = m_mapSkillStep.find(rhs._ID);
                if( it == m_mapSkillStep.end() ) {
                    // 由服务器做prepare, 没有则说明没有杀死对应种类的鱼
                    return false;
                }
                if( it->second._curStep != 0 ) {
                    // 说明客户端可能伪造了一个0上来,用来多次杀鱼
                    return false;
                }
            }
            break;
        case e_jsonSkillType_SpecialBattle:
            RegisterSkill(rhs._ID, useCount);
            break;
        case e_jsonSkillType_NonePhaseFishDeath:
            // 电鳗/炸弹/黑洞 在鱼死亡时已经Prepare, 客户端不会发送step0
            return false;
        // 普通技能只需要判定扣除物品,不需要后续step
        //case e_jsonSkillType_Normal:
        }
        return true;
    }
    // step>0的包,肯定要注册过才能用
    auto it = m_mapSkillStep.find(rhs._ID);
    if( it == m_mapSkillStep.end() ) {
        // 普通技能只会发step0, 其他技能都会先发0
        LOGERROR("user[%lu] skill[%d] unregistered", GetKey(), rhs._ID);
        return false;
    }
    if( skillStep > it->second._maxStep ) {
        LOGERROR("user[%lu] skill[%d] step[%d][%d] overflow", GetKey(), rhs._ID, skillStep, it->second._maxStep);
        return false;
    }
    if( useCount != it->second._useCount ) {
        LOGERROR("user[%lu] skill[%d] step[%d] useCount[%d][%d] failed", GetKey(), rhs._ID, skillStep, useCount, it->second._useCount);
        return false;
    }
    // 每次都+1
    if( it->second._curStep+1 != skillStep ) {
        LOGERROR("user[%lu] skill[%d] step[%d] [%d] failed", GetKey(), rhs._ID, skillStep, it->second._curStep);
        return false;
    }
    ++it->second._curStep;
    return true;
}

bool FishPlayer::PushOneSkill(const InputUserCastSkill& req) {
    if( req.skill_step() != 0 ) {
        return false;
    }
    auto it = m_mapSkillStep.find(req.skill_id());
    if( it == m_mapSkillStep.end() ) {
        return false;
    }
    // 如果相同技能还没放完, 存一个

    auto it2 = m_mapSkillQueue.find(req.skill_id());
    if( it2 == m_mapSkillQueue.end()) {
        list<InputUserCastSkill> lst;
        lst.push_back(req);
        m_mapSkillQueue[req.skill_id()] = lst;
    }
    else {
        it2->second.push_back(req);
    }
    return true;
}

bool FishPlayer::PopOneSkill(int32 skillId, InputUserCastSkill& req) {
    auto it2 = m_mapSkillQueue.find(skillId);
    if( it2 == m_mapSkillQueue.end()) {
        return false;
    }
    if( it2->second.empty() ) {
        return false;
    }
    req = it2->second.front();
    it2->second.pop_front();
    if( it2->second.empty() ) {
        m_mapSkillQueue.erase(it2);
    }
    return true;
}

/*
// 普通技能,锁定-冰冻-急速
// 鱼死亡后触发的技能
// 弹头技能, 扣弹头道具
// 翅膀技能
*/
int32 FishPlayer::PlayerCastSkill(InputUserCastSkill& req) {
    if( !IsUser() ) {
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    if( PushOneSkill(req) ) {
        return JDATA->ErrorCodePtr()->GetSuccess();
    }
    SyncUserCastSkill msg;
    msg.set_playerid(GetKey());
    msg.set_skill_id(req.skill_id());
    msg.set_skill_step(req.skill_step());
    msg.set_fish_index(req.fish_index());
    msg.set_fish_x(req.fish_x());
    msg.set_fish_y(req.fish_y());
    msg.set_swing_index(req.swing_index());
    msg.set_use_count(req.use_count());

    int32 skillId = req.skill_id();
    int32 skillStep = req.skill_step();
    int32 useCount = max(req.use_count(), 1);
    if( req.fish_index() != 0 ) {
        // 要检查一下是否有对应的step0,如果没有的话,这个消息的step必须是0
        int32 functionId = JDATA->FishDataPtr()->FunctionIDByID(req.fish_index());
        if( functionId == 0 ) {
            return JDATA->ErrorCodePtr()->GetSystemError();
        }
        skillId = JDATA->FishFunctionPtr()->SkillIDByID(functionId);
        if( skillId == 0 ) {
            return JDATA->ErrorCodePtr()->GetSystemError();
        }
    }
    tagJsonSkill skData;
    if( !JDATA->SkillPtr()->ByID(skillId, skData) ) {
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    if( !CheckSkillStep(skData, skillStep, useCount) ) {
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    // 到了这里,就全部检测完了,消耗品也成功扣除了
    bool tryNext = false;
    do {
        m_pUser->OnQuestUseSkillType(skData._Type);
        // 普通技能,只要通过上面的判定,消耗品应该都扣除了,step值应该也是正确的
        if( skData._Type == e_jsonSkillType_Normal ) {
            m_pUser->OnUseSkill(skillId);
            m_pTable->RoomTargetOnUseCommonSkill(skillId, skData._Type);
            m_pUser->Day7Inc(e_jsonNewBieCarnivalCondition_Skill_ID, skData._ID, 1);
            m_pUser->GTaskInc(e_jsonGeneralTaskCondition_Skill_Release, skData._Type, 1);
            m_pUser->GTaskInc(e_jsonGeneralTaskCondition_Skill_Type_Daily, skData._Type, 1);
            m_pUser->GTaskInc(e_jsonGeneralTaskCondition_Skill_Release_Daily, skData._ID, 1);
            if( skillId == SkillID_Freeze ) {
                int32 tick = (int32)(skData._Duration*(1000.0+GetTurretFrozenTime())/1000.0f);
                m_pTable->SetFreezeTime(GetKey(), tick, true);
            }
            else if( skillId == SkillID_Fast ) {
                int32 tick = skData._Duration*(1000 + GetTurretRapidTime() + m_pUser->TechGetFastEffect())/1000;
                m_SkillFast.init(skillId, tick);
                m_SkillLock.init(SkillID_Lock, tick);
                m_SkillSuper.clear();
                m_pUser->CounterAdd(e_jsonGeneralTaskDynamicTarget_Skill_Rapid, 1);
            }
            else if( skillId == SkillID_Lock ) {
                m_SkillLock.init(skillId, skData._Duration*(1000+GetTurretLockTime())/1000);
                m_SkillFast.clear();
                m_pUser->CounterAdd(e_jsonGeneralTaskDynamicTarget_Skill_Lock, 1);
            }
            else if( skillId == SkillID_Fury ) {
                m_SkillFury.init(skillId, skData._Duration);
                m_SkillLock.init(SkillID_Lock, skData._Duration);
                m_SkillSuper.clear();
                m_pUser->CounterAdd(e_jsonGeneralTaskDynamicTarget_Skill_Crazy, 1);
            }
            else if( skillId == SkillID_Summon ) {
                // 召唤类
                list<IntPair> lst;
                int32 ret = m_pTable->UseSummonSkill(m_pUser->PBGetUserGold(), lst, this);
                for( auto & fish : lst ) {
                    if( fish.key() > 0 && fish.value() > 0 ) {
                        if( ret == EUSSR_Boss ) {
                            int64 guid = RedisData::GenerateBossGuid();
                            m_pTable->TableCreateBoss(guid, fish.key(), fish.value(), this);
                            m_pUser->OnBossSummoned(fish.key());
                        }
                        else {
                            m_pTable->TableCreateFish(fish.key(), fish.value(), nullptr);
                        }
                    }
                }
                m_pUser->CounterAdd(e_jsonGeneralTaskDynamicTarget_Skill_Summon, 1);
            }
            else if( skillId == SkillID_SuperWeapon ) {
                m_SkillFast.clear();
                m_SkillFury.clear();
                int32 tick = skData._Duration*(1000+GetTurretSweaponTime())/1000;
                m_SkillSuper.init(skillId, tick);
                m_pUser->CounterAdd(e_jsonGeneralTaskDynamicTarget_Skill_SuperWeapon, 1);
            }
            break;
        }
        if( skData._Type == e_jsonSkillType_SuperWeaponSample ) {
            m_pUser->OnUseSkill(skillId);
            m_pTable->RoomTargetOnUseCommonSkill(skillId, skData._Type);
            m_pUser->Day7Inc(e_jsonNewBieCarnivalCondition_Skill_ID, skData._ID, 1);
            m_pUser->GTaskInc(e_jsonGeneralTaskCondition_Skill_Release, skData._Type, 1);
            m_pUser->GTaskInc(e_jsonGeneralTaskCondition_Skill_Type_Daily, skData._Type, 1);
            m_pUser->GTaskInc(e_jsonGeneralTaskCondition_Skill_Release_Daily, skData._ID, 1);
            m_SkillSuper.init(skillId, skData._Duration);
            break;
        }
        // 技能最后一段,如果是核弹技能,要计算一下实际要给的金币
        if( skData._Type == e_jsonSkillType_NuclearBomb && skData._Param.size() > 0 && skData._Param.size() % 3 == 0 ) {
            Roll dice;
            for( size_t i = 0; i < skData._Param.size(); i+=3 ) {
                dice.push_value(skData._Param[i], i);
            }
            auto idx = dice.roll();
            int64 gold = GlobalUtils::GetRandLong(skData._Param[idx+1], skData._Param[idx+2]) * 10000 * (int64)useCount;
            m_pUser->ChangeGold(gold, ELRI_NuclearBomb);
            m_pUser->Day7Inc(e_jsonNewBieCarnivalCondition_Nuclear_Gold, 0, gold);
            m_pUser->GTaskInc(e_jsonGeneralTaskCondition_Skill_Release_Daily, skData._ID, useCount);
            m_pUser->GTaskInc(e_jsonGeneralTaskCondition_Skill_Type_Daily, skData._Type, useCount);
            msg.set_gold(gold);
            m_pUser->CounterAdd(e_jsonGeneralTaskDynamicTarget_Skill_NuclearUse, useCount);
            break;
        }
        if( skillStep == 0 ) {
            break;
        }
        auto itStep = m_mapSkillStep.find(skillId);
        if( itStep == m_mapSkillStep.end() ) {
            // 这个逻辑应该不会执行到, CheckSkillStep的时候已经处理过了
            break;
        }
        int32 maxKill = itStep->second.GetMaxKill();
        switch( skData._Type ) {
        case e_jsonSkillType_Swing:
        case e_jsonSkillType_Fish:
        case e_jsonSkillType_NonePhaseFishDeath:
        {
            int32 killNum = 0;
            int64 gold = 0;
            for( int32 n = 0 ; n < req.fishids_size() ; ++n ) {
                int32 fishId = req.fishids(n);
                FishFish* fish = m_pTable->GetFish(fishId);
                if (fish == nullptr)
                {
                    continue;
                }
                if( skData._Type == e_jsonSkillType_Swing && !fish->GetFishData()._CanBeKilledByWing ) {
                    continue;
                }
                if( (skData._Type == e_jsonSkillType_NonePhaseFishDeath || skData._Type == e_jsonSkillType_Fish) && !fish->GetFishData()._CanBeKilledByFuncion ) {
                    continue;
                }
                if( !fish->IsValid() ) {
                    continue;
                }
                auto result = msg.add_results();
                m_pTable->PlayerHitFish(this, fish, true, false, GetBulletPower(), *result);
                gold += result->totalscore();
                killNum++;
                if( killNum >= maxKill ) {
                    break;
                }
            }
            itStep->second._totalGold += gold;
            msg.set_gold(itStep->second._totalGold);
            break;
        }
        case e_jsonSkillType_SpecialBattle:
            break;
        default:
            break;
        }

        // 到达最大阶段以后就移除, 防止后续继续发送技能包导致多杀鱼
        if( itStep->second._curStep == itStep->second._maxStep ) {
            m_mapSkillStep.erase(itStep);
            tryNext = true;
        }
    } while(0);

    WrapPacket packet;
    LxGameHelper::MakeSyncUserCastSkill(packet, msg);
    m_pTable->SyncToAll(packet);

    m_pUser->SendUserInfoChange(EPIC_FishSkill);

    if( tryNext ) {
        InputUserCastSkill nextReq;
        if( PopOneSkill(skillId, nextReq) ) {
            return PlayerCastSkill(nextReq);
        }
    }
    return JDATA->ErrorCodePtr()->GetSuccess();
}

double FishPlayer::GetBulletPower() {
    if( InFuryStatus() ) {
        return m_FuryRate*(1000.0f+m_attrHeroStar[e_jsonHeroSetAllAttribute_SkillCrazy])/1000.0f;
    }
    return m_attrHeroLevel[e_jsonHeroAttributeAttributeType_BulletCount];
}

bool FishPlayer::HitTableBoss(FishFish* fish) {
    if( !fish->IsSlotTableBoss() ) {
        return false;
    }
    int64 cost = GetTurretRate()*GetBulletPower();
    auto ret = fish->SlotTableBossOnHit(cost);
    bool killed = TUPLE0(ret);
    int64 reward = TUPLE1(ret);
    int32 reason = (killed ? ELRI_KillTableBoss : ELRI_HitTableBoss);
    if( reward > 0 ) {
        m_pUser->AddBattlePassExp(reward/10000);
        // 有钱拿就需要广播一下
        auto data = m_pTable->SplitGold(reward, fish->GetIndex());
        int64 gold = TUPLE0(data);
        int32 bombId = TUPLE1(data);
        int64 bombNum = TUPLE2(data);

        m_pUser->ChangeGold(gold, reason);
        if( bombNum > 0 && bombId > 0 ) {
            m_pUser->ItemChange(bombId, bombNum, reason, false);
        }

        // 击杀了
        ActFishFundTrigger msg;
        msg.set_fishid(fish->GetKey());
        msg.set_playerid(GetKey());
        msg.set_gold(gold);
        msg.set_killed(killed);
        if( bombNum > 0 && bombId > 0 ) {
            auto item = msg.add_items();
            item->set_item_id(bombId);
            item->set_item_num(bombNum);
            item->set_item_change(bombNum);
        }
        WrapPacket packet;
        LxGameHelper::MakeActFishFundTrigger(packet, msg);
        m_pTable->SyncToAll(packet);

        if( killed ) {
            m_pTable->TypeFishKilled(fish->GetFishType());
            if( fish->GetFishData()._KillNoticeTipID != 0 ) {
                SyncSpecialFishKill msg;
                msg.set_user_name(GetUserStarName());
                msg.set_user_portrait(GetUserPortrait());
                msg.set_user_frame(GetUserFrame());
                msg.set_user_vip(GetUserVip());
                msg.set_fish_index(fish->GetIndex());
                msg.set_rate(GetTurretRate());
                msg.set_gold(gold);
                string strMsg;
                msg.SerializeToString(&strMsg);
                sDispatcher->broadcast(FISH_SyncSpecialFishKill, strMsg);
            }
        }
    }
    return true;
}

bool FishPlayer::KillNow(FishFish* fish, int32 hitLeft) {
    if( !IsUser() ) {
        return false;
    }
    if( m_pUser->PBGetUserGold() > (int64)hitLeft*(int64)GetTurretRate() ) {
        // 不会破产的不杀
        return false;
    }
    if( m_pUser->PBGetUserGold() > (int64)JDATA->SystemConstPtr()->GetPovertyProtectTurretLeft()*GetTurretRate()) {
        // 剩余指定炮数之后再开始保护, 制造紧张气氛
        return false;
    }
    if( fish->GetScore() > JDATA->SystemConstPtr()->GetPovertyProtectFishPoint() ) {
        return false;
    }
    if( m_pTable->GetGamePlay()._RoomRefund.size() < 2 ) {
        return false;
    }
    if( !m_pUser->CanKillByBrokenBonus(m_pTable->GetGamePlay()._RoomRefund[1]) ) {
        return false;
    }
    return true;
}

void FishPlayer::GetFishParam(FishFish* fish, double bulletPower, tagFishHitParam& param) {
    auto it = m_mapFishHitParam.find(fish->GetFishHeritageGroup());
    if( it != m_mapFishHitParam.end() ) {
        it->second.hitNum += bulletPower;
        it->second.totalGold += bulletPower*GetTurretRate();
        param = it->second;
        if( fish->GetFishData()._SummonBossRefundMin > 0 ) {
            // 参与boss净分计算
            if( m_pUser != nullptr ) {
                m_pUser->OnHuntHitCost(fish->GetBossGuid(), fish->GetIndex(), bulletPower*GetTurretRate());
            }
        }
        return;
    }
    float alpha = 1.0f;
    auto tableConfig = m_pTable->GetGamePlay();
    if( fish->IsSummonBoss() ) {
        int64 tNow = sGameUtils->GetFakeTimeNow();
        // 召唤boss, 按资产计算实际鱼分
        int32 rmbCardParam = 0;
        if( m_pUser->IsRmbCardSuperMonth(tNow) ) {
            rmbCardParam += JDATA->MonthCardPtr()->ExtraBossGoldBonusByID(e_jsonChargeProductType_SuperMonthCard);
        }
        if( m_pUser->IsRmbCardMonth(tNow) ) {
            rmbCardParam += JDATA->MonthCardPtr()->ExtraBossGoldBonusByID(e_jsonChargeProductType_MonthCard);
        }
        if( m_pUser->IsRmbCardWeek(tNow) ) {
            rmbCardParam += JDATA->MonthCardPtr()->ExtraBossGoldBonusByID(e_jsonChargeProductType_WeeklyCard);
        }
        param.score = fish->GetScore()*(1.0+sHTax->GetTaxRate(m_pUser->GetUserGoldProperty(), fish->GetIndex(), rmbCardParam));
    }
    else {
        param.score = fish->GetScore();
    }
    auto data = GetFeelingAndRoomFAndTaxAndAlpha();
    param.f = TUPLE0(data); // 个人感受值
    param.F = TUPLE1(data);// 房间友好度
    param.C = TUPLE2(data);//房间抽水率
    alpha = TUPLE3(data);   // alpha值
    param.B = GetTurretRate();// 炮倍
    param.R = 5000000;
    if( tableConfig._TurretParam.size() >= 1 ) {
        param.R = tableConfig._TurretParam[0];  // 房间的R值
    }
    param.Fi = (int64)(1000000.0/(param.score*(1.0 + m_pUser->GetFishPoolRate() + m_pTable->GetTablePoolInfo()._rate + param.C*1.0/1000.0)));
    param.BN = 0;
    bool bn = false;
    param.AT = 0;
    switch( fish->GetFishData()._Type ) {
    case e_jsonFishDataType_Small:
    case e_jsonFishDataType_Range:
        break;
    case e_jsonFishDataType_Bonus:
        // 判断个人奖池是否触发
        if( !tableConfig._PersonalRefund.empty() && m_pUser->IsFishPoolInUse() ) {
            bn = true;
        }
        break;
    case e_jsonFishDataType_Function:
        // 判断桌面奖池是否触发
        if( !tableConfig._TableRefund.empty() && m_pTable->GetTablePoolInfo()._in_use ) {
            bn = true;
        }
        break;
    case e_jsonFishDataType_Sboss:
        // 判断桌面奖池是否触发
        if( !tableConfig._TableRefund.empty() && m_pTable->GetTablePoolInfo()._in_use ) {
            bn = true;
        }
        break;
    case e_jsonFishDataType_Activity:
        // 判断活动奖池是否触发
        break;
    case e_jsonFishDataType_Boss:
        break;
    case e_jsonFishDataType_Special:
        break;
    default:
        break;
    }
    if( bn ) {
        param.BN = GlobalUtils::GetRandNumber(JDATA->SystemConstPtr()->GetRefundDeathRateMin(), JDATA->SystemConstPtr()->GetRefundDeathRateMax());
    }
    param.BP = 0;
    if( fish->GetOwner() == GetKey() ) {
        param.BP = GlobalUtils::GetRandNumber(JDATA->SystemConstPtr()->GetBPDeathRateMin(), JDATA->SystemConstPtr()->GetBPDeathRateMax());
    }
    // 玩家当前的概率
    if( m_pTable->IsPoolBoss(fish->GetKey()) ) {
        // 召唤boss不参与感受值和区间控制, 仅通过预期值做随机
        param.rate = 1000000.0/param.score;
    }
    else {
        param.rate = param.GetRate(alpha);
    }
    param.hitNum = bulletPower;
    param.isBonusBoss = false;
    if( fish->IsTreasureBoxFish() ) {
        // 宝箱鱼击杀规则与其他不同
        int64 mu = param.score;
        mu *= 10000;
        mu /= param.B;
        param.expectNum = m_pTable->GetGame()->GetExpectHitNum(mu, mu*1.0/3.0);
    }
    else if( fish->IsBombCardFish() ) {
        int64 mu = param.score;
        mu *= 1000000;
        mu /= param.B;
        double sigma = mu*1.0/8.0;
        double sigmaParam = JDATA->SystemConstPtr()->GetCardFishKillSigmaParam();
        if( sigmaParam > 0 ) {
            sigma = mu / sigmaParam;
        }
        param.expectNum = m_pTable->GetGame()->GetExpectHitNum(mu, sigma);
    }
    else {
        param.expectNum = m_pTable->GetGame()->GetExpectHitNum(JDATA->SystemConstPtr()->GetFishDeathMiuParam(), JDATA->SystemConstPtr()->GetFishDeathSigmaParam(), param.rate);
        if( fish->GetFishData()._SummonBossRefundMin > 0 ) {
            int64 N = m_pUser->PBGetSummonBossPoint();
            float Q = N*1.0f/(abs(N) + m_pTable->GetMaxTurretRate());
            int32 Y = 0;
            if( N > JDATA->SystemConstPtr()->GetSummonNetScoreRangeMax() || N < JDATA->SystemConstPtr()->GetSummonNetScoreRangeMin() ) {
                Y = JDATA->SystemConstPtr()->GetSummonNetScoreRate();
            }
            double Ptn = param.score*(1.0+Y*1.0f*Q/100.0f);
            param.expectNum = m_pTable->GetGame()->GetExpectHitNum(Ptn, Ptn/3);
            if( fish->GetFishData()._SummonBossNewbieBuff.size() == 2 ) {
                // 新手击杀boss有福利
                if( !m_pUser->IsBossBonused(fish->GetIndex()) ) {
                    param.isBonusBoss = true;
                    param.expectNum = param.expectNum*fish->GetFishData()._SummonBossNewbieBuff[0]/10000;
                    param.bossPointParam = fish->GetFishData()._SummonBossNewbieBuff[1];
                }
            }
        }
    }
    m_mapFishHitParam[fish->GetFishHeritageGroup()] = param;
}

void FishPlayer::TryKillSummonBoss(FishFish* fish, ActHitFish& msg) {
    if( !IsUser() ) {
        return;
    }
    if( m_SummonBossData._fish_index != 0 ) {
        // 已经有一条击杀了, 还没发奖励
        return;
    }
    if( m_pTable->GetGamePlay()._TurretRate.size() == 0 ) {
        return;
    }
    bool needBossFix = false;
    int64 goldValue = m_pUser->GetUserGoldProperty();

    int32 rmbRateUp = 0;
    int64 tNow = sGameUtils->GetFakeTimeNow();
    if( m_pUser->IsRmbCardSuperMonth(tNow) ) {
        rmbRateUp += JDATA->MonthCardPtr()->ExtraPoolBonusByID(e_jsonChargeProductType_SuperMonthCard);
    }
    if( m_pUser->IsRmbCardMonth(tNow) ) {
        rmbRateUp += JDATA->MonthCardPtr()->ExtraPoolBonusByID(e_jsonChargeProductType_MonthCard);
    }
    if( m_pUser->IsRmbCardWeek(tNow) ) {
        rmbRateUp += JDATA->MonthCardPtr()->ExtraPoolBonusByID(e_jsonChargeProductType_WeeklyCard);
    }
    JDATA->BossFixPtr()->ForEachWithBreak([&](tagJsonBossFix* ptr){
        if( goldValue >= ptr->_gold ) {
            int32 rate = GlobalUtils::GetRandNumber(0,100);
            if( rate < ptr->_rate - rmbRateUp ) {
                needBossFix = true;
            }
            return true;
        }
        return false;
    });
    if( fish->RandSummonBossRate(GetTurretRate(), m_pTable->GetGamePlay()._SummonBossBonusTurret, needBossFix, sHero->GetMenghuoMinRate(), sHero->GetMenghuoMaxRate(), m_SummonBossData) ) {
        // 召唤boss的金币在OnUserKillFish时赋值成0了, 战令经验按配表鱼分走
        int64 avgGold = GetTurretRate()*(int64)fish->GetScore();
        m_pUser->AddBattlePassExp(avgGold/10000);

        m_SummonBossData._total_gold = fish->GetKillerCost();
        m_SummonBossData._expect_num = fish->GetKillerExpectNum();
        m_SummonBossData._fish_score = fish->GetKillerSummonBossScore();
        m_SummonBossData._is_bonus_boss = fish->IsBonusBoss();
        m_SummonBossData._boss_point_param = fish->GetBossPointParam();

        // 召唤boss击杀后会开始做倍率表现, 需要暂停瞄准急速和狂暴
        m_SkillLock.halt();
        m_SkillFast.halt();
        m_SkillFury.halt();
        m_SkillSuper.halt();
        m_pUser->OnBossKilled(m_SummonBossData._fish_index);
        m_pUser->OnHuntKilled(fish->GetBossGuid());


        m_pTable->OnSummonBossDead(fish, GetKey());

        msg.add_summonbossrate(m_SummonBossData._rate1);
        msg.set_summonjarsresetline(m_SummonBossData._jar_reset_rate);
        m_SummonBossData.ForEachDoorNormal([&](int32 num){
            msg.add_summondoorsnormal(num);
        });

        m_SummonBossData.ForEachJarNormal([&](const BossJarInfo& info){
            *msg.add_summonjarsnormal() = info;
        });

        if( m_SummonBossData._rate2 > 0 ) {
            msg.add_summonbossrate(m_SummonBossData._rate2);

            m_SummonBossData.ForEachDoorReset([&](int32 num){
                msg.add_summondoorsreset(num);
            });

            m_SummonBossData.ForEachJarReset([&](const BossJarInfo& info){
                *msg.add_summonjarsreset() = info;
            });
        }
    }
}

void FishPlayer::GetExtraDrop(int32 fishIndex, map<int32, int64>& mapItem) {
    tagJsonFishData tagFish;
    if( !JDATA->FishDataPtr()->ByID(m_SummonBossData._fish_index, tagFish) ) {
        return;
    }
    if( tagFish._ItemDropParam.size() % 3 == 0 ) {
        for( size_t i = 0 ; i < tagFish._ItemDropParam.size() ; i+=3 ) {
            int32 add = GetTurretStarAttr(tagFish._ItemDropParam[i]);
            if( GlobalUtils::GetRandNumber(0,100) <= tagFish._ItemDropParam[i+2]*(1000+add)/1000 ) {
                sHLottery->GetLootItem(tagFish._ItemDropParam[i+1], mapItem);
            }
        }
    }
    if( IsUser() && tagFish._HRItemDropParam.size() % 3 == 0 ) {
        for( size_t i = 0 ; i < tagFish._HRItemDropParam.size() ; i+=3 ) {
            int32 add = m_pUser->GetHeroRelationAttr(tagFish._HRItemDropParam[i]);
            if( GlobalUtils::GetRandNumber(0,100) <= tagFish._HRItemDropParam[i+2]*(1000+add)/1000 ) {
                sHLottery->GetLootItem(tagFish._HRItemDropParam[i+1], mapItem);
            }
        }
    }
}

int32 FishPlayer::GetSummonBossIndex() {
    if( !IsUser() ) {
        return 0;
    }
    return m_pUser->PBGetCurBossIndex();
}

// 在转换完弹头以后剩余的金币, 奖池金币, 核弹id, 核弹数量, 击杀概率, 鱼的id
void FishPlayer::SummonBossReward(bool resetRate, bool hammerNormal, bool hammerReset, bool byMail, SyncSummonBossReward& msg) {
    if( !IsUser() ) {
        LOGERROR("SUMMON no user[%lu]", GetKey());
        return;
    }
    if( m_SummonBossData._fish_index == 0 ) {
        // 无奖励
        LOGINFO("SUMMON[%lu] no data", GetKey());
        return;
    }
    if( resetRate && m_SummonBossData._rate2 == 0 ) {
        LOGERROR("SUMMON no reset, flag error[%lu][%d][%d]", m_pUser->GetKey(), m_SummonBossData._fish_index, m_SummonBossData._rate1);
        return;
    }
    m_pUser->CounterAdd(e_jsonGeneralTaskDynamicTarget_Summon_Boss_Kill, 1);
    if( m_SummonBossData._fish_index == JDATA->SystemConstPtr()->GetSunquanBossID() ) {
        m_pUser->CounterAdd(e_jsonGeneralTaskDynamicTarget_Kill_Sunquan, 1);
    }
    else if( m_SummonBossData._fish_index == JDATA->SystemConstPtr()->GetCaocaoBossID() ) {
        m_pUser->CounterAdd(e_jsonGeneralTaskDynamicTarget_Kill_Caocao, 1);
    }
    else if( m_SummonBossData._fish_index == JDATA->SystemConstPtr()->GetLvbuBossID() ) {
        m_pUser->CounterAdd(e_jsonGeneralTaskDynamicTarget_Kill_Lvbu, 1);
    }

    int64 oldBossPoint = m_pUser->PBGetSummonBossPoint();
    msg.set_fish_index(m_SummonBossData._fish_index);
    int64 resetPoint = 0;
    int32 mhGold = 0;
    map<int32, int64> mapItem;
    int64 rate = m_SummonBossData._rate1;
    if( resetRate ) {
        rate = m_SummonBossData._rate2;
        resetPoint = m_SummonBossData._avg_reset_tax*m_SummonBossData._curB;
    }
    if( m_SummonBossData._fish_index == JDATA->SystemConstPtr()->GetMenghuoBossID() ) {
        auto result = m_SummonBossData.GetMenghuoReward(resetRate, hammerNormal, hammerReset, sHero->GetMenghuoGoldRate(), mapItem);
        rate = TUPLE0(result);
        mhGold = TUPLE1(result);
    }

    msg.set_rate(rate);
    // 炮倍获得的钱, 要拆成核弹和钱
    int64 reward = m_SummonBossData._curB * rate;
    int64 point = (m_SummonBossData._fish_score - m_SummonBossData._expect_num)*m_SummonBossData._curB + resetPoint;
    if( m_SummonBossData._is_bonus_boss ) {
        point = point*m_SummonBossData._boss_point_param/1000;
    }
    m_pUser->PBIncSummonBossPoint(point);

    auto data = m_pTable->SplitGold(reward, m_SummonBossData._fish_index);
    int64 gold = TUPLE0(data);
    msg.set_fish_gold(gold);

    int32 bombId = TUPLE1(data);
    int64 bombNum = TUPLE2(data);
    if( bombId != 0 && bombNum != 0 ) {
        if( m_SummonBossData._fish_index == JDATA->SystemConstPtr()->GetCaocaoBossID() ) {
            bombNum = bombNum * (1000 + m_pUser->GetHeroRelationAttr(e_jsonHeroRelationAllAttribute_KillCaocaoNuclear)) / 1000;
        }
        auto item = msg.add_item();
        item->set_item_id(TUPLE1(data));
        item->set_item_change(bombNum);
        item->set_item_num(bombNum);
    }
    // boss的额外掉落, 这里始终要掉一份
    FishFish::DoAdditionLoot(m_SummonBossData._fish_index, mapItem);
    // 检查一下受各种属性影响的掉落是否出现
    GetExtraDrop(m_SummonBossData._fish_index, mapItem);
    for( auto& it : mapItem ) {
        int64 realNum = it.second;
        // TODO 这里的受控道具实际分两种, 一种要受炮倍控制, 一种不受, 目前全都收到炮倍控制, 所以暂时就这么处理
        // 后续如果有道具不受炮倍控制掉落, 但是有系统控制的额外掉率, 则需要在这里分开处理
        if( sHBuff->ItemHasExtraDropRate(it.first) ) {
            int32 extraRate = sGameUtils->GetItemExtraDropRate(it.first);
            extraRate += m_pUser->GetItemExtraDropRate(it.first, sGameUtils->GetFakeTimeNow());
            extraRate *= 10;
            switch(JDATA->ItemPtr()->MainTypeByID(it.first)) {
            case e_jsonItemMainType_HeroSpirit:
                extraRate += m_attrHeroStar[e_jsonHeroSetAllAttribute_HeroSpiritLoot];// 炮台星级对照的
                break;
            case e_jsonItemMainType_LvbuSpirit:
                extraRate += m_pUser->GetHeroRelationAttr(e_jsonHeroRelationAllAttribute_LvbuSpiritLoot);
                break;
            default:
                break;
            }
            // 受掉落buff控制的才需要重新计算数量
            float p1 = 1.0f/(1.0f + m_pTable->GetMaxTurretRate()*1.0f/GetTurretRate()) + JDATA->SystemConstPtr()->GetAdditionLootParamM()*1.0f/100.0f;
            int32 N = max((int32)(realNum*pow(p1, JDATA->SystemConstPtr()->GetAdditionLootParamK()*1.0f/100)), 1);
            N = N*(1000+extraRate)/1000;
            realNum = N;
        }
        if(JDATA->ItemPtr()->MainTypeByID(it.first) == e_jsonItemMainType_ShiningStone ) {
            realNum = realNum*(1000+m_pUser->GetHeroRelationAttr(e_jsonHeroRelationAllAttribute_ShiningStoneLoot))/1000;
        }
        auto item = msg.add_item();
        item->set_item_id(it.first);
        item->set_item_change(realNum);
        item->set_item_num(realNum);

        m_pUser->ItemChange(it.first, realNum, ELRI_KillSummonBoss, false);
    }

    int64 poolGold = 0;
    msg.set_use_pool(false);
    if( rate >= m_SummonBossData._pool_min_rate ) {
        // 分奖池
        msg.set_use_pool(true);
        poolGold = sRankingList->TableSummonPoolDecPct(m_pTable->GetTableIndex(), m_SummonBossData._pool_bonus_rate+mhGold*5, m_SummonBossData._curB, m_SummonBossData._maxB);
        msg.set_gold(poolGold);
        gold += poolGold;
        // 击杀了要系统广播
        if( m_SummonBossData._pool_yell_id != 0 ) {
            list<string> lst;
            lst.push_back(GetUserStarName());
            lst.push_back(GlobalUtils::ToString(GetTurretRate()));
            lst.push_back(GlobalUtils::ToString(rate));
            lst.push_back(GlobalUtils::GetNumberString(poolGold));
            sDispatcher->broadcast_rolling_msg(m_SummonBossData._pool_yell_id, "", lst);
        }

        // 房间内的击杀列表
        SummonBossKiller killer;
        killer.set_name(GetUserName());
        killer.set_rate(GlobalUtils::ToString(rate));
        killer.set_gold(GlobalUtils::ToString(poolGold));
        killer.set_fish_index(GlobalUtils::ToString(m_SummonBossData._fish_index));

        sRankingList->AddSummonPoolKiller(m_pTable->GetTableIndex(), killer);
    }
    else {
        // 没有触发奖池的击杀
        if( m_SummonBossData._normal_yell_id != 0
            && bombNum > 0 && rate >= m_SummonBossData._normal_yell_rate ) {
            // 触发了普通击杀公告
            list<string> lst;
            lst.push_back(GetUserStarName());
            lst.push_back(GlobalUtils::ToString(GetTurretRate()));
            lst.push_back(GlobalUtils::ToString(rate));
            lst.push_back(GlobalUtils::ToString(bombNum));
            lst.push_back(GlobalUtils::GetNumberString(bombNum*JDATA->ItemPtr()->ItemParamByID(bombId)));
            sDispatcher->broadcast_rolling_msg(m_SummonBossData._normal_yell_id, "", lst);
        }
    }
    if( byMail ) {
        map<int32, int64> mapBomb;
        mapBomb[bombId] = bombNum;
        sDispatcher->send_mail(m_pUser->GetKey(), JDATA->SystemConstPtr()->GetSlotBossMailID(), 0, gold, mapBomb, "", "");
    }
    else {
        m_pUser->ChangeGold(gold, ELRI_KillSummonBoss);
        m_pUser->ItemChange(bombId, bombNum, ELRI_KillSummonBoss, false);
    }
    m_pUser->UpdateBulletinData(m_SummonBossData._fish_index, 1, rate, 0);
    LOG_SUMMON_BOSS_KILLED_V2(sGameUtils->GetFakeTimeNow(),
                            m_pTable->GetTableIndex(),
                            m_SummonBossData._fish_index,
                            GetKey(),
                            m_SummonBossData._total_gold,
                            m_SummonBossData._expect_num,
                            m_SummonBossData._rate1,
                            m_SummonBossData._rate2,
                            gold,
                            poolGold,
                            bombId,
                            bombNum,
                            resetRate,
                            oldBossPoint,
                            m_pUser->PBGetSummonBossPoint());
    m_SummonBossData.reset();
    // 召唤boss奖励领取后, 恢复瞄准急速和狂暴
    m_SkillLock.resume();
    m_SkillFast.resume();
    m_SkillFury.resume();
    m_SkillSuper.resume();
}

void FishPlayer::OnKillTreasureFish(int32 fishId, int32 gid, set<int32>& cards) {
    if( !IsUser() ) {
        return;
    }
    m_pUser->RandCards(3, cards);

    tagTreasureFishData data;
    data._groupId = gid;
    data._cards = cards;
    m_mapTreasureFishData[fishId] = data;
}

int32 FishPlayer::RewardTreasureFish(int32 fishId) {
    auto it = m_mapTreasureFishData.find(fishId);
    if( it == m_mapTreasureFishData.end() ) {
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    m_pUser->RewardCards(it->second._groupId, it->second._cards);
    return JDATA->ErrorCodePtr()->GetSuccess();
}
