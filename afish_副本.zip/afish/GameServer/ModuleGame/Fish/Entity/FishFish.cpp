﻿#include "FishFish.h"
#include "Entity/FishRoute.h"
#include "Entity/FishTable.h"
#include "Entity/FishShoal.h"
#include "FishGame.h"

bool FishFish::Init(FishTable* pTable, FishShoal* pShoal, int32 fishId, int fishCfgId, FishRoute* route)
{
    m_pTable = pTable;
    m_pShoal = pShoal;
    m_Key = fishId;
    m_pRoute = route;
    m_UsedTableRouteId = 0;
    m_KillerCost = 0;
    m_KillerExpectNum = 0;
    m_KillerSummonBossScore = 0;
    m_BonusBoss = false;
    m_BossPointParam = 0;
    m_Summoner = 0;
    m_pRoute->SetFish(this);
    m_LifeTime = m_pRoute->GetLifeTime() + 5;
    m_CurLifeTick = 0;
    m_Owner = 0;
    m_BossGuid = 0;
    m_mapPlayerFish.clear();
    m_bEscaped = true;
    JDATA->FishDataPtr()->ByID(fishCfgId, m_FishData);
    if( m_FishData._FunctionID != 0 ) {
        JDATA->FishFunctionPtr()->ByID(m_FishData._FunctionID, m_FishFunction);
    }
    m_Score = GlobalUtils::GetRandNumber(m_FishData._ScoreMin, m_FishData._Score, m_FishData._ScoreSTDEV)*1.0f;
    if( m_pTable->IsClassic() ) {
        // 经典场才需要这个判定
        if( m_Score <= 0.0f ) {
            m_Score = 1.0f;
        }
    }
    if( IsTurnTableFish() ) {
        // 转盘鱼,由于需要做向下取整,所以分值要保证能整除,否则会导致客户端显示的和给的实际金币不符
        // 所以这里根据随机出来的分值,先计算N和M,然后重新算一次鱼分
        m_TurnTableN = GlobalUtils::GetRandNumber(2,9);// 内圈数字为2-9，总共8个数字，随机一个数字（N）
        m_TurnTableM = (((m_Score/m_TurnTableN)/10)*10);
        m_Score = m_TurnTableM*m_TurnTableN;
    }
    if( m_FishData._Type == e_jsonFishDataType_Boss ) {
        m_Owner = m_pTable->GetRandPlayerId();
    }
    float hpRate = m_pTable->GetHpParamByFishType(m_FishData._Type)/1000.0f;
    float pdRate = m_pTable->GetPdParamByFishType(m_FishData._Type)/1000.0f;
    float mdRate = m_pTable->GetMdParamByFishType(m_FishData._Type)/1000.0f;
    m_hpInfo.set_maxhp(m_FishData._FishHP*hpRate);
    m_hpInfo.set_curhp(m_FishData._FishHP*hpRate);
    m_hpInfo.set_curlifepart(m_FishData._LifePartNum);
    m_hpInfo.set_maxlifepart(m_FishData._LifePartNum);
    m_setQuestGroup.clear();
    for( size_t i = 0; i < m_FishData._QuestGroup.size(); i++ ) {
        m_setQuestGroup.insert(m_FishData._QuestGroup[i]);
    }
    _pd = m_FishData._PhysicalDefense * pdRate;
    _md = m_FishData._MagicDefense * mdRate;
    if( m_FishData._Simultaneous > 0 ) {
        m_pTable->IncLimitFish(m_FishData._ID);
    }
    if( m_pShoal != nullptr ) {
        m_pShoal->ChangeCurFishNum(1);
    }
    if( m_FishData._FundAddType == e_jsonFishDataFundAddType_Table ) {
        sHTableBoss->fetch(m_FishData._ID, m_TableBoss);
        m_TableBoss._last_reward_idx = initLastReward(m_TableBoss._cur, m_FishData._FundParam);
        if( m_TableBoss._last_reward_idx >= (int32)m_FishData._FundParam.size() - 2 ) {
            // 这里防一手bug, 如果已经领取过死亡奖励的还是被push回去了, 这里重置一下到初始状态
            m_TableBoss._cur = 0;
            m_TableBoss._last_reward_idx = -1;
        }
        m_TableBoss.Log();
    }
    else if( m_FishData._FundAddType == e_jsonFishDataFundAddType_World ) {
        // 初始化无其他操作
    }
    m_BossSlotParam.init(m_FishData._BossSlotParam);
    m_mapPlayerCost.clear();
    if( m_FishData._SummonRefreshRule.size() == 2 ) {
        m_pTable->TableFishSetFlag(m_Key, m_BossSlotParam._valid, m_FishData._SummonRefreshRule[1]>0, m_FishData._SummonRefreshRule[0]>0);
    }
    return true;
}

void FishFish::Update(int deltaMS)
{
    if( !IsValid() ) {
        return;
    }
    if (m_pTable->InFreeze() && m_FishData._CanFrozen)
    {
        return;
    }
    m_CurLifeTick += deltaMS;
}

void FishFish::OnRecycled() {
    if( m_pShoal != nullptr ) {
        m_pShoal->ChangeCurFishNum(-1);
        if( m_pShoal->GetCurFishNum() < 0 ) {
            LOGERROR("Recycle fish[%d] FATAL SHOAL[%d] [%d]", m_FishData._ID, m_pShoal->GetShoal()._ID, m_pShoal->GetCurFishNum());
        }
        m_pShoal = nullptr;
    }
    m_pTable->TableRecycleFish(this);
    if( IsSlotTableBoss() && m_TableBoss._idx != 0 ) {
        // 说明回收时没有被杀, 保存一下
        sHTableBoss->recycled(m_TableBoss);
        m_TableBoss.Log();
    }
    m_pRoute = nullptr;
    m_pTable = nullptr;
    m_Key = 0;
}

void FishFish::FillProto(uint64 userId, FishInfoProto& proto) {
    proto.set_id(GetKey());
    proto.set_fishid(GetIndex());
    proto.set_lifetimems(GetCurLifeTick());
    m_pRoute->GetRouteParamProto(*proto.mutable_routeparam());

    if( !m_pTable->IsClassic() ) {
        auto it = m_mapPlayerFish.find(userId);
        if( it == m_mapPlayerFish.end() ) {
            InitPlayerFish(userId);
            it = m_mapPlayerFish.find(userId);
        }
        *proto.mutable_hpinfo() = it->second;
    }
}

void FishFish::DoAdditionLoot(int32 fishIndex, map<int32, int64>& mapItem) {
    int32 lotterId = JDATA->FishDataPtr()->AdditionLotteryByID(fishIndex);
    map<int32, int32> mapTurret;// 渔场不会掉完整炮台,这里仅仅用于函数调用,后续不加进去
    map<int32, int32> mapSwing;// 渔场不会掉完整翅膀,这里仅仅用于函数调用,后续不加进去
    map<int32, int64> mapTempItem;
    if( lotterId != 0 ) {
        sHLottery->GetLotteryItem(lotterId, mapItem, mapTurret, mapSwing);
    }
}

void FishFish::DoLoot(int32 iTurretIndex, bool isSwingBond, map<int32, int64>& mapItem) {
    map<int32, int32> mapTurret;// 渔场不会掉完整炮台,这里仅仅用于函数调用,后续不加进去
    map<int32, int32> mapSwing;// 渔场不会掉完整翅膀,这里仅仅用于函数调用,后续不加进去
    if( m_FishData._LotteryID != 0 ) {
        sHLottery->GetLotteryItem(m_FishData._LotteryID, mapItem, mapTurret, mapSwing);
    }
    for( size_t n = 0 ; n < m_FishData._BombLotteryID.size() ; n+=3 ) {
        if( m_FishData._BombLotteryID[n] == iTurretIndex ) {
            if( isSwingBond ) {
                sHLottery->GetLotteryItem(m_FishData._BombLotteryID[n+2], mapItem, mapTurret, mapSwing);
            }
            else {
                sHLottery->GetLotteryItem(m_FishData._BombLotteryID[n+1], mapItem, mapTurret, mapSwing);
            }
        }
    }
    if( IsBombCardFish() && m_FishData._CardFishLootParam.size() == 2 ) {
        mapItem[JDATA->SystemConstPtr()->GetCollectionCardItemID()] = GlobalUtils::GetRandNumber(m_FishData._CardFishLootParam[0], m_FishData._CardFishLootParam[1]);
    }
}

void FishFish::OnDamagePct(uint64 userId, int32 rate) {
    int32 nDamage = m_FishData._FishHP*rate/1000;
    OnDamage(userId, nDamage);
}

void FishFish::OnDamage(uint64 userId, int32 nDamage) {
    auto it = m_mapPlayerFish.find(userId);
    if( it == m_mapPlayerFish.end() ) {
        InitPlayerFish(userId);
        return OnDamage(userId, nDamage);
    }
    int32 nCurHp = it->second.curhp() - nDamage;
    if( nCurHp <= 0 ) {
        it->second.set_curlifepart( it->second.curlifepart() - 1 );
        if( it->second.curlifepart() > 0 ) {
            it->second.set_curhp(m_FishData._FishHP);
        }
        else {
            it->second.set_curhp(0);
        }
    }
    else {
        it->second.set_curhp(nCurHp);
    }
    if( !m_pTable->IsClassic() ) {
        // 非经典场要同步血量
        SyncFishHp msg;
        msg.set_fish_id(GetKey());
        *msg.mutable_hpinfo() = it->second;
        WrapPacket pkg;
        LxGameHelper::MakeSyncFishHp(pkg, msg);
        m_pTable->SyncToAll(pkg);
    }
}

bool FishFish::GetDeathBuff(int32& buffId, int32& duration) {
    if( m_FishData._FunctionID == 0 ) {
        return false;
    }
    if( m_FishFunction._Type == e_jsonFishFunctionType_Laser
        || m_FishFunction._Type == e_jsonFishFunctionType_DrillingBit
        || m_FishFunction._Type == e_jsonFishFunctionType_Missile ) {
        tagJsonBuff tagBuff;
        if( !JDATA->BuffPtr()->ByID(m_FishFunction._Param, tagBuff)) {
            return false;
        }
        buffId = tagBuff._ID;
        duration = tagBuff._Duration;
        return true;
    }
    return false;
}

void FishFish::OnDead() {
    m_bEscaped = false;
    m_CurLifeTick = (int32)(m_LifeTime*1000.0f)+1;
    if( !IsSmallFish() ) {
        m_pTable->FishPoolLinePtr()->OnFishDead();
    }
}

tuple<bool, int64> FishFish::SlotTableBossOnHit(int64 gold) {
    if( !IsSlotTableBoss() || m_FishData._FundParam.size() == 0 || m_FishData._FundParam.size() % 2 != 0 ) {
        return std::make_tuple(false, 0);
    }
    int32 rewardIdx = -1;
    m_TableBoss._cur += gold;
    // 检查是否触发返奖
    int32 checkIdx = (m_TableBoss._last_reward_idx==-1)?0:(m_TableBoss._last_reward_idx+2);
    if( (int32)m_FishData._FundParam.size() > checkIdx+1 && m_TableBoss._cur >= m_FishData._FundParam[checkIdx] ) {
        // 触发返奖
        m_TableBoss._last_reward_idx = checkIdx;
        rewardIdx = checkIdx;
        bool killed = false;
        if( rewardIdx >= (int32)m_FishData._FundParam.size()-2 ) {
            killed = true;
            OnDead();
            m_TableBoss._idx = 0;// 重置成0, OnRecycle的时候就不会去调用 sHTableBoss->recycled
        }
        m_TableBoss.Log();
        return std::make_tuple(killed, m_FishData._FundParam[checkIdx+1]);
    }
    return std::make_tuple(false, 0);
}
