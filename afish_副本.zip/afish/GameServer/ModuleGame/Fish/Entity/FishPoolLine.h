#pragma once

#include "ServerDefine.h"
#include "GameUtils.h"

// 鱼池刷新类型
enum E_FishPoolRefreshType {
    EFPRT_None      = 0,
    EFPRT_ActTime   = 1,    // 活动鱼池按间隔刷新
    EFPRT_ActKill   = 2,    // 活动鱼池按击杀刷新
    EFPRT_FixTime   = 3,    // 配置鱼池按间隔刷新
    EFPRT_FixKill   = 4,    // 配置鱼池按击杀刷新
};

struct tagFishPool {
    // 活动开始时间
    int64 _startTime;
    // 活动结束时间
    int64 _endTime;
    // 鱼池id
    int32 _poolId;
    int32 _type;
    int64 _param;
    // 生存时间
    int64 _lifeTime;
    /**
     * 活动池与配置池同参数
     *  _type == e_jsonGamePlayAdditionFishPool_Kill_Fish
     *      _curKillNum 当前击杀非小鱼的数量
     *  _type == e_jsonGamePlayAdditionFishPool_Interval_Time
     *      配置鱼池 _curDefaultPoolTick 当前默认鱼池存在时间
     *      活动鱼池 _curInPoolTick 活动期间在可用池中存在的时间
     */
    union
    {
        int64 _uData;
        int64 _curKillNum;
        int64 _curDefaultPoolTick;
        int64 _curInPoolTick;
    };
    tagFishPool() {
        Reset();
    }
    void Reset() {
        _startTime = 0;
        _endTime = 0;
        _poolId = 0;
        _type = 0;
        _param = 0;
        _lifeTime = 0;
        _uData = 0;
    }
    tagFishPool& operator=(const tagFishPool& rhs) {
        _startTime = rhs._startTime;
        _endTime = rhs._endTime;
        _poolId = rhs._poolId;
        _type = rhs._type;
        _param = rhs._param;
        _lifeTime = rhs._lifeTime;
        _uData = rhs._uData;
        return *this;
    }
    int32 GetRealType() {
        if( _poolId == 0 ) {
            return EFPRT_None;
        }
        if( _startTime > 0 ) {
            // 活动
            if( _type == e_jsonGamePlayAdditionFishPool_Kill_Fish ) {
                return EFPRT_ActKill;
            }
            else {
                return EFPRT_ActTime;
            }
        }
        else{
            // 配置
            if( _type == e_jsonGamePlayAdditionFishPool_Kill_Fish ) {
                return EFPRT_FixKill;
            }
            else {
                return EFPRT_FixTime;
            }
        }
    }
    void Update(bool isDefaultPool, int64 tNow, int32 dt) {
        switch(GetRealType()) {
        case EFPRT_ActTime:
            if( tNow >= _startTime ) {
                _curInPoolTick += dt;
            }
            break;
        case EFPRT_FixTime:
            if( isDefaultPool ) {
                _curDefaultPoolTick += dt;
            }
            break;
        default:
            break;
        }
    }
    // 判断是否已经无效
    bool IsValid(int64 tNow) {
        switch(GetRealType()) {
        case EFPRT_ActTime:
        case EFPRT_ActKill:
            return tNow < _endTime;
        case EFPRT_FixTime:
        case EFPRT_FixKill:
            return true;
        default:
            return false;
        }
    }
    bool CanActivate(int64 tNow) {
        switch(GetRealType()) {
        case EFPRT_ActTime:
            return _curInPoolTick >= _param;
        case EFPRT_FixTime:
            return _curDefaultPoolTick >= _param;
        case EFPRT_ActKill:
        case EFPRT_FixKill:
            return _curKillNum >= _param;
        default:
            return false;
        }
    }
    void OnFishDead() {
        switch(GetRealType()) {
        case EFPRT_ActKill:
        case EFPRT_FixKill:
            _curKillNum++;
            break;
        default:
            break;
        }
    }
};

class FishPoolLine
{
// 当前是否在使用默认鱼池
GETSET_BOOL(DefaultPoolInUse);
public:
    FishPoolLine() {
        Reset();
    }
    ~FishPoolLine() {};
public:
    // 配置中的鱼池
    // type eJsonGamePlayAdditionFishPool
    void AddFishPool(int32 type, int32 param, int32 poolId) {
        AddFishPool(0, 0, type, param, poolId);
    }
    // 鱼池结束后重新加回到可用池
    void AddFishPool(const tagFishPool& rhs) {
        AddFishPool(rhs._startTime, rhs._endTime, rhs._type, rhs._param, rhs._poolId);
    }
    // 按时间段增加活动鱼池
    void AddFishPool(int64 tStart, int64 tEnd, int32 type, int32 param, int32 poolId) {
        if( type >= e_jsonGamePlayAdditionFishPool_end || type <= e_jsonGamePlayAdditionFishPool_start ) {
            return;
        }
        tagFishPool tag;
        tag._startTime = tStart;
        tag._endTime = tEnd;
        tag._poolId = poolId;
        tag._type = type;
        tag._param = param;
        tag._lifeTime = JDATA->FishPoolPtr()->LifeTimeByID(poolId);
        if( tag._lifeTime > 0 ) {
            m_mapPools[poolId] = tag;
        }
    }
    void Update(int64 tNow, int32 dt) {
        // 检测 m_mapPools 里有没有可以触发的鱼池,触发了就扔到m_lstPoolLine里
        for( auto it = m_mapPools.begin(); it != m_mapPools.end(); ) {
            if( !it->second.IsValid(tNow) ) {
                // 活动鱼池, 如果已经过期了, 就删除
                m_mapPools.erase(it++);
                continue;
            }
            if( it->second.CanActivate(tNow) ) {
                m_lstPoolLine.push_back(it->second);
                m_mapPools.erase(it++);
                continue;
            }
            it->second.Update(m_DefaultPoolInUse, tNow, dt);
            ++it;
        }
        for( auto it = m_lstPoolLine.begin() ; it != m_lstPoolLine.end() ; ) {
            if( !(*it).IsValid(tNow) ) {
                // 活动鱼池, 如果已经过期了, 就删除
                m_lstPoolLine.erase(it++);
                continue;
            }
            ++it;
        }
    }
    void OnFishDead() {
        for( auto it = m_mapPools.begin(); it != m_mapPools.end(); ++it) {
            it->second.OnFishDead();
        }
    }
    void Reset() {
        m_DefaultPoolInUse = false;
        m_lstPoolLine.clear();
        m_mapPools.clear();
    }
    bool IsValid() {
        return !m_mapPools.empty();
    }
    bool FetchFishPool(tagFishPool& lhs) {
        if( m_lstPoolLine.empty() ) {
            return false;
        }
        lhs = m_lstPoolLine.front();
        m_lstPoolLine.pop_front();
        return true;
    }
    void ForEachKillPool(std::function<void(int32, int32, int32)> func) {
        for( auto it = m_mapPools.begin(); it != m_mapPools.end(); ++it ) {
            switch( it->second.GetRealType() ) {
            case EFPRT_ActKill:
            case EFPRT_FixKill:
                func(it->second._poolId, (int32)it->second._curKillNum, (int32)it->second._param);
                break;
            default:
                break;
            }
        }
        for( auto it = m_lstPoolLine.begin() ; it != m_lstPoolLine.end() ; ++it ) {
            switch( (*it).GetRealType() ) {
            case EFPRT_ActKill:
            case EFPRT_FixKill:
                func((*it)._poolId, (int32)(*it)._curKillNum, (int32)(*it)._param);
                break;
            default:
                break;
            }
        }
    }
private:
    // 队列中的鱼池
    list<tagFishPool> m_lstPoolLine;
    // 目前可用的鱼池
    map<int32, tagFishPool> m_mapPools;
};
