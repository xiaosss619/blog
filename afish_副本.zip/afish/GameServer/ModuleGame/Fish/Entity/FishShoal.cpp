#include "FishShoal.h"
#include "GameUtils.h"
#include "Entity/FishTable.h"
#include "Entity/FishRoute.h"
#include "Entity/FishFish.h"
#include "FishGame.h"

bool FishShoal::Init(FishTable* pTable, int32 shoalId, const tagJsonFishShoal& rhs) {
    m_pTable = pTable;
    m_Key = shoalId;
    m_CurFishNum = 0;
    m_pLogicGroup = nullptr;
    m_Shoal = rhs;
    m_bOnce = false;
    m_Valid = true;
    m_lifeTickForInterval = 0;
    m_lstNormalFish.clear();
    m_fishRoute.clear();
    m_mapTides.clear();
    for( size_t i = 0; i < rhs._RouteIDs.size(); ++i ) {
        m_fishRoute.push_value(10, rhs._RouteIDs[i]);
    }
    m_fishRoute.set_extra(true, 1);
    m_curFishRoute = m_fishRoute;

    m_fishGroup.clear();
    m_lstDelayTides.clear();
    if( !CheckRefreshRule() ) {
        LOGERROR("shoal[%d] has invalid RefreshRule id", rhs._ID);
        return false;
    }
    if( m_Shoal._MoveType == e_jsonFishShoalMoveType_Route ) {
        // 刷单条鱼
        if( !sHFish->GetFishGroupRollInfo(rhs._FishGroupID, m_fishGroup) ) {
            LOGERROR("shoal has invalid randomroute fishgroup id[%d]", rhs._FishGroupID);
            return false;
        }
    }
    else if( m_Shoal._MoveType == e_jsonFishShoalMoveType_Generator ) {
        // 刷鱼阵
    }
    else {
        LOGERROR("shoal has invalid move type[%d]", m_Shoal._MoveType);
        return false;
    }
    return true;
}

bool FishShoal::CheckRefreshRule() {
    if( m_Shoal._RefreshRule.size() == 0 ) {
        return false;
    }
    switch( m_Shoal._RefreshRule[0] ) {
    case e_jsonFishShoalRefreshRule_Basic:
        return m_Shoal._RefreshRule.size() == 2;
    case e_jsonFishShoalRefreshRule_Once:
        return m_Shoal._RefreshRule.size() == 1;
    case e_jsonFishShoalRefreshRule_Cumulative:
        return m_Shoal._RefreshRule.size() == 3;
    case e_jsonFishShoalRefreshRule_Interval:
        return m_Shoal._RefreshRule.size() == 2;
    default:
        return false;
    }
}

void FishShoal::Update(int32 dt) {
    if( m_pTable->GetLifeTick() < (int64)m_Shoal._DelayTime ) {
        return;
    }
    if( m_pTable->InFreeze() ) {
        // 冰冻状态,不计算任何时间
        return;
    }
    m_lifeTickForInterval += dt;
    for( auto it = m_lstDelayTides.begin() ; it != m_lstDelayTides.end() ; ) {
        (*it).Update(dt);
        if( (*it).CanCreate() ) {
            int32 routeId = 0;
            if( m_Shoal._RouteIDs.size() > 0 ) {
                // >0表示配置了路径点,需要鱼阵走路径点,取不到说明路径被使用了,那么等下一次过来再刷新
                routeId = GetFishRoute();
                if( routeId == 0 ) {
                    break;
                }
            }
            auto ptr = m_pTable->GetGame()->CreateTide(this, (*it)._tideId, routeId);
            if( ptr != nullptr ) {
                m_mapTides[ptr->GetKey()] = ptr;
                if( routeId != 0 ) {
                    m_pTable->UseFishRoute(routeId, GlobalUtils::GetTickCount() + TIDE_ROUTE_LIFE_TICK);
                    ptr->SetUsedTableRouteId(routeId);
                }
            }
            m_lstDelayTides.erase(it++);
        }
        else {
            ++it;
        }
    }

    list<IntPair> lst;
    for( auto it = m_lstNormalFish.begin() ; it != m_lstNormalFish.end() ;) {
        int32 maxNum = JDATA->FishDataPtr()->SimultaneousByID((*it));
        if( maxNum > 0 && m_pTable->IsFishLimited((*it), maxNum) ) {
            // 受限于刷新数量,暂时不刷新这条
            it++;
        }
        else {
            int32 routeId = GetFishRoute();
            if( routeId == 0 ) {
                // 没路径了,不刷鱼
                break;
            }
            IntPair ip;
            ip.set_key((*it));
            ip.set_value(routeId);
            lst.push_back(ip);
            m_pTable->UseFishRoute(routeId, GlobalUtils::GetTickCount() + FISH_ROUTE_LIFE_TICK);
            m_lstNormalFish.erase(it++);
        }
    }
    if( !lst.empty() ) {
        m_pTable->TableCreateFishes(lst, this);
    }

    if( m_Shoal._MoveType == e_jsonFishShoalMoveType_Generator ) {
        // 鱼阵
        DoTideUpdate(dt);
    }
    else {
        // 普通鱼组刷鱼
        DoNormalUpdate(dt);
    }

    for( auto it = m_mapTides.begin(); it != m_mapTides.end(); ) {
        if( it->second->IsValid() ) {
            it->second->Update(dt);
            ++it;
        }
        else {
            m_pTable->ReturnFishRoute(it->second->GetUsedTableRouteId());
            m_pTable->GetGame()->RemoveTide(it->second);
            m_mapTides.erase(it++);
        }
    }
}

void FishShoal::OnRecycled() {
    for( auto it = m_mapTides.begin(); it != m_mapTides.end(); ++it ) {
        m_pTable->GetGame()->RemoveTide(it->second);
    }
    m_mapTides.clear();
    m_lstNormalFish.clear();
    m_Key = 0;
}

void FishShoal::DoNormalUpdate(int32 dt) {
    int32 needFishNum = 0;
    switch( m_Shoal._RefreshRule[0] ) {
    case e_jsonFishShoalRefreshRule_Basic:
        needFishNum = (m_Shoal._TotalFishNum - m_CurFishNum - m_lstNormalFish.size());
        if( needFishNum < 0 ) {
            needFishNum = 0;
        }
        break;
    case e_jsonFishShoalRefreshRule_Once:
        if( !m_bOnce ) {
            m_bOnce = true;
            needFishNum = m_Shoal._TotalFishNum;
        }
        break;
    case e_jsonFishShoalRefreshRule_Cumulative:
        if( m_pTable->GetTypeFishKilledNum(m_Shoal._RefreshRule[1]) >= m_Shoal._RefreshRule[2] ) {
            m_pTable->ResetTypeFishCounter(m_Shoal._RefreshRule[1]);
            needFishNum = m_Shoal._TotalFishNum;
        }
        break;
    case e_jsonFishShoalRefreshRule_Interval:
        if( m_lifeTickForInterval >= m_Shoal._RefreshRule[1] ) {
            m_lifeTickForInterval = 0;
            needFishNum = m_Shoal._TotalFishNum;
        }
        break;
    default:
        break;
    }
    for( int32 i = 0 ; i < needFishNum ; i++ ) {
        m_lstNormalFish.push_back( m_fishGroup.roll() );
    }
}

void FishShoal::DoTideUpdate(int32 dt) {
    bool needTide = false;
    switch( m_Shoal._RefreshRule[0] ) {
    case e_jsonFishShoalRefreshRule_Once:
        if( !m_bOnce ) {
            m_bOnce = true;
            needTide = true;
        }
        break;
    case e_jsonFishShoalRefreshRule_Cumulative:
        if( m_pTable->GetTypeFishKilledNum(m_Shoal._RefreshRule[1]) >= m_Shoal._RefreshRule[2] ) {
            m_pTable->ResetTypeFishCounter(m_Shoal._RefreshRule[1]);
            needTide = true;
        }
        break;
    case e_jsonFishShoalRefreshRule_Interval:
        if( m_lifeTickForInterval >= m_Shoal._RefreshRule[1] ) {
            m_lifeTickForInterval = 0;
            needTide = true;
        }
        break;
    default:
        break;
    }
    if( needTide ) {
        GenerateDelayTide(m_Shoal._FishGroupID, 0);
    }
}

// 根据鱼阵id, 递归生成刷新序列
void FishShoal::GenerateDelayTide(int32 genId, int32 delay) {
    tagJsonFishGenerator gen;
    if( JDATA->FishGeneratorPtr()->ByID(genId, gen) ) {
        if( gen._Type == e_jsonFishGeneratorType_Combination ) {
            // 组合型鱼阵读取到鱼群里,之后按时间刷
            if( gen._Param.size() > 2 ) {
                int32 genDelay = delay;
                for( size_t i = 0; i < gen._Param.size(); i+=2 ) {
                    genDelay += gen._Param[i];
                    GenerateDelayTide(gen._Param[i+1], genDelay);
                }
            }
        }
        else {
            // 下一帧马上刷
            tagDelayTide tide(genId, delay);
            m_lstDelayTides.push_back(tide);
        }
    }
}

void FishShoal::FillTideProto(FishRoomProto& roomProto) {
    for( auto & tide : m_mapTides ) {
        auto pTide = roomProto.add_generators();
        pTide->set_generatorid(tide.second->GetGeneratorId());
        pTide->set_lifetimems((int32)tide.second->GetElapsedTime()*1000);
        pTide->set_startid(tide.second->GetFishStartId());
        pTide->set_routeid(tide.second->GetRouteId());
        pTide->set_posx((int32)tide.second->GetPosition().x);
        pTide->set_posy((int32)tide.second->GetPosition().y);
    }
}

int32 FishShoal::GetFishRoute() {
    if( m_curFishRoute.empty() ) {
        m_curFishRoute = m_fishRoute;
    }
    int nLoopMax = 100;
    while( !m_curFishRoute.empty() && nLoopMax-- ) {
        int32 routeId = m_curFishRoute.roll();
        if( !m_pTable->IsFishRouteUsed(routeId) ) {
            return routeId;
        }
    }
    return 0;
}
