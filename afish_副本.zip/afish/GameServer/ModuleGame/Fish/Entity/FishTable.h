﻿#pragma once

#include "ServerDefine.h"
#include "EntityPool.h"
#include "FishUtils.h"
#include "FishPoolLine.h"

// 获取房间人数的类型
enum E_GetPlayerType {
    ERPT_All    = 0,    // 都包括
    ERPT_User   = 1,    // 只包括玩家
};

enum E_UseSummonSkillResult {
    EUSSR_Failed = 0,   // 参数错误
    EUSSR_Boss = 1,     // 召唤了boss
    EUSSR_CardFish = 2, // 召唤了卡牌鱼
};

struct tagRoomTarget {
    // 获得的金币
    int64 _gold;
    // 获得的升星石经验
    int32 _star_exp;
    // 鱼的总死亡条数
    int32 _total_fish_killed;
    // 翅膀技能使用次数
    int32 _swing_skill_use_num;
    // 指定id鱼死亡数量
    map<int32, int32> _fish_killed;
    // 指定taskgroupId的鱼死亡数量
    map<int32, int32> _group_fish_killed;
    // 道具使用次数
    map<int32, int32> _skill_use_num;
    // 道具数量
    map<int32, int64> _items;
    // 指定类型技能使用次数
    map<int32, int32> _type_skill_use_num;
    // 指定taskgroupId的鱼存活到路径终点的数量
    map<int32, int32> _group_fish_escaped;
    tagRoomTarget() {
        reset();
    }
    string GetDebugString() {
        ostringstream oss;
        oss << " _gold : " << _gold;
        oss << " _star_exp : " << _star_exp;
        oss << " _total_fish_killed : " << _total_fish_killed;
        oss << " _swing_skill_use_num : " << _swing_skill_use_num;
        oss << " _total_fish_killed : " << _total_fish_killed;
        oss << " _fish_killed : {";
        for( auto & it : _fish_killed ) {
            oss << " " << it.first << " : " << it.second << " ";
        }
        oss << " }";
        oss << " _group_fish_killed : {";
        for( auto & it : _group_fish_killed ) {
            oss << " " << it.first << " : " << it.second << " ";
        }
        oss << " }";
        oss << " _group_fish_escaped : {";
        for( auto & it : _group_fish_escaped ) {
            oss << " " << it.first << " : " << it.second << " ";
        }
        oss << " }";
        oss << " _skill_use_num : {";
        for( auto & it : _skill_use_num ) {
            oss << " " << it.first << " : " << it.second << " ";
        }
        oss << " }";
        oss << " _type_skill_use_num : {";
        for( auto & it : _type_skill_use_num ) {
            oss << " " << it.first << " : " << it.second << " ";
        }
        oss << " }";
        oss << " _items : {";
        for( auto & it : _items ) {
            oss << " " << it.first << " : " << it.second << " ";
        }
        oss << " }";
        return oss.str();
    }
    void reset() {
        _gold = 0;
        _star_exp = 0;
        _items.clear();
        _total_fish_killed = 0;
        _swing_skill_use_num = 0;
        _fish_killed.clear();
        _type_skill_use_num.clear();
        _group_fish_killed.clear();
        _group_fish_escaped.clear();
        _skill_use_num.clear();
    }
    tagRoomTarget& operator=(const tagRoomTarget & rhs) {
        _gold = rhs._gold;
        _star_exp = rhs._star_exp;
        _items = rhs._items;
        _total_fish_killed = rhs._total_fish_killed;
        _swing_skill_use_num = rhs._swing_skill_use_num;
        _fish_killed = rhs._fish_killed;
        _group_fish_killed = rhs._group_fish_killed;
        _group_fish_escaped = rhs._group_fish_escaped;
        _type_skill_use_num = rhs._type_skill_use_num;
        _skill_use_num = rhs._skill_use_num;
        return *this;
    }
    bool IsKillFishMoreThan(int32 fishIndex, int32 num) {
        if( fishIndex == 0 ) {
            return _total_fish_killed >= num;
        }
        else {
            auto it = _fish_killed.find( fishIndex );
            if( it != _fish_killed.end() ) {
                return it->second >= num;
            }
            return false;
        }
    }
    bool IsKillFishTypeMoreThan(int32 taskGroup, int32 num) {
        auto it = _group_fish_killed.find( taskGroup );
        if( it != _group_fish_killed.end() ) {
            return it->second >= num;
        }
        return false;
    }
    bool IsKillFishTypeLessThan(int32 taskGroup, int32 num) {
        auto it = _group_fish_killed.find( taskGroup );
        if( it != _group_fish_killed.end() ) {
            return it->second < num;
        }
        return true;
    }
    bool IsKillFishLessThan(int32 fishIndex, int32 num) {
        if( fishIndex == 0 ) {
            return _total_fish_killed < num;
        }
        else {
            auto it = _fish_killed.find( fishIndex );
            if( it != _fish_killed.end() ) {
                return it->second < num;
            }
            return true;
        }
    }
    bool IsEscapeFishGroupMoreThan(int32 taskGroup, int32 num) {
        auto it = _group_fish_escaped.find( taskGroup );
        if( it != _group_fish_escaped.end() ) {
            return it->second >= num;
        }
        return false;
    }
    bool IsEscapeFishGroupLessThan(int32 taskGroup, int32 num) {
        auto it = _group_fish_escaped.find( taskGroup );
        if( it != _group_fish_escaped.end() ) {
            return it->second < num;
        }
        return true;
    }
    bool IsSwingSkillUseLessThan(int32 notUsed, int32 num) {
        return _swing_skill_use_num < num;
    }
    bool IsCommonSkillUseLessThan(int32 itemId, int32 num) {
        auto it = _skill_use_num.find( itemId );
        if( it != _skill_use_num.end() ) {
            return it->second < num;
        }
        return true;
    }
    bool IsTypeSkillUseLessThan(int32 skillType, int32 num) {
        auto it = _type_skill_use_num.find( skillType );
        if( it != _type_skill_use_num.end() ) {
            return it->second < num;
        }
        return true;
    }
    bool IsGetGoldMoreThan(int64 gold) {
        return _gold >= gold;
    }
    bool IsGetExpMoreThan(int32 exp) {
        return _star_exp >= exp;
    }
    bool IsGetItemMoreThan(int32 itemId, int64 num) {
        auto it = _items.find(itemId);
        if( it == _items.end() ) {
            return false;
        }
        return it->second >= num;
    }
    // 击杀鱼数量
    int32 GetKillFishNum(int32 fishIndex) {
        if( fishIndex == 0 ) {
            return _total_fish_killed;
        }
        else {
            auto it = _fish_killed.find( fishIndex );
            if( it != _fish_killed.end() ) {
                return it->second;
            }
            return 0;
        }
    }
    // 指定任务组击杀鱼数量
    int32 GetKillFishTypeNum(int32 taskGroup) {
        auto it = _group_fish_killed.find( taskGroup );
        if( it != _group_fish_killed.end() ) {
            return it->second;
        }
        return 0;
    }
    // 指定任务组击杀鱼数量
    int32 GetEscapeFishGroupNum(int32 taskGroup) {
        auto it = _group_fish_escaped.find( taskGroup );
        if( it != _group_fish_escaped.end() ) {
            return it->second;
        }
        return 0;
    }
    int32 GetSwingSkillUseNum(int32 notUsed) {
        return _swing_skill_use_num;
    }
    int32 GetCommonSkillUseNum(int32 itemId) {
        auto it = _skill_use_num.find( itemId );
        if( it != _skill_use_num.end() ) {
            return it->second;
        }
        return 0;
    }
    int32 GetTypeSkillUseNum(int32 skillType) {
        auto it = _type_skill_use_num.find( skillType );
        if( it != _type_skill_use_num.end() ) {
            return it->second;
        }
        return 0;
    }
};

struct tagTableLogData {
    int64 _game_tick;
    int64 _fire_cost;
    int64 _fish_win;
    int64 _bomb1001;
    int64 _bomb1002;
    int64 _bomb1003;
    int64 _bomb1004;
    int32 _lock_item;
    int32 _lock_diamond;
    int32 _freeze_item;
    int32 _freeze_diamond;
    int32 _fast_item;
    int32 _fast_diamond;
    int32 _fury_item;
    int32 _fury_diamond;
    int32 _summon_item;
    int32 _summon_diamond;
    tagTableLogData() {
        reset();
    }
    void reset() {
        memset(this, 0, sizeof(tagTableLogData));
    }
    tagTableLogData& operator=(const tagTableLogData& rhs) {
        memcpy(this, &rhs, sizeof(tagTableLogData));
        return *this;
    }
    void Log(int32 tableIndex);
    void LogPlayerKillFish(int64 gold) {
        _fish_win += gold;
    }
    void LogPlayerFire(int64 cost) {
        _fire_cost += cost;
    }
    // log部分写死了道具id
    void LogDiamondCost(int32 itemId, int32 count) {
        switch( itemId ) {
        case 11401001:
            _lock_diamond += count;
            break;
        case 11401002:
            _freeze_diamond += count;
            break;
        case 11401003:
            _fast_diamond += count;
            break;
        case 11401007:
            _fury_diamond += count;
            break;
        case 11401008:
            _summon_diamond += count;
            break;
        default:
            break;
        }
    }
    void LogBombGot(int32 itemId, int32 count) {
        switch( itemId ) {
        case 11901001:
            _bomb1001 += count;
            break;
        case 11901002:
            _bomb1002 += count;
            break;
        case 11901003:
            _bomb1003 += count;
            break;
        case 11901004:
            _bomb1004 += count;
            break;
        default:
            break;
        }
    }

    void LogItemCost(int32 itemId, int32 count) {
        switch( itemId ) {
        case 11401001:
            _lock_item += count;
            break;
        case 11401002:
            _freeze_item += count;
            break;
        case 11401003:
            _fast_item += count;
            break;
        case 11401007:
            _fury_item += count;
            break;
        case 11401008:
            _summon_item += count;
            break;
        default:
            break;
        }
    }
};

struct tagPoolLog {
    int32 _cur_num;
    int32 _free_num;
    int32 _used_num;
    tagPoolLog() {
        memset(this, 0, sizeof(tagPoolLog));
    }
    tagPoolLog& operator=(const tagPoolLog& rhs) {
        memcpy(this, &rhs, sizeof(tagPoolLog));
        return *this;
    }
};

struct tagTableSummonCard {
    Roll _fish;
    Roll _route;
    tagTableSummonCard() {
        _fish.clear();
        _route.clear();
    }
    tagTableSummonCard& operator=(const tagTableSummonCard& rhs) {
        _fish = rhs._fish;
        _route = rhs._route;
        return *this;
    }
    bool Fill(const vector<int64>& vec) {
        if( (int32)vec.size() <= 2 ) {
            LOGERROR("CARD SUMMON failed");
            return false;
        }
        int32 fishNum = vec[1];
        if( (int32)vec.size() < 2 + fishNum ) {
            LOGERROR("CARD SUMMON failed");
            return false;
        }
        for( int32 i = 0 ; i < fishNum ; i++ ) {
            _fish.push_value(10, vec[2+i]);
        }
        _fish.set_extra(false, 1);
        int32 routeStarts = 2+fishNum;
        int32 minRoutesNum = max(fishNum, 5);
        if( (int32)vec.size() < 2+fishNum+minRoutesNum ) {
            LOGERROR("CARD SUMMON failed");
            return false;
        }
        for( size_t i = routeStarts ; i < vec.size() ; i++ ) {
            _route.push_value(10, vec[i]);
        }
        _route.set_extra(true, 1);
        return true;
    }
    void GetOne(IntPair& ip) {
        ip.set_key(_fish.roll());
        ip.set_value(_route.roll());
    }
};

class LxUser;
class FishGame;
class FishShoal;
class LogicGroup;
class FishPlayer;
class FishRoute;
class TideBase;
class FishFish;
class FishBullet;
class FishTable
{
GETSET(int32, Key);
GETSET_BOOL(RoomFinish);
GETSET_BOOL(Valid);
GETSET_BOOL(UserQuit);
GETSET(int64, CreateTime);
GETSET(int64, EndTime);
// 已经存在的毫秒数,冰冻时间不计入内,主要用于计算鱼群的延迟刷新时间
GETSET(int64, LifeTick);
GETSET_PTR(FishGame, Game);
GETSET(tagJsonGamePlay, GamePlay);
// 客户端需要的延迟,来保证刷鱼消息都能收到
GETSET(int64, DefaultDelayTick);
public:
    bool IsFull() { return GetPlayerCount(ERPT_All) >= m_GamePlay._MaxPlayer; };
    bool IsFull(uint64 userId);
    bool IsClassic() { return m_GamePlay._GameType == e_jsonGamePlayGameType_Classic; }
    int32 GetDifficulty() { return m_GamePlay._Difficulty; };
    int32 GetTableIndex() { return m_GamePlay._ID; };
    int32 GetLogIncReason() {
        switch( m_GamePlay._GameType ) {
        case e_jsonGamePlayGameType_Classic:
            return ELRI_TableClassic;
        case e_jsonGamePlayGameType_Custom_Gold:
            return ELRI_TableGold;
        case e_jsonGamePlayGameType_Custom_Stone:
            return ELRI_TableStone;
        case e_jsonGamePlayGameType_Custom_Feather:
            return ELRI_TableFeather;
        case e_jsonGamePlayGameType_Tower:
            return ELRI_TableTower;
        case e_jsonGamePlayGameType_Arena:
            return ELRI_TableArenaDaily;
        default:
            return ELRI_Other;
        }
    }
    int32 GetLogDecReason() {
        switch( m_GamePlay._GameType ) {
        case e_jsonGamePlayGameType_Classic:
            return ELRD_TableClassic;
        case e_jsonGamePlayGameType_Custom_Gold:
            return ELRD_TableGold;
        case e_jsonGamePlayGameType_Custom_Stone:
            return ELRD_TableStone;
        case e_jsonGamePlayGameType_Custom_Feather:
            return ELRD_TableFeather;
        case e_jsonGamePlayGameType_Tower:
            return ELRD_TableTower;
        case e_jsonGamePlayGameType_Arena:
            return ELRD_TableArena;
        default:
            return ELRD_Other;
        }
    }
public:
    bool InFreeze() { return m_TimeLine.IsFreeze(); }
    // 路径被使用
    void UseFishRoute(int32 routeId, int64 endTick) { m_usedFishRoutes.Add(routeId, routeId, endTick); }
    bool IsFishRouteUsed(int32 routeId) { return m_usedFishRoutes.Contains(routeId); }
    void ReturnFishRoute(int32 routeId) { m_usedFishRoutes.Remove(routeId); }
    tagGoldPool& GetTablePoolInfo() { return m_tablePool; };
protected:
    // 房间内的小型管理对象
    tagFishTimeLine m_TimeLine;
    set<int32> m_setQuest;
    tagGoldPool m_tablePool;
    // 累计获得的道具
    map<int32, int64> m_mapCustomItems;
    // 累计获得的金币
    int64 m_goldNow;
    // 累计的竞技场积分
    int64 m_scoreNow;
    // 倒计时结束时间
    int64 m_cdEndTime;
    // 已经使用过的路径点, 目的是同一个路径点在一定的时间内,尽量不多次使用,否则会造成鱼的重合
    LifeObj<int32, int32> m_usedFishRoutes;
protected:
    void InitSummonBossConfig();
    JsonGamePlaySummonBoss m_confSummonBoss;
public:
    bool IsFishLimited(int32 fishIndex, int32 maxNum) {
        auto it = m_limitFish.find(fishIndex);
        if( it == m_limitFish.end() ) {
            return false;
        }
        return it->second >= maxNum;
    }
    void IncLimitFish(int32 fishIndex) {
        GlobalUtils::SimpleMapAdd(m_limitFish, fishIndex, 1);
    }
    void DecLimitFish(int32 fishIndex) {
        auto it = m_limitFish.find(fishIndex);
        if( it != m_limitFish.end() ) {
            --it->second;
            if( it->second <= 0 ) {
                m_limitFish.erase(it);
            }
        }
    }
protected:
    // 刷新受数量限制的鱼
    map<int32, int32> m_limitFish;
public:
    void RoomTargetOnUseSwingSkill(int32 skillId, int32 skillType);
    void RoomTargetOnUseCommonSkill(int32 skillId, int32 skillType);
    void RoomTargetOnKillFish(FishFish* fish);
    void RoomTargetOnFishEscape(FishFish* fish);
    void RoomTargetGetItem(int32 itemId, int64 itemNum);
    void RoomTargetGetGold(int64 gold);
    int32 RoomTargetCheck();
    void ForEachRoomTarget(std::function<void(const FishTargetInfo& info)> func);
private:
    // 房间通关任务列表
    tagRoomTarget m_target;
public:
    bool Init(FishGame* pGame, int32 key, const tagJsonGamePlay& rhs);
    void Update(int32 dt);
    void OnRecycled();
    void ClearUser(LxUser* pUser);
public:
    FishTable();
    ~FishTable();
public:
    void TableRecycleFish(FishFish* fish);
    void TableKillFish(FishPlayer* player, FishFish* fish, int64 gold);
    void TableCreateFish(int32 fishCfgId, int32 routeId, FishShoal* pShoal);
    void TableCreateBoss(int64 guid, int32 fishCfgId, int32 routeId, FishPlayer* player);
    void TideCreateFish(FishShoal* pShoal, int32 fishId, int32 fishCfgId, FishRoute* fishRoute);
    void TableCreateFishes(const list<IntPair>& lst, FishShoal* pShoal);
    FishFish* GetFish(int32 id) { return m_Fishes.GetEntity(id); }
    bool Init(FishTable* pTable, int32 fishPoolId);
    FishBullet* CreateBullet(FishPlayer* player, int32 bulletId);
    FishBullet* GetBullet(FishPlayer* player, int32 bulletId);
    void BuildPoolLog(map<string, tagPoolLog>& mapLog);
    uint64 GetFirstUser();
protected:
    EntityDriver<int32, FishFish> m_Fishes;    // 鱼管理器
    EntityDriver<int32, FishShoal> m_Shoals;   // 鱼群管理
    EntityDriver<string, FishBullet> m_Bullets; // 子弹管理
    FishPlayer* m_arPlayers[ROOM_MAX_PLAYER];
public:
    void PushBullet(FishPlayer* player, int32 bulletId, int32 bulletAngle, int32 bulletType, int32 bulletCount, int64 cost);
    void PushGenerator(const SyncCreateGenerator& msg) {
        m_lstTides.push_back(msg);
    }
protected:
    void DoDelaySyncs();

    list<SyncCreateGenerator> m_lstTides;
    int64 m_lastTideTick;
    list<ActManualFire> m_lstFire;
    int64 m_lastFireTick;
    int32 m_nFireInterval;
    list<TableFishInfo> m_lstFishes;
    int64 m_lastCreateFishTick;
    map<uint64, ActLockFish> m_mapPlayerLocks;
    int64 m_lastTargetTick;
public:
    void OnPlayerCommand(WrapPacket& pkg, WrapPacket& response);
    void OnFishInputHitFish(FishPlayer* player, WrapPacket& req, InputHitFish& proto, WrapPacket& response);
    void OnFishInputHitFishs(FishPlayer* player, WrapPacket& req, InputHitFishs& proto, WrapPacket& response);
    void OnFishInputManualFire(FishPlayer* player, WrapPacket& req, InputManualFire& proto, WrapPacket& response);
    void OnFishInputChangeRate(FishPlayer* player, WrapPacket& req, InputChangeRate& proto, WrapPacket& response);
    void OnFishInputTurretRotate(FishPlayer* player, WrapPacket& req, InputTurretRotate& proto, WrapPacket& response);
    void OnFishInputLockFish(FishPlayer* player, WrapPacket& req, InputLockFish& proto, WrapPacket& response);
    void OnFishInputChangeFury(FishPlayer* player, WrapPacket& req, InputChangeFury& proto, WrapPacket& response);
    void OnFishGetRoomDataReq(FishPlayer* player, WrapPacket& req, GetRoomDataReq& proto, WrapPacket& response);
    void OnFishQuitRoomReq(FishPlayer* player, WrapPacket& req, QuitRoomReq& proto, WrapPacket& response);
    void OnFishInputSummonBossReward(FishPlayer* p, WrapPacket& pkg, InputSummonBossReward& req, WrapPacket& response);
    void OnFishLxUserChangeTurret(FishPlayer* p, WrapPacket& pkg, LxUserChangeTurret& req, WrapPacket& response);
    void OnFishLxUserChangeWeapon(FishPlayer* p, WrapPacket& pkg, LxUserChangeWeapon& req, WrapPacket& response);
    void OnFishLxRandQuest(FishPlayer* p, WrapPacket& pkg, LxRandQuest& req, WrapPacket& response);
    void OnFishInputUserBuffEnd(FishPlayer* p, WrapPacket& pkg, InputUserBuffEnd& req, WrapPacket& response);
    void OnFishKickUserReq(FishPlayer* p, WrapPacket& pkg, KickUserReq& req, WrapPacket& response);
    void OnFishInputUserCastSkill(FishPlayer* p, WrapPacket& pkg, InputUserCastSkill& req, WrapPacket& response);
    void OnFishSummonBossKillerReq(FishPlayer* p, WrapPacket& pkg, SummonBossKillerReq& req, WrapPacket& response);
    void OnFishHuntBossRewardReq(FishPlayer* p, WrapPacket& pkg, HuntBossRewardReq& req, WrapPacket& response);
    void OnFishTreasureFishRewardReq(FishPlayer* p, WrapPacket& pkg, TreasureFishRewardReq& req, WrapPacket& response);
    void OnFishUserKillBossReq(FishPlayer* player, WrapPacket& req, UserKillBossReq& proto, WrapPacket& response);
    void OnFishImBrokenReq(FishPlayer* player, WrapPacket& req, ImBrokenReq& proto, WrapPacket& response);

    void GetRoomProto(FishPlayer* p, FishRoomProto& proto);
    void SetFreezeTime(uint64 playerId, int32 freezeTimeMS, bool show = true);
    void BroadcastCreateFish(FishFish* fish, int routeId);
    void BroadcastRoomTargets();
    // 把金币拆分成金币加房间指定弹头
    std::tuple<int64, int32, int64> SplitGold(int64 gold, int32 fishIndex);
    int64 GetMaxTurretRate() {
        if( m_GamePlay._TurretRate.empty() ) {
            return 5000000;
        }
        return m_GamePlay._TurretRate[m_GamePlay._TurretRate.size()-1];
    }
    // 玩家击中了一条鱼
    bool PlayerHitFish(FishPlayer* player, FishFish* fish, bool bForceKill, bool bForceKillBoss, double bulletPower, ActHitFish& msg);
protected:
    int64 CalcHitFish(FishPlayer* player, FishFish* fish, double bulletPower, bool bForceKillBoss);
public:
    uint64 GetRandPlayerId();
    void GetAllPlayer(vector<LxUser*>& vec);
    FishPlayer* GetPlayer(uint64 playerId);
    // 获得房间人数
    int32 GetPlayerCount(E_GetPlayerType eType);
    bool IsInRoom(uint64 userId);
    void SyncToOtherPlayers(FishPlayer* thisPlayer, WrapPacket& pkg);
    void SyncToAll(WrapPacket& pkg);
    void SyncToPlayer(FishPlayer* player, WrapPacket& pkg);
    tagTableLogData* LogDataPtr() { return &m_LogData; };
    void TableFishSetFlag(int32 fishId, bool isPoolBoss, bool stopSummon, bool stopFishPoolRefresh) {
        if( isPoolBoss ) {
            m_PoolBossSet.insert(fishId);
        }
        if( stopSummon ) {
            m_StopSummonSet.insert(fishId);
        }
        if( stopFishPoolRefresh ) {
            m_StopFishPoolRefreshSet.insert(fishId);
        }
    }
    bool CanSummonBoss() { return m_StopSummonSet.size() == 0; }
    bool CanFishPoolRefresh() { return m_StopFishPoolRefreshSet.size() == 0; }
    bool IsPoolBoss(int32 fisId) { return m_PoolBossSet.find(fisId) != m_PoolBossSet.end(); }
    bool CanUseSummonSkill();
    int32 UseSummonSkill(int64 curGold, list<IntPair>& lstFish, FishPlayer* player);
    void OnSummonBossDead(FishFish* fish, uint64 killer);
protected:
    tagTableLogData m_LogData;
public:
    int32 OnPlayerJoin(LxUser* pUser, bool isReconnect, FishEnterRoomResp& resp);

    FishPlayer* PlayerSitDown(LxUser* pUser);

    int32 GetEmptySeatCount();
    void OnPlayerQuit(FishPlayer* player, int32 reason);
// 竞技场相关判定
public:
    // 竞技场积分类型
    int32 GetArenaPointType();
    bool IsPointDoubleFish(int32 fishIndex) { return m_setArenaPointDoubleFish.find(fishIndex) != m_setArenaPointDoubleFish.end(); }
protected:
    set<int32> m_setArenaPointDoubleFish;
// 鱼池刷新部分
public:
    void InitLineFishPool();
    bool UseFishPool(bool bNotifyClient, bool isDefault, int32 poolId);
    // 更新所有鱼池状态,返回true表示Update不再继续执行
    bool UpdateSpecialPoolStatus(int64 tNow, int32 dt);

    // 击杀了指定类型的鱼,用于刷新规则
    void TypeFishKilled(int32 type) {
        GlobalUtils::SimpleMapAdd(m_mapTypeFishKilled, type, 1);
    }
    void ResetTypeFishCounter(int32 type) {
        m_mapTypeFishKilled.erase(type);
    }
    int32 GetTypeFishKilledNum(int32 type) {
        auto it = m_mapTypeFishKilled.find(type);
        if( it == m_mapTypeFishKilled.end()) {
            return 0;
        }
        return it->second;
    }
    void CheckActivityFishPool();
    FishPoolLine* FishPoolLinePtr() { return &m_lineFishPool; }

    int32 GetHpParamByFishType( int32 type ) {
        auto it = m_mapTypeHpParam.find(type);
        if( it == m_mapTypeHpParam.end() ) {
            return 1000;
        }
        return it->second;
    }
    int32 GetPdParamByFishType( int32 type ) {
        auto it = m_mapTypePdParam.find(type);
        if( it == m_mapTypePdParam.end() ) {
            return 1000;
        }
        return it->second;
    }
    int32 GetMdParamByFishType( int32 type ) {
        auto it = m_mapTypeMdParam.find(type);
        if( it == m_mapTypeMdParam.end() ) {
            return 1000;
        }
        return it->second;
    }
private:
    // 鱼池管理
    FishPoolLine m_lineFishPool;
    tagFishPool m_curPool;
    int32 m_linePoolStatus; // E_FishPoolStatus
    set<int32> m_PoolBossSet;   // 奖池类boss, 包括召唤boss和桌面会刷新的小boss
    set<int32> m_StopFishPoolRefreshSet;   // 阻止鱼池刷新的鱼id列表
    set<int32> m_StopSummonSet;   // 阻止召唤的鱼id列表
    int64 m_lCurPoolTick;
    int64 m_lSwitchPoolDelayTick;
    int64 m_lFrameCount;
    map<int32, int32> m_mapTypeFishKilled;
    int32 m_nFishKillStdev;
    map<int32, int32> m_mapTypeHpParam;
    map<int32, int32> m_mapTypePdParam;
    map<int32, int32> m_mapTypeMdParam;
};
