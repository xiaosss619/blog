#pragma once

#include "ServerDefine.h"

// 子弹最长存在15秒
#define DEFALT_LIFE_TICK 15000

class FishPlayer;
class FishBullet {
GETSET(string, Key);
GETSET(int32, MaxHitNum);
GETSET_PTR(FishPlayer, Player);
public:
    static string MakePlayerBulletKey(FishPlayer* player, int32 bulletId);
    bool Init(FishPlayer* player, int32 bulletId);
    void Update(int32 dt) {
         m_nCurLifeTick += dt;
    }
    bool IsValid() {
        return m_nHitNum < m_MaxHitNum && m_nCurLifeTick < DEFALT_LIFE_TICK;
    }
    bool OnHit() {
        if( m_nHitNum >= m_MaxHitNum ) {
            return false;
        }
        m_nHitNum++;
        return true;
    }
    string DebugString() {
        ostringstream os;
        os << "key: " << m_Key;
        os << ", hitMax: " << m_MaxHitNum;
        os << ", hitNum: " << m_nHitNum;
        os << ", lifeTick: " << m_nCurLifeTick;
        return os.str();
    }
    void OnRecycled() {};
protected:
    int32 m_nHitNum;
    int32 m_nCurLifeTick;
};
