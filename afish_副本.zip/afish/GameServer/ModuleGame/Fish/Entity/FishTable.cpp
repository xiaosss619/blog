/**
 * GamePlay defaultFishPoolID
 * 				=> FishPool.poolID
 * 				   FishPool.fishShoalGroup字符串组
 * 						=> FishShoal.shoalID
 * 							MoveType:1 moveID => FishRandomRoute.houseID
 * 													FishRandomRoute.fishGroupID,totalFishNum,random(routeIDs) => FishGroup.groupID
 * 													按fishIDWeight 随机totalFishNum 条 fishID
 *
 *
 *
 * 							MoveType:2 moveID => FishGnerator.generatorID => param 对应鱼阵参数
 *
 * 						FishShoal.refreshRuleType+refreshRuleTypeNum对应的枚举和数值进行死亡后的重新刷新
 *
 */

#include "FishTable.h"
#include "Entity/FishPlayer.h"
#include "Entity/FishFish.h"
#include "Entity/FishRoute.h"
#include "Entity/FishShoal.h"
#include "Entity/FishBullet.h"
#include "FishUtils.h"
#include "FishGame.h"
#include "ModuleUser/LxUser.h"
#include "Dispatcher.h"
#include "ModuleHelper.h"
#include "LxGameLogHelper.h"

// 鱼池状态
enum E_FishPoolStatus
{
    EFPS_DefaultPool            = 0,    // 正在使用默认鱼池
    EFPS_DefaultToSpecial_Delay = 1,    // 默认切特殊之间的延迟阶段
    EFPS_SpecialToDefault_Delay = 2,    // 特殊切默认之间的延迟阶段
    EFPS_SpecialPool            = 3,    // 正在使用特殊鱼池
};

void tagTableLogData::Log(int32 tableIndex) {
    LOG_TABLE_DATA(sGameUtils->GetFakeTimeNow(), tableIndex,
                    _game_tick,
                    _fire_cost, _fish_win,
                    _bomb1001, _bomb1002, _bomb1003, _bomb1004,
                    _lock_item, _lock_diamond,
                    _freeze_item, _freeze_diamond,
                    _fast_item, _fast_diamond,
                    _fury_item, _fury_diamond,
                    _summon_item, _summon_diamond);
    reset();
}

FishTable::FishTable() {
    m_Fishes.Init("Fish", 300, 50);
    m_Shoals.Init("Shoal", 20, 10);
    m_Bullets.Init("Bullet", 200, 10);
    for( int32 i = 0; i < ROOM_MAX_PLAYER; i++ ) {
        m_arPlayers[i] = nullptr;
    }
}

FishTable::~FishTable() {
}

bool FishTable::Init(FishGame* pGame, int32 key, const tagJsonGamePlay& rhs)
{
    m_pGame = pGame;
    m_LogData.reset();
    m_Valid = true;
    m_EndTime = 0;
    m_cdEndTime = 0;
    m_LifeTick = 0;
    m_UserQuit = false;
    m_CreateTime = sGameUtils->GetFakeTimeNow();
    m_DefaultDelayTick = 0;
    if( rhs._FishingTime > 0 ) {
        m_EndTime = sGameUtils->GetFakeTimeNow() + rhs._FishingTime / 1000;
        m_cdEndTime = sGameUtils->GetFakeTimeNow()+5;
        m_CreateTime = m_cdEndTime;// 如果是有捕鱼限制时间的,就会有5秒倒计时,房间创建时间变为5秒后
    }
    m_GamePlay = rhs;
    m_Key = key;
    m_TimeLine.reset();
    InitLineFishPool();
    if( m_GamePlay._AdditionFishPool.size() % 3 == 0 ) {
        for( size_t i = 0; i < m_GamePlay._AdditionFishPool.size(); i+= 3 ) {
            m_lineFishPool.AddFishPool(m_GamePlay._AdditionFishPool[i], m_GamePlay._AdditionFishPool[i+1], m_GamePlay._AdditionFishPool[i+2]);
        }
    }
    CheckActivityFishPool();

    if( !UseFishPool(false, true, m_GamePlay._DefautFishPoolID) ) {
        return false;
    }

    m_tablePool.reset();
    if( rhs._TableRefund.size() == 3 ) {
        if( !sGameUtils->GetAvaliableTablePool(m_GamePlay._ID, m_tablePool) ) {
            m_tablePool._win = 0;
            m_tablePool._lose = 0;
            m_tablePool._pool = 0;
            m_tablePool._rate = rhs._TableRefund[0]*1.0f/1000;
            m_tablePool._pool_start = rhs._TableRefund[1];
            m_tablePool._pool_end = rhs._TableRefund[2];
        }
    }

    m_setQuest.clear();
    for( size_t i = 0 ; i < m_GamePlay._RandomQuestList.size() ; ++i ) {
        m_setQuest.insert(m_GamePlay._RandomQuestList[i]);
    }
    m_mapCustomItems.clear();
    m_goldNow = 0;
    m_scoreNow = 0;
    m_target.reset();

    for( int32 i = 0; i < ROOM_MAX_PLAYER; i++ ) {
        if( m_arPlayers[i] == nullptr ) {
            m_arPlayers[i] = new FishPlayer();
        }
    }
    m_usedFishRoutes.Clear();
    m_limitFish.clear();
    m_setArenaPointDoubleFish.clear();
    m_mapTypeFishKilled.clear();
    if( m_GamePlay._GameType == e_jsonGamePlayGameType_Arena && m_GamePlay._ArenaFishList.size() >= 3 ) {
        Roll roll;
        for( size_t i = 0; i < m_GamePlay._ArenaFishList.size() ; ++i ) {
            roll.push_value(10, m_GamePlay._ArenaFishList[i]);
        }
        roll.set_extra(true, 3);
        m_setArenaPointDoubleFish.insert(roll.roll());
        m_setArenaPointDoubleFish.insert(roll.roll());
        m_setArenaPointDoubleFish.insert(roll.roll());
    }
    m_mapTypeHpParam.clear();
    m_mapTypePdParam.clear();
    m_mapTypeMdParam.clear();
    m_lFrameCount = 0;

    tagJsonDifficulty dft;
    if( JDATA->DifficultyPtr()->ByID(m_GamePlay._Difficulty, dft) ) {
        if( dft._HPScale.size() % 2 == 0 ) {
            for( size_t i = 0; i < dft._HPScale.size() ; i += 2 ) {
                m_mapTypeHpParam[dft._HPScale[i]] = dft._HPScale[i+1];
            }
        }
        if( dft._PhysicalDefenseScale.size() % 2 == 0 ) {
            for( size_t i = 0; i < dft._PhysicalDefenseScale.size() ; i += 2 ) {
                m_mapTypePdParam[dft._PhysicalDefenseScale[i]] = dft._PhysicalDefenseScale[i+1];
            }
        }
        if( dft._MagicDefenseScale.size() % 2 == 0 ) {
            for( size_t i = 0; i < dft._MagicDefenseScale.size() ; i += 2 ) {
                m_mapTypeMdParam[dft._MagicDefenseScale[i]] = dft._MagicDefenseScale[i+1];
            }
        }
    }

    m_StopSummonSet.clear();
    m_StopFishPoolRefreshSet.clear();
    m_PoolBossSet.clear();
    m_lstFire.clear();
    m_lastFireTick = 0;
    m_lstTides.clear();
    m_lastTideTick = 0;
    m_lstFishes.clear();
    m_lastCreateFishTick = 0;
    m_mapPlayerLocks.clear();
    m_lastTargetTick = 0;
    m_nFireInterval = RedisData::GetSysFireInterval();

    InitSummonBossConfig();
    return true;
}

void FishTable::CheckActivityFishPool() {
	// 活动鱼池
    int64 tNow = sGameUtils->GetFakeTimeNow();
    map<int32, tagActivityInfo> mapAct;
    sHActs->GetActivities(mapAct);
    for( auto it = mapAct.begin(); it != mapAct.end(); ++it) {
        if( tNow >= it->second._end ) {
            continue;
        }
        tagJsonActivities act;
        if( !JDATA->ActivitiesPtr()->ByID(it->first, act) ) {
            continue;
        }
        if( act._Type == e_jsonActivitiesType_FishPoolSwitch && act._ACTParam.size() == 4 && act._ACTParam[0] == m_GamePlay._ID ) {
            m_lineFishPool.AddFishPool(it->second._start, it->second._end, act._ACTParam[1], act._ACTParam[2], act._ACTParam[3]);
        }
    }
}

bool FishTable::UseFishPool(bool bNotifyClient, bool isDefault, int32 poolId) {
    m_usedFishRoutes.Clear();
    m_limitFish.clear();
    m_Fishes.RemoveAll();
    m_Shoals.RemoveAll();
    do {
        tagJsonFishPool data;
        if( !JDATA->FishPoolPtr()->ByID(poolId, data) ) {
            LOGERROR("fishpool not found %d", poolId);
            break;
        }
        if( data._FishShoalGroup.empty() ) {
            LOGERROR("fish pool has empty shoal[%d]", poolId);
            break;
        }
        for( size_t i = 0; i < data._FishShoalGroup.size(); ++i ) {
            int32 fishShoalId = data._FishShoalGroup[i];
            tagJsonFishShoal data;
            if( !JDATA->FishShoalPtr()->ByID(fishShoalId, data) ) {
                LOGERROR("invalid shoal id[%d]", fishShoalId);
                continue;
            }

            FishShoal* pShoal = m_Shoals.CreateEntity(this, m_pGame->FetchFishId(1), data);
            if( pShoal == nullptr ) {
                LOGERROR("invalid shoal id[%d]", fishShoalId);
                continue;
            }
        }
    }while(0);
    if( bNotifyClient ) {
        WrapPacket packet;
        SyncSwitchFishPool msg;
        msg.set_pool_id(poolId);
        m_lineFishPool.ForEachKillPool([&](int32 poolId, int32 curKill, int32 maxKill){
            auto ptr = msg.add_pools();
            ptr->set_pool_id(poolId);
            ptr->set_cur_num(curKill);
            ptr->set_max_num(maxKill);
        });
        LxGameHelper::MakeSyncSwitchFishPool(packet, msg);
        SyncToAll(packet);
    }
    m_lineFishPool.SetDefaultPoolInUse(isDefault);
    return true;
}

// 初始化
void FishTable::InitLineFishPool() {
    m_lineFishPool.Reset();
    m_curPool.Reset();
    m_lCurPoolTick = 0;
    m_lSwitchPoolDelayTick = 0;
    m_linePoolStatus = EFPS_DefaultPool;
}

bool FishTable::UpdateSpecialPoolStatus(int64 tNow, int32 dt) {
    m_lCurPoolTick += dt;
    m_lSwitchPoolDelayTick += dt;
    m_lineFishPool.Update(tNow, dt);
    if( !CanFishPoolRefresh() ) {
        return false;
    }
    switch( m_linePoolStatus ) {
    case EFPS_DefaultPool:
        // 默认池的最短寿命在系统参数中
        if( m_lCurPoolTick < JDATA->SystemConstPtr()->GetDefaultFishPoolExistedTime() ) {
            return false;
        }
        if( !m_lineFishPool.FetchFishPool(m_curPool) ) {
            return false;
        }
        m_lSwitchPoolDelayTick = 0;
        // 刷鱼池
        UseFishPool(true, false, m_curPool._poolId);
        m_lCurPoolTick = 0;
        m_linePoolStatus = EFPS_DefaultToSpecial_Delay;
        return true;
    case EFPS_SpecialPool:
        if( m_lCurPoolTick >= m_curPool._lifeTime ) {
            // 到期了
            m_lineFishPool.AddFishPool(m_curPool);
            m_curPool.Reset();
            if( m_lineFishPool.FetchFishPool(m_curPool) ) {
                m_lSwitchPoolDelayTick = 0;
                // 刷鱼池
                UseFishPool(true, false, m_curPool._poolId);
                m_lCurPoolTick = 0;
                m_linePoolStatus = EFPS_DefaultToSpecial_Delay;
                return true;
            }
            // 要刷默认池了
            m_lSwitchPoolDelayTick = 0;
            // 刷鱼池
            UseFishPool(true, true, m_GamePlay._DefautFishPoolID);
            m_lCurPoolTick = 0;
            m_linePoolStatus = EFPS_SpecialToDefault_Delay;
            return true;
        }
        else {
            return false;
        }
    case EFPS_DefaultToSpecial_Delay:
        if( m_lSwitchPoolDelayTick >= JDATA->SystemConstPtr()->GetFishPoolSwitchTime() ) {
            m_lSwitchPoolDelayTick = 0;
            m_lCurPoolTick = 0;
            m_linePoolStatus = EFPS_SpecialPool;
            return false;
        }
        return true;
    case EFPS_SpecialToDefault_Delay:
        if( m_lSwitchPoolDelayTick >= JDATA->SystemConstPtr()->GetFishPoolSwitchTime() ) {
            m_lSwitchPoolDelayTick = 0;
            m_lCurPoolTick = 0;
            m_linePoolStatus = EFPS_DefaultPool;
            return false;
        }
        return true;
    default:
        return false;
    }
}

FishBullet* FishTable::CreateBullet(FishPlayer* player, int32 bulletId) {
    return m_Bullets.CreateEntity(player, bulletId);
}

FishBullet* FishTable::GetBullet(FishPlayer* player, int32 bulletId) {
    string strKey = FishBullet::MakePlayerBulletKey(player, bulletId);
    return m_Bullets.GetEntity(strKey);
}

int32 FishTable::GetArenaPointType() {
    if( m_GamePlay._GameType != e_jsonGamePlayGameType_Arena ) {
        return EAPT_None;
    }
    int64 tNow = sGameUtils->GetFakeTimeNow();

    int64 start = m_EndTime - JDATA->SystemConstPtr()->GetArenaDoubleStartTime()/1000;
    int64 end = start + JDATA->SystemConstPtr()->GetArenaDoubleLasting()/1000;

    if( start <= tNow && tNow <= end ) {
        return EAPT_Double;
    }
    start = m_EndTime - JDATA->SystemConstPtr()->GetArenaTripleStartTime()/1000;
    end = start + JDATA->SystemConstPtr()->GetArenaTripleLasting()/1000;

    if( start <= tNow && tNow <= end ) {
        return EAPT_Tripple;
    }

    return EAPT_Normal;
}

void FishTable::Update(int dt)
{
    DoDelaySyncs();
    m_LogData._game_tick += dt;
    if( m_LogData._game_tick >= 1000*5*60 ) {
        // 5分钟记录一条
        m_LogData.Log(GetTableIndex());
    }
    m_lFrameCount++;
    int64 tNow = sGameUtils->GetFakeTimeNow();
    if( m_cdEndTime > 0 ) {
        if( tNow < m_cdEndTime ) {
            // 倒计时未结束
            return;
        }
        m_cdEndTime = 0;
    }
    else {
        m_DefaultDelayTick += dt;
        if( m_DefaultDelayTick < 1000 ) {
            return;
        }
    }
    if( UpdateSpecialPoolStatus(tNow, dt) ) {
        return;
    }
    if( !InFreeze() ) {
        m_usedFishRoutes.Update(dt);
    }
    m_Bullets.Update(dt);
    m_Shoals.Update(dt);
    m_Fishes.Update(dt);
    for( int32 i = 0; i < ROOM_MAX_PLAYER; i++ ) {
        auto player = m_arPlayers[i];
        if( player->IsUser() ) {
            player->Update(tNow, dt);
            if( player->IsTimeout() ) {
                SyncForceLeft msg;
                msg.set_playerid(player->GetKey());
                msg.set_reason(1);
                WrapPacket packet;
                LxGameHelper::MakeSyncForceLeft(packet, msg);
                SyncToPlayer(player, packet);
                OnPlayerQuit(m_arPlayers[i], ELLT_Disconnect);
            }
        }
    }

    int32 reason = RoomTargetCheck();
    if( reason == 0 && m_EndTime > 0 && tNow >= m_EndTime ) {
        reason = EFRFR_Timeout;
    }
    if( reason != 0 ) {
        // 游戏需要结束了
        SyncRoomFinish msg;
        msg.set_result(reason);
        if( m_scoreNow > 0 ) {
            msg.set_arenascore(m_scoreNow);
        }
        if( m_goldNow > 0 ) {
            msg.set_customgoldnow(m_goldNow);
        }
        for( auto& item : m_mapCustomItems ) {
            auto ptr = msg.add_customitemnow();
            ptr->set_item_id(item.first);
            ptr->set_item_change(item.second);
            ptr->set_item_num(item.second);
        }
        vector<LxUser*> vecUser;
        GetAllPlayer(vecUser);
        // 这里应该只有一个人的
        if( vecUser.size() != 1 ) {
            LOGERROR("table[%d] end with [%d] user", m_GamePlay._ID, vecUser.size());
        }
        for( size_t i = 0; i < vecUser.size(); i++ ) {
            int32 nInfoChangeReason = 0;
            if( reason == EFRFR_TideCompleted ) {
                if( m_GamePlay._GameType == e_jsonGamePlayGameType_Tower ) {
                    // 通关了
                    map<int32, int64> mapItem;
                    // 鱼潮场不会掉炮台
                    map<int32, int32> mapTurret;
                    if( sHLottery->GetLootItem(m_GamePlay._RoomRewardLootID, mapItem) ) {
                        for( auto& it : mapItem ) {
                            vecUser[i]->ItemChange(it.first, it.second, GetLogIncReason(), false);
                            auto ptr = msg.add_customitemnow();
                            ptr->set_item_id(it.first);
                            ptr->set_item_change(it.second);
                            ptr->set_item_num(it.second);
                        }
                    }
                    vecUser[i]->TideCompleted(m_GamePlay._ID);
                    nInfoChangeReason = EPIC_TideComplete;
                }
                else {
                    // 休闲模式通关
                    nInfoChangeReason = EPIC_CasualComplete;
                    m_EndTime = tNow;// 休闲玩法, 已经结束了就可以销毁房间了, 不需要等到超时
                }
            }
            else if( reason == EFRFR_Timeout ){
                if( m_GamePlay._GameType == e_jsonGamePlayGameType_Arena ) {
                    // 竞技场房间,要结算本次积分
                    auto rank = sRankingList->UserDoArena(vecUser[i]->GetKey(), m_scoreNow, tNow);
                    int32 oldRank = TUPLE0(rank);
                    int32 newRank = TUPLE1(rank);
                    msg.set_arenaoldrank(oldRank);
                    msg.set_arenanewrank(newRank);
                    if( oldRank == -1 || newRank <= oldRank ) {
                        // 说明排名更新了
                        vecUser[i]->UpdateArenaData(newRank, m_scoreNow);
                    }
                }
            }
            vecUser[i]->SetFishTableInfo(0, 0, 0);
            auto fishPlayer = GetPlayer(vecUser[i]->GetKey());
            if( fishPlayer != nullptr ) {
                WrapPacket pkg;
                LxGameHelper::MakeSyncRoomFinish(pkg, msg);
                SyncToPlayer(fishPlayer, pkg);
                OnPlayerQuit(fishPlayer, reason);
            }
            if( m_GamePlay._GameType == e_jsonGamePlayGameType_Custom_Gold
                || m_GamePlay._GameType == e_jsonGamePlayGameType_Custom_Stone
                || m_GamePlay._GameType == e_jsonGamePlayGameType_Custom_Feather ) {
                vecUser[i]->GTaskInc(e_jsonGeneralTaskCondition_Custom_Play, 0, 1);
            }
            else if( m_GamePlay._GameType == e_jsonGamePlayGameType_Tower ) {
                vecUser[i]->GTaskSet(e_jsonGeneralTaskCondition_Tower_Challenge, m_GamePlay._ID, 1);
            }
            else if( m_GamePlay._GameType == e_jsonGamePlayGameType_Arena ) {
                vecUser[i]->GTaskInc(e_jsonGeneralTaskCondition_Arena_Play, 0, 1);
            }
            vecUser[i]->SendUserInfoChange(nInfoChangeReason);
        }
    }
    if( m_GamePlay._IsResume ) {
        // 可重连类的房间,不做结束,一直等到超时,或者用户主动退出
        // TODO 这里的UserQuit标记默认可重连类的房间只能有一个玩家,后续这里需要考虑更稳妥的做法
        if( m_UserQuit || tNow >= m_EndTime ) {
            m_Valid = false;
        }
    }
    else {
        // CanSummonBoss说明房间内没有召唤boss了, 如果房间存在召唤boss, 则房间继续开着, 直到召唤boss消失
        if( GetPlayerCount(ERPT_User) == 0 && CanSummonBoss() ) {
            m_Valid = false;
        }
    }
    if( !m_TimeLine.IsFreeze() ) {
        m_LifeTick += dt;
    }
}

void FishTable::OnRecycled() {
    if( IsClassic() ) {
        sGameUtils->OnTableClosed(GetTableIndex(), m_tablePool);
        // 房间抽水率为动态值, 房间关闭时记录没有意义, 所以暂时填0处理
        m_LogData.Log(GetTableIndex());
    }
    m_pGame->OnTableRecycled(GetTableIndex(), GetKey());
    m_Fishes.RemoveAll();
    m_Shoals.RemoveAll();
    m_Bullets.RemoveAll();
    for( int32 i = 0; i < ROOM_MAX_PLAYER; i++ ) {
        m_arPlayers[i]->OnRecycled();
    }
    LOGDEBUG("table closed id[%d] index[%d]", GetKey(), GetTableIndex());
    m_Key = 0;
}

bool FishTable::IsFull(uint64 userId) {
    int count = 0;
    for( int32 i = 0 ; i < ROOM_MAX_PLAYER ; ++i ) {
        if( m_arPlayers[i]->IsUser() && m_arPlayers[i]->GetKey() == userId ) {
            return false;
        }
        if( m_arPlayers[i]->IsValid() ) {
            ++count;
        }
    }
    return count >= m_GamePlay._MaxPlayer;
}

void FishTable::BroadcastCreateFish(FishFish* fish, int routeId)
{
    SyncCreateFish data;
    data.set_id(fish->GetKey());
    data.set_fishid(fish->GetIndex());
    data.set_routeid(routeId);
    data.set_lifetick((int32)(fish->GetLifeTime()*1000));
    if( IsClassic() ) {
        for( int32 i = 0 ; i < ROOM_MAX_PLAYER ; ++i ) {
            if( m_arPlayers[i]->IsUser() ) {
                if( fish->GetSummoner() == 0 || fish->GetSummoner() == m_arPlayers[i]->GetKey() ) {
                    WrapPacket pkg;
                    LxGameHelper::MakeSyncCreateFish(pkg, data);
                    SyncToPlayer(m_arPlayers[i], pkg);
                }
            }
        }
    }
    else {
        for( int32 i = 0 ; i < ROOM_MAX_PLAYER ; ++i ) {
            if( m_arPlayers[i]->IsUser() ) {
                fish->GetHpInfo(m_arPlayers[i]->GetKey(), *data.mutable_hpinfo());
                WrapPacket pkg;
                LxGameHelper::MakeSyncCreateFish(pkg, data);
                SyncToPlayer(m_arPlayers[i], pkg);
            }
        }
    }
}

int32 FishTable::GetEmptySeatCount() {
    int32 emptySeat = 0;
    for( int32 i = 0; i < ROOM_MAX_PLAYER; i++ ) {
        if( !m_arPlayers[i]->IsValid() ) {
            emptySeat++;
        }
    }
    return emptySeat;
}

int32 FishTable::OnPlayerJoin(LxUser* pUser, bool isReconnect, FishEnterRoomResp& resp)
{
    int32 ret = JDATA->ErrorCodePtr()->GetSuccess();
    if( !isReconnect ) {
        ret = pUser->CheckEnterRoom(m_GamePlay);
        if( ret != JDATA->ErrorCodePtr()->GetSuccess() ) {
            return ret;
        }
    }
    auto player = PlayerSitDown(pUser);
    if( player == nullptr ) {
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    if( !isReconnect ) {
        if( e_jsonGamePlayGameType_Custom_Feather == m_GamePlay._GameType
            || e_jsonGamePlayGameType_Custom_Stone == m_GamePlay._GameType
            || e_jsonGamePlayGameType_Custom_Gold == m_GamePlay._GameType
            || e_jsonGamePlayGameType_Arena == m_GamePlay._GameType ) {
            // 这四个类型,次数先扣,后面超时,重连什么的,都没关系,次数已经正确了
            pUser->ChangeCurEnergy(-m_GamePlay._EnergyCost);
            if( e_jsonGamePlayGameType_Arena == m_GamePlay._GameType ) {
                pUser->PBIncUserArenaNum(1);
                // 把炮台参与时间也扔进去
                pUser->HeroSetArenaTime();
            }
            else {
                pUser->HeroSetCasualTime();
            }
        }
    }

    LOG_GAME_ENTER(pUser
                    , 0
                    , pUser->PBGetUserGold()
                    , pUser->PBGetDiamondFree()
                    , pUser->PBGetDiamondRmb()
                    , pUser->GetCouponNum()
                    , 0
                    , m_GamePlay._ID
                    , GetKey());
    WrapPacket pkg;
    SyncPlayerJoin join;
    player->FillFishPlayerProto(*join.mutable_user_info());
    LxGameHelper::MakeSyncPlayerJoin(pkg, join);
    SyncToOtherPlayers(player, pkg);
    //向新加入的客户端同步必要信息
    GetRoomProto(player, *resp.mutable_roominfo());
    pUser->SetFishTableInfo(GetKey(), m_GamePlay._ID, m_EndTime);

    // 房间在某帧内认为要关闭, 设置了m_Valid=false, 等待下一帧做移除
    // 如果房间内的玩家在100毫秒内连回来了, 是会造成房间不需要删除,所以需要在这里设置一下m_Valid = true,防止下一帧房间误删除
    m_Valid = true;
    LOGINFO("user[%lu] enter table[%d][%d]", pUser->GetKey(), GetKey(), GetTableIndex());
    return JDATA->ErrorCodePtr()->GetSuccess();
}

void FishTable::ClearUser(LxUser* pUser) {
    FishPlayer* player = GetPlayer(pUser->GetKey());
    if( player != nullptr ) {
        OnPlayerQuit(player, ELLT_Other);
    }
}

#define PROCESS(player, pkg, Type, param, response) \
Type param;\
if( param.ParseFromString(pkg.data()) ) { \
    OnFish##Type(player, pkg, param, response);\
}\
else {\
    LOGERROR("parse[%s] failed", pkg.DebugString().data());\
}

void FishTable::OnPlayerCommand(WrapPacket& pkg, WrapPacket& response)
{
    // response为外部统一回包, 如果不需要外部回包,则调用response.clear_userid();
    FishPlayer* player = GetPlayer(pkg.userid());
    if( player == nullptr ) {
        LOGERROR("table[%d] can not find packet[%ld] user[%ld]", GetKey(), pkg.cmd(), pkg.userid());
        return;
    }
    if( !player->IsUser() ) {
        LOGERROR("ILLEGAL CLIENT");
        return;
    }
    player->Touch();
    switch (pkg.cmd())
    {
        case FISH_GetRoomDataReq: { PROCESS(player, pkg, GetRoomDataReq, proto, response); break; }
        case FISH_QuitRoomReq: { PROCESS(player, pkg, QuitRoomReq, proto, response); break; }
        case FISH_KickUserReq: { PROCESS(player, pkg, KickUserReq, proto, response); break; }
        case FISH_SummonBossKillerReq: { PROCESS(player, pkg, SummonBossKillerReq, proto, response); break; }
        case FISH_HuntBossRewardReq: { PROCESS(player, pkg, HuntBossRewardReq, proto, response); break; }
        case FISH_TreasureFishRewardReq: { PROCESS(player, pkg, TreasureFishRewardReq, proto, response); break; }

        case FISH_InputUserCastSkill: { PROCESS(player, pkg, InputUserCastSkill, proto, response); break; }
        case FISH_InputUserBuffEnd: { PROCESS(player, pkg, InputUserBuffEnd, proto, response); break; }
        case FISH_InputHitFish: { PROCESS(player, pkg, InputHitFish, proto, response); break; }
        case FISH_InputHitFishs: { PROCESS(player, pkg, InputHitFishs, proto, response); break; }
        case FISH_InputManualFire: { PROCESS(player, pkg, InputManualFire, proto, response); break; }
        case FISH_InputChangeRate: { PROCESS(player, pkg, InputChangeRate, proto, response); break; }
        case FISH_InputTurretRotate: { PROCESS(player, pkg, InputTurretRotate, proto, response); break; }
        case FISH_InputLockFish: { PROCESS(player, pkg, InputLockFish, proto, response); break; }
        case FISH_InputSummonBossReward: { PROCESS(player, pkg, InputSummonBossReward, proto, response); break; }
        case FISH_InputChangeFury: { PROCESS(player, pkg, InputChangeFury, proto, response); break; }
        case FISH_UserKillBossReq: { PROCESS(player, pkg, UserKillBossReq, proto, response); break; }
        case FISH_ImBrokenReq: { PROCESS(player, pkg, ImBrokenReq, proto, response); break; }

        case FISH_LxUserChangeTurret: { PROCESS(player, pkg, LxUserChangeTurret, proto, response); break; }
        case FISH_LxUserChangeWeapon: { PROCESS(player, pkg, LxUserChangeWeapon, proto, response); break; }
        case FISH_LxRandQuest: { PROCESS(player, pkg, LxRandQuest, proto, response); break; }
        default:
            response.clear_userid();
            LOGINFO("unknown command[%d]", pkg.cmd());
            break;
    }
}

void FishTable::OnFishSummonBossKillerReq(FishPlayer* p, WrapPacket& pkg, SummonBossKillerReq& req, WrapPacket& response) {
    SummonBossKillerResp msg;
    msg.set_table_index(req.table_index());
    list<SummonBossKiller> killers;
    sRankingList->GetSummonPoolKillers(req.table_index(), killers);
    for( auto& killer : killers ) {
        *msg.add_killers() = killer;
    }
    LxGameHelper::MakeSummonBossKillerResp(response, msg);
}

void FishTable::OnFishHuntBossRewardReq(FishPlayer* p, WrapPacket& pkg, HuntBossRewardReq& req, WrapPacket& response) {
    if( !p->IsUser() ) {
        return;
    }
    response.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    do{
        int64 guid = req.bossid();
        bool useItem = req.use_item();

        LxUser* pUser = p->GetUser();
        pUser->SendUserInfoChange(0);
        HuntBossSimple bossData;
        if( !pUser->GetHuntBossData(guid, bossData) || bossData.endtime() == 0 ) {
            response.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
            break;
        }
        int32 rewardType = EHBS_rewarded;
        if( useItem ) {
            if( !pUser->ItemChange(JDATA->SystemConstPtr()->GetHunterRefundItemID(), -1, ELRD_HuntRefund, false) ) {
                response.set_errorcode(JDATA->ErrorCodePtr()->GetItemUseNumLow());
                break;
            }
            pUser->ChangeGold(bossData.item_gold(), ELRI_HuntRefund);
            rewardType = EHBS_item_rewarded;
        }
        else {
            pUser->ChangeGold(bossData.gold(), ELRI_HuntRefund);
            pUser->PBDecSummonBossPoint(bossData.cost() - bossData.gold());
        }
        pUser->OnHuntRewarded(guid, rewardType);
        pUser->SendUserInfoChange(EPIC_HuntRefund);
    }while(0);
    LxGameHelper::MakeHuntBossRewardResp(response);
}

void FishTable::OnFishTreasureFishRewardReq(FishPlayer* p, WrapPacket& pkg, TreasureFishRewardReq& req, WrapPacket& response) {
    if( !p->IsUser() ) {
        return;
    }
    response.set_errorcode(p->RewardTreasureFish(req.fishid()));
    LxGameHelper::MakeTreasureFishRewardResp(response);
}

void FishTable::OnFishInputUserCastSkill(FishPlayer* p, WrapPacket& pkg, InputUserCastSkill& req, WrapPacket& response) {
    response.clear_userid();
    p->PlayerCastSkill(req);
    if( p->IsUser() ) {
        p->GetUser()->SendUserInfoChange(0);
    }
}

void FishTable::OnFishInputUserBuffEnd(FishPlayer* p, WrapPacket& pkg, InputUserBuffEnd& req, WrapPacket& response) {
    response.clear_userid();
    tagFishBuff buff;
    if( p->GetBuff(req.buff_id(), buff) ) {
        p->DelBuff(req.buff_id());
    }
    {
        WrapPacket sync;
        SyncPlayerBuffEnd msg;
        msg.set_playerid(p->GetKey());
        msg.set_buff_id(req.buff_id());
        msg.set_buff_gold(buff._gold);
        msg.set_buff_fish_index(buff._fishIndex);
        LxGameHelper::MakeSyncPlayerBuffEnd(sync, msg);
        SyncToAll(sync);
    }
}

void FishTable::OnFishQuitRoomReq(FishPlayer* p, WrapPacket& pkg, QuitRoomReq& req, WrapPacket& response) {
    //
    // NOTICE 可重连类的房间,都是单人房,这个标记才会起作用
    // 如果之后有多人的可重连房间,这里的逻辑要重新改
    m_UserQuit = true;
    p->GetUser()->SetFishTableInfo(0, 0, 0);
    OnPlayerQuit(p, ELLT_UserQuit);
    LxGameHelper::MakeQuitRoomResp(response);
}

void FishTable::OnFishGetRoomDataReq(FishPlayer* p, WrapPacket& pkg, GetRoomDataReq& req, WrapPacket& response) {
    GetRoomDataResp resp;
    GetRoomProto(p, *resp.mutable_roominfo());
    response.set_packtype(EPT_RoomData);
    LxGameHelper::MakeGetRoomDataResp(response, resp);
}

void FishTable::GetRoomProto(FishPlayer* p, FishRoomProto& roomProto)
{
    for( int32 i = 0 ; i < ROOM_MAX_PLAYER ; ++i ) {
        if( m_arPlayers[i]->IsValid() ) {
            auto pData = roomProto.add_players();
            m_arPlayers[i]->FillFishPlayerProto(*pData);
        }
    }
    if( m_curPool._poolId == 0 ) {
        roomProto.set_sceneid(m_GamePlay._DefautFishPoolID);
    }
    else {
        roomProto.set_sceneid(m_curPool._poolId);
    }
    m_Fishes.ForEachEntity([&](FishFish* pFish) {
        if( pFish->GetSummoner() == 0 || pFish->GetSummoner() == p->GetKey() ) {
            pFish->FillProto(p->GetKey(), *(roomProto.add_fishes()));
        }
    });
    m_Shoals.ForEachEntity([&](FishShoal* pShoal) {
        pShoal->FillTideProto(roomProto);
    });

    roomProto.set_endtime(m_EndTime);
    roomProto.set_goldnow(m_goldNow);
    roomProto.set_scorenow(m_scoreNow);
    for( auto & it : m_mapCustomItems ) {
        auto item = roomProto.add_itemnow();
        item->set_item_id(it.first);
        item->set_item_change(it.second);
        item->set_item_num(it.second);
    }
    if( m_cdEndTime > 0 ) {
        roomProto.set_cdendtime(m_cdEndTime);
    }
    ForEachRoomTarget([&](const FishTargetInfo& info){
        *roomProto.add_targets() = info;
    });
    if( m_GamePlay._GameType == e_jsonGamePlayGameType_Arena ) {
        for( auto & id : m_setArenaPointDoubleFish ) {
            roomProto.add_arenadoublefish((int32)id);
        }
    }
    m_lineFishPool.ForEachKillPool([&](int32 poolId, int32 curKill, int32 maxKill){
        auto ptr = roomProto.add_pools();
        ptr->set_pool_id(poolId);
        ptr->set_cur_num(curKill);
        ptr->set_max_num(maxKill);
    });
    roomProto.set_summonbosspool(sRankingList->GetTableSummonPool(GetTableIndex()));
}

void FishTable::SetFreezeTime(uint64 playerId, int32 freezeTimeMS, bool show)
{
    m_TimeLine.SetFreeze(freezeTimeMS);

    SyncFreeze proto;
    proto.set_playerid(playerId);
    proto.set_freezetimems(freezeTimeMS);
    proto.set_isshow(show);
    WrapPacket pkg;
    LxGameHelper::MakeSyncFreeze(pkg, proto);
    SyncToAll(pkg);
}

void FishTable::TableRecycleFish(FishFish* fish) {
    int32 fishId = fish->GetKey();
    auto fishData = fish->GetFishData();

    m_PoolBossSet.erase(fishId);
    m_StopSummonSet.erase(fishId);
    m_StopFishPoolRefreshSet.erase(fishId);
    if( fishData._Simultaneous > 0 ) {
        DecLimitFish(fishData._ID);
    }
    ReturnFishRoute(fish->GetUsedTableRouteId());
    if( fish->IsEscaped() ) {
        RoomTargetOnFishEscape(fish);
        if( fishData._SummonBossRefundMin > 0 ) {
            // 说明是围猎boss逃跑了
            OnSummonBossDead(fish, 0);
        }
    }
    auto route = fish->GetRoute();
    if( route != nullptr ) {
        m_pGame->RemoveRoute(route);
    }

}

void FishTable::TableKillFish(FishPlayer* player, FishFish* fish, int64 gold) {
    if( fish != nullptr ) {
        RoomTargetOnKillFish(fish);
        TypeFishKilled(fish->GetFishType());
    }
    if( IsClassic() && gold > 0 ) {
        // 如果处于控分红利阶段, 则桌面不做赢分记录
        if( player->IsUser() && !player->GetUser()->IsUserInChargeBonus() ) {
            float totalRate = player->GetUser()->GetFishPoolRate() + m_tablePool._rate;
            int64 totalGold = gold*(1.0+totalRate);
            m_tablePool._lose += totalGold;
            if( m_tablePool._in_use ) {
                m_tablePool._pool -= gold;
            }
            // 获得金币时,有部分进入奖池
            int64 tax = (int64)(gold * m_tablePool._rate);
            if( m_tablePool._pool < m_tablePool._pool_start ) {
                m_tablePool._pool += tax;
            }
            m_tablePool.CheckUsePool();
        }
    }
}

bool FishTable::PlayerHitFish(FishPlayer* player, FishFish* fish, bool bForceKill, bool bForceKillBoss, double bulletPower, ActHitFish& msg) {
    int64 gold = 0;
    int64 tNow = sGameUtils->GetFakeTimeNow();
    if( !IsClassic() || bForceKill ) {
        int64 turretRate = player->GetTurretRate();
        if( !IsClassic() ) {
            // 非经典场不需要*炮倍
            turretRate = 1;
        }
        gold = turretRate*fish->GetScore();
        LOG_FISH_DEATH_NORATE(tNow
                                , m_GamePlay._ID
                                , GetKey()
                                , fish->GetIndex()
                                , fish->GetType()
                                , player->GetKey()
                                , fish->GetScore()
                                , gold
                                , 0
                                , fish->GetGoldCost());
    }
    else {
        gold = CalcHitFish(player, fish, bulletPower, bForceKillBoss);
        if( gold == 0 ) {
            return false;
        }
    }
    fish->OnDead();// 把鱼弄死
    // 部分特殊鱼死亡时,金币是不奖励的 召唤boss也在其中
    if( fish->IsSpecialFishWithNoGold() ) {
        gold = 0;
    }
    ItemPair bombItem;
    bombItem.set_item_id(0);
    for( int32 i = 0; i < ROOM_MAX_PLAYER; i++ ) {
        if( m_arPlayers[i]->IsValid() ) {
            m_arPlayers[i]->OnFishDead(fish);
            if( player == m_arPlayers[i] ) {
                gold = player->OnUserKillFish(fish, gold, bombItem);
            }
        }
    }
    TableKillFish(player, fish, gold);
    // 说明击杀了
    msg.set_fishid(fish->GetKey());
    msg.set_fishindex(fish->GetIndex());
    msg.set_playerid(player->GetKey());
    msg.set_basescore(gold);
    msg.set_addscore(0);
    msg.set_totalscore(gold);
    msg.set_summonbosspool(sRankingList->GetTableSummonPool(GetTableIndex()));
    if( fish->IsSummonBoss() ) {
        player->TryKillSummonBoss(fish, msg);
    }
    if( m_GamePlay._GameType == e_jsonGamePlayGameType_Custom_Gold ) {
        m_goldNow += gold;
    }
    else if( m_GamePlay._GameType == e_jsonGamePlayGameType_Arena ) {
        int32 ptType = GetArenaPointType();
        if( ptType == EAPT_Double ) {
            // 双倍期间要看一下是否是对应的鱼
            if( !IsPointDoubleFish(fish->GetIndex()) ) {
                ptType = EAPT_Normal;
            }
        }
        int32 fishScore = fish->GetArenaPoint()*(1.0f+player->GetTurretPointExtra()*1.0f/1000.0f);
        int32 randNumber = GlobalUtils::GetRandNumber(0,100);
        int32 crit = 0;
        if( randNumber <= JDATA->SystemConstPtr()->GetArenaRankCritical()*(1.0+player->GetTurretPointCr()*1.0f/1000.0f) ) {
            crit = 1;
        }
        if( crit ) {
            fishScore = fishScore * ptType * 2;
            m_scoreNow += fish->GetArenaPoint()*ptType*2;
        }
        else {
            fishScore = fishScore * ptType;
        }
        m_scoreNow += fishScore;
        msg.set_arenacurscore(m_scoreNow);
        msg.set_arenascore(fishScore);
        msg.set_arenascorecrit(crit);
        msg.set_arenascoretype(ptType);
    }
    int32 buffId = 0, duration = 0;
    if( fish->GetDeathBuff(buffId, duration) ) {
        if( !player->HasBuff(buffId) ) {
            player->AddBuff(buffId, fish->GetIndex(), duration);
            auto buff = msg.add_buffs();
            buff->set_buff_id(buffId);
            buff->set_end_time(tNow + duration/1000);
        }
    }
    LxUser* pUser = player->GetUser();
    map<int32, int64> mapItem;
    fish->DoLoot(player->GetTurretIndex(), player->GetWingIndex()!=0, mapItem);
    if( !fish->IsSummonBoss() ) {
        // 非召唤boss死亡, 要检查一下受各种属性影响的掉落是否出现
        player->GetExtraDrop(fish->GetIndex(), mapItem);
    }
    if( fish->GetFishData()._CouponReward.size() == 2 ) {
        int32 num = JDATA->CouponPtr()->Size();
        if( pUser != nullptr && num > 0 ) {
            int32 loginNum = pUser->PBGetLoginNum()%num + 1;
            if( fish->GetFishData()._CouponReward[0] > 0 ) {
                // 计算奖券概率
                int32 totalCoupon = JDATA->CouponPtr()->CouponByID(loginNum) - pUser->PBGetTodayCoupon();
                if( totalCoupon > 0 ) {
                    int32 rate = fish->GetFishData()._CouponReward[0]*pow(totalCoupon, JDATA->SystemConstPtr()->GetCouponControlParam()/1000.0f);
                    rate = rate*(1000.0f+pUser->GetHeroRelationAttr(e_jsonHeroRelationAllAttribute_CouponLoot))/1000.0f;
                    if( GlobalUtils::GetRandNumber(0,100) < rate) {
                        GlobalUtils::SimpleMapAdd(mapItem, JDATA->SystemConstPtr()->GetCoupon(), (int64)1);
                        pUser->PBIncTodayCoupon(1);
                    }
                }
            }
            if( fish->GetFishData()._CouponReward[1] > 0 ) {
                // 计算钻石概率
                int32 totalDiamond = JDATA->CouponPtr()->DiamondByID(loginNum) - pUser->PBGetTodayDiamond();
                if( totalDiamond > 0 ) {
                    int32 rate = fish->GetFishData()._CouponReward[1]*pow(totalDiamond, JDATA->SystemConstPtr()->GetCouponControlParam()/1000.0f);
                    rate = rate*(1000+player->GetTurretDiamondLoot())/1000;
                    if( GlobalUtils::GetRandNumber(0,100) < rate) {
                        GlobalUtils::SimpleMapAdd(mapItem, JDATA->SystemConstPtr()->GetDiamond(), (int64)1);
                        pUser->PBIncTodayDiamond(1);
                    }
                }
            }
        }
    }
    if( bombItem.item_id() != 0 ) {
        mapItem[bombItem.item_id()] = bombItem.item_num();
    }

    for( auto & item : mapItem ) {
        int64 itemNum = item.second;
        if( pUser != nullptr ) {
            switch(JDATA->ItemPtr()->MainTypeByID(item.first)) {
            case e_jsonItemMainType_ExpBook:
                itemNum = itemNum*(1000+pUser->GetHeroRelationAttr(e_jsonHeroRelationAllAttribute_ExpStoneLoot))/1000;
                break;
            default:
                break;
            }
        }
        RoomTargetGetItem(item.first, itemNum);
        player->GetUser()->ItemChange(item.first, itemNum, GetLogIncReason(), false);
        auto p = msg.add_dropitemlist();
        p->set_item_id(item.first);
        p->set_item_change(itemNum);
        p->set_item_num(itemNum);
        if( m_GamePlay._GameType == e_jsonGamePlayGameType_Custom_Stone &&
            e_jsonItemMainType_StarUpgrade == JDATA->ItemPtr()->MainTypeByID(item.first) ) {
            GlobalUtils::SimpleMapAdd(m_mapCustomItems, item.first, itemNum);
        }
        else if( m_GamePlay._GameType == e_jsonGamePlayGameType_Custom_Feather
            && e_jsonItemMainType_PhaseUpgrade == JDATA->ItemPtr()->MainTypeByID(item.first) ) {
            GlobalUtils::SimpleMapAdd(m_mapCustomItems, item.first, itemNum);
        }
    }
    if( fish->IsTortoiseFish() ) {
        // 如果是翻牌
        msg.set_gametype(EFKG_Tortoise);
        msg.set_gameturretrate(player->GetTurretRate());
        auto data = GlobalUtils::SplitTortoiseScore((int32)fish->GetScore());
        msg.add_tortoisenumbers(TUPLE0(data));
        msg.add_tortoisenumbers(TUPLE1(data));
        msg.add_tortoisenumbers(TUPLE2(data));
        player->GetUser()->SendUserInfoChange(EPIC_FishTortoise);
    }
    else if( fish->IsTurnTableFish() ) {
        msg.set_gametype(EFKG_TurnTable);
        msg.set_gameturretrate(player->GetTurretRate());
        Roll ttPool;
        sHFish->GetTurnTablePool(ttPool);
        ttPool.remove_value(fish->GetTurnTableM());
        msg.set_turntableinside(fish->GetTurnTableN());
        msg.set_turntableoutside(fish->GetTurnTableM());
        msg.add_turntablenumbers(fish->GetTurnTableM());
        for(int i = 0 ; i < 7 ; i++) {
            msg.add_turntablenumbers((int32)ttPool.roll());
        }
        player->GetUser()->SendUserInfoChange(EPIC_FishTurnTable);
    }
    else if( fish->IsTreasureBoxFish() ) {
        set<int32> cards;
        player->OnKillTreasureFish(fish->GetKey(), fish->GetTreasureBoxParam(), cards);
        for( auto& card : cards ) {
            msg.add_cards(card);
        }
    }
    else {
        player->GetUser()->SendUserInfoChange(EPIC_FishReward);
    }
    if( m_goldNow > 0 ) {
        msg.set_customgoldnow(m_goldNow);
    }
    if( !m_mapCustomItems.empty() ) {
        for( auto & item : m_mapCustomItems ) {
            auto ptr = msg.add_customitemnow();
            ptr->set_item_id(item.first);
            ptr->set_item_change(item.second);
            ptr->set_item_num(item.second);
        }
    }
    m_lineFishPool.ForEachKillPool([&](int32 poolId, int32 curKill, int32 maxKill){
        auto ptr = msg.add_pools();
        ptr->set_pool_id(poolId);
        ptr->set_cur_num(curKill);
        ptr->set_max_num(maxKill);
    });

    return true;
}

// 击中鱼
void FishTable::OnFishInputHitFish(FishPlayer* player, WrapPacket& pkg, InputHitFish& proto, WrapPacket& response)
{
    response.clear_userid();
    // 防一手抓包
    if( !player->CheckTablePlayGold() ) {
        return;
    }
    int32 bulletId = proto.bulletid();
    int32 fishId = proto.fishid();
    //检查子弹
    auto bullet = GetBullet(player, bulletId);
    if ( bullet == nullptr ) {
        return;
    }
    if (!bullet->OnHit()) {
        return;
    }
    FishFish* fish = m_Fishes.GetEntity(fishId);
    if (fish == nullptr) {
        return;
    }
    if( !fish->IsValid() ) {
        return;
    }
    if( player->HitTableBoss(fish) ) {
        return;
    }
    fish->AddPlayerCost(player->GetKey(), player->GetTurretRate()*player->GetBulletPower());
    // 这个消息上来的,都是一次计算所有的HitNum,同时不考虑一击必杀的情况
    // 先计算伤害
    auto data = fish->GetDefence();
    int32 dmg = player->CalculateDamage(TUPLE0(data), TUPLE1(data));
    fish->OnDamage(player->GetKey(), dmg*player->GetBulletPower());
    if( fish->GetCurHp(player->GetKey()) > 0 ) {
        return;
    }
    {
        // 如果处于控分红利阶段, 则桌面不做赢分记录
        int64 gold = player->GetTurretRate()*player->GetBulletPower();
        if( player->IsUser() && IsClassic() && !fish->IsTreasureBoxFish() && !fish->IsBombCardFish() && !IsPoolBoss(fish->GetKey()) ) {
            // 召唤类boss, 桌面和玩家都不参与净分计算
            player->OnFire(gold);
            if( !player->GetUser()->IsUserInChargeBonus() ) {
                // 在放分阶段, 桌面也不参与净分计算
                m_tablePool._win += gold;
            }
        }
    }

    ActHitFish msg;
    if( PlayerHitFish(player, fish, false, false, player->GetBulletPower(), msg) ) {
        WrapPacket syncPkt;
        LxGameHelper::MakeActHitFish(syncPkt, msg);
        SyncToAll(syncPkt);
    }
}

void FishTable::OnFishInputHitFishs(FishPlayer* player, WrapPacket& pkg, InputHitFishs& proto, WrapPacket& response)
{
    response.clear_userid();
    ActHitFishs msg;
    msg.set_playerid(player->GetKey());
    msg.set_buffid(proto.buffid());
    msg.set_bulletid(proto.bulletid());
    msg.set_lockfishid(proto.lockfishid());
    msg.set_rotateangle(proto.rotateangle());
    if( player->InSuperStatus() && proto.buffid() == 0 ) {
        auto user = player->GetUser();
        // 超级武器的击杀模式与普通子弹不同
        tagJsonSkill sklData;
        if( !JDATA->SkillPtr()->ByID(player->GetSuperWeaponSkillId(), sklData) ) {
            LOGERROR("[%lu]super weapon id[%d] failed", player->GetKey(), player->GetSuperWeaponSkillId());
            return;
        }
        int32 mainBulletNum = 0;
        int32 otherBulletNum = 0;
        if( sklData._Param.size() == 3 ) {
            int32 bulletNum = sklData._Param[0]*(100+user->TechGetSuperWeaponEffect())/100;
            mainBulletNum = bulletNum * sklData._Param[2] / 100;
            otherBulletNum = bulletNum - mainBulletNum;
        }
        else if( sklData._Param.size() == 6 ) {
            int32 bulletNum = sklData._Param[0]*(100+sHTech->GetTechEffect(sklData._Param[1], sklData._Param[2]))/100;
            mainBulletNum = bulletNum * sklData._Param[3] / 100;
            otherBulletNum = bulletNum - mainBulletNum;
        }
        else {
            LOGERROR("[%lu]super weapon skill param[%d] failed", player->GetKey(), sklData._ID);
            return;
        }
        int64 cost = (mainBulletNum+otherBulletNum)*player->GetTurretRate();
        if( !IsClassic() ) {
            cost = 0;
        }
        int64 curGold = user->PBGetUserGold();
        bool lastShot = false;
        if( curGold > 0 && cost > curGold ) {
            // 如果玩家是有钱的 ,但是不够发这一炮, 让他发出去
            cost = curGold;
            lastShot = true;
        }
        if( cost > 0 && !user->ChangeGold(-cost, 10000+GetTableIndex()) ) {
            return;
        }

        if( cost > 0 ) {
            m_LogData.LogPlayerFire(cost);
        }
        if( user->PBGetNewbieFeeId() != 0 ) {
            user->PBIncNewbieFeeGold(cost);
        }
        player->SuperFire();

        FishFish* mainTarget = m_Fishes.GetEntity(proto.lockfishid());
        vector<FishFish*> vecTargets;
        for( int32 n = 0 ; n < proto.fishids_size() ; ++n ) {
            int32 fishId = proto.fishids(n);
            FishFish* fish = m_Fishes.GetEntity(fishId);
            if (fish == nullptr)
            {
                continue;
            }
            if( !fish->IsValid() ) {
                continue;
            }
            vecTargets.push_back(fish);
        }
        if( mainTarget == nullptr ) {
            // 没有主目标, 所有子弹全部打次要目标
            otherBulletNum += mainBulletNum;
            mainBulletNum = 0;
        }
        else {
            //
            // 次要目标为空, 则所有子弹全部打主目标
            // 次要目标中也要包括主目标, 因此这里如果次要目标非空, 需要重算一下主目标的实际中弹数量
            if( vecTargets.size() == 0 ) {
                mainBulletNum = mainBulletNum + otherBulletNum;
                otherBulletNum = 0;
            }
            else {
                int32 bulletNum = otherBulletNum / (vecTargets.size()+1);
                mainBulletNum += bulletNum;
                otherBulletNum -= bulletNum;
            }
        }
        int64 goldNoCost = 0;  // 击中卡牌鱼, 宝箱鱼, 或者召唤boss的钱, 不能算在玩家消耗里
        if( mainTarget != nullptr ) {
            if( mainTarget->IsTreasureBoxFish() || mainTarget->IsBombCardFish() || IsPoolBoss(mainTarget->GetKey()) ) {
                goldNoCost += player->GetTurretRate()*mainBulletNum;
            }
            mainTarget->AddPlayerCost(player->GetKey(), player->GetTurretRate()*mainBulletNum);
            auto data = mainTarget->GetDefence();
            int32 dmg = player->CalculateDamage(TUPLE0(data), TUPLE1(data));
            mainTarget->OnDamage(player->GetKey(), dmg*mainBulletNum);
            if( mainTarget->GetCurHp(player->GetKey()) <= 0 ) {
                ActHitFish result;
                if( PlayerHitFish(player, mainTarget, false, false, mainBulletNum, result) ) {
                    *msg.add_results() = result;
                }
            }
        }
        for( size_t i = 0; i < vecTargets.size() ; ++i ) {
            int32 bulletNum = otherBulletNum/vecTargets.size();
            if( vecTargets[i]->IsTreasureBoxFish() || vecTargets[i]->IsBombCardFish() || IsPoolBoss(vecTargets[i]->GetKey()) ) {
                goldNoCost += player->GetTurretRate()*bulletNum;
            }
            vecTargets[i]->AddPlayerCost(player->GetKey(), player->GetTurretRate()*bulletNum);
            auto data = vecTargets[i]->GetDefence();
            int32 dmg = player->CalculateDamage(TUPLE0(data), TUPLE1(data));
            vecTargets[i]->OnDamage(player->GetKey(), dmg*bulletNum);
            if( vecTargets[i]->GetCurHp(player->GetKey()) <= 0 ) {
                ActHitFish result;
                if( PlayerHitFish(player, vecTargets[i], false, false, bulletNum, result) ) {
                    *msg.add_results() = result;
                }
            }
        }
        if( IsClassic() ) {
            player->OnFire(cost-goldNoCost);
            if( !player->GetUser()->IsUserInChargeBonus() ) {
                // 在放分阶段, 桌面也不参与净分计算
                m_tablePool._win += (cost-goldNoCost);
            }
        }
        if( lastShot && user->PBGetUserGold() <= 0 ) {
            // 最后一发要同步出去给客户端, 否则破产流程会出错
            user->SendUserInfoChange(0);
        }
    }
    else {
        int32 buffId = proto.buffid();
        int32 bulletId = proto.bulletid();
        //检查子弹
        auto bullet = GetBullet(player, bulletId);
        if (bullet == nullptr) {
            return;
        }
        auto buff = player->GetBuffPtr(buffId);
        if( buff == nullptr ) {
            return;
        }
        for( int32 n = 0 ; n < proto.fishids_size() ; ++n ) {
            int32 fishId = proto.fishids(n);
            FishFish* fish = m_Fishes.GetEntity(fishId);
            if (fish == nullptr)
            {
                continue;
            }
            if( !fish->IsValid() ) {
                continue;
            }
            if( bullet->OnHit() ) {
                auto result = msg.add_results();
                PlayerHitFish(player, fish, true, false, player->GetBulletPower(), *result);
                buff->_gold += result->basescore();
            }
        }
    }
    msg.set_gold(player->GetUser()->PBGetUserGold());

    WrapPacket syncPkg;
    LxGameHelper::MakeActHitFishs(syncPkg, msg);
    SyncToAll(syncPkg);
}

void FishTable::OnFishInputManualFire(FishPlayer* player, WrapPacket& pkg, InputManualFire& proto, WrapPacket& response)
{
    int32 bulletId = proto.bulletid();
    int32 bulletType = proto.bullettype();
    int32 bulletAngle = proto.bulletangle();

    do {
        if( !player->CheckBulletSpeed() ) {
            break;
        }
        if( !player->CheckTablePlayGold() ) {
            if( player->GetInValidBulletDueToGold() >= 10 ) {
                SyncNeedChangeRoom msg;
                msg.set_gold(player->GetUser()->PBGetUserGold());
                WrapPacket syncPkg;
                LxGameHelper::MakeSyncNeedChangeRoom(syncPkg, msg);
                SyncToPlayer(player, syncPkg);
                player->SetInValidBulletDueToGold(0);
            }
            else{
                player->ChangeInValidBulletDueToGold(1);
            }
            break;
        }
        // 先判断一次保险
        auto user = player->GetUser();
        if( user == nullptr ) {
            LOGERROR("FIRE user failed[%ld]", player->GetKey());
            break;
        }
        if( IsClassic() && user->PBGetUserGold() <= 0 ) {
            // 客户端的金币和服务器可能同步上有时间差异, 这里服务器发现是0了, 强制发一个同步包出去, 保证客户端数据正确,不会继续开炮
            ActManualFire msg;
            msg.set_playerid(player->GetKey());
            msg.set_bulletid(bulletId);
            msg.set_bulletangle(bulletAngle);
            msg.set_bullettype(bulletType);
            msg.set_bulletcount(proto.bulletcount());
            msg.set_cost(0);
            msg.set_playerlevel(player->GetUserLevel());
            msg.set_playervip(player->GetUserVip());
            msg.set_total(0);

            WrapPacket packet = pkg;
            LxGameHelper::MakeActManualFire(packet, msg);
            SyncToAll(packet);
            break;
        }
        int64 cost = 0;
        if( proto.buffid() == 0 || !player->HasBuff(proto.buffid()) ) {
            cost = player->GetTurretRate() * player->GetBulletPower();
            if( !IsClassic() ) {
                cost = 0;
            }
            int64 curGold = user->PBGetUserGold();
            bool lastShot = false;
            if( curGold > 0 && cost > curGold ) {
                // 如果玩家是有钱的 ,但是不够发这一炮, 让他发出去
                cost = curGold;
                lastShot = true;
            }
            if( cost > 0 && !user->ChangeGold(-cost, 10000+GetTableIndex(), true) ) {
                break;
            }
            if( lastShot ) {
                // 最后一发要同步出去给客户端, 否则破产流程会出错
                user->SendUserInfoChange(0);
            }
            if( cost > 0 ) {
                m_LogData.LogPlayerFire(cost);
            }
            if( user->PBGetNewbieFeeId() != 0 ) {
                user->PBIncNewbieFeeGold(cost);
            }
        }
        player->CreateBullet(bulletId);
        PushBullet(player, bulletId, bulletAngle, bulletType, proto.bulletcount(), cost);
        // m_lastFireTick = 0;
        // m_lastTideTick = 0;
        // m_lastCreateFishTick = 0;
        // m_lastTargetTick = 0;
        // DoDelaySyncs();
    } while(0);
    response.clear_userid();
}

void FishTable::DoDelaySyncs() {
    int64 tick = GlobalUtils::GetTickCount();
    bool hasData = false;
    SyncTableCombineMsg msg;
    if( !m_lstFire.empty() && tick - m_lastFireTick >= m_nFireInterval ) {
        msg.set_interval(m_nFireInterval);
        for( auto& fire : m_lstFire ) {
            *msg.add_fires() = fire;
        }
        m_lstFire.clear();
        m_lastFireTick = tick;
        hasData = true;
    }
    if( !m_lstTides.empty() && tick - m_lastTideTick >= 199 ) {
        for( auto& tide : m_lstTides ) {
            *msg.add_tides() = tide;
        }
        m_lstTides.clear();
        m_lastTideTick = tick;
        hasData = true;
    }
    if( !m_lstFishes.empty() && tick - m_lastCreateFishTick >= 199 ) {
        for( auto& fish : m_lstFishes ) {
            *msg.add_fishes() = fish;
        }
        m_lstFishes.clear();
        m_lastCreateFishTick = tick;
        hasData = true;
    }
    if( !m_mapPlayerLocks.empty() && tick - m_lastTargetTick >= 199 ) {
        for( auto& lock : m_mapPlayerLocks ) {
            *msg.add_targets() = lock.second;
        }
        m_mapPlayerLocks.clear();
        m_lastTargetTick = tick;
        hasData = true;
    }
    if( hasData ) {
        WrapPacket packet;
        LxGameHelper::MakeSyncTableCombineMsg(packet, msg);
        SyncToAll(packet);
    }
}

void FishTable::PushBullet(FishPlayer* player, int32 bulletId, int32 bulletAngle, int32 bulletType, int32 bulletCount, int64 cost) {
    ActManualFire msg;
    msg.set_playerid(player->GetKey());
    msg.set_bulletid(bulletId);
    msg.set_bulletangle(bulletAngle);
    msg.set_bullettype(bulletType);
    msg.set_bulletcount(bulletCount);
    msg.set_cost(cost);
    msg.set_playerlevel(player->GetUserLevel());
    msg.set_playervip(player->GetUserVip());
    msg.set_total(player->GetCurGold());
    m_lstFire.push_back(msg);
}

void FishTable::OnFishInputChangeRate(FishPlayer* player, WrapPacket& pkg, InputChangeRate& proto, WrapPacket& response)
{
    response.clear_userid();
    bool bTableRate = false;
    int32 tRate = proto.turretrate();
    for( size_t i = 0; i < m_GamePlay._TurretRate.size() ; ++i ) {
        if( tRate == m_GamePlay._TurretRate[i] ) {
            bTableRate = true;
            break;
        }
    }
    if( !bTableRate ) {
        if( m_GamePlay._InstituteTurret == 0 ) {
            return;
        }
        int32 maxRate = GetMaxTurretRate();
        if( tRate > maxRate + player->GetUser()->TechGetTurretRate() || tRate < maxRate ) {
            return;
        }
    }
    player->SetTurretRate(tRate);

    if( player->IsUser() ) {
        player->GetUser()->OnQuestChangeTurretRate();
        player->GetUser()->SendUserInfoChange(0);
    }

    ActChangeRate msg;
    msg.set_playerid(player->GetKey());
    msg.set_turretrate(tRate);

    WrapPacket packet = pkg;
    LxGameHelper::MakeActChangeRate(packet, msg);
    SyncToAll(packet);
}

void FishTable::OnFishInputChangeFury(FishPlayer* player, WrapPacket& pkg, InputChangeFury& proto, WrapPacket& response)
{
    response.clear_userid();
    int32 rate = proto.rate();
    if( rate < DEFAULT_FURY_RATE || rate > player->GetUser()->TechGetFuryEffect() + DEFAULT_FURY_RATE ) {
        return;
    }
    player->SetFuryRate(rate);

    ActChangeFury msg;
    msg.set_playerid(player->GetKey());
    msg.set_rate(rate);

    WrapPacket packet = pkg;
    LxGameHelper::MakeActChangeFury(packet, msg);
    SyncToAll(packet);
}

void FishTable::OnFishInputTurretRotate(FishPlayer* player, WrapPacket& pkg, InputTurretRotate& proto, WrapPacket& response)
{
    response.clear_userid();
    int32 rotateAngle = proto.rotateangle();
    player->SetTurretAngle(rotateAngle);

    ActTurretRotate msg;
    msg.set_playerid(player->GetKey());
    msg.set_rotateangle(rotateAngle);

    WrapPacket packet = pkg;
    LxGameHelper::MakeActTurretRotate(packet, msg);
    SyncToAll(packet);
}

void FishTable::OnFishInputLockFish(FishPlayer* player, WrapPacket& pkg, InputLockFish& proto, WrapPacket& response)
{
    response.clear_userid();
    int32 fishId = proto.fishid();
    if( !player->InLockStatus() ) {
        return;
    }
    if( player->GetLockFishId() == fishId ) {
        // 同一条鱼, 不切换
        return;
    }
    FishFish* logicFish = m_Fishes.GetEntity(fishId);
    if (logicFish == nullptr)
        return;
    player->SetLockFishId(fishId);
    ActLockFish msg;
    msg.set_playerid(player->GetKey());
    msg.set_fishid(fishId);
    msg.set_skillid(proto.skillid());
    msg.set_fishcfgid(logicFish->GetIndex());
    m_mapPlayerLocks[player->GetKey()] = msg;
}

void FishTable::BroadcastRoomTargets()
{
    SyncRoomTargets msg;
    ForEachRoomTarget([&](const FishTargetInfo& info){
        *msg.add_targets() = info;
    });
    WrapPacket pkg;
    LxGameHelper::MakeSyncRoomTargets(pkg, msg);
    SyncToAll(pkg);
}

void FishTable::OnFishLxUserChangeWeapon(FishPlayer* p, WrapPacket& pkg, LxUserChangeWeapon& req, WrapPacket& response) {
    response.clear_userid();// 不需要回包
    if( !p->IsUser() ) {
        return;
    }
    WrapPacket packet;
    SyncChangeWeapon msg;
    msg.set_playerid(p->GetKey());
    msg.set_weapon(p->GetUser()->PBGetUserSweapon());
    LxGameHelper::MakeSyncChangeWeapon(packet, msg);
    SyncToAll(packet);
}

void FishTable::OnFishLxUserChangeTurret(FishPlayer* p, WrapPacket& pkg, LxUserChangeTurret& req, WrapPacket& response) {
    response.clear_userid();// 不需要回包
    p->ReloadTurret();

    WrapPacket packet;
    SyncTurretOrSwing msg;
    msg.set_playerid(p->GetKey());
    msg.set_turret_index(p->GetTurretIndex());
    msg.set_turret_bullet_index(p->GetTurretBulletIndex());
    msg.set_swing_index(p->GetWingIndex());
    LxGameHelper::MakeSyncTurretOrSwing(packet, msg);
    SyncToAll(packet);
}

void FishTable::OnFishLxRandQuest(FishPlayer* p, WrapPacket& pkg, LxRandQuest& req, WrapPacket& response) {
    response.clear_userid();// 不需要回包
    if( m_GamePlay._RandomQuestList.size() == 0 ) {
        LOGERROR("QUEST user[%ld] want quest in table[%d]", p->GetUser()->GetKey(), GetTableIndex());
        return;
    }
    p->GetUser()->RandQuest(m_setQuest, m_GamePlay._RandomQuestList);
    p->GetUser()->SendUserInfoChange(0);
}

void FishTable::OnFishKickUserReq(FishPlayer* p, WrapPacket& pkg, KickUserReq& req, WrapPacket& response) {
    response.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    do {
        int32 vip = p->GetUser()->PBGetUserVip();
        if( !JDATA->VIPPtr()->CanKickByID(vip) ) {
            response.set_errorcode(JDATA->ErrorCodePtr()->GetVipKickDenied());
            break;
        }
        FishPlayer* target = GetPlayer(req.targetid());
        if( target == nullptr ) {
            response.set_errorcode(JDATA->ErrorCodePtr()->GetVipKickTargetLeave());
            break;
        }
        if( target->IsUser() && vip <= target->GetUser()->PBGetUserVip() ) {
            response.set_errorcode(JDATA->ErrorCodePtr()->GetVipKickLowVip());
            break;
        }
        int64 cost = JDATA->SystemConstPtr()->GetKickCost();
        if( !p->GetUser()->ChangeDiamond(-cost, ELRD_KickPlayer, false)  ) {
            response.set_errorcode(JDATA->ErrorCodePtr()->GetVipKickLowVip());
            break;
        }
        if( target->IsUser() ) {
            int64 gold = JDATA->SystemConstPtr()->GetBeKickedReward();
            target->GetUser()->ChangeGold(gold, ELRI_BeKicked);
            target->GetUser()->SendUserInfoChange(0);
            SyncUserBeKicked msg;
            msg.set_kicker_name(p->GetUserStarName());
            msg.set_gold(gold);
            CALL_CLIENT(target->GetUser(), SyncUserBeKicked, msg);
        }
        OnPlayerQuit(target, ELLT_BeKicked);
        p->GetUser()->SendUserInfoChange(0);
    }while(0);
    LxGameHelper::MakeKickUserResp(response);
}

void FishTable::OnFishImBrokenReq(FishPlayer* player, WrapPacket& req, ImBrokenReq& proto, WrapPacket& response) {
    LxUser* pUser = player->GetUser();
    if( pUser == nullptr ) {
        return;
    }
    response.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    do {
        if( pUser->PBGetUserGold() > 0 ) {
            break;
        }
        pUser->OnBroken();
        player->OnBroken();
    }while(0);
    pUser->SendUserInfoChange(0);
    LxGameHelper::MakeImBrokenResp(response);
}

void FishTable::OnFishUserKillBossReq(FishPlayer* player, WrapPacket& pkg, UserKillBossReq& proto, WrapPacket& response)
{
    response.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    do {
        auto pUser = player->GetUser();
        if( pUser == nullptr ) {
            response.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
            break;
        }
        auto fish = GetFish(proto.fishid());
        if( fish == nullptr || !fish->IsValid() ) {
            response.set_errorcode(JDATA->ErrorCodePtr()->GetKillBossNotFound());
            break;
        }
        if( !pUser->CanChangeItem(proto.itemid(), -1) ) {
            response.set_errorcode(JDATA->ErrorCodePtr()->GetItemUseNumLow());
            break;
        }
        tagJsonSkill tagSkl;
        if( !JDATA->SkillPtr()->ByID(JDATA->ItemPtr()->MiscByID(proto.itemid()), tagSkl) ) {
            response.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
            break;
        }
        bool bCanKill = false;
        for( size_t i = 0; i < tagSkl._Param.size() ; ++i ) {
            if( tagSkl._Param[i] == fish->GetIndex() ) {
                bCanKill = true;
                break;
            }
        }
        if( !bCanKill ) {
            response.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
            break;
        }
        pUser->ItemChange(proto.itemid(), -1, ELRD_ItemKillBoss, false);
        WrapPacket packet;
        SyncUserKillBoss msg;
        msg.set_playerid(player->GetKey());
        msg.set_fishid(proto.fishid());
        msg.set_itemid(proto.itemid());
        PlayerHitFish(player, fish, false, true, player->GetBulletPower(), *msg.mutable_result());
        LxGameHelper::MakeSyncUserKillBoss(packet, msg);
        SyncToAll(packet);
    }while(0);
    LxGameHelper::MakeUserKillBossResp(response);
}

void FishTable::OnFishInputSummonBossReward(FishPlayer* p, WrapPacket& pkg, InputSummonBossReward& req, WrapPacket& response) {
    response.clear_userid();
    SyncSummonBossReward msg;
    do {
        if( !p->IsUser() ) {
            break;
        }
        p->GetUser()->SendUserInfoChange(0);
        if( req.reset_rate() && !p->GetUser()->ItemChange(JDATA->SystemConstPtr()->GetSlotResetItemID(), -1, ELRD_ResetSummonBoss, false) ) {
            break;
        }
        int64 hammerNum = req.hammer_normal() + req.hammer_reset();
        if( hammerNum > 0 && !p->GetUser()->ItemChange(JDATA->SystemConstPtr()->GetHunterContinueItemID(), -hammerNum, ELRD_JarContinue, false) ) {
            LOGERROR("user[%lu] hammer not enough need[%d]", p->GetKey(), hammerNum);
            break;
        }
        msg.set_playerid(p->GetKey());
        p->SummonBossReward(req.reset_rate(), req.hammer_normal(), req.hammer_reset(), false, msg);
    }while(0);
    WrapPacket packet = pkg;
    LxGameHelper::MakeSyncSummonBossReward(packet, msg);
    SyncToAll(packet);
    p->GetUser()->SendUserInfoChange(EPIC_KillSummonBoss);
}

int32 FishTable::RoomTargetCheck() {
    if( m_GamePlay._RoomCondition.size() == 0 ) {
        return 0;
    }
    int32 nFinishedNeed = 0;
    int32 nFinishedGot = 0;
    for( size_t i = 0; i < m_GamePlay._RoomCondition.size() ; i += 3 ) {
        switch( m_GamePlay._RoomCondition[i] ) {
        case e_jsonGamePlayRoomCondition_Kill_Fish_MoreThan:
            ++nFinishedNeed;
            if( m_target.IsKillFishMoreThan(m_GamePlay._RoomCondition[i+1], m_GamePlay._RoomCondition[i+2]) ) {
                ++nFinishedGot;
            }
            break;
        case e_jsonGamePlayRoomCondition_Kill_Fish_Type_MoreThan:
            ++nFinishedNeed;
            if( m_target.IsKillFishTypeMoreThan(m_GamePlay._RoomCondition[i+1], m_GamePlay._RoomCondition[i+2]) ) {
                ++nFinishedGot;
            }
            break;
        case e_jsonGamePlayRoomCondition_Kill_Fish_LessThan:
            if( !m_target.IsKillFishLessThan(m_GamePlay._RoomCondition[i+1], m_GamePlay._RoomCondition[i+2]) ) {
                return EFRFR_TideFailed;
            }
            break;
        case e_jsonGamePlayRoomCondition_Kill_Fish_Type_LessThan:
            if( !m_target.IsKillFishTypeLessThan(m_GamePlay._RoomCondition[i+1], m_GamePlay._RoomCondition[i+2]) ) {
                return EFRFR_TideFailed;
            }
            break;
        case e_jsonGamePlayRoomCondition_SwingSkill_Use_LessThan:
            if( !m_target.IsSwingSkillUseLessThan(m_GamePlay._RoomCondition[i+1], m_GamePlay._RoomCondition[i+2]) ) {
                return EFRFR_TideFailed;
            }
            break;
        case e_jsonGamePlayRoomCondition_CommonSkill_Use_LessThan:
            if( !m_target.IsCommonSkillUseLessThan(m_GamePlay._RoomCondition[i+1], m_GamePlay._RoomCondition[i+2]) ) {
                return EFRFR_TideFailed;
            }
            break;
        case e_jsonGamePlayRoomCondition_Skill_Use_LessThan:
            if( !m_target.IsTypeSkillUseLessThan(m_GamePlay._RoomCondition[i+1], m_GamePlay._RoomCondition[i+2]) ) {
                return EFRFR_TideFailed;
            }
            break;
        case e_jsonGamePlayRoomCondition_FishLife_LessThan:
            if( !m_target.IsEscapeFishGroupLessThan(m_GamePlay._RoomCondition[i+1], m_GamePlay._RoomCondition[i+2]) ) {
                return EFRFR_TideFailed;
            }
            break;
        case e_jsonGamePlayRoomCondition_GetGold_MoreThan:
            ++nFinishedNeed;
            if( m_target.IsGetGoldMoreThan(m_GamePlay._RoomCondition[i+2]) ) {
                ++nFinishedGot;
            }
            break;
        case e_jsonGamePlayRoomCondition_GetExp_MoreThan:
            ++nFinishedNeed;
            if( m_target.IsGetExpMoreThan(m_GamePlay._RoomCondition[i+2]) ) {
                ++nFinishedGot;
            }
            break;
        case e_jsonGamePlayRoomCondition_GetItem_MoreThan:
            ++nFinishedNeed;
            if( m_target.IsGetItemMoreThan(m_GamePlay._RoomCondition[i+1], m_GamePlay._RoomCondition[i+2]) ) {
                ++nFinishedGot;
            }
            break;
        case e_jsonGamePlayRoomCondition_FishLife_MoreThan:
            ++nFinishedNeed;
            if( m_target.IsEscapeFishGroupMoreThan(m_GamePlay._RoomCondition[i+1], m_GamePlay._RoomCondition[i+2]) ) {
                ++nFinishedGot;
            }
            break;
        }
    }
    // 正常情况通关目标肯定是有一条数量超过类型的
    if( nFinishedNeed == 0 ) {
        LOGERROR("table[%d] condition error", m_GamePlay._ID);
        return 0;
    }
    if( nFinishedGot >= nFinishedNeed ) {
        return EFRFR_TideCompleted;
    }
    return 0;
}

void FishTable::RoomTargetOnUseSwingSkill(int32 skillId, int32 skillType) {
    if( m_GamePlay._RoomCondition.size() == 0 ) {
        return;
    }
    ++m_target._swing_skill_use_num;

    GlobalUtils::SimpleMapAdd(m_target._type_skill_use_num, skillType, 1);
    BroadcastRoomTargets();
}

void FishTable::RoomTargetOnUseCommonSkill(int32 skillId, int32 skillType) {
    if( m_GamePlay._RoomCondition.size() == 0 ) {
        return;
    }
    GlobalUtils::SimpleMapAdd(m_target._type_skill_use_num, skillType, 1);
    GlobalUtils::SimpleMapAdd(m_target._skill_use_num, skillId, 1);
    BroadcastRoomTargets();
}

void FishTable::RoomTargetOnKillFish(FishFish* fish) {
    if( m_GamePlay._RoomCondition.size() == 0 ) {
        return;
    }
    fish->ForEachQuestGroup([&](int32 taskGroup){
        GlobalUtils::SimpleMapAdd(m_target._group_fish_killed, taskGroup, 1);
    });
    ++m_target._total_fish_killed;
    GlobalUtils::SimpleMapAdd(m_target._fish_killed, fish->GetIndex(), 1);
    BroadcastRoomTargets();
}

void FishTable::RoomTargetOnFishEscape(FishFish* fish) {
    if( m_GamePlay._RoomCondition.size() == 0 ) {
        return;
    }
    fish->ForEachQuestGroup([&](int32 taskGroup){
        GlobalUtils::SimpleMapAdd(m_target._group_fish_escaped, taskGroup, 1);
    });
    BroadcastRoomTargets();
}

void FishTable::RoomTargetGetItem(int32 itemId, int64 itemNum) {
    if( m_GamePlay._RoomCondition.size() == 0 ) {
        return;
    }
    if( m_GamePlay._GameType == e_jsonGamePlayGameType_Custom_Stone ) {
        GlobalUtils::SimpleMapAdd(m_target._items, itemId, itemNum);
    }
    else if( m_GamePlay._GameType == e_jsonGamePlayGameType_Custom_Feather ) {
        GlobalUtils::SimpleMapAdd(m_target._items, itemId, itemNum);
    }
}

void FishTable::RoomTargetGetGold(int64 gold) {
    if( m_GamePlay._RoomCondition.size() == 0 ) {
        return;
    }
    if( m_GamePlay._GameType == e_jsonGamePlayGameType_Custom_Gold ) {
        m_target._gold += gold;
    }
}

void FishTable::ForEachRoomTarget(std::function<void(const FishTargetInfo&)> func) {
    if( m_GamePlay._RoomCondition.size() == 0 ) {
        return;
    }
    for( size_t i = 0; i < m_GamePlay._RoomCondition.size() ; i += 3 ) {
        FishTargetInfo info;
        bool bServerOnly = false;
        switch( m_GamePlay._RoomCondition[i] ) {
        case e_jsonGamePlayRoomCondition_Kill_Fish_MoreThan:
        case e_jsonGamePlayRoomCondition_Kill_Fish_LessThan:
            info.set_cur_num(m_target.GetKillFishNum(m_GamePlay._RoomCondition[i+1]));
            info.set_target_num(m_GamePlay._RoomCondition[i+2]);
            break;
        case e_jsonGamePlayRoomCondition_Kill_Fish_Type_MoreThan:
        case e_jsonGamePlayRoomCondition_Kill_Fish_Type_LessThan:
            info.set_cur_num(m_target.GetKillFishTypeNum(m_GamePlay._RoomCondition[i+1]));
            info.set_target_num(m_GamePlay._RoomCondition[i+2]);
            break;
        case e_jsonGamePlayRoomCondition_SwingSkill_Use_LessThan:
            info.set_cur_num(m_target.GetSwingSkillUseNum(m_GamePlay._RoomCondition[i+1]));
            info.set_target_num(m_GamePlay._RoomCondition[i+2]);
            break;
        case e_jsonGamePlayRoomCondition_CommonSkill_Use_LessThan:
            info.set_cur_num(m_target.GetCommonSkillUseNum(m_GamePlay._RoomCondition[i+1]));
            info.set_target_num(m_GamePlay._RoomCondition[i+2]);
            break;
        case e_jsonGamePlayRoomCondition_Skill_Use_LessThan:
            info.set_cur_num(m_target.GetTypeSkillUseNum(m_GamePlay._RoomCondition[i+1]));
            info.set_target_num(m_GamePlay._RoomCondition[i+2]);
            break;
        case e_jsonGamePlayRoomCondition_FishLife_MoreThan:
        case e_jsonGamePlayRoomCondition_FishLife_LessThan:
            info.set_cur_num(m_target.GetEscapeFishGroupNum(m_GamePlay._RoomCondition[i+1]));
            info.set_target_num(m_GamePlay._RoomCondition[i+2]);
            break;
        default:
            bServerOnly = true;
            break;
        }
        if( !bServerOnly )
            func(info);
    }
}

void FishTable::TableCreateFish(int fishCfgId, int routeId, FishShoal* pShoal)
{
    auto fishRoute = m_pGame->CreateAdvanceRoute(routeId);
    if (fishRoute == nullptr)
    {
        LOGERROR("failed to create route[%d] for fish[%d]", routeId, fishCfgId);
        return;
    }
    auto logicFish = m_Fishes.CreateEntity(this, pShoal, m_pGame->FetchFishId(1), fishCfgId, fishRoute);
    if( logicFish == nullptr ) {
        LOGERROR("CREATE fish failed fish[%d] routeId[%d] groupId[%d]", fishCfgId, routeId);
        return;
    }
    logicFish->SetUsedTableRouteId(routeId);
    BroadcastCreateFish(logicFish, routeId);
}

void FishTable::TableCreateBoss(int64 guid, int fishCfgId, int routeId, FishPlayer* player)
{
    auto fishRoute = m_pGame->CreateAdvanceRoute(routeId);
    if (fishRoute == nullptr)
    {
        LOGERROR("failed to create route[%d] for fish[%d]", routeId, fishCfgId);
        return;
    }
    auto logicFish = m_Fishes.CreateEntity(this, nullptr, m_pGame->FetchFishId(1), fishCfgId, fishRoute);
    if( logicFish == nullptr ) {
        LOGERROR("CREATE fish failed fish[%d] routeId[%d] groupId[%d]", fishCfgId, routeId);
        return;
    }
    logicFish->SetBossGuid(guid);
    logicFish->SetUsedTableRouteId(routeId);
    BroadcastCreateFish(logicFish, routeId);
}

void FishTable::TideCreateFish(FishShoal* pShoal, int fishId, int fishCfgId, FishRoute* fishRoute)
{
    //鱼群里的鱼，客户端自己创建，服务器不通知
    m_Fishes.CreateEntity(this, pShoal, fishId, fishCfgId, fishRoute);
}

uint64 FishTable::GetFirstUser() {
    for( int32 i = 0 ; i < ROOM_MAX_PLAYER ; ++i ) {
        if( m_arPlayers[i]->IsUser() ) {
            return m_arPlayers[i]->GetKey();
        }
    }
    return 0;
}

void FishTable::TableCreateFishes(const list<IntPair>& lst, FishShoal* pShoal)
{
    uint64 userId = 0;
    if( !IsClassic() ) {
        userId = GetFirstUser();
    }
    for( auto& fish : lst ) {
        int32 fishIndex = fish.key();
        int32 routeId = fish.value();
        auto fishRoute = m_pGame->CreateAdvanceRoute(routeId);
        if (fishRoute == nullptr)
        {
            LOGERROR("failed to create route[%d] for fish[%d]", routeId, fishIndex);
            continue;
        }
        auto logicFish = m_Fishes.CreateEntity(this, pShoal, m_pGame->FetchFishId(1), fishIndex, fishRoute);
        if( logicFish == nullptr ) {
            LOGERROR("CREATE fish failed fish[%d] routeId[%d] groupId[%d]", fishIndex, routeId);
            continue;
        }
        logicFish->SetUsedTableRouteId(routeId);
        TableFishInfo fishInfo;
        fishInfo.set_id(logicFish->GetKey());
        fishInfo.set_fishid(logicFish->GetIndex());
        fishInfo.set_routeid(routeId);
        fishInfo.set_lifetick((int32)(logicFish->GetLifeTime()*1000));
        if( userId != 0 ) {
            logicFish->GetHpInfo(userId, *fishInfo.mutable_hpinfo());
        }
        m_lstFishes.push_back(fishInfo);
    }
}

// 计算鱼死亡
int64 FishTable::CalcHitFish(FishPlayer* player, FishFish* fish, double bulletPower, bool bForceKillBoss) {
    if( !player->IsUser() ) {
        // 本函数只会被用户使用
        return 0;
    }
    uint64 userId = player->GetKey();
    tagFishHitParam param;
    player->GetFishParam(fish, bulletPower, param);
    bool bKillByMercy = false;
    if( !bForceKillBoss && param.hitNum < param.expectNum ) {
        bKillByMercy = player->KillNow(fish, param.expectNum - param.hitNum + 1);
        if( !bKillByMercy ) {
            return 0;
        }
    }
    if( fish->IsBombCardFish() || fish->IsTreasureBoxFish() || (fish->IsSummonBoss() && !bForceKillBoss) ) {
        // 召唤boss和卡牌鱼, 要满足预期消耗才能击杀 因为预期收益是按击杀时炮倍计算的, 所以击杀时也需要满足当前炮倍对应的预期消耗
        if( param.totalGold < param.expectNum*player->GetTurretRate() ) {
            return 0;
        }
    }
    int64 gold = ((int64)param.score)*player->GetTurretRate();
    if( bKillByMercy ) {
        player->GetUser()->KillByBrokenBonus(gold);
    }
    fish->SetKillerCost(param.totalGold);
    fish->SetKillerExpectNum(param.expectNum);
    fish->SetKillerSummonBossScore(param.score);
    fish->SetBonusBoss(param.isBonusBoss);
    fish->SetBossPointParam(param.bossPointParam);
    // 鱼击杀了 算出来的总值再乘上炮台的金币额外奖励
    LOG_FISH_DEATH_V2(sGameUtils->GetFakeTimeNow()
                            , m_GamePlay._ID
                            , fish->GetIndex()
                            , fish->GetType()
                            , userId
                            , param.score
                            , gold
                            , fish->GetCurLifeTick()
                            , param.Fi, param.BP, param.BN, param.AT, param.B, param.R, param.F, param.f, param.rate, param.expectNum
                            , bKillByMercy
                            , GetPlayerCount(ERPT_All)
                            , player->GetTurretIndex()
                            , player->GetTurretSpeed()
                            , bulletPower
                            , player->GetUser()->PBGetFishWinGold()
                            , player->GetUser()->PBGetFishCostGold()
                            , m_tablePool._win
                            , m_tablePool._lose);
    return gold;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void FishTable::SyncToPlayer(FishPlayer* player, WrapPacket& pkg)
{
    pkg.set_packtype(EPT_Sync);
    pkg.set_connectionid(player->GetUser()->GetConnectionId());
    pkg.set_userid(player->GetUser()->GetKey());
    sDispatcher->call_client(pkg);
}

void FishTable::SyncToOtherPlayers(FishPlayer* thisPlayer, WrapPacket& pkg) {
    for( int32 i = 0 ; i < ROOM_MAX_PLAYER ; ++i ) {
        if( m_arPlayers[i]->IsUser() && thisPlayer != m_arPlayers[i] ) {
            SyncToPlayer(m_arPlayers[i], pkg);
        }
    }
}

void FishTable::SyncToAll(WrapPacket& pkg) {
    for( int32 i = 0 ; i < ROOM_MAX_PLAYER ; ++i ) {
        if( m_arPlayers[i]->IsUser() ) {
            SyncToPlayer(m_arPlayers[i], pkg);
        }
    }
}

int32 FishTable::GetPlayerCount(E_GetPlayerType eType)
{
    int32 count = 0;
    for( int32 i = 0 ; i < ROOM_MAX_PLAYER ; ++i ) {
        switch( eType ) {
        case ERPT_All:
            if( m_arPlayers[i]->IsValid() ) {
                count++;
            }
            break;
        case ERPT_User:
            if( m_arPlayers[i]->IsUser() ) {
                count++;
            }
            break;
        }
    }
    return count;
}

FishPlayer* FishTable::GetPlayer(uint64 playerId)
{
    for( int32 i = 0 ; i < ROOM_MAX_PLAYER ; ++i ) {
        if( m_arPlayers[i]->IsValid() && m_arPlayers[i]->GetKey() == playerId ) {
            return m_arPlayers[i];
        }
    }
    return nullptr;
}

uint64 FishTable::GetRandPlayerId() {
    Roll roll;
    for( int32 i = 0 ; i < ROOM_MAX_PLAYER ; ++i ) {
        if( m_arPlayers[i]->IsValid() ) {
            roll.push_value(100, (int64)m_arPlayers[i]->GetKey());
        }
    }
    return roll.roll();
}

FishPlayer* FishTable::PlayerSitDown(LxUser* pUser) {
    // 先检查该用户是否在某个位子上
    for( int32 i = 0 ; i < ROOM_MAX_PLAYER ; ++i ) {
        auto player = m_arPlayers[i];
        if( player->IsUser() && player->GetKey() == pUser->GetKey() ) {
            if( !player->Init(this, pUser) ) {
                LOGERROR("player join failed");
                return nullptr;
            }
            player->SetSeatId(i);
            return player;
        }
    }
    // 没有老用户在桌子上,就选个位置
    for( int32 i = 0 ; i < ROOM_MAX_PLAYER ; ++i ) {
        auto player = m_arPlayers[i];
        if( !player->IsValid() ) {
            if( !player->Init(this, pUser) ) {
                LOGERROR("player join failed");
                return nullptr;
            }
            player->SetSeatId(i);
            sGameUtils->IncTableUser(GetTableIndex());
            return m_arPlayers[i];
        }
    }
    return nullptr;
}

bool FishTable::IsInRoom(uint64 userId) {
    for( int32 i = 0 ; i < ROOM_MAX_PLAYER ; ++i ) {
        if( m_arPlayers[i]->IsValid() && m_arPlayers[i]->GetKey() == userId ) {
            return true;
        }
    }
    return false;
}

void FishTable::GetAllPlayer(vector<LxUser*>& vec) {
    for( int32 i = 0 ; i < ROOM_MAX_PLAYER ; ++i ) {
        if( m_arPlayers[i]->IsUser() ) {
            vec.push_back(m_arPlayers[i]->GetUser());
        }
    }
}

void FishTable::OnPlayerQuit(FishPlayer* player, int32 reason)
{
    if( player->IsUser() ) {
        if( !IsInRoom(player->GetKey()) ) {
            return;
        }
        // power字段, 战力重要性不高, 目前用来记录玩家在本房间呆的时间, 用于统计游戏时长
        LOG_GAME_LEAVE(player->GetUser()
                        , reason
                        , player->GetUser()->PBGetUserGold()
                        , player->GetUser()->PBGetDiamondFree()
                        , player->GetUser()->PBGetDiamondRmb()
                        , player->GetUser()->GetCouponNum()
                        , player->GetUserPlayTime()
                        , m_GamePlay._ID
                        , GetKey());
        LOGINFO("user[%lu] leave table[%d][%d] reason[%d]", player->GetKey(), GetKey(), GetTableIndex(), reason);
    }
    SyncPlayerQuit msg;
    msg.set_playerid(player->GetKey());
    WrapPacket packet;
    LxGameHelper::MakeSyncPlayerQuit(packet, msg);
    SyncToOtherPlayers(player, packet);

    player->OnRecycled();
}

void FishTable::OnSummonBossDead(FishFish* fish, uint64 killer) {
    // 召唤boss被击杀或者逃跑
    int32 fishIndex = fish->GetIndex();
    int64 fishMinRefund = JDATA->FishDataPtr()->SummonBossRefundMinByID(fishIndex);
    for( int32 i = 0 ; i < ROOM_MAX_PLAYER ; ++i ) {
        LxUser* pUser = m_arPlayers[i]->GetUser();
        if( pUser == nullptr  ) {
            continue;
        }
        if( killer == 0 || killer != pUser->GetKey() ) {
            int64 cost = pUser->GetHuntHitCost(fish->GetBossGuid());
            if( cost > fishMinRefund*m_arPlayers[i]->GetTurretRate() ) {
                int64 itemGold = cost*sHTax->GetHunterRefundRate(pUser->GetUserGoldProperty(), fishIndex);
                int64 gold = itemGold;
                {
                    int32 div = JDATA->SystemConstPtr()->GetHunterRefundDivider();
                    if( div > 0 ) {
                        gold /= div;
                    }
                    gold = (gold/10000)*10000;
                }
                pUser->OnHunted(fish->GetBossGuid(), gold, itemGold);
                pUser->SendUserInfoChange(0);
            }
            else {
                // cost不够, 直接移除
                pUser->OnHuntMissed(fish->GetBossGuid());
            }
        }
    }
}


// 把金币拆分成金币加房间指定弹头
std::tuple<int64, int32, int64> FishTable::SplitGold(int64 gold, int32 fishIndex) {
    int64 convertRate = JDATA->FishDataPtr()->BombConvertRateByID(fishIndex);
    int32 bombId = 0;
    int32 bombNum = 0;
    if( convertRate > 0 ) {
        bombId = m_GamePlay._BombConvert;
        if( bombId != 0 ) {
            int64 goldValue = JDATA->ItemPtr()->ItemParamByID(bombId);
            if( goldValue > 0 ) {
                bombNum = (gold*convertRate/100)/goldValue;
                return make_tuple(gold-bombNum*goldValue, bombId, bombNum);
            }
        }
    }
    return make_tuple(gold, 0, 0);
}

void FishTable::BuildPoolLog(map<string, tagPoolLog>& mapLog) {
    {
        auto data = m_Fishes.DebugInfo();
        auto it = mapLog.find(TUPLE0(data));
        if( it == mapLog.end() ) {
            tagPoolLog log;
            log._cur_num = TUPLE1(data);
            log._free_num = TUPLE2(data);
            log._used_num = TUPLE3(data);
            mapLog[TUPLE0(data)] = log;
        }
        else {
            it->second._cur_num += TUPLE1(data);
            it->second._free_num += TUPLE2(data);
            it->second._used_num += TUPLE3(data);
        }
    }
    {
        auto data = m_Shoals.DebugInfo();
        auto it = mapLog.find(TUPLE0(data));
        if( it == mapLog.end() ) {
            tagPoolLog log;
            log._cur_num = TUPLE1(data);
            log._free_num = TUPLE2(data);
            log._used_num = TUPLE3(data);
            mapLog[TUPLE0(data)] = log;
        }
        else {
            it->second._cur_num += TUPLE1(data);
            it->second._free_num += TUPLE2(data);
            it->second._used_num += TUPLE3(data);
        }
    }
    {
        auto data = m_Bullets.DebugInfo();
        auto it = mapLog.find(TUPLE0(data));
        if( it == mapLog.end() ) {
            tagPoolLog log;
            log._cur_num = TUPLE1(data);
            log._free_num = TUPLE2(data);
            log._used_num = TUPLE3(data);
            mapLog[TUPLE0(data)] = log;
        }
        else {
            it->second._cur_num += TUPLE1(data);
            it->second._free_num += TUPLE2(data);
            it->second._used_num += TUPLE3(data);
        }
    }
}

void FishTable::InitSummonBossConfig() {
    m_confSummonBoss.Clear();
    if( m_GamePlay._SummonBoss.size() < 9 ) {
        return;
    }
    if( m_GamePlay._SummonBoss[0] != e_jsonGamePlaySummonBoss_Room5 ) {
        return;
    }
    if( (m_GamePlay._SummonBoss.size() - 2)%8 != 0 ) {
        LOGERROR("table[%d] summonboss config error[%d]", m_GamePlay._ID, m_GamePlay._SummonBoss.size());
        return;
    }
    m_confSummonBoss.set_route_id(m_GamePlay._SummonBoss[1]);
    for( size_t i = 2 ; i < m_GamePlay._SummonBoss.size(); i+=8 ) {
        auto subData = m_confSummonBoss.add_config();
        {
            auto ptr = subData->add_boss();
            ptr->set_key(m_GamePlay._SummonBoss[i+0]);
            ptr->set_value(m_GamePlay._SummonBoss[i+1]);
        }
        {
            auto ptr = subData->add_boss();
            ptr->set_key(m_GamePlay._SummonBoss[i+2]);
            ptr->set_value(m_GamePlay._SummonBoss[i+3]);
        }
        {
            auto ptr = subData->add_boss();
            ptr->set_key(m_GamePlay._SummonBoss[i+4]);
            ptr->set_value(m_GamePlay._SummonBoss[i+5]);
        }
        subData->set_min_gold(m_GamePlay._SummonBoss[i+6]*100000000);
        subData->set_max_gold(m_GamePlay._SummonBoss[i+7]*100000000);
    }
}

bool FishTable::CanUseSummonSkill() {
    if( m_GamePlay._SummonBoss.size() <= 1 ) { return false; }
    switch( m_GamePlay._SummonBoss[0] ) {
    case e_jsonGamePlaySummonBoss_Room4:
        return m_GamePlay._SummonBoss.size() == 3;
    case e_jsonGamePlaySummonBoss_Room5:
        return m_confSummonBoss.has_route_id();
    case e_jsonGamePlaySummonBoss_Room6:
        return m_GamePlay._SummonBoss.size() >= 8;
    default:
        return false;
    }
}

int32 FishTable::UseSummonSkill(int64 curGold, list<IntPair>& lstFish, FishPlayer* player) {
    if( m_GamePlay._SummonBoss.size() <= 1 ) { return EUSSR_Failed; }
    switch( m_GamePlay._SummonBoss[0] ) {
    case e_jsonGamePlaySummonBoss_Room4:
    {
        IntPair ip;
        ip.set_key(m_GamePlay._SummonBoss[1]);
        ip.set_value(m_GamePlay._SummonBoss[2]);
        lstFish.push_back(ip);
        return EUSSR_Boss;
    }
    case e_jsonGamePlaySummonBoss_Room5:
    {
        for( int32 i = 0 ; i < m_confSummonBoss.config_size() ; ++i ) {
            if( m_confSummonBoss.config(i).min_gold() <= curGold ) {
                if( m_confSummonBoss.config(i).max_gold() == 0 || curGold <= m_confSummonBoss.config(i).max_gold() ) {
                    Roll dice;
                    for( int32 j = 0 ; j < m_confSummonBoss.config(i).boss_size() ; ++j ) {
                        int32 bossid = m_confSummonBoss.config(i).boss(j).key();
                        int32 weight = m_confSummonBoss.config(i).boss(j).value();
                        if( player->IsUser() ) {
                            if( bossid == JDATA->SystemConstPtr()->GetLvbuBossID() ) {
                                weight += (weight*player->GetUser()->GetHeroRelationAttr(e_jsonHeroRelationAllAttribute_SummonLvbu))/1000;
                            }
                        }
                        dice.push_value(weight, bossid);
                    }
                    IntPair ip;
                    ip.set_key(dice.roll());
                    ip.set_value(m_confSummonBoss.route_id());
                    lstFish.push_back(ip);
                    return EUSSR_Boss;
                }
            }
        }
        LOGERROR("table[%d] summon boss[%s] failed", GetTableIndex(), m_confSummonBoss.DebugString().c_str());
        return EUSSR_Failed;
    }
    case e_jsonGamePlaySummonBoss_Room6:
    {
        int32 num = GlobalUtils::GetRandNumber(2,5);
        tagTableSummonCard fish;
        if( !fish.Fill(m_GamePlay._SummonBoss) ) {
            return EUSSR_Failed;
        }
        if( player->IsUser() ) {
            if( GlobalUtils::GetRandNumber(0,1000) < player->GetUser()->GetHeroRelationAttr(e_jsonHeroRelationAllAttribute_SummonCardFish) ) {
                num += 1;
            }
        }
        for( int32 i = 0 ; i < num ; i++ ) {
            IntPair ip;
            fish.GetOne(ip);
            lstFish.push_back(ip);
        }
        return EUSSR_CardFish;
    }
    default:
        return EUSSR_Failed;
    }
}
