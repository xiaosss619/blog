#pragma once

#include "ServerDefine.h"
#include "ModuleConnection/NetServer.h"
#include "ModuleThread/ThreadData.h"
#include "ModuleThread/ThreadUser.h"
#include "ModuleThread/ThreadTimer.h"
#include "ModuleThread/ThreadArena.h"
#include "ModuleThread/ThreadBoard.h"
#include "ModuleThread/ThreadEventLog.h"
#include "ModuleThread/ThreadChat.h"
#include "GameUtils.h"

#define DATA_THREAD_NUM 3
#define USER_THREAD_NUM 5
#define TIMER_THREAD_NUM 1
#define ARENA_THREAD_NUM 1
#define BOARD_THREAD_NUM 1
#define LOGGER_THREAD_NUM 1
#define CHAT_THREAD_NUM 1

#define THREAD_TOTAL DATA_THREAD_NUM+USER_THREAD_NUM+TIMER_THREAD_NUM+ARENA_THREAD_NUM+BOARD_THREAD_NUM+LOGGER_THREAD_NUM+CHAT_THREAD_NUM

enum E_ThreadRange {
	ETR_DataStart	= 0,
	ETR_UserStart = ETR_DataStart+DATA_THREAD_NUM,
	ETR_TimerStart = ETR_UserStart+USER_THREAD_NUM,
	ETR_ArenaStart = ETR_TimerStart+TIMER_THREAD_NUM,
	ETR_BoardStart = ETR_ArenaStart+ARENA_THREAD_NUM,
	ETR_LoggerStart = ETR_BoardStart+BOARD_THREAD_NUM,
	ETR_ChatStart = ETR_LoggerStart+CHAT_THREAD_NUM,
};

enum E_WaitRedisType {
	EWRT_Normal	= 0,
	EWRT_ExchangeCode = 1, // 等待兑换码返回
	EWRT_Exchange	= 2,	// 等待兑换商城返回
};

class Dispatcher : public Poolize
{
public:
	Dispatcher();
	virtual ~Dispatcher();

	bool init_sql(const string& strUrl, const string& strUserName, const string& strPassword);
	// 通过命令字在后台派发
	void dispatch(WrapPacket& pkg);
	// 直接返回给客户端
	void call_client(WrapPacket& pkg) {
		sNetServer->PostPacket(pkg);
	}
	void kick_user(uint64 userId);
    void kick_duplicate_user(uint64 userId);
	// 发送给所有指定的房间
	void notify_all_fish_room(WrapPacket& pkg);
	void log_event(const string& name, const string& data) {
		_logger->LogEvent(name, data);
	}
	void log_redis(const string& name, const string& data) {
		_logger->LogRedis(name, data);
	}
public:
	////////////////////////////////////////////////////////////////
	//  部分功能函数
	bool make_mail(uint64 uUserId, int32 nMailType, int64 iDiamond, int64 iGold, const map<int32, int64>& mapItem, const string& title, const string& content, LxMail& mail);
	bool send_mail(uint64 uUserId, int32 nMailType, int64 iDiamond, int64 iGold, const map<int32, int64>& mapItem, const string& title, const string& content);
	bool send_mail(uint64 uUserId, int32 nMailType, int32 itemId, int64 itemNum);

	// 广播跑马灯消息
	void broadcast_rolling_msg(int32 msgId) {
		list<string> lst;
		broadcast_rolling_msg(msgId, "", lst);
	}
	void broadcast_rolling_msg(int32 msgId, const string& strBonusId, const list<string>& lstData);
	void broadcast_channel_msg(const string& chn, const string& content);
	// 广播系统跑马灯
	void broadcast(int32 cmd, const string& strMsg);
	void chat_public(const TargetInfo& src, const string& content);
public:
	ThreadData* _datas[DATA_THREAD_NUM];
	ThreadUser* _users[USER_THREAD_NUM];
	ThreadTimer* _timer;
	ThreadArena* _arena;
	ThreadBoard* _board;
	ThreadEventLog* _logger;
	ThreadChat* _chat;
};

#define sDispatcher Singleton<Dispatcher>::Instance()
