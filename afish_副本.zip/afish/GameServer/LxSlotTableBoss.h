/**
 * 桌面奖池鱼控制类 无法动态加载
 * 桌面刷新 _FundAddType == e_jsonFishDataFundAddType_Table 的鱼时
 *      调用一次 fetch , 或者新生成一条, 或者取一条老的, 同时放置到 m_tableBoss 表中, 不会再被其他table获得
 * 鱼的update时钟, 定时1分钟调用一次 update , 用于刷新到redis中, 持久化保存
 * 鱼死亡时, 调用 killed , 删除保存过的记录
 * 鱼走完路线回收时, 调用 recycled , 再次保存数据, 同时将鱼返还到 m_mapTableBoss 表, 等待下一次刷新
 */

#pragma once

#include <string>
#include <sstream>
#include <map>
#include <set>
#include <vector>
using namespace std;

#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>

#include <google/protobuf/stubs/common.h>
using namespace google::protobuf;

#include "RedisKey.h"
#include "GameUtils.h"
#include "DataCache/RedisData.h"

struct tagTableBoss {
    int32 _idx;
    int64 _cur;
    int32 _last_reward_idx;
    tagTableBoss() {
        _idx = 0;
        _cur = 0;
        _last_reward_idx = -1;
    }
    tagTableBoss& operator=(const tagTableBoss& rhs) {
        _idx = rhs._idx;
        _cur = rhs._cur;
        _last_reward_idx = rhs._last_reward_idx;
        return *this;
    }
    void Log() {
    }
};

class LxSlotTableBoss {
public:
    LxSlotTableBoss() {}
    ~LxSlotTableBoss() {}
public:
    void fetch(int32 idx, tagTableBoss& lhs) {
        FETCH_VOID();
        int64 cur = 0;
        string strData;
        if( pConnection->rpop(RedisKey::MakeSysSlotTableFishKey(idx), strData) ) {
            cur = atol(strData.c_str());
        }
        lhs._idx = idx;
        lhs._cur = cur;
    }
    void recycled(const tagTableBoss& rhs) {
        FETCH_VOID();
        pConnection->lpush(RedisKey::MakeSysSlotTableFishKey(rhs._idx), GlobalUtils::ToString(rhs._cur));
    }
};

#define sHTableBoss Singleton<LxSlotTableBoss>::Instance()
