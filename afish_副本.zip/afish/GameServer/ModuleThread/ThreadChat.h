#pragma once

#include "ServerDefine.h"

class HelperChat;
class ThreadChat
{
public:
	ThreadChat(boost::asio::io_service& io);
	~ThreadChat();

	void PostPacket(WrapPacket& packet) {
		WrapPacket pkg = packet;
		_io_service.post(boost::bind(&ThreadChat::ProcessPacket, this, pkg));
	}

	void ProcessPacket(WrapPacket& packet);
private:
	boost::asio::io_service& _io_service;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
private:
	void ProcessTargetInfoReq(WrapPacket& packet, WrapPacket& response);
	void ProcessMsgInfoReq(WrapPacket& packet, WrapPacket& response);
	void ProcessChatReq(WrapPacket& packet, WrapPacket& response);
	void ProcessChatGroupCreateReq(WrapPacket& packet, WrapPacket& response); // 创建聊天群
	void ProcessChatGroupRenameReq(WrapPacket& packet, WrapPacket& response); // 修改群名
	void ProcessChatGroupResetPwdReq(WrapPacket& packet, WrapPacket& response); // 修改群密码
	void ProcessChatGroupInviteReq(WrapPacket& packet, WrapPacket& response); // 修改群密码
	void ProcessChatGroupAcceptInviteReq(WrapPacket& packet, WrapPacket& response); // 接受邀请,加入群聊
	void ProcessChatGroupSearchReq(WrapPacket& packet, WrapPacket& response); // 群搜索
	void ProcessChatGroupJoinReq(WrapPacket& packet, WrapPacket& response); // 加入群聊请求
	void ProcessChatGroupQuitReq(WrapPacket& packet, WrapPacket& response); // 退出群聊请求
	void ProcessChatGroupDismissReq(WrapPacket& packet, WrapPacket& response); // 群主解散
	void ProcessChatGroupKickReq(WrapPacket& packet, WrapPacket& response); // 群主踢人
	void ProcessChatGroupClearChatReq(WrapPacket& packet, WrapPacket& response); // 清理聊天记录
	void ProcessChatGroupListReq(WrapPacket& packet, WrapPacket& response); // 聊天群列表
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	void ProcessGiftDataReq(WrapPacket& packet, WrapPacket& packetResponse);
	void ProcessGiftListReq(WrapPacket& packet, WrapPacket& packetResponse);
	void ProcessRGiftAcceptReq(WrapPacket& packet, WrapPacket& packetResponse);
	void ProcessSGiftCancelReq(WrapPacket& packet, WrapPacket& packetResponse);
	void ProcessSGiftVerifyReq(WrapPacket& packet, WrapPacket& packetResponse);
	void ProcessRGiftGetReq(WrapPacket& packet, WrapPacket& packetResponse);
	void ProcessGiftChangeCodeReq(WrapPacket& packet, WrapPacket& packetResponse);
};
