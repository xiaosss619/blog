/**
 * 排名模块
*/
#include "ThreadBoard.h"
#include "GameUtils.h"
#include "RedisManager/RedisManager.h"
#include "Include/RedisProtoHelper.h"
#include "Include/MySQLProtoHelper.h"
#include "DataCache/RedisData.h"
#include "Dispatcher.h"
#include "ModuleHelper/HelperArena.h"
#include "ModuleUser/LxUser.h"

ThreadBoard::ThreadBoard(boost::asio::io_service& io)
    : _io_service(io)
{
}

ThreadBoard::~ThreadBoard() {
}

void ThreadBoard::ProcessPacket(WrapPacket& packet) {
    WrapPacket response = packet;
    response.clear_data();
	switch(packet.cmd()) {
    case BOARD_BoardDataReq:
        {
            ProcessBoardDataReq(packet, response);
            break;
        }
    case BOARD_LxUserBoardData:
        {
            ProcessLxUserBoardData(packet, response);
            break;
        }
	default:
        {
            response.clear_userid();
            break;
        }
	}
    if( response.has_userid() ) {
        // 有用户id,返回给客户端
        sDispatcher->call_client(response);
    }
}

void ThreadBoard::ProcessBoardDataReq(WrapPacket& packet, WrapPacket& response) {
    BoardDataReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
    response.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());

    BoardDataResp msg;
    msg.set_board_type(request.board_type());
    msg.set_own_data(0);
    msg.set_own_rank(-1);
    do {
        FETCH_RESPONSE_BREAK(response);
        FetchBoardTopUser(pConnection, request.board_type(), packet.userid(), 100, msg);
    } while(0);

    LxGameHelper::MakeBoardDataResp(response, msg);
}

void ThreadBoard::ProcessLxUserBoardData(WrapPacket& packet, WrapPacket& response) {
    response.clear_userid();// 无需回包
    if( GlobalUtils::IsInMondayGL5(sGameUtils->GetFakeTimeNow()) ) {
        // 周一0点是结算期间, 不记录数据
        return;
    }
    LxUserBoardData request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
    FETCH_VOID();
    SaveBoardUser(pConnection, request.user());
}

bool ThreadBoard::GetBoardUser(RedisConnection* pConnection, uint64 userId, BoardUser& lhs) {
    string strUser;
    if( !pConnection->hget(BOARD_USER_INFO_KEY, userId, strUser) ) {
        LOGERROR("user[%lu] failed to get info", userId);
        return false;
    }
    if( !JsonProto::ProtoFromJson(strUser, lhs) ) {
        LOGERROR("user[%lu] failed to get info[%s]", userId, strUser.data());
        return false;
    }
    return true;
}

void ThreadBoard::SaveBoardUser(RedisConnection* pConnection, const BoardUser& user) {
    BoardUser oldInfo;
    if( !pConnection->hexists(BOARD_USER_INFO_KEY, GlobalUtils::ToString(user.user_id()))
        || !GetBoardUser(pConnection, user.user_id(), oldInfo) ) {
        RedisProtoHelper::RedisSaveHSET(pConnection, BOARD_USER_INFO_KEY, GlobalUtils::ToString(user.user_id()), user);
    }
    else {
        oldInfo.set_user_vip(user.user_vip());
        oldInfo.set_user_name(user.user_name());
        oldInfo.set_user_head(user.user_head());
        oldInfo.set_user_frame(user.user_frame());

        bool needSave = false;
        if( user.user_gold_win() > 0 ) {
            needSave = true;
            oldInfo.set_user_gold_win(user.user_gold_win()+oldInfo.user_gold_win());
            pConnection->zadd(RedisKey::MakeBoardDataKey(e_jsonRankRewardRankID_GoldIncome), user.user_id(), oldInfo.user_gold_win());
        }
        if( user.user_gold_cost() > 0 ) {
            needSave = true;
            oldInfo.set_user_gold_cost(user.user_gold_cost()+oldInfo.user_gold_cost());
            pConnection->zadd(RedisKey::MakeBoardDataKey(e_jsonRankRewardRankID_GoldExpense), user.user_id(), oldInfo.user_gold_cost());
        }
        if( user.user_bomb_win() > 0 ) {
            needSave = true;
            oldInfo.set_user_bomb_win(user.user_bomb_win()+oldInfo.user_bomb_win());
            pConnection->zadd(RedisKey::MakeBoardDataKey(e_jsonRankRewardRankID_NuclearIncome), user.user_id(), oldInfo.user_bomb_win());
        }
        if( user.user_bomb_cost() > 0 ) {
            needSave = true;
            oldInfo.set_user_bomb_cost(user.user_bomb_cost()+oldInfo.user_bomb_cost());
            pConnection->zadd(RedisKey::MakeBoardDataKey(e_jsonRankRewardRankID_NuclearExpense), user.user_id(), oldInfo.user_bomb_cost());
        }
        if( user.user_crystal_win() > 0 ) {
            needSave = true;
            oldInfo.set_user_crystal_win(user.user_crystal_win()+oldInfo.user_crystal_win());
            pConnection->zadd(RedisKey::MakeBoardDataKey(e_jsonRankRewardRankID_CrystalIncome), user.user_id(), oldInfo.user_crystal_win());
        }
        if( user.user_crystal_cost() > 0 ) {
            needSave = true;
            oldInfo.set_user_crystal_cost(user.user_crystal_cost()+oldInfo.user_crystal_cost());
            pConnection->zadd(RedisKey::MakeBoardDataKey(e_jsonRankRewardRankID_CrystalExpense), user.user_id(), oldInfo.user_crystal_cost());
        }
        if( user.user_vip_score() > 0 ) {
            needSave = true;
            oldInfo.set_user_vip_score(user.user_vip_score()+oldInfo.user_vip_score());
            pConnection->zadd(RedisKey::MakeBoardDataKey(e_jsonRankRewardRankID_VIP), user.user_id(), oldInfo.user_vip_score());
        }
        if( needSave ) {
            string strUserKey = GlobalUtils::ToString(user.user_id());
            RedisProtoHelper::RedisSaveHSET(pConnection, BOARD_USER_INFO_KEY, GlobalUtils::ToString(user.user_id()), oldInfo);
        }
    }
}

void ThreadBoard::FetchBoardTopUser(RedisConnection* pConnection, int32 type, uint64 userId, int32 maxNum, BoardDataResp& resp) {
    bool onBoard = false;
    std::vector< std::pair<int64, int64 > > values;
    if( pConnection->zrevrange(RedisKey::MakeBoardDataKey(type), 0, maxNum, values) ) {
        for( size_t i = 0; i < values.size() ; ++i ) {
            uint64 uid = values[i].first;
            int64 score = values[i].second;
            BoardUser top50;
            if( GetBoardUser(pConnection, uid, top50) ) {
                auto ptr = resp.add_users();
                *ptr = top50;
                switch(type) {
                case e_jsonRankRewardRankID_GoldIncome:
                    ptr->set_user_gold_win(score);
                    break;
                case e_jsonRankRewardRankID_GoldExpense:
                    ptr->set_user_gold_cost(score);
                    break;
                case e_jsonRankRewardRankID_NuclearIncome:
                    ptr->set_user_bomb_win(score);
                    break;
                case e_jsonRankRewardRankID_NuclearExpense:
                    ptr->set_user_bomb_cost(score);
                    break;
                case e_jsonRankRewardRankID_CrystalIncome:
                    ptr->set_user_crystal_win(score);
                    break;
                case e_jsonRankRewardRankID_CrystalExpense:
                    ptr->set_user_crystal_cost(score);
                    break;
                default://case e_jsonRankRewardRankID_VIP:
                    ptr->set_user_vip_score(score);
                    break;
                }
                if( uid == userId ) {
                    resp.set_own_data(score);
                    resp.set_own_rank(i+1);
                    onBoard = true;
                }
            }
        }
    }
    if( !onBoard ) {
        BoardUser self;
        if( GetBoardUser(pConnection, userId, self) ) {
            switch(type) {
            case e_jsonRankRewardRankID_GoldIncome:
                resp.set_own_data(self.user_gold_win());
                break;
            case e_jsonRankRewardRankID_GoldExpense:
                resp.set_own_data(self.user_gold_cost());
                break;
            case e_jsonRankRewardRankID_NuclearIncome:
                resp.set_own_data(self.user_bomb_win());
                break;
            case e_jsonRankRewardRankID_NuclearExpense:
                resp.set_own_data(self.user_bomb_cost());
                break;
            case e_jsonRankRewardRankID_CrystalIncome:
                resp.set_own_data(self.user_crystal_win());
                break;
            case e_jsonRankRewardRankID_CrystalExpense:
                resp.set_own_data(self.user_crystal_cost());
                break;
            default://case e_jsonRankRewardRankID_VIP:
                resp.set_own_data(self.user_vip_score());
                break;
            }
        }
    }
}
