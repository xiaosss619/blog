/**
 * 用户系统数据管理
 * 每个用户通过用户id取模分配线程id,保证同一用户数据在同一个线程中处理,有跨用户的消息,需要做分布式处理
 */
#include "ThreadUser.h"
#include "LxUser.h"
#include "Dispatcher.h"
#include "Include/RedisProtoHelper.h"
#include "Include/MySQLProtoHelper.h"
#include "Handler/MailHandler.h"
#include "ModuleHelper.h"
#include "LxGameLogHelper.h"
#include "Handler/RedisCmdHandler.h"

ThreadUser::ThreadUser(boost::asio::io_service& io, int32 idx)
	: _io_service(io), _timer_update(io), _timer_1s(io), _timer_5m(io), m_nThreadIndex(idx)
{
	m_users.Init("User", 200, 10);

	m_lastUpdateTick = GlobalUtils::GetTickCount();
    _timer_update.expires_from_now(boost::posix_time::milliseconds(100));
    _timer_update.async_wait(boost::bind(&ThreadUser::Update, this, boost::asio::placeholders::error));
    _timer_1s.expires_from_now(boost::posix_time::seconds(1));
    _timer_1s.async_wait(boost::bind(&ThreadUser::OnTimer1s, this, boost::asio::placeholders::error));
    _timer_5m.expires_from_now(boost::posix_time::seconds(300));
    _timer_5m.async_wait(boost::bind(&ThreadUser::OnTimer5m, this, boost::asio::placeholders::error));
	srand(time(nullptr));
}

ThreadUser::~ThreadUser() {

}

LxUser* ThreadUser::GetUser(uint64 uUserId) {
	return m_users.GetEntity(uUserId);
}

LxUser* ThreadUser::CreateUser(uint64 connectionId, const LxUserOnline& info) {
	return m_users.CreateEntity(connectionId, info);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void ThreadUser::Update(const boost::system::error_code& error) {
	if( !error ) {
		int64 nowTick = GlobalUtils::GetTickCount();
		m_game.Update(nowTick - m_lastUpdateTick);
		m_lastUpdateTick = GlobalUtils::GetTickCount();
		int64 sleepTick = 100-(m_lastUpdateTick-nowTick);
		if( sleepTick < 0 ) { sleepTick = 5; }
        _timer_update.expires_from_now(boost::posix_time::milliseconds(sleepTick));
        _timer_update.async_wait(boost::bind(&ThreadUser::Update, this, boost::asio::placeholders::error));
	}
}

void ThreadUser::OnTimer1s(const boost::system::error_code& error) {
	if( !error ) {
		m_users.Update(1000);
        _timer_1s.expires_from_now(boost::posix_time::seconds(1));
        _timer_1s.async_wait(boost::bind(&ThreadUser::OnTimer1s, this, boost::asio::placeholders::error));
	}
}

void ThreadUser::OnTimer5m(const boost::system::error_code& error) {
	if( !error ) {
		LOG_POOL(m_users, m_nThreadIndex);
		m_game.OnTimer5m(m_nThreadIndex);
        _timer_5m.expires_from_now(boost::posix_time::seconds(300));
        _timer_5m.async_wait(boost::bind(&ThreadUser::OnTimer5m, this, boost::asio::placeholders::error));
	}
}

void ThreadUser::NotifyAllRoom(WrapPacket& packet) {
	m_game.NotifyAllRoom(packet);
}

void ThreadUser::DoNotifyChannel(const string& chn, int32 cmd, const string& msg) {
	m_users.ForEachEntity([&](LxUser* pUser){
		if( chn.empty() || pUser->PBGetClientChannel() == chn) {
			WrapPacket packet;
			packet.set_cmd(cmd);
			packet.set_userid(pUser->GetKey());
			packet.set_connectionid(pUser->GetConnectionId());
			packet.set_packtype(EPT_Sync);
			*packet.mutable_data() = msg;
			sDispatcher->call_client(packet);
		}
	});
}

void ThreadUser::ProcessPacket(WrapPacket& packet) {
	if( packet.cmd() == USER_LxUserOnline ) {
		// 登录包单独处理一下
		ProcessUserOnline(packet);
		return;
	}
	auto pUser = GetUser(packet.userid());
	if( pUser == nullptr ) {
		LOGERROR("User[%lu] msg[%d] before user login", packet.userid(), packet.cmd());
		return;
	}
	switch(packet.cmd()) {
	case FISH_LxFishUserOffline:
		{
			m_game.UserClearFishTable(pUser, pUser->PBGetFishTableId());
			pUser->Offline();
			pUser->SendUserInfoChange(-1);// 发送一下数据记录
            // Offline之后直接释放指针
            //    1. 保证LxUser::Update函数不再执行
            //    2. 如果在下一帧执行之前, ThreadData过来一个登录包, 会重新执行登录,
            //          指针对应的Conection会设置成新的, 但是Key还是0, 在update时仍旧会被清理, 导致用户不在映射表中
            //          这里也可以处理成登录时设置SetKey SetConnectionId ,这样在下一帧也就不会去做删除指针,目前先处理成直接移除
            m_users.RemoveEntity(pUser);
			break;
		}
	default:
		{
			// 用户初始化完毕
			int32 serviceId = GlobalUtils::GetServiceId(packet.cmd());
			if( serviceId == ESID_user ) {
				WrapPacket response = packet;
				response.clear_data();
				pUser->ProcessPacket(packet, response);
				if( response.has_userid() ) {
					// 有用户id,返回给客户端
					sDispatcher->call_client(response);
				}
			}
			else if( serviceId == ESID_fish ) {
				m_game.ProcessPacket(pUser, packet);
			}
			else {
				LOGERROR("unkown cmd got[%d]", packet.cmd());
			}
			break;
		}
	}
}

void ThreadUser::ProcessUserOnline(WrapPacket& packet) {
	LxUserOnline msg;
	if( !msg.ParseFromString(packet.data()) ) {
		LOGINFO("parse failed[%s]", packet.DebugString());
		return;
	}
	auto user = GetUser(packet.userid());
	if( user == nullptr ) {
		user = CreateUser((int32)packet.connectionid(), msg);
		if( user == nullptr ) {
			LOGERROR("create entity, impossible!!![%lu]", packet.userid());
			return;
		}
	}
	// 1分钟内重连的用户, 重新设置一下connectionid
	user->SetConnectionId(packet.connectionid());
	// 登录成功了
    WrapPacket packetResponse = packet;
    packetResponse.clear_data();
	UserLoginResp response = msg.resp();

	// 要根据用户当前所在房间进行一下退出或者重连处理
	// 根据fish_table_index和fish_table_end_time信息把用户从经典渔场内踢出,
	int32 tableId = user->PBGetFishTableId();
	int32 tableIndex = user->PBGetFishTableIndex();
	int64 tableEndTime = user->PBGetFishTableEndTime();
	if( tableIndex != 0 ) {
		tagJsonGamePlay tData;
		if( !JDATA->GamePlayPtr()->ByID(tableIndex, tData) ) {
			// 对应桌子无效 除非修改配置删除了对应的房间id,否则这个逻辑不应该被走到
			response.mutable_user_info()->set_fish_table_id(0);
			response.mutable_user_info()->set_fish_table_index(0);
			response.mutable_user_info()->set_fish_table_end_time(0);
			user->SetFishTableInfo(0, 0, 0);
		}
		else {
			// 需要重连的房间,并且超时
			// 经典房离线3分钟以内直接重连
			if( (tData._IsResume && sGameUtils->GetFakeTimeNow() < tableEndTime)
				|| (tData._GameType == e_jsonGamePlayGameType_Classic && sGameUtils->GetFakeTimeNow() < user->PBGetTimeOffline() + 180 ) ) {
				// 用户属性设置了tableIndex,让用户自己发送FishEnterRoom回来
			}
			else {
				user->SetFishTableInfo(0, 0, 0);
				// 不需要重连,或者已经超时的,都去调用一下离开房间
				m_game.UserClearFishTable(user, tableId);
				response.mutable_user_info()->set_fish_table_id(0);
				response.mutable_user_info()->set_fish_table_index(0);
				response.mutable_user_info()->set_fish_table_end_time(0);
			}
		}
	}

	user->FillLoginResp(response);
	response.set_result(JDATA->ErrorCodePtr()->GetSuccess());
	LxGameHelper::MakeUserLoginResp(packetResponse, response);
	sDispatcher->call_client(packetResponse);

	// 登录成功后,执行一些登录处理,跨天数据等
	user->AfterLogin();
	user->SendUserInfoChange(0);
	{
		FETCH_VOID();
		SyncGameRoomLimit msg;
		int32 num = 0;
		JDATA->GamePlayPtr()->ForEachWithBreak([&](tagJsonGamePlay* ptr){
			if( ptr->_GameType == e_jsonGamePlayGameType_Classic ) {
				++num;
				auto p = msg.add_rooms();
				p->set_room_id(ptr->_ID);
				p->set_min_gold(ptr->_MinGoldPlay);
				p->set_max_gold(ptr->_MaxGoldPlay);
				if( ptr->_MaxGoldPlay == 0 ) {
					p->set_max_gold(-1);
				}
				p->set_skip_gold(ptr->_SkipGold);
				RedisData::GetTableSkillLockFlag(pConnection, ptr->_ID, p);
				if( num >= 5 ) {
					return true;
				}
			}
			return false;
		});
	    CALL_CLIENT(user, SyncGameRoomLimit, msg);
	}
}
