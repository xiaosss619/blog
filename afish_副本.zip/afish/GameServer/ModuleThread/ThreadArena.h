#pragma once

#include "ServerDefine.h"

class RedisConnection;
class ThreadArena
{
public:
	ThreadArena(boost::asio::io_service& io);
	~ThreadArena();

	void PostPacket(WrapPacket& packet) {
		WrapPacket pkg = packet;
		_io_service.post(boost::bind(&ThreadArena::ProcessPacket, this, pkg));
	}

	void ProcessPacket(WrapPacket& packet);
private:
	int64 MakeScore(int32 score);
private:
	void ProcessArenaDataReq(WrapPacket& packet, WrapPacket& response);
	void ProcessLxArenaUserInfo(WrapPacket& packet, WrapPacket& response);
	bool ArenaGetUser(uint64 userId, ArenaUser& lhs);
private:
	boost::asio::io_service& _io_service;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// 召唤boss排行榜部分
private:
	void ProcessBossBulletinBoardReq(WrapPacket& packet, WrapPacket& response);
	void ProcessLxUserBulletinData(WrapPacket& packet, WrapPacket& response);
private:
	// strUserKey 为 用户信息的key hset
	// strBossKey 为 boss排行榜对应的key zset
	void BulletinFetchTop50(RedisConnection* pConnection, int32 type, uint64 userId, const string& strUserKey, const string& strBossKey, int32 maxNum, BossBulletinBoardResp& resp);

	std::tuple<int32, int32, int32> BulletinSaveUser(RedisConnection* pConnection, const BulletinUser& user, const string& strUserKey);
	bool BulletinGetUser(RedisConnection* pConnection, const string& strUserKey, uint64 userId, BulletinUser& lhs);
};
