#pragma once

#include "ServerDefine.h"
#include "io_service_pool.h"
#include "EntityPool.h"
#include "RedisKey.h"
#include "ModuleGame/Fish/FishGame.h"

class LxUser;
class ThreadUser
{
public:
	ThreadUser(boost::asio::io_service& io, int32 idx);
	virtual ~ThreadUser();
	void NotifyChannel(const string& chn, int32 cmd, const string& msg) {
		_io_service.post(boost::bind(&ThreadUser::DoNotifyChannel, this, chn, cmd, msg));
	}
	void NotifyAll(WrapPacket& packet) {
		WrapPacket pkg = packet;
		_io_service.post(boost::bind(&ThreadUser::NotifyAllRoom, this, pkg));
	}
	void PostPacket(WrapPacket& packet) {
		WrapPacket pkg = packet;
		_io_service.post(boost::bind(&ThreadUser::ProcessPacket, this, pkg));
	}
///////////////////////////////////////////////////////////////////////////////////////////////
public:
	void ProcessPacket(WrapPacket& packet);
	LxUser* GetUser(uint64 uUserId);
    void NotifyAllRoom(WrapPacket& packet);
	void Update(const boost::system::error_code& error);
	void OnTimer1s(const boost::system::error_code& error);
	void OnTimer5m(const boost::system::error_code& error);
private:
	// 根据userid对USER_THREAD_NUM取模,获得m_users[xxxx]对应的对象池,每个线程对应一个对象池,每个用户只在自己的线程中进行处理
	LxUser* CreateUser(uint64 connectionId, const LxUserOnline& info);
	void ProcessUserOnline(WrapPacket& packet);

	void DoNotifyChannel(const string& chn, int32 cmd, const string& msg);
private:
	// 每个线程一个用户集合
	EntityDriver<uint64, LxUser> m_users;
	FishGame m_game;
	boost::asio::io_service& _io_service;
	boost::asio::deadline_timer _timer_update;
	boost::asio::deadline_timer _timer_1s;
	boost::asio::deadline_timer _timer_5m;
	int64 m_lastUpdateTick;
	int32 m_nThreadIndex;
};
