/**
 * 聊天+礼物模块
*/
#include "ThreadChat.h"
#include "GameUtils.h"
#include "RedisManager/RedisManager.h"
#include "Include/RedisProtoHelper.h"
#include "DataCache/ProtoCmdHelper.h"
#include "DataCache/RedisData.h"
#include "Dispatcher.h"
#include "ModuleHelper/HelperArena.h"
#include "Handler/RedisCmdHandler.h"
#include "LxGameHelper.h"

ThreadChat::ThreadChat(boost::asio::io_service& io)
    : _io_service(io)
{
}

ThreadChat::~ThreadChat() {
}

void ThreadChat::ProcessPacket(WrapPacket& packet) {
    WrapPacket response = packet;
    response.clear_data();
	switch(packet.cmd()) {
    case CHAT_TargetInfoReq:
    {
        ProcessTargetInfoReq(packet, response);
        break;
    }
    case CHAT_MsgInfoReq:
    {
        ProcessMsgInfoReq(packet, response);
        break;
    }
    case CHAT_ChatReq:
    {
        ProcessChatReq(packet, response);
        break;
    }
	case CHAT_ChatGroupCreateReq: // 创建聊天群
    {
        ProcessChatGroupCreateReq(packet, response);
        break;
    }
	case CHAT_ChatGroupRenameReq: // 修改群名
    {
        ProcessChatGroupRenameReq(packet, response);
        break;
    }
	case CHAT_ChatGroupResetPwdReq: // 修改群密码
    {
        ProcessChatGroupResetPwdReq(packet, response);
        break;
    }
	case CHAT_ChatGroupInviteReq: // 聊天群邀请
    {
        ProcessChatGroupInviteReq(packet, response);
        break;
    }
	case CHAT_ChatGroupAcceptInviteReq: // 接受邀请,加入群聊
    {
        ProcessChatGroupAcceptInviteReq(packet, response);
        break;
    }
	case CHAT_ChatGroupSearchReq: // 群搜索
    {
        ProcessChatGroupSearchReq(packet, response);
        break;
    }
	case CHAT_ChatGroupJoinReq: // 加入群聊请求
    {
        ProcessChatGroupJoinReq(packet, response);
        break;
    }
    case CHAT_ChatGroupQuitReq:
    {
        ProcessChatGroupQuitReq(packet, response);
        break;
    }
    case CHAT_ChatGroupDismissReq:
    {
        ProcessChatGroupDismissReq(packet, response);
        break;
    }
	case CHAT_ChatGroupKickReq: // 群主踢人
    {
        ProcessChatGroupKickReq(packet, response);
        break;
    }
    case CHAT_ChatGroupClearChatReq:
    {
        ProcessChatGroupClearChatReq(packet, response);
        break;
    }
	case CHAT_ChatGroupListReq: // 聊天相关信息列表
    {
        ProcessChatGroupListReq(packet, response);
        break;
    }
////////////////////////////////////////////////////////////////////////////////////////////////
    case CHAT_GiftListReq:
    {
        ProcessGiftListReq(packet, response);
        break;
    }
    case CHAT_SGiftCancelReq:
    {
        ProcessSGiftCancelReq(packet, response);
        break;
    }
    case CHAT_RGiftAcceptReq:
    {
        ProcessRGiftAcceptReq(packet, response);
        break;
    }
    case CHAT_SGiftVerifyReq:
    {
        ProcessSGiftVerifyReq(packet, response);
        break;
    }
    case CHAT_RGiftGetReq:
    {
        ProcessRGiftGetReq(packet, response);
        break;
    }
    case CHAT_GiftDataReq:
    {
        ProcessGiftDataReq(packet, response);
        break;
    }
    case CHAT_GiftChangeCodeReq:
    {
        ProcessGiftChangeCodeReq(packet, response);
        break;
    }
	default:
        response.clear_userid();
        break;
	}
    if( response.has_userid() ) {
        // 有用户id,返回给客户端
        sDispatcher->call_client(response);
    }
}

/////////////////////////////////////////////////////////////////////////////////////////////
void ThreadChat::ProcessTargetInfoReq(WrapPacket& packet, WrapPacket& packetResponse) {
    TargetInfoReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
    packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    TargetInfoResp resp;
    do {
        FETCH_RESPONSE_BREAK(packetResponse);
        bool bFindOne = false;
        for( int32 i = 0 ; i < request.uids_size() ; ++i ) {
            TargetInfo tag;

            if( RedisData::GetUserTargetInfo(pConnection, request.uids(i), tag) ) {
                if( !tag.has_t_pop() ) {
                    tag.set_t_pop(0);
                }
                bFindOne = true;
                *resp.add_infos() = tag;
            }
        }
        if( request.uids_size() > 0 && !bFindOne ) {
            packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
        }
    }while(0);
    LxGameHelper::MakeTargetInfoResp(packetResponse, resp);
}

void ThreadChat::ProcessMsgInfoReq(WrapPacket& packet, WrapPacket& packetResponse) {
    MsgInfoReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
    MsgInfoResp resp;
    do {
        FETCH_RESPONSE_BREAK(packetResponse);
        // 出错则返回系统错误, 否则转发到聊天服处理
        packetResponse.clear_userid();
        ChatChannelCmd cmd;
        cmd.set_cmd(CHAT_MsgInfoReq);
        cmd.set_userid(packet.userid());
        cmd.set_requestid(packet.requestid());
        *cmd.mutable_msg_info_req() = request;
        ProtoCmdHelper::PushChatCmd(pConnection, cmd);
    }while(0);
    LxGameHelper::MakeMsgInfoResp(packetResponse, resp);
}

void ThreadChat::ProcessChatReq(WrapPacket& packet, WrapPacket& packetResponse) {
    ChatReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
    do {
        FETCH_RESPONSE_BREAK(packetResponse);
        // 出错则返回系统错误, 否则转发到聊天服处理
        packetResponse.clear_userid();

        ChatChannelCmd cmd;
        cmd.set_cmd(CHAT_ChatReq);
        cmd.set_userid(packet.userid());
        cmd.set_requestid(packet.requestid());
        *cmd.mutable_chat_req() = request;
        ProtoCmdHelper::PushChatCmd(pConnection, cmd);
    }while(0);
    LxGameHelper::MakeChatResp(packetResponse);
}

void ThreadChat::ProcessChatGroupCreateReq(WrapPacket& packet, WrapPacket& packetResponse) {
    ChatGroupCreateReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
    ChatGroupCreateResp resp;
    packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    do {
        FETCH_RESPONSE_BREAK(packetResponse);
        if( !sGameUtils->IsChatGroupNameValid(request.name()) ) {
            packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetChatGroupCreateInvalidName());
            break;
        }
        // 出错则返回系统错误, 否则转发到聊天服处理
        packetResponse.clear_userid();
        ChatChannelCmd cmd;
        cmd.set_cmd(CHAT_ChatGroupCreateReq);
        cmd.set_userid(packet.userid());
        cmd.set_requestid(packet.requestid());
        *cmd.mutable_chat_group_create_req() = request;
        ProtoCmdHelper::PushChatCmd(pConnection, cmd);
    }while(0);
    LxGameHelper::MakeChatGroupCreateResp(packetResponse, resp);
}

void ThreadChat::ProcessChatGroupRenameReq(WrapPacket& packet, WrapPacket& packetResponse) {
    ChatGroupRenameReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
    packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    do {
        FETCH_RESPONSE_BREAK(packetResponse);
        if( !sGameUtils->IsChatGroupNameValid(request.name())) {
            packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetChatGroupCreateInvalidName());
            break;
        }
        // 出错则返回系统错误, 否则转发到聊天服处理
        packetResponse.clear_userid();
        ChatChannelCmd cmd;
        cmd.set_cmd(CHAT_ChatGroupRenameReq);
        cmd.set_userid(packet.userid());
        cmd.set_requestid(packet.requestid());
        *cmd.mutable_chat_group_rename_req() = request;
        ProtoCmdHelper::PushChatCmd(pConnection, cmd);
    }while(0);
    LxGameHelper::MakeChatGroupRenameResp(packetResponse);
}

void ThreadChat::ProcessChatGroupResetPwdReq(WrapPacket& packet, WrapPacket& packetResponse) {
    ChatGroupResetPwdReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
    packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    do {
        FETCH_RESPONSE_BREAK(packetResponse);
        // 出错则返回系统错误, 否则转发到聊天服处理
        packetResponse.clear_userid();
        ChatChannelCmd cmd;
        cmd.set_cmd(CHAT_ChatGroupResetPwdReq);
        cmd.set_userid(packet.userid());
        cmd.set_requestid(packet.requestid());
        *cmd.mutable_chat_group_reset_pwd_req() = request;
        ProtoCmdHelper::PushChatCmd(pConnection, cmd);
    }while(0);
    LxGameHelper::MakeChatGroupResetPwdResp(packetResponse);
}

void ThreadChat::ProcessChatGroupInviteReq(WrapPacket& packet, WrapPacket& packetResponse) {
    ChatGroupInviteReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
    packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    do {
        FETCH_RESPONSE_BREAK(packetResponse);
        // 出错则返回系统错误, 否则转发到聊天服处理
        packetResponse.clear_userid();
        ChatChannelCmd cmd;
        cmd.set_cmd(CHAT_ChatGroupInviteReq);
        cmd.set_userid(packet.userid());
        cmd.set_requestid(packet.requestid());
        *cmd.mutable_chat_group_invite_req() = request;
        ProtoCmdHelper::PushChatCmd(pConnection, cmd);
    }while(0);

    LxGameHelper::MakeChatGroupInviteResp(packetResponse);
}

void ThreadChat::ProcessChatGroupAcceptInviteReq(WrapPacket& packet, WrapPacket& packetResponse) {
    ChatGroupAcceptInviteReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
    packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    do {
        FETCH_RESPONSE_BREAK(packetResponse);
        // 出错则返回系统错误, 否则转发到聊天服处理
        packetResponse.clear_userid();
        ChatChannelCmd cmd;
        cmd.set_cmd(CHAT_ChatGroupAcceptInviteReq);
        cmd.set_userid(packet.userid());
        cmd.set_requestid(packet.requestid());
        *cmd.mutable_chat_group_accept_invite_req() = request;
        ProtoCmdHelper::PushChatCmd(pConnection, cmd);
    }while(0);
    LxGameHelper::MakeChatGroupAcceptInviteResp(packetResponse);
}

void ThreadChat::ProcessChatGroupSearchReq(WrapPacket& packet, WrapPacket& packetResponse) {
    ChatGroupSearchReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
    packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    ChatGroupSearchResp resp;
    do {
        FETCH_RESPONSE_BREAK(packetResponse);
        // 出错则返回系统错误, 否则转发到聊天服处理
        packetResponse.clear_userid();
        ChatChannelCmd cmd;
        cmd.set_cmd(CHAT_ChatGroupSearchReq);
        cmd.set_userid(packet.userid());
        cmd.set_requestid(packet.requestid());
        *cmd.mutable_chat_group_search_req() = request;
        ProtoCmdHelper::PushChatCmd(pConnection, cmd);
    }while(0);
    LxGameHelper::MakeChatGroupSearchResp(packetResponse, resp);
}

void ThreadChat::ProcessChatGroupJoinReq(WrapPacket& packet, WrapPacket& packetResponse) {
    ChatGroupJoinReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
    packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    ChatGroupJoinResp resp;
    do {
        FETCH_RESPONSE_BREAK(packetResponse);
        // 出错则返回系统错误, 否则转发到聊天服处理
        packetResponse.clear_userid();
        ChatChannelCmd cmd;
        cmd.set_cmd(CHAT_ChatGroupJoinReq);
        cmd.set_userid(packet.userid());
        cmd.set_requestid(packet.requestid());
        *cmd.mutable_chat_group_join_req() = request;
        ProtoCmdHelper::PushChatCmd(pConnection, cmd);
    }while(0);
    LxGameHelper::MakeChatGroupJoinResp(packetResponse, resp);
}

void ThreadChat::ProcessChatGroupQuitReq(WrapPacket& packet, WrapPacket& packetResponse) {
    ChatGroupQuitReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}

    packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    do {
        FETCH_RESPONSE_BREAK(packetResponse);
        // 出错则返回系统错误, 否则转发到聊天服处理
        packetResponse.clear_userid();
        ChatChannelCmd cmd;
        cmd.set_cmd(CHAT_ChatGroupQuitReq);
        cmd.set_userid(packet.userid());
        cmd.set_requestid(packet.requestid());
        *cmd.mutable_chat_group_quit_req() = request;
        ProtoCmdHelper::PushChatCmd(pConnection, cmd);
    }while(0);

    LxGameHelper::MakeChatGroupQuitResp(packetResponse);
}

void ThreadChat::ProcessChatGroupDismissReq(WrapPacket& packet, WrapPacket& packetResponse) {
    ChatGroupDismissReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
    packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    do {
        FETCH_RESPONSE_BREAK(packetResponse);
        // 出错则返回系统错误, 否则转发到聊天服处理
        packetResponse.clear_userid();
        ChatChannelCmd cmd;
        cmd.set_cmd(CHAT_ChatGroupDismissReq);
        cmd.set_userid(packet.userid());
        cmd.set_requestid(packet.requestid());
        *cmd.mutable_chat_group_dismiss_req() = request;
        ProtoCmdHelper::PushChatCmd(pConnection, cmd);
    }while(0);

    LxGameHelper::MakeChatGroupDismissResp(packetResponse);
}

void ThreadChat::ProcessChatGroupKickReq(WrapPacket& packet, WrapPacket& packetResponse) {
    ChatGroupKickReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
    do {
        FETCH_RESPONSE_BREAK(packetResponse);
        // 出错则返回系统错误, 否则转发到聊天服处理
        packetResponse.clear_userid();
        ChatChannelCmd cmd;
        cmd.set_cmd(CHAT_ChatGroupKickReq);
        cmd.set_userid(packet.userid());
        cmd.set_requestid(packet.requestid());
        *cmd.mutable_chat_group_kick_req() = request;
        ProtoCmdHelper::PushChatCmd(pConnection, cmd);
    }while(0);
    LxGameHelper::MakeChatGroupKickResp(packetResponse);
}

void ThreadChat::ProcessChatGroupClearChatReq(WrapPacket& packet, WrapPacket& packetResponse) {
    ChatGroupClearChatReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
    do {
        FETCH_RESPONSE_BREAK(packetResponse);
        // 出错则返回系统错误, 否则转发到聊天服处理
        packetResponse.clear_userid();
        ChatChannelCmd cmd;
        cmd.set_cmd(CHAT_ChatGroupClearChatReq);
        cmd.set_userid(packet.userid());
        cmd.set_requestid(packet.requestid());
        *cmd.mutable_chat_group_clear_chat_req() = request;
        ProtoCmdHelper::PushChatCmd(pConnection, cmd);
    }while(0);
    LxGameHelper::MakeChatGroupClearChatResp(packetResponse);
}

void ThreadChat::ProcessChatGroupListReq(WrapPacket& packet, WrapPacket& packetResponse) {
    packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    ChatGroupListResp resp;
    do {
        FETCH_RESPONSE_BREAK(packetResponse);
        // 出错则返回系统错误, 否则转发到聊天服处理
        packetResponse.clear_userid();
        ChatChannelCmd cmd;
        cmd.set_cmd(CHAT_ChatGroupListReq);
        cmd.set_userid(packet.userid());
        cmd.set_requestid(packet.requestid());
        ProtoCmdHelper::PushChatCmd(pConnection, cmd);
    }while(0);
    LxGameHelper::MakeChatGroupListResp(packetResponse, resp);
}
////////////////////////////////////////////////////////////////////////////////////////

void ThreadChat::ProcessGiftDataReq(WrapPacket& packet, WrapPacket& packetResponse) {
    GiftDataReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGERROR("parse failed");
		return;
	}
    packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    GiftDataResp resp;
    do {
        FETCH_RESPONSE_BREAK(packetResponse);
        if( !RedisData::GetGift(pConnection, request.gid(), *resp.mutable_gift()) ) {
            resp.clear_gift();
            packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
            break;
        }
    }while(0);
    LxGameHelper::MakeGiftDataResp(packetResponse, resp);
}

void ThreadChat::ProcessGiftListReq(WrapPacket& packet, WrapPacket& packetResponse) {
    packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    GiftListResp response;
    sGameUtils->GetGiftFee(response);
    int64 now = sGameUtils->GetFakeTimeNow();
    do {
        FETCH_RESPONSE_BREAK(packetResponse);
        vector<int64> vecInvalidGift;
        vector<int64> vecExpired;
        int32 maxSeconds = JDATA->SystemConstPtr()->GetGiftRecordKeepTime()*TIME_DAY;
        map<uint64, int64> mapGiftTime;
        pConnection->hgetall(RedisKey::MakeUserGiftListKey(packet.userid()), mapGiftTime);
        for( auto& it : mapGiftTime) {
            if( it.second + maxSeconds <= now ) {
                continue;
            }
            GiftData gift;
            if( !RedisData::GetGift(pConnection, it.first, gift) ) {
                continue;
            }
            // 临时防一手包字节超大
            if( gift.status() != EGS_SendCanceled && response.ByteSize() < 60000 ) {
                auto ptr = response.add_gifts();
                *ptr = gift;
                ptr->mutable_receiver()->clear_t_sign();
                ptr->mutable_receiver()->clear_t_comment();
                ptr->mutable_sender()->clear_t_sign();
                ptr->mutable_sender()->clear_t_comment();
            }
        }
    }while(0);
    LxGameHelper::MakeGiftListResp(packetResponse, response);
}

void ThreadChat::ProcessRGiftAcceptReq(WrapPacket& packet, WrapPacket& packetResponse) {
    RGiftAcceptReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGERROR("parse failed");
		return;
	}
    packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    do {
        FETCH_RESPONSE_BREAK(packetResponse);
        GiftData gift;
        if( !RedisData::GetGift(pConnection, request.gid(), gift) ) {
            packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
            break;
        }
        if( packet.userid() != gift.receiver().t_id() ) {
            packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
            break;
        }
        if( gift.status() != EGS_RecvAccepting ) {
            packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
            break;
        }
        GiftChannelCmd cmd;
        cmd.set_cmd(CHAT_RGiftAcceptReq);
        cmd.set_userid(packet.userid());
        *cmd.mutable_accept() = request;
        ProtoCmdHelper::PushGiftCmd(pConnection, cmd);
    }while(0);
    LxGameHelper::MakeRGiftAcceptResp(packetResponse);
}

void ThreadChat::ProcessSGiftCancelReq(WrapPacket& packet, WrapPacket& packetResponse) {
    SGiftCancelReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGERROR("parse failed");
		return;
	}
    packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    do{
        FETCH_RESPONSE_BREAK(packetResponse);
        GiftData gift;
        if( !RedisData::GetGift(pConnection, request.gid(), gift) ) {
            packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
            break;
        }
        if( gift.sender().t_id() != packet.userid() ) {
            packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
            break;
        }
        if( gift.status() != EGS_RecvAccepting ) {
            packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
            break;
        }
        GiftChannelCmd cmd;
        cmd.set_cmd(CHAT_SGiftCancelReq);
        cmd.set_userid(packet.userid());
        *cmd.mutable_cancel() = request;
        ProtoCmdHelper::PushGiftCmd(pConnection, cmd);
    }while(0);
    LxGameHelper::MakeSGiftCancelResp(packetResponse);
}

void ThreadChat::ProcessSGiftVerifyReq(WrapPacket& packet, WrapPacket& packetResponse) {
    SGiftVerifyReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGERROR("parse failed");
		return;
	}
    packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    do{
        FETCH_RESPONSE_BREAK(packetResponse);
        GiftData gift;
        if( !RedisData::GetGift(pConnection, request.gid(), gift) ) {
            packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
            break;
        }
        if( gift.sender().t_id() != packet.userid() ) {
            packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
            break;
        }
        if( gift.status() != EGS_SendVerify ) {
            packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
            break;
        }
        if( request.confirm() ) {
            string strCode = RedisData::GetUserGiftCode(pConnection, packet.userid());
            if( strCode != request.code() ) {
                packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetGiftCodeNotSet());
                break;
            }
        }
        GiftChannelCmd cmd;
        cmd.set_cmd(CHAT_SGiftVerifyReq);
        cmd.set_userid(packet.userid());
        *cmd.mutable_verify() = request;
        ProtoCmdHelper::PushGiftCmd(pConnection, cmd);
    }while(0);
    LxGameHelper::MakeSGiftVerifyResp(packetResponse);
}

void ThreadChat::ProcessRGiftGetReq(WrapPacket& packet, WrapPacket& packetResponse) {
    RGiftGetReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGERROR("parse failed");
		return;
	}
    packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    do{
        FETCH_RESPONSE_BREAK(packetResponse);
        GiftData gift;
        if( !RedisData::GetGift(pConnection, request.gid(), gift) ) {
            packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
            break;
        }
        if( packet.userid() != gift.receiver().t_id() ) {
            packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
            break;
        }
        if( gift.status() != EGS_RecvFetching ) {
            packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
            break;
        }
        GiftChannelCmd cmd;
        cmd.set_cmd(CHAT_RGiftGetReq);
        cmd.set_userid(packet.userid());
        *cmd.mutable_recv() = request;
        ProtoCmdHelper::PushGiftCmd(pConnection, cmd);
    }while(0);
    LxGameHelper::MakeRGiftGetResp(packetResponse);
}

void ThreadChat::ProcessGiftChangeCodeReq(WrapPacket& packet, WrapPacket& packetResponse) {
    GiftChangeCodeReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGERROR("parse failed");
		return;
	}
    packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    do {
        FETCH_RESPONSE_BREAK(packetResponse);
        string strCode = RedisData::GetUserGiftCode(pConnection, packet.userid());
        if( strCode != request.old_pwd() ) {
            packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetGiftCodeNotSet());
            break;
        }
        if( request.new_pwd().empty() ) {
            packetResponse.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
            break;
        }
        vector<string> vec;
        vec.push_back(request.new_pwd());
        ProtoCmdHelper::PushGmCmd(pConnection, packet.userid(), EIC_GiftCode, vec);
    } while(0);
    LxGameHelper::MakeGiftChangeCodeResp(packetResponse);
}
