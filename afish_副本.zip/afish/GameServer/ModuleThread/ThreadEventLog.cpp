/**
 * 游戏日志记录模块
*/
#include "ThreadEventLog.h"
#include "GameUtils.h"

ThreadEventLog::ThreadEventLog(boost::asio::io_service& io)
    : _io_service(io), _timer(io)
{
    m_mapEventFile.clear();
    _timer.expires_from_now(boost::posix_time::seconds(300));
    _timer.async_wait(boost::bind(&ThreadEventLog::OnTimerMinute5, this, boost::asio::placeholders::error));
}

ThreadEventLog::~ThreadEventLog() {
}

void ThreadEventLog::OnTimerMinute5(const boost::system::error_code& error) {
    if( !error ) {
        for( auto & evt : m_mapEventFile ) {
            evt.second._event_file.flush();
        }
        _timer.expires_from_now(boost::posix_time::seconds(300));
        _timer.async_wait(boost::bind(&ThreadEventLog::OnTimerMinute5, this, boost::asio::placeholders::error));
    }
}

void ThreadEventLog::DoLogEvent(const string& name, const string& data) {
	string strLogFileName = MakeEventLogFileName(name);
    auto it = m_mapEventFile.find(name);
    if( it != m_mapEventFile.end() ) {
        if( it->second._event_file_name != strLogFileName ) {
            if( it->second._event_file.is_open() ) {
                it->second._event_file.close();
            }
            it->second._event_file_name = strLogFileName;
            it->second._event_file.open(strLogFileName, ios::app);
        }
        it->second._event_file << data << endl;
    }
    else {
        tagEventFile evt;
        evt._event_file_name = "";
        m_mapEventFile[name] = evt;
        DoLogEvent(name, data);
    }
}

void ThreadEventLog::DoLogRedis(const string& name, const string& data) {
    FETCH_VOID();
    pConnection->xadd("log_stream", name, data);
}

string ThreadEventLog::MakeEventLogFileName(const string& name)
{
    // ./game_log/20200801/14/[event_name].log

    time_t tNow = time(nullptr);
    struct tm lt;
    localtime_r(&tNow, &lt);

    ostringstream osDir;
    osDir << "./game_log";
    mkdir(osDir.str().c_str(),0775);

    // ./game_log/20200801/
    char szYearMonDay[32] = {0};
    sprintf(szYearMonDay, "%04d%02d%02d", lt.tm_year + 1900, lt.tm_mon+1, lt.tm_mday);
    osDir << "/" << szYearMonDay;
    mkdir(osDir.str().c_str(),0775);

    // ./game_log/20200801/14/
    char szYearMonDayHourFile[32] = {0};
    sprintf(szYearMonDayHourFile, "%02d", lt.tm_hour);
    osDir << "/" << szYearMonDayHourFile;
    mkdir(osDir.str().c_str(),0775);

    // ./game_log/20200801/14/[event_name].log
    osDir << "/" << name << ".log";
    return osDir.str();
}
