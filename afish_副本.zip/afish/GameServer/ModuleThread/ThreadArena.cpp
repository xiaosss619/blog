/**
 * 竞技场排名模块
*/
#include "ThreadArena.h"
#include "GameUtils.h"
#include "RedisManager/RedisManager.h"
#include "Include/RedisProtoHelper.h"
#include "Include/MySQLProtoHelper.h"
#include "DataCache/RedisData.h"
#include "Dispatcher.h"
#include "ModuleHelper/HelperArena.h"
#include "ModuleUser/LxUser.h"

ThreadArena::ThreadArena(boost::asio::io_service& io)
    : _io_service(io)
{
}

ThreadArena::~ThreadArena() {
}

void ThreadArena::ProcessPacket(WrapPacket& packet) {
    WrapPacket response = packet;
    response.clear_data();
	switch(packet.cmd()) {
	case ARENA_ArenaDataReq:
		{
            ProcessArenaDataReq(packet, response);
			break;
		}
    case ARENA_LxArenaUserInfo:
        {
            ProcessLxArenaUserInfo(packet, response);
            break;
        }
    case ARENA_LxUserBulletinData:
        {
            ProcessLxUserBulletinData(packet, response);
            break;
        }
    case ARENA_BossBulletinBoardReq:
        {
            ProcessBossBulletinBoardReq(packet, response);
            break;
        }
	default:
        {
            response.clear_userid();
            break;
        }
	}
    if( response.has_userid() ) {
        // 有用户id,返回给客户端
        sDispatcher->call_client(response);
    }
}

void ThreadArena::ProcessLxArenaUserInfo(WrapPacket& packet, WrapPacket& response) {
    LxArenaUserInfo request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
    FETCH_VOID();
    RedisProtoHelper::RedisSaveHSET(pConnection, RedisKey::MakeArenaUserKey(), GlobalUtils::ToString(request.user().user_id()), request.user());
}

void ThreadArena::ProcessArenaDataReq(WrapPacket& packet, WrapPacket& response) {
    ArenaDataResp msg;
    msg.set_daily_score(0);
    msg.set_daily_rank(-1);
    msg.set_week_score(0);
    msg.set_week_rank(-1);
    response.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    do {
        FETCH_RESPONSE_BREAK(response);
        int64 userId = packet.userid();
        int32 score = U_RankScore::GetScore(pConnection->zscore(RedisKey::MakeArenaDayKey(), userId));
        int32 rank = pConnection->zrevrank(RedisKey::MakeArenaDayKey(), GlobalUtils::ToString(userId));
        if( rank >= 0 ) {
            rank++;// 0起始 排名需要+1
        }
        msg.set_daily_score(score);
        msg.set_daily_rank(rank);
        score = U_RankScore::GetScore(pConnection->zscore(RedisKey::MakeArenaWeekKey(), userId));
        rank = pConnection->zrevrank(RedisKey::MakeArenaWeekKey(), GlobalUtils::ToString(userId));
        if( rank >= 0 ) {
            rank++;// 0起始 排名需要+1
        }
        msg.set_week_score(score);
        msg.set_week_rank(rank);
        {
            std::vector< std::pair<int64, int64 > > values;
            if( pConnection->zrevrange(RedisKey::MakeArenaDayKey(), 0, 49, values) ) {
                for( size_t i = 0; i < values.size() ; ++i ) {
                    int64 userId = values[i].first;
                    int32 score = U_RankScore::GetScore(values[i].second);
                    ArenaUser top50;
                    if( ArenaGetUser(userId, top50) ) {
                        top50.set_user_score(score);
                        top50.set_user_rank(i+1);
                        *msg.add_daily() = top50;
                    }
                }
            }
        }
        {
            std::vector< std::pair<int64, int64 > > values;
            if( pConnection->zrevrange(RedisKey::MakeArenaWeekKey(), 0, 49, values) ) {
                for( size_t i = 0; i < values.size() ; ++i ) {
                    int64 userId = values[i].first;
                    int32 score = U_RankScore::GetScore(values[i].second);
                    ArenaUser top50;
                    if( ArenaGetUser(userId, top50) ) {
                        top50.set_user_score(score);
                        top50.set_user_rank(i+1);
                        *msg.add_weekly() = top50;
                    }
                }
            }
        }
        {
            map<uint64, ArenaUser> mapData;
            // 上周排名的field是排名的序号,1-2-3,map遍历时正好符合1-2-3的名词
            RedisProtoHelper::RedisLoadArenaUser(pConnection, RedisKey::MakeArenaLastWeekKey(), mapData);
            for( auto & it : mapData ) {
                it.second.set_user_name(GlobalUtils::GetStarName(it.second.user_name()));
                it.second.set_user_rank((int32)it.first);
                *msg.add_last_week() = it.second;
            }
        }
    } while(0);
    LxGameHelper::MakeArenaDataResp(response, msg);
}

bool ThreadArena::ArenaGetUser(uint64 userId, ArenaUser& lhs) {
    FETCH_RETURN(false);
    string strUser;
    pConnection->hget(RedisKey::MakeArenaUserKey(), userId, strUser);
    if( !JsonProto::ProtoFromJson(strUser, lhs) ) {
        LOGERROR("user[%lu] arena info failed[%s]", userId, strUser.data());
        return false;
    }
    return true;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////

void ThreadArena::ProcessBossBulletinBoardReq(WrapPacket& packet, WrapPacket& response) {
    BossBulletinBoardReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
    FETCH_VOID();
    int64 now = sGameUtils->GetFakeTimeNow();
    BossBulletinBoardResp msg;
    msg.set_bulletin_type(request.bulletin_type());
    msg.set_boss_index(request.boss_index());
    msg.set_own_data(0);
    msg.set_own_rank(-1);
    int32 bType = 0;
    string strDate;
    switch( request.bulletin_type() ) {
    case EBBBT_LastKill:
        bType = EBST_HornKill;
        strDate = GlobalUtils::GetTimeByFormat(ETF_YMD_SHORT, now - 86400);
        break;
    case EBBBT_LastRate:
        bType = EBST_HornRate;
        strDate = GlobalUtils::GetTimeByFormat(ETF_YMD_SHORT, now - 86400);
        break;
    case EBBBT_TodayKill:
        bType = EBST_HornKill;
        strDate = GlobalUtils::GetTimeByFormat(ETF_YMD_SHORT, now);
        break;
    case EBBBT_TodayRate:
        bType = EBST_HornRate;
        strDate = GlobalUtils::GetTimeByFormat(ETF_YMD_SHORT, now);
        break;
    case EBBBT_LastBomb:
        bType = EBST_BombCost;
        strDate = GlobalUtils::GetTimeByFormat(ETF_YMD_SHORT, now - 86400);
        break;
    case EBBBT_TodayBomb:
        bType = EBST_BombCost;
        strDate = GlobalUtils::GetTimeByFormat(ETF_YMD_SHORT, now);
        break;
    default:
        return;
    }
    string strBossKey = RedisKey::MakeBulletinHornKey(request.boss_index(), bType, strDate);
    string strUserKey = RedisKey::MakeBulletinHornKey(request.boss_index(), EBST_BulletinUser, strDate);
    BulletinFetchTop50(pConnection, bType, packet.userid(), strUserKey, strBossKey, sHArena->GetBulletinMaxRank(request.boss_index())-1, msg);

    LxGameHelper::MakeBossBulletinBoardResp(response, msg);
}

void ThreadArena::ProcessLxUserBulletinData(WrapPacket& packet, WrapPacket& response) {
    response.clear_userid();// 无需回包
    LxUserBulletinData request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed [%lu]", packet.userid());
		return;
	}
    int64 now = sGameUtils->GetFakeTimeNow();
    if( !GlobalUtils::InSameDay(now, now + 5*60)
        || !GlobalUtils::InSameDay(now, now - 5*60) ) {
        // 跨天的前后5分钟内击杀的boss, 不计入榜单
        return;
    }
    FETCH_VOID();
    uint64 userId = request.user().user_id();
    int32 bossId = request.boss_index();

    // 先设置今日用户
    string strToday = GlobalUtils::GetTimeByFormat(ETF_YMD_SHORT, now);
    string strUserKey = RedisKey::MakeBulletinHornKey(bossId, EBST_BulletinUser, strToday);
    auto data = BulletinSaveUser(pConnection, request.user(), strUserKey);
    int32 maxRate = TUPLE0(data);
    int32 killNum = TUPLE1(data);
    int32 bombCost = TUPLE2(data);
    if( bossId == JDATA->SystemConstPtr()->GetNuclearDrawRankFishID() ) {
        string strBossKey = RedisKey::MakeBulletinHornKey(bossId, EBST_BombCost, strToday);
        pConnection->zadd(strBossKey, userId, U_RankScore::MakeScore(now, bombCost));
        pConnection->expire(strBossKey, TIME_DAY*2);
    }
    else {
        tagJsonFishData tagFish;
        if( JDATA->FishDataPtr()->ByID(bossId, tagFish) && tagFish._SummonRankParam.size() == 2 ) {
            if( killNum > 0 && killNum >= tagFish._SummonRankParam[0] ) {
                string strBossKey = RedisKey::MakeBulletinHornKey(bossId, EBST_HornKill, strToday);
                pConnection->zadd(strBossKey, userId, U_RankScore::MakeScore(now, killNum));
                pConnection->expire(strBossKey, TIME_DAY*2);
            }

            if( maxRate > 0 && maxRate >= tagFish._SummonRankParam[1] ) {
                string strBossKey = RedisKey::MakeBulletinHornKey(bossId, EBST_HornRate, strToday);
                pConnection->zadd(strBossKey, userId, U_RankScore::MakeScore(now, maxRate));
                pConnection->expire(strBossKey, TIME_DAY*2);
            }
        }
    }
}

std::tuple<int32, int32, int32> ThreadArena::BulletinSaveUser(RedisConnection* pConnection, const BulletinUser& user, const string& strUserKey) {
    int32 maxRate = user.user_max_rate();
    int32 killNum = user.user_kill();
    int32 bombCost = user.user_bomb();

    BulletinUser oldInfo;
    if( !pConnection->hexists(strUserKey, GlobalUtils::ToString(user.user_id()))
        || !BulletinGetUser(pConnection, strUserKey, user.user_id(), oldInfo)) {
        string strJson = JsonProto::ProtoToJson(user);
        pConnection->hset(strUserKey, user.user_id(), strJson);
    }
    else {
        oldInfo.set_user_vip(user.user_vip());
        oldInfo.set_user_name(user.user_name());
        oldInfo.set_user_head(user.user_head());
        oldInfo.set_user_frame(user.user_frame());
        oldInfo.set_user_weapon(user.user_weapon());
        oldInfo.set_user_turret(user.user_turret());
        oldInfo.set_user_turret_star(user.user_turret_star());
        oldInfo.set_user_swing(user.user_swing());

        bombCost += oldInfo.user_bomb();
        oldInfo.set_user_bomb(bombCost);

        killNum += oldInfo.user_kill();
        oldInfo.set_user_kill(killNum);

        if( oldInfo.user_max_rate() < maxRate ) {
            oldInfo.set_user_max_rate(maxRate);
        }
        else {
            // 比之前的小, 就不需要返回去更新排行榜了
            maxRate = 0;
        }
        string strJson = JsonProto::ProtoToJson(oldInfo);
        pConnection->hset(strUserKey, user.user_id(), strJson);
    }
    pConnection->expire(strUserKey, TIME_DAY*2);
    return std::make_tuple(maxRate, killNum, bombCost);
}

bool ThreadArena::BulletinGetUser(RedisConnection* pConnection, const string& strUserKey, uint64 userId, BulletinUser& lhs) {
    string strUser;
    if( !pConnection->hget(strUserKey, userId, strUser) ) {
        LOGERROR("user[%lu] get bulletin user failed[%s]", userId, strUserKey.c_str());
        return false;
    }
    if( !JsonProto::ProtoFromJson(strUser, lhs) ) {
        LOGERROR("user[%lu] get bulletin user[%s] failed[%s]", userId, strUserKey.c_str(), strUser.c_str());
        return false;
    }
    return true;
}

void ThreadArena::BulletinFetchTop50(RedisConnection* pConnection, int32 type, uint64 userId, const string& strUserKey, const string& strBossKey, int32 maxNum, BossBulletinBoardResp& resp) {
    bool onBoard = false;
    std::vector< std::pair<int64, int64 > > values;
    if( pConnection->zrevrange(strBossKey, 0, maxNum, values) ) {
        for( size_t i = 0; i < values.size() ; ++i ) {
            uint64 uid = values[i].first;
            int32 score = U_RankScore::GetScore(values[i].second);
            BulletinUser top50;
            if( BulletinGetUser(pConnection, strUserKey, uid, top50) ) {
                auto ptr = resp.add_users();
                *ptr = top50;
                if( type == EBST_HornKill ) {
                    ptr->set_user_kill(score);
                }
                else if( type == EBST_BombCost ) {
                    ptr->set_user_bomb(score);
                }
                else {
                    ptr->set_user_max_rate(score);
                }
                if( uid == userId ) {
                    resp.set_own_data(score);
                    resp.set_own_rank(i+1);
                    onBoard = true;
                }
            }
        }
    }
    if( !onBoard ) {
        BulletinUser self;
        if( BulletinGetUser(pConnection, strUserKey, userId, self) ) {
            if( type == EBST_HornKill ) {
                resp.set_own_data(self.user_kill());
            }
            else if( type == EBST_BombCost ) {
                resp.set_own_data(self.user_bomb());
            }
            else {
                resp.set_own_data(self.user_max_rate());
            }
        }
    }
}
