#pragma once

#include "ServerDefine.h"

class ThreadTimer
{
public:
	ThreadTimer(boost::asio::io_service& io);
	~ThreadTimer();

	// 执行初始化, 本函数在主线程执行
	void InitInMain();

	void OnTimer1s(const boost::system::error_code& error);
private:
	void OnInit(RedisConnection* pConnection, int64 now);
	void LoadCronTasks();
	// 按Activities表, 检测当前活动开关状态
	void CheckActivities(int64 now);
	// 检测系统邮件
	void CheckSystemMails(RedisConnection* pConnection);
	// 检测兑换商店
	void CheckBombGameBroadcast(int64 now);
///////////////////////////////////////////////////////////////////////////////////////
private:
	boost::asio::io_service& _io_service;
	boost::asio::deadline_timer _timer;
	// Activities表中对应的活动开启和关闭控制对象
	LxCrontab* m_tasks;
////////////////////////////////////////////////////////////////////////////////////////
private:
	// 是否进行过初始化动作，部分系统启动之后的初始化行为放在线程的第一次时钟内进行
	bool m_bInited;
	int64 m_i64Clock;
	int64 m_tmLastBombGameBroadcast;
};
