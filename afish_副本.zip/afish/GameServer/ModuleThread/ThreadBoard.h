#pragma once

#include "ServerDefine.h"

class RedisConnection;
class ThreadBoard
{
public:
	ThreadBoard(boost::asio::io_service& io);
	~ThreadBoard();

	void PostPacket(WrapPacket& packet) {
		WrapPacket pkg = packet;
		_io_service.post(boost::bind(&ThreadBoard::ProcessPacket, this, pkg));
	}

	void ProcessPacket(WrapPacket& packet);
private:
	boost::asio::io_service& _io_service;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
private:
	void ProcessBoardDataReq(WrapPacket& packet, WrapPacket& response);
	void ProcessLxUserBoardData(WrapPacket& packet, WrapPacket& response);
private:
	void FetchBoardTopUser(RedisConnection* pConnection, int32 type, uint64 userId, int32 maxNum, BoardDataResp& resp);
	void SaveBoardUser(RedisConnection* pConnection, const BoardUser& user);
	bool GetBoardUser(RedisConnection* pConnection, uint64 userId, BoardUser& lhs);
};
