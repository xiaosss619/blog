#pragma once

#include "io_service_pool.h"
#include "ServerDefine.h"

class RedisConnection;
class SqlLink;
class ThreadData
{
public:
	ThreadData(boost::asio::io_service& io);
	virtual ~ThreadData();

    void InitSqlLink(const string& strUrl, const string& strUserName, const string& strPassword);
    // 只有线程0会进行调用, 初始化数据库表
    bool InitDatabases();
public:
	void PostPacket(WrapPacket& packet) {
		WrapPacket pkg = packet;
		_io_service.post(boost::bind(&ThreadData::ProcessPacket, this, pkg));
	}

///////////////////////////////////////////////////////////////////////////////////////////////////
// 登录逻辑
public:
    void ProcessPacket(WrapPacket& packet);

    // 返回登录错误码,如果成功,则不需要返回,ThreadUser会接着处理登录流程
    int32 ProcessLoginRequest(WrapPacket& packet);
private:
    // 注册新账号
    int32 DoRegister(RedisConnection* pConnection, UserLoginReq& request, UserInfo& basicInfo);
    // 查找用户信息，不存在则注册一个新的
    int32 QueryUserInfoWithRegister(RedisConnection* pConnection, UserLoginReq& request, UserInfo& playerInfo);
    // sdk校验
    int32 VerifyToken(const std::string& token, std::string& strOpenId, std::string& strFbId);
private:
    void ProcessLxSaveData(WrapPacket& packet);

    void OnTimer1s(const boost::system::error_code& error);
private:
	boost::asio::io_service& _io_service;
	boost::asio::deadline_timer _timer_1s;
    int32 _timer_count;
    SqlLink* m_pSqlLink;
    string m_strUrl;
    string m_strUserName;
    string m_strPassword;
    // ProcessLoginRequest返回-1的放入到 m_mapLoginLine
    // Timer时钟里, 每次从m_mapLoginTimerLine中获取若干个去重新登录, 如果没数据, 则从m_mapLoginLine里swap所有数据
    map<uint64, WrapPacket> m_mapLoginLine;
    map<uint64, WrapPacket> m_mapLoginTimerLine;
};
