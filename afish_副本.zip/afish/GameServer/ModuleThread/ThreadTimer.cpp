/**
 * 定时器相关处理模块
*/
#include "ThreadTimer.h"
#include "GameUtils.h"
#include "Include/RedisKey.h"
#include "Include/MySQLProtoHelper.h"
#include "Dispatcher.h"
#include "LxSlotTableBoss.h"
#include "LxSlot.h"
#include "ModuleHelper/ModuleHelper.h"
#include "DataCache/ProtoCmdHelper.h"

ThreadTimer::ThreadTimer(boost::asio::io_service& io)
    : _io_service(io), _timer(io)
{
    m_tmLastBombGameBroadcast = 0;
    m_i64Clock = 0;
    m_bInited = false;
    m_tasks = new LxCrontab;
    _timer.expires_from_now(boost::posix_time::seconds(1));
    _timer.async_wait(boost::bind(&ThreadTimer::OnTimer1s, this, boost::asio::placeholders::error));
}

ThreadTimer::~ThreadTimer() {
}

void ThreadTimer::OnTimer1s(const boost::system::error_code& error) {
    if( !error ) {
        RedisConnectionIdGetter idGetter(enumRedisServerTypeData);
        auto pConnection = idGetter.GetConnection();
        if( pConnection != nullptr ) {
            int64 now = sGameUtils->GetFakeTimeNow();
            OnInit(pConnection, now);
            // 每秒交互一下 ChatServer的GmThread
            ProtoCmdHelper::ForEachServerCmd(pConnection, sGameUtils->GetServerId(), [&](const ServerProtoCmd& proto){
                switch(proto.cmd()) {
                case CHAT_SyncChatPublic:
                    sDispatcher->chat_public(proto.src(), proto.content());
                    break;
                case CHAT_LxReloadJson:
                {
                    LOGINFO("JSON file reload");
                    JDATA->LoadAll("../json/");
                    sGameUtils->Init();
                    LoadCronTasks();
                    break;
                }
                case CHAT_LxBoardcastChannelMsg:
                {
                    sDispatcher->broadcast_channel_msg(proto.channel(), proto.content());
                    break;
                }
                case CHAT_LxServerMaintain:
                {
                    sNetServer->KickAll();
                    break;
                }
                case CHAT_LxUpdateGiftFee:
                {
                    map<int32, GiftFeeData> mapFee;
                    if( RedisProtoHelper::RedisLoadGiftFeeData(pConnection, SYS_GIFT_FEE_KEY, mapFee) ) {
                        for( auto& it : mapFee ) {
                            sGameUtils->SetGiftFee(it.first, it.second.fee(), it.second.discount(), it.second.start_time(), it.second.end_time());
                        }
                    }
                    break;
                }
                default:
                    LOGERROR("unknown GmThread cmd[%ld]", proto.cmd());
                    break;
                }
            });
            ++m_i64Clock;
            if( m_i64Clock % 5 == 0 ) {
                // 每5秒做一次活动开启和关闭的判定,高效率一点的做法是在启动时加一个一次性定时器,计算一下各个活动的开始时间,每5秒判定比较影响性能
                CheckActivities(now);
            }
            if( m_i64Clock % 60 == 0 ) {
                CheckBombGameBroadcast(now);
            }
            if( m_i64Clock % 300 == 0 ) {
                CheckSystemMails(pConnection);
                sGameUtils->LogOnlineNum();
            }
            if( m_i64Clock >= 200000000 ) {
                m_i64Clock = 0;
            }
        }
        _timer.expires_from_now(boost::posix_time::seconds(1));
        _timer.async_wait(boost::bind(&ThreadTimer::OnTimer1s, this, boost::asio::placeholders::error));
    }
}

void ThreadTimer::LoadCronTasks() {
    // reload的时候要把目前正在进行中的保持住
    JDATA->ActivitiesPtr()->ForEach([&](tagJsonActivities* ptr){
        tagCronTask task;
        if( task.assign(ptr->_ID, ptr->_StartTime, ptr->_EndTime, ptr->_Lasting,
            ptr->_Year, ptr->_Month, ptr->_Week, ptr->_Day, ptr->_Hour, ptr->_Minute) ) {
            m_tasks->push(task);
        }
        else {
            LOGERROR("error build cron task[%d]", ptr->_ID);
        }
    });
}

void ThreadTimer::OnInit(RedisConnection* pConnection, int64 now) {
    if( m_bInited ) {
        return;
    }
    m_bInited = true;
    LoadCronTasks();
    sHTableBoss;
    CheckSystemMails(pConnection);
    sRankingList->LoadSummonPool();
    sHSDFish->init(pConnection);
    // 借用一下当前时间, 没有特别关联
    CheckActivities(now);
}

void ThreadTimer::CheckActivities(int64 now) {
    m_tasks->check(now, [&](int32 id, int64 start, int64 end) {
        if( start == -1 && end == -1 ) {
            sHActs->OnActivityClose(id);
        }
        else {
            sHActs->OnActivityOpen(id, start, end);
            LxActivityOpen msg;
            msg.set_id(id);
            msg.set_start(start);
            msg.set_end(end);
            WrapPacket pkt;
            LxGameHelper::MakeLxActivityOpen(pkt, msg);
            sDispatcher->notify_all_fish_room(pkt);
        }
    });
}

void ThreadTimer::CheckBombGameBroadcast(int64 now) {
    BombGameInfo config;
    sHBombGame->GetGameConfig(config);
    if( config.yell_gold_id() != 0 ) {
        if( now - m_tmLastBombGameBroadcast >= config.yell_gold_sec() ) {
            int64 poolGold = sRankingList->GetBombGamePoolGold();
            if( poolGold >= config.yell_gold() ) {
                m_tmLastBombGameBroadcast = now;
                list<string> lst;
                lst.push_back(GlobalUtils::GetNumberString(poolGold));
                sDispatcher->broadcast_rolling_msg(config.yell_gold_id(), "", lst);
            }
        }
    }
}

void ThreadTimer::CheckSystemMails(RedisConnection* pConnection) {
    int64 i64MaxSystemMailId = sGameUtils->GetMaxSystemMailId();
    map<string, string> mapMail;
    string strSystemMailKey = RedisKey::MakeSystemMailKey();
    pConnection->hgetall(strSystemMailKey, mapMail);
    map<int64, tagSystemMail> mapSystemMail;
    for( auto & it : mapMail ) {
        int64 iMailId = atol(it.first.c_str());
        string strJson = it.second;
        TRYBEGIN()
        Document doc;
        if( doc.Parse(strJson.data()).HasParseError() ) {
            LOGERROR("FORMAT failed[%s]", strJson.c_str());
            continue;
        }
        rapidjson::Value& param = doc;
        tagSystemMail mail;
        mail._mailid = iMailId;
        mail._title = param["title"].GetString();
        mail._content = param["content"].GetString();
        mail._timestamp = param["timestamp"].GetInt64();
        if( param.HasMember("items") && param["items"].IsArray() ) {
            for( uint32 i = 0 ; i < param["items"].Size() ; i++ ) {
                int32 iItemId = param["items"][i]["item"].GetInt();
                int64 iItemNum = param["items"][i]["num"].GetInt64();
                if( JDATA->ItemPtr()->ContainID(iItemId) && iItemNum > 0 ) {
                    GlobalUtils::SimpleMapAdd(mail._mapItem, iItemId, iItemNum);
                }
            }
        }
        if( i64MaxSystemMailId < mail._mailid ) {
            i64MaxSystemMailId = mail._mailid;
        }
        mapSystemMail[mail._mailid] = mail;
        TRYEND(strJson);
    }
    sGameUtils->UpdateSystemMail(i64MaxSystemMailId, mapSystemMail);
}
