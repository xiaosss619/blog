#pragma once

#include "ServerDefine.h"

struct tagEventFile {
	string _event_file_name;
	ofstream _event_file;
	tagEventFile& operator=(tagEventFile& rhs) {
		_event_file_name = rhs._event_file_name;
		_event_file = std::move(rhs._event_file);
		return *this;
	}
};

class RedisConnection;
class ThreadEventLog
{
public:
	ThreadEventLog(boost::asio::io_service& io);
	~ThreadEventLog();

	void LogEvent(const string& name, const string& data) {
		_io_service.post(boost::bind(&ThreadEventLog::DoLogEvent, this, name, data));
	}
	void LogRedis(const string& name, const string& data) {
		_io_service.post(boost::bind(&ThreadEventLog::DoLogRedis, this, name, data));
	}

	void OnTimerMinute5(const boost::system::error_code& error);
	void DoLogEvent(const string& name, const string& data);
	void DoLogRedis(const string& name, const string& data);
private:
	string MakeEventLogFileName(const string& name);
private:
	boost::asio::io_service& _io_service;
	boost::asio::deadline_timer _timer;
	map<string, tagEventFile> m_mapEventFile;
};
