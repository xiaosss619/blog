/**
 * 只处理登录消息,登录线程使用packet.connectionid作为线程池索引,保证同一个连接的数据在同一个登录线程中处理
 * TODO 目前是如果登录失败, 则会循环登录用户,
 * 如果用户频繁断连接重登, 由于每次的connectionid不同, 可能导致用户在多个ThreadData同时登录, 然后多次返回成功
 * 暂时来说没什么逻辑上的问题, 后续待思考
 *
 * 先检查request.account()在redis中是否能找到对应的userid,
 *      如果找到,则继续查找对应用户是否在线 hget PUB_USER_INFO_KEY userid,对应的offline_time=0表示在线
 *          在线,则传递LxUserOnline消息给UserManager,不带UserInfo字段,UserManager方处理时判定,向玩家返回一个UserLoginReq
 *          离线,则hget所有字段数据到UserInfo中, 返回UserLoginReq,同时发送LxUserOnline到UserManager,带UserInfo数据
 *      未找到则为新账号,创建用户,然后返回UserLoginReq,同时发送LxUserOnline到UserManager,带UserInfo数据
 */
#include "ThreadData.h"
#include "Dispatcher.h"
#include "ModuleConnection/NetServer.h"
#include "GameUtils.h"
#include "LxGame.pb.h"
#include "Utils/fasthash.h"
#include "jwt-cpp/jwt.h"
#include <boost/algorithm/string.hpp>
#include "RedisManager/RedisManager.h"
#include "DataCache/RedisData.h"
#include "DataCache/SqlLink.h"
#include "Include/RedisProtoHelper.h"
#include "Include/MySQLProtoHelper.h"
#include "DataCache/ProtoCmdHelper.h"
#include "ModuleHelper.h"

ThreadData::ThreadData(boost::asio::io_service& io)
    : _io_service(io), _timer_1s(io)
{
    m_mapLoginTimerLine.clear();
    m_mapLoginLine.clear();
    m_pSqlLink = nullptr;
    _timer_count = 0;
    _timer_1s.expires_from_now(boost::posix_time::seconds(1));
    _timer_1s.async_wait(boost::bind(&ThreadData::OnTimer1s, this, boost::asio::placeholders::error));
}

ThreadData::~ThreadData() {
    if( m_pSqlLink != nullptr ) {
        delete m_pSqlLink;
    }
}

bool ThreadData::InitDatabases() {
    return MySQLProtoHelper::InitDatabases(m_pSqlLink, MAX_DB_NUM, MAX_TATBLE_NUM);
}

void ThreadData::InitSqlLink(const string& strUrl, const string& strUserName, const string& strPassword) {
    m_pSqlLink = new SqlLink();
    m_strUrl = strUrl;
    m_strUserName = strUserName;
    m_strPassword = strPassword;
    m_pSqlLink->Init(strUrl, strUserName, strPassword);
}

void ThreadData::OnTimer1s(const boost::system::error_code& error) {
	if( !error ) {
        if( _timer_count % 5 == 0 ) {
            // 5秒重连一下db
            if( m_pSqlLink != nullptr ) {
                m_pSqlLink->check_database();
            }
            else {
                InitSqlLink(m_strUrl, m_strUserName, m_strPassword);
            }
        }
        if( m_mapLoginTimerLine.empty() ) {
            m_mapLoginTimerLine.swap(m_mapLoginLine);
        }
        // 每秒处理一个
        auto it = m_mapLoginTimerLine.begin();
        if( it != m_mapLoginTimerLine.end() ) {
            // 这里不需要删除, 如果登录成功, 函数内会删除
            // 如果不成功, ProcessLoginRequest返回-1之后会再次设置一下该用户的数值
            ProcessPacket(it->second);
            m_mapLoginTimerLine.erase(it);
        }
        ++_timer_count;
        _timer_1s.expires_from_now(boost::posix_time::seconds(1));
        _timer_1s.async_wait(boost::bind(&ThreadData::OnTimer1s, this, boost::asio::placeholders::error));
	}
}

void ThreadData::ProcessPacket(WrapPacket& packet) {
    WrapPacket pktLine = packet;    // 多复制一个, 如果要进队列, 就用这个原始数据进
    WrapPacket packetResponse = packet;
    switch(packet.cmd()) {
    case DATA_UserLoginReq:
    {
        packetResponse.set_cmd(DATA_UserLoginResp);
        packetResponse.clear_data();
        int32 ret = ProcessLoginRequest(packet);
        if( ret == -1 ) {
            // 返回值为-1的包, 肯定设置了userid
            m_mapLoginLine[packet.userid()] = pktLine;
            // 表示进入踢人逻辑, 不回包, 服务器进入踢人逻辑, 客户端会自动重新发登录包
        }
        else if( ret != JDATA->ErrorCodePtr()->GetSuccess() ) {
            // 只要是登录成功的,不走这里回包,这边都是登录失败的数据
            packetResponse.set_errorcode(ret);
            sDispatcher->call_client(packetResponse);
        }
        break;
    }
    case DATA_LxSaveData:
    {
        ProcessLxSaveData(packet);
        break;
    }
    default:
        LOGERROR("unhandled message got[%d]", packet.cmd());
        break;
    }
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int32 ThreadData::VerifyToken(const std::string& token, std::string& strOpenId, std::string& strFbId) {
    try {
        string strSecureKey = "Lixu_Service@509!@#401";
        auto decoded = jwt::decode(token);
        if( decoded.get_algorithm() == "HS256" ) {
            // 校验失败会抛出一个异常
            jwt::verify().allow_algorithm(jwt::algorithm::hs256{strSecureKey}).verify(decoded);
        }
        else {
            // 暂时只搞了HS256，其他的后面再加
            return JDATA->ErrorCodePtr()->GetLoginInvalidToken();
        }
        auto acc = decoded.get_payload_claim("AccountInfo").to_json();
        strOpenId = acc.get("open_id").to_str();
        if( acc.contains("account") ) {
            strFbId = acc.get("account").get("id").to_str();
        }
        int64 expire = decoded.get_payload_claim("Expired").as_int();
        int64 tNow = time(nullptr);
        if( expire < tNow ) {
            LOGINFO("token expired [%s] %ld %ld", strOpenId.c_str(), expire, tNow);
            return JDATA->ErrorCodePtr()->GetLoginTokenExpired();
        }
        return JDATA->ErrorCodePtr()->GetSuccess();
    }
    catch (std::exception& e) {
        LOGERROR("SDKTOKEN [%s] failed %s", token.c_str(), e.what());
        return JDATA->ErrorCodePtr()->GetLoginInvalidToken();
    }
}

int32 ThreadData::ProcessLoginRequest(WrapPacket& packet)
{
	UserLoginReq request;
	if (!request.ParseFromString(packet.data())) {
		LOGINFO("parse failed");
		return JDATA->ErrorCodePtr()->GetSystemError();
	}

    string strOpenId;
    string strFbId;
    switch( request.login_type() ) {
    case ELT_Anonymous:
    case ELT_Visitor:
    case ELT_Sdk:
        {
            int32 ret = VerifyToken(request.token(), strOpenId, strFbId);
            if( ret != JDATA->ErrorCodePtr()->GetSuccess() ) {
                LOGINFO("LOGINFAIL[%s]", request.DebugString().data());
                return ret;
            }
            request.set_account(strOpenId);
            request.set_token(strOpenId);
            request.set_tpacc(strFbId);
            break;
        }
    default:
        LOGINFO("LOGINFAIL[%s]", request.DebugString().data());
        return JDATA->ErrorCodePtr()->GetLoginInvalidType();
    }
    FETCH_RETURN(JDATA->ErrorCodePtr()->GetLoginDatabaseFailed());
    UserInfo playerInfo;
    RedisProtoHelper::UserInfoInit(playerInfo);
    playerInfo.set_battle_pass_vip_now(-1);
    // 从db中获取用户信息，用户不存在，则新建一个
    int32 ret = QueryUserInfoWithRegister(pConnection, request, playerInfo);
    if( ret != JDATA->ErrorCodePtr()->GetSuccess() ) {
        return ret;
    }
    if( !request.tpacc().empty() && playerInfo.user_fbid().empty() ) {
        // 老账号 如果是fb登录的, 但是原来数据里没记录, 这里补一下, 但是这里没存储到redis里
        playerInfo.set_user_fbid(request.tpacc());
    }
    uint64 uUserId = playerInfo.user_id();
    if( !RedisData::PassWhiteList(pConnection, GlobalUtils::ToString(uUserId)) ) {
        return JDATA->ErrorCodePtr()->GetSystemInChecking();
    }
    if( pConnection->hexists(RedisKey::MakeSystemUserBlockKey(), GlobalUtils::ToString(uUserId)) ) {
        return JDATA->ErrorCodePtr()->GetAccountBanned();
    }
    SeverIdAndLinkId tag;
    tag._serverId = sGameUtils->GetServerId();
    tag._linkId = packet.connectionid();
    if( !pConnection->setnxex(RedisKey::MakeUserLoginLockKey(uUserId), tag._data, 20) ) {
        tag._data = 0;
        pConnection->get(RedisKey::MakeUserLoginLockKey(uUserId), tag._data);
        if( sGameUtils->GetServerId() != tag._serverId || (int32)packet.connectionid() != tag._linkId ) {
            LOGINFO("user[%lu]server[%d]link[%d] relogin, need to kick previous one server[%d]link[%d]",
                uUserId, sGameUtils->GetServerId(), packet.connectionid(), tag._serverId, tag._linkId);
            vector<string> vec;
            vec.push_back(GlobalUtils::ToString(sGameUtils->GetServerId()));
            vec.push_back(GlobalUtils::ToString(packet.connectionid()));
            ProtoCmdHelper::PushGmCmd(pConnection, uUserId, EIC_KickRelogin, vec);
            packet.set_userid(uUserId);
            return -1;
        }
    }
    m_mapLoginLine.erase(uUserId);
    // 登录成功,向用户线程发送一条
    WrapPacket onlinePacket = packet;
    onlinePacket.set_userid(uUserId);// 新账号这里是linkid,需要设置一下
    onlinePacket.clear_data();
    LxUserOnline msg;
    {
        list<UserChargeData> lstCharge;
        string strKey = RedisKey::MakeUserChargeKey(uUserId);
        if( pConnection->exists(strKey) ) {
            RedisProtoHelper::RedisLoadUserChargeDataList(pConnection, strKey, lstCharge);
        }
        else {
            MySQLProtoHelper::MySqlUserChargeDataLoad(m_pSqlLink, uUserId, lstCharge);
            for( auto & product : lstCharge ) {
                RedisProtoHelper::RedisSaveUserChargeDataToList(pConnection, strKey, product);
            }
        }
        pConnection->expire(strKey, TIME_REDIS_EXPIRE);
        for( auto & charge : lstCharge ) {
            *(msg.mutable_resp()->add_productlist()) = charge;
        }

        list<BombGameRecord> lstRecord;
        strKey = RedisKey::MakeUserBombGameKey(uUserId);
        RedisData::ShrinkListUsingRPop(pConnection, strKey, 50);
        if( pConnection->exists(strKey) ) {
            RedisProtoHelper::RedisLoadBombGameRecordList(pConnection, strKey, lstRecord);
        }
        pConnection->expire(strKey, TIME_DAY*15);
        int64 now = sGameUtils->GetFakeTimeNow();
        for( auto & data : lstRecord ) {
            if( now - data.timestamp() >= TIME_DAY*15 ) {
                // 超过15天了,要删除, 直接从redis中rpop一条即可
                string strTemp;
                pConnection->rpop(strKey, strTemp);
            }
            else {
                *(msg.add_bomb_rewards()) = data;
            }
        }

        msg.mutable_resp()->set_user_data(RedisData::GetUserDefineData(uUserId, pConnection));

        strKey = RedisKey::MakeUserMailKey(uUserId);
        map<int64, LxMail> mapMail;
        MySQLProtoHelper::LoadAndInitLxMail(pConnection, m_pSqlLink, strKey, uUserId, mapMail);
        int64 tNow = sGameUtils->GetFakeTimeNow();
        vector<int64> vecMails;
        for( auto & mail : mapMail ) {
            if( mail.second.mail_rewarded() != 0 && tNow - mail.second.mail_time() >= 7*TIME_DAY ) {
                vecMails.push_back(mail.second.mail_id());
            }
            else {
                *msg.add_mails() = mail.second;
            }
        }
        pConnection->expire(strKey, TIME_REDIS_EXPIRE);
        // 超期无附件邮件直接删除
        for( size_t i = 0 ; i < vecMails.size() ; ++i ) {
            string strSubKey = GlobalUtils::ToString(vecMails[i]);
            pConnection->hdel(strKey, strSubKey);
            MySQLProtoHelper::MySqlLxMailDelete(m_pSqlLink, uUserId, vecMails[i]);
        }

        strKey = RedisKey::MakeUserItemKey(uUserId);
        map<int32, ItemPair> mapItem;
        MySQLProtoHelper::LoadAndInitItemPair(pConnection, m_pSqlLink, strKey, uUserId, mapItem);
        for( auto & item : mapItem ) {
            *(msg.mutable_resp()->add_items()) = item.second;
        }
		if( !mapItem.empty() ) {
        	pConnection->expire(strKey, TIME_REDIS_EXPIRE);
		}

        strKey = RedisKey::MakeUserHeroKey(uUserId);
        map<int32, HeroInfo> mapHero;
        MySQLProtoHelper::LoadAndInitHeroInfo(pConnection, m_pSqlLink, strKey, uUserId, mapHero);
        for( auto & tag : mapHero ) {
            *(msg.mutable_resp()->add_heros()) = tag.second;
        }
        if( !mapHero.empty() ) {
            pConnection->expire(strKey, TIME_REDIS_EXPIRE);
        }

        strKey = RedisKey::MakeUserWingKey(uUserId);
        map<int32, WingInfo> mapWing;
        MySQLProtoHelper::LoadAndInitWingInfo(pConnection, m_pSqlLink, strKey, uUserId, mapWing);
        for( auto & tag : mapWing ) {
            *(msg.mutable_resp()->add_wings()) = tag.second;
        }
        if( !mapWing.empty() ) {
            pConnection->expire(strKey, TIME_REDIS_EXPIRE);
        }

        strKey = RedisKey::MakeUserQuestKey(uUserId);
        map<int32, QuestInfo> mapQuest;
        MySQLProtoHelper::LoadAndInitQuestInfo(pConnection, m_pSqlLink, strKey, uUserId, mapQuest);
        for( auto & iq : mapQuest ) {
            *(msg.mutable_resp()->add_quests()) = iq.second;
        }
        if( !mapQuest.empty() ) {
            pConnection->expire(strKey, TIME_REDIS_EXPIRE);
        }

        strKey = RedisKey::MakeUserDay7Key(uUserId);
        map<int32, SevenDayInfo> mapDay7;
        MySQLProtoHelper::LoadAndInitSevenDayInfo(pConnection, m_pSqlLink, strKey, uUserId, mapDay7);
        for( auto & iq : mapDay7 ) {
            *(msg.mutable_resp()->add_sevendays()) = iq.second;
        }
        if( !mapDay7.empty() ) {
            pConnection->expire(strKey, TIME_REDIS_EXPIRE);
        }

        strKey = RedisKey::MakeUserGTaskKey(uUserId);
        map<int32, GeneralTaskInfo> mapGTask;
        MySQLProtoHelper::LoadAndInitGeneralTaskInfo(pConnection, m_pSqlLink, strKey, uUserId, mapGTask);
        for( auto & iq : mapGTask ) {
            *(msg.mutable_resp()->add_gtasks()) = iq.second;
        }
        if( !mapGTask.empty() ) {
            pConnection->expire(strKey, TIME_REDIS_EXPIRE);
        }

        strKey = RedisKey::MakeUserTurnTableKey(uUserId);
        map<int32, TurnTableInfo> mapTT;
        MySQLProtoHelper::LoadAndInitTurnTableInfo(pConnection, m_pSqlLink, strKey, uUserId, mapTT);
        for( auto & iq : mapTT ) {
            *(msg.mutable_resp()->add_tts()) = iq.second;
        }
        if( !mapTT.empty() ) {
            pConnection->expire(strKey, TIME_REDIS_EXPIRE);
        }

        strKey = RedisKey::MakeUserMarketKey(uUserId);
        map<int32, UserMarket> mapMarket;
        MySQLProtoHelper::LoadAndInitUserMarket(pConnection, m_pSqlLink, strKey, uUserId, mapMarket);
        for( auto & iq : mapMarket ) {
            *(msg.mutable_resp()->add_markets()) = iq.second;
        }
        if( !mapMarket.empty() ) {
            pConnection->expire(strKey, TIME_REDIS_EXPIRE);
        }

        strKey = RedisKey::MakeUserExchangeKey(uUserId);
        map<int64, UserExchangeData> mapExchange;
        MySQLProtoHelper::LoadAndInitUserExchangeData(pConnection, m_pSqlLink, strKey, uUserId, mapExchange);
        for( auto & iq : mapExchange ) {
            *(msg.add_exchanges()) = iq.second;
        }
        if( !mapExchange.empty() ) {
            pConnection->expire(strKey, TIME_REDIS_EXPIRE);
        }

        strKey = RedisKey::MakeUserBombActKey(uUserId);
        map<int32, BombActCardInfo> mapCards;
        MySQLProtoHelper::LoadAndInitBombActCardInfo(pConnection, m_pSqlLink, strKey, uUserId, mapCards);
        for( auto & ic : mapCards ) {
            *(msg.add_cards()) = ic.second;
        }
        if( !mapCards.empty() ) {
            pConnection->expire(strKey, TIME_REDIS_EXPIRE);
        }

        strKey = RedisKey::MakeUserTechKey(uUserId);
        map<int32, TechInfo> mapTech;
        MySQLProtoHelper::LoadAndInitTechInfo(pConnection, m_pSqlLink, strKey, uUserId, mapTech);
        for( auto & ic : mapTech ) {
            *(msg.mutable_resp()->add_techs()) = ic.second;
        }
        if( !mapTech.empty() ) {
            pConnection->expire(strKey, TIME_REDIS_EXPIRE);
        }

        strKey = RedisKey::MakeUserBuffKey(uUserId);
        map<int32, BuffInfo> mapBuff;
        MySQLProtoHelper::LoadAndInitBuffInfo(pConnection, m_pSqlLink, strKey, uUserId, mapBuff);
        for( auto & ic : mapBuff ) {
            *(msg.mutable_resp()->add_buffs()) = ic.second;
        }
        if( !mapBuff.empty() ) {
            pConnection->expire(strKey, TIME_REDIS_EXPIRE);
        }

        strKey = RedisKey::MakeUserTreasureKey(uUserId);
        map<int32, TreasureInfo> mapTreasure;
        MySQLProtoHelper::LoadAndInitTreasureInfo(pConnection, m_pSqlLink, strKey, uUserId, mapTreasure);
        for( auto & ic : mapTreasure ) {
            *(msg.mutable_resp()->add_treasures()) = ic.second;
        }
        if( !mapTreasure.empty() ) {
            pConnection->expire(strKey, TIME_REDIS_EXPIRE);
        }

        strKey = RedisKey::MakeUserCounterKey(uUserId);
        map<int32, DayCounterInfo> mapCounter;
        MySQLProtoHelper::LoadAndInitDayCounterInfo(pConnection, m_pSqlLink, strKey, uUserId, mapCounter);
        for( auto & ic : mapCounter ) {
            *(msg.add_counters()) = ic.second;
        }
        if( !mapCounter.empty() ) {
            pConnection->expire(strKey, TIME_REDIS_EXPIRE);
        }

        strKey = RedisKey::MakeUserFriendKey(uUserId);
        map<uint64, TargetInfo> mapFriend;
        MySQLProtoHelper::LoadAndInitTargetInfo(pConnection, m_pSqlLink, strKey, uUserId, mapFriend);
        for( auto & ic : mapFriend ) {
            *(msg.mutable_resp()->add_friends()) = ic.second;
        }
        if( !mapFriend.empty() ) {
            pConnection->expire(strKey, TIME_REDIS_EXPIRE);
        }

        // 黑名单不保存db
        strKey = RedisKey::MakeUserBlockKey(uUserId);
        map<uint64, TargetInfo> mapBlock;
        RedisProtoHelper::RedisLoadTargetInfo(pConnection, strKey, mapBlock);
        for( auto & ic : mapBlock ) {
            *(msg.mutable_resp()->add_blocks()) = ic.second;
        }
        if( !mapBlock.empty() ) {
            pConnection->expire(strKey, TIME_REDIS_EXPIRE);
        }

        strKey = RedisKey::MakeUserFrozensKey(uUserId);
        map<int64, FrozenAssets> mapFrozens;
        MySQLProtoHelper::LoadAndInitFrozenAssets(pConnection, m_pSqlLink, strKey, uUserId, mapFrozens);
        for( auto & ic : mapFrozens ) {
            *(msg.mutable_resp()->add_frozens()) = ic.second;
        }
        if( !mapFrozens.empty() ) {
            pConnection->expire(strKey, TIME_REDIS_EXPIRE);
        }

        strKey = RedisKey::MakeUserGiftCounterKey(uUserId);
        map<int32, ItemPair> mapGCounter;
        MySQLProtoHelper::LoadAndInitItemPair(pConnection, m_pSqlLink, strKey, uUserId, mapGCounter);
        for( auto & ic : mapGCounter ) {
            *(msg.mutable_resp()->add_gcounter()) = ic.second;
        }
        if( !mapGCounter.empty() ) {
            pConnection->expire(strKey, TIME_REDIS_EXPIRE);
        }

        strKey = RedisKey::MakeUserHuntBossInfoKey(uUserId);
        map<int64, HuntBossSimple> mapHunts;
        MySQLProtoHelper::LoadAndInitHuntBossSimple(pConnection, m_pSqlLink, strKey, uUserId, mapHunts);
        for( auto & ic : mapHunts ) {
            *(msg.mutable_resp()->add_hunts()) = ic.second;
        }
        if( !mapHunts.empty() ) {
            pConnection->expire(strKey, TIME_REDIS_EXPIRE);
        }

        strKey = RedisKey::MakeUserBossInfoKey(uUserId);
        map<int32, BossInfo> mapBoss;
        MySQLProtoHelper::LoadAndInitBossInfo(pConnection, m_pSqlLink, strKey, uUserId, mapBoss);
        for( auto & ic : mapBoss ) {
            *(msg.add_boss()) = ic.second;
        }
        if( !mapBoss.empty() ) {
            pConnection->expire(strKey, TIME_REDIS_EXPIRE);
        }

        // 服务器客户端版本控制机制:
        // 每个渠道在服务器有不同的版本号 通过GM后台在redis中设置, {key = gm:server::[CHANNEL] value=1.0.1
        // 每个渠道的客户端在登录时发送 client_version和 channel到服务器
        // 服务器通过对应的渠道和版本号做以下判定
        // 如果 客户端版本号 > 服务器对应渠道版本号 所有系统开关使用SystemEntrance的本地配置
        // 反之, 服务器读取 gm:channel:[CHANNEL]对应的系统开关发送给客户端
        // 在客户端发版本时: 如当前版本为1.0.0
        // 1. 生成一个1.0.1对应的热更版本, 在发布后台设置资源版本号为1.0.1, 同时设置服务器版本号为1.0.1
        // 2. 生成一个1.0.2的完整包, 作为提审包, 提交审核
        // 3. 审核通过后,在发布后台设置服务器版本号为1.0.2
        string strVersion;
        string strPlatformId = JDATA->ChannelConfigPtr()->PlatformIdByChannel(request.channel());
        string strEntranceId = JDATA->ChannelConfigPtr()->SystemEntranceByChannel(request.channel());
        if( !pConnection->get(RedisKey::MakeChannelVersionKey(strPlatformId), strVersion) ) {
            strVersion = "1.0.0";
        }
        if( GlobalUtils::VersionCompare(request.client_version(), strVersion) == 1 ) {
            msg.mutable_resp()->set_use_local(1);
        }
        else {
            msg.mutable_resp()->set_use_local(0);
            vector<string> vecSys;
            pConnection->smembers(RedisKey::MakeChannelKey(strEntranceId), vecSys);
            for( size_t i = 0; i < vecSys.size(); i++ ) {
                msg.mutable_resp()->add_system_id(vecSys[i]);
            }
        }

        strKey = RedisKey::MakeUserDrawRmbKey(uUserId);
        map<int32, DrawRmbInfo> mapDraw;
        MySQLProtoHelper::LoadAndInitDrawRmbInfo(pConnection, m_pSqlLink, strKey, uUserId, mapDraw);
        for( auto & draw : mapDraw ) {
            *msg.add_draws() = draw.second;
        }
        if( !mapDraw.empty() ) {
            pConnection->expire(strKey, TIME_REDIS_EXPIRE);
        }
    }
    *(msg.mutable_resp()->mutable_user_info()) = playerInfo;

    LxGameHelper::MakeLxUserOnline(onlinePacket, msg);
    sDispatcher->dispatch(onlinePacket);
    return JDATA->ErrorCodePtr()->GetSuccess();
}

int32 ThreadData::DoRegister(RedisConnection* pConnection, UserLoginReq& request, UserInfo& basicInfo) {
    uint64 uUserId = RedisData::GetUserIdByOpenId(request.account(), pConnection);
    if( uUserId == 0 ) {
        uUserId = RedisData::GenerateUserId(pConnection);
        RedisData::SetUserIdWithOpenId(request.account(), uUserId, pConnection);
    }
    if( uUserId == 0 ) {
		LOGERROR("redis generate id failed");
		return JDATA->ErrorCodePtr()->GetLoginGenUserIdFailed();
    }
    string strNickName = sGameUtils->GetRandName();
    strNickName = boost::algorithm::replace_all_copy(strNickName,"'"," ");
    strNickName = GlobalUtils::GetLimitNickName(strNickName);
    strNickName = strNickName + GlobalUtils::ToString(uUserId % 10000);

    int64 tNow = sGameUtils->GetFakeTimeNow();
    std::ostringstream ostrInsertTable;
    RedisProtoHelper::UserInfoInit(basicInfo);
    basicInfo.set_user_open_id(request.account());
    basicInfo.set_user_fbid(request.tpacc());
    basicInfo.set_user_id(uUserId);
    basicInfo.set_user_name(strNickName);
    basicInfo.set_user_gender(1);
    basicInfo.set_user_level(1);
    basicInfo.set_user_portrait(JDATA->SystemConstPtr()->GetInitialHeadIcon());
    basicInfo.set_user_frame(JDATA->SystemConstPtr()->GetInitialHeadFrame());
    basicInfo.set_user_property(JDATA->SystemConstPtr()->GetInitialPropertyBG());
    basicInfo.set_popularity(JDATA->SystemConstPtr()->GetSendGiftsNeedPopularity());
    basicInfo.set_time_register(tNow);
    basicInfo.set_client_version(request.client_version());
    basicInfo.set_client_channel(request.channel());
    basicInfo.set_battle_pass_vip_now(-1);  // 通行证未开启时,设置为-1
    basicInfo.set_passport_vip_now(-1);
    basicInfo.set_user_growth_fund_version(1);
    //
    if( pConnection->exists("pponly") || (pConnection->exists("ppab") && uUserId % 2 == 0) ) {
        basicInfo.set_passport_id(JDATA->SystemConstPtr()->GetPeriodPassID());
        basicInfo.set_passport_expire(tNow + JDATA->PeriodPassControlPtr()->LastingTimeByID(basicInfo.passport_id()));
    }

    basicInfo.set_user_cur_energy(JDATA->SystemConstPtr()->GetInitialEnergyMax());
    basicInfo.set_user_energy_time(tNow);
    basicInfo.set_need_newbie_gift(1);

    if( !MySQLProtoHelper::MySqlUserInfoInit(m_pSqlLink, uUserId, basicInfo) ) {
        LOGERROR("create user failed![%lu]", uUserId);
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    if( !RedisProtoHelper::RedisInitUserInfo(pConnection, RedisKey::MakeUserKey(uUserId), basicInfo)) {
        LOGERROR("create user to redis failed![%lu]", uUserId);
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    return JDATA->ErrorCodePtr()->GetSuccess();
}

// 根据登录类型，token，查找或新建用户 返回用户userid所在的库表索引
int32 ThreadData::QueryUserInfoWithRegister(RedisConnection* pConnection, UserLoginReq& request, UserInfo& playerInfo) {
    string strLoginToken = request.token();
    uint64 uUserId = RedisData::GetUserIdByOpenId(strLoginToken, pConnection);
    if( uUserId == 0 ) {
        // redis没找到openid和userid的对照
        OpenidToUserid data;
        int32 ret = MySQLProtoHelper::MySqlOpenidToUseridLoad(m_pSqlLink, strLoginToken, data);
        if( ret == ENUM_DBOP_RTNCODE_SUCCESS ) {
            // 找到userid了
            uUserId = data.userid();
        }
        else if(ret == ENUM_DBOP_RTNCODE_RESULTNOTFOUND) {
            // redis和db都没找到,就去新建账号
            ret = DoRegister(pConnection, request, playerInfo);
            if( ret == JDATA->ErrorCodePtr()->GetSuccess() ) {
                data.set_openid(strLoginToken);
                data.set_userid(playerInfo.user_id());
                if( !MySQLProtoHelper::MySqlOpenidToUseridInit(m_pSqlLink, strLoginToken, data) ) {
                    LOGERROR("mysql save openid-userid failed");
                    return JDATA->ErrorCodePtr()->GetSystemError();
                }
            }
            return ret;
        }
        else {
            // mysql db failed
            return JDATA->ErrorCodePtr()->GetSystemError();
        }
    }
    // 老账号
    if( RedisData::HasUser(uUserId, pConnection) ) {
        if( !RedisProtoHelper::RedisLoadUserInfo(pConnection, RedisKey::MakeUserKey(uUserId), playerInfo) ) {
            LOGERROR("redis load old user failed![%lu]", uUserId);
            return JDATA->ErrorCodePtr()->GetSystemError();
        }
        if( uUserId != playerInfo.user_id() ) {
            LOGERROR("redis saved without mysql save");
            return JDATA->ErrorCodePtr()->GetSystemError();
        }
    }
    else {
        if( MySQLProtoHelper::MySqlUserInfoLoad(m_pSqlLink, uUserId, playerInfo) != ENUM_DBOP_RTNCODE_SUCCESS ) {
            LOGERROR("mysql load old user failed![%lu]", uUserId);
            return JDATA->ErrorCodePtr()->GetSystemError();
        }
        RedisProtoHelper::RedisInitUserInfo(pConnection, RedisKey::MakeUserKey(uUserId), playerInfo);
    }
    return JDATA->ErrorCodePtr()->GetSuccess();
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void ThreadData::ProcessLxSaveData(WrapPacket& packet) {
    // 保存相关数据 道具-炮台-属性-邮件
    LxSaveData data;
	if (!data.ParseFromString(packet.data())) {
		LOGERROR("parse failed");
		return;
	}
    FETCH_VOID();
    uint64 uUserId = packet.userid();
    map<string, string> mapValue;
    for( int32 i = 0 ; i < data.fields_size() ; ++i ) {
        auto field = data.fields(i);
        mapValue[field.field()] = field.value();
        if( field.field() == "time_offline" && field.value() != "0" ) {
            LOGINFO("user[%lu] logout ", uUserId);
            // 这里检测是否有offline字段, 如果是offline, 则清除 USER_LOGIN_LOCK
            SeverIdAndLinkId tag;
            if( pConnection->get(RedisKey::MakeUserLoginLockKey(uUserId), tag._data) ) {
                if( tag._serverId == sGameUtils->GetServerId() && tag._linkId == (int32)packet.connectionid() ) {
                    LOGINFO("user[%lu]server[%d]link[%d] offline, remove login lock", uUserId, tag._serverId, tag._linkId);
                    pConnection->del(RedisKey::MakeUserLoginLockKey(uUserId));
                }
                else {
                    //
                    LOGINFO("user[%lu]server[%d]link[%d] keep login lock server[%d]link[%d]",
                        uUserId, sGameUtils->GetServerId(), packet.connectionid(), tag._serverId, tag._linkId);
                }
            }
            else {
                LOGINFO("user[%lu]server[%d]link[%d] lost login lock", uUserId, sGameUtils->GetServerId(), packet.connectionid());
            }
        }
    }
    string strHashKey = RedisKey::MakeUserKey(uUserId);
    // 用户属性更新
    if( !mapValue.empty() ) {
        RedisProtoHelper::RedisSaveUserInfoFields(pConnection, strHashKey, mapValue);
        MySQLProtoHelper::MySqlUserInfoUpdate(m_pSqlLink, uUserId, mapValue);
        pConnection->expire(strHashKey, TIME_REDIS_EXPIRE);
    }

    // 道具更新和删除
    strHashKey = RedisKey::MakeUserItemKey(uUserId);
    for( int32 i = 0 ; i < data.items_size() ; ++i ) {
        auto item = data.items(i);
    	string strSubKey = GlobalUtils::ToString(item.item_id());
        RedisProtoHelper::RedisSaveHSET(pConnection, strHashKey, strSubKey, item);
        MySQLProtoHelper::MySqlItemPairInsertOnUpdate(m_pSqlLink, uUserId, item);
    }
    for( int32 i = 0 ; i < data.del_items_size() ; ++i ) {
    	string strSubKey = GlobalUtils::ToString(data.del_items(i));
        pConnection->hdel(strHashKey, strSubKey);
        MySQLProtoHelper::MySqlItemPairDelete(m_pSqlLink, uUserId, data.del_items(i));
    }

    // 炮台更新
   	strHashKey = RedisKey::MakeUserHeroKey(uUserId);
    for( int32 i = 0 ; i < data.heros_size() ; ++i ) {
        auto tag = data.heros(i);
    	string strSubKey = GlobalUtils::ToString(tag.hero_index());
        RedisProtoHelper::RedisSaveHSET(pConnection, strHashKey, strSubKey, tag);
        MySQLProtoHelper::MySqlHeroInfoInsertOnUpdate(m_pSqlLink, uUserId, tag);
    }

   	strHashKey = RedisKey::MakeUserWingKey(uUserId);
    // 翅膀更新
    for( int32 i = 0 ; i < data.wings_size() ; ++i ) {
        auto tag = data.wings(i);
    	string strSubKey = GlobalUtils::ToString(tag.wing_index());
        RedisProtoHelper::RedisSaveHSET(pConnection, strHashKey, strSubKey, tag);
        MySQLProtoHelper::MySqlWingInfoInsertOnUpdate(m_pSqlLink, uUserId, tag);
    }

    strHashKey = RedisKey::MakeUserMailKey(uUserId);
    // 邮件更新和删除
    for( int32 i = 0 ; i < data.mails_size() ; ++i ) {
        auto mail = data.mails(i);
    	string strSubKey = GlobalUtils::ToString(mail.mail_id());
        RedisProtoHelper::RedisSaveHSET(pConnection, strHashKey, strSubKey, mail);
        MySQLProtoHelper::MySqlLxMailInsertOnUpdate(m_pSqlLink, uUserId, mail);
    }
    for( int32 i = 0 ; i < data.del_mails_size() ; ++i ) {
    	string strSubKey = GlobalUtils::ToString(data.del_mails(i));
        pConnection->hdel(strHashKey, strSubKey);
        MySQLProtoHelper::MySqlLxMailDelete(m_pSqlLink, uUserId, data.del_mails(i));
    }

    strHashKey = RedisKey::MakeUserQuestKey(uUserId);
    // 任务更新和删除
    for( int32 i = 0 ; i < data.quests_size() ; ++i ) {
        auto quest = data.quests(i);
    	string strSubKey = GlobalUtils::ToString(quest.quest_id());
        RedisProtoHelper::RedisSaveHSET(pConnection, strHashKey, strSubKey, quest);
        MySQLProtoHelper::MySqlQuestInfoInsertOnUpdate(m_pSqlLink, uUserId, quest);
    }
    for( int32 i = 0 ; i < data.del_quests_size() ; ++i ) {
    	string strSubKey = GlobalUtils::ToString(data.del_quests(i));
        pConnection->hdel(strHashKey, strSubKey);
        MySQLProtoHelper::MySqlQuestInfoDelete(m_pSqlLink, uUserId, data.del_quests(i));
    }

    strHashKey = RedisKey::MakeUserDay7Key(uUserId);
    // 七日任务更新
    for( int32 i = 0 ; i < data.sevendays_size() ; ++i ) {
        auto quest = data.sevendays(i);
    	string strSubKey = GlobalUtils::ToString(quest.quest_id());
        RedisProtoHelper::RedisSaveHSET(pConnection, strHashKey, strSubKey, quest);
        MySQLProtoHelper::MySqlSevenDayInfoInsertOnUpdate(m_pSqlLink, uUserId, quest);
    }

    strHashKey = RedisKey::MakeUserGTaskKey(uUserId);
    // 通用任务更新
    for( int32 i = 0 ; i < data.gtasks_size() ; ++i ) {
        auto task = data.gtasks(i);
    	string strSubKey = GlobalUtils::ToString(task.task_id());
        RedisProtoHelper::RedisSaveHSET(pConnection, strHashKey, strSubKey, task);
        MySQLProtoHelper::MySqlGeneralTaskInfoInsertOnUpdate(m_pSqlLink, uUserId, task);
    }
    for( int32 i = 0 ; i < data.del_gtasks_size() ; ++i ) {
    	string strSubKey = GlobalUtils::ToString(data.del_gtasks(i));
        pConnection->hdel(strHashKey, strSubKey);
        MySQLProtoHelper::MySqlGeneralTaskInfoDelete(m_pSqlLink, uUserId, data.del_gtasks(i));
    }

    strHashKey = RedisKey::MakeUserTurnTableKey(uUserId);
    // 转盘数据
    for( int32 i = 0 ; i < data.tts_size() ; ++i ) {
        auto tt = data.tts(i);
    	string strSubKey = GlobalUtils::ToString(tt.tt_id());
        RedisProtoHelper::RedisSaveHSET(pConnection, strHashKey, strSubKey, tt);
        MySQLProtoHelper::MySqlTurnTableInfoInsertOnUpdate(m_pSqlLink, uUserId, tt);
    }

    strHashKey = RedisKey::MakeUserChargeKey(uUserId);
    // 充值商品新增
    for( int32 i = 0 ; i < data.products_size() ; ++i ) {
        RedisProtoHelper::RedisSaveUserChargeDataToList(pConnection, strHashKey, data.products(i));
        MySQLProtoHelper::MySqlUserChargeDataInsert(m_pSqlLink, uUserId, data.products(i));
    }

    strHashKey = RedisKey::MakeUserBombGameKey(uUserId);
    // 核弹场抽卡中奖新增
    for( int32 i = 0 ; i < data.bomb_rewards_size() ; ++i ) {
        RedisProtoHelper::RedisSaveBombGameRecordToList(pConnection, strHashKey, data.bomb_rewards(i));
    }
    RedisData::ShrinkListUsingRPop(pConnection, strHashKey, 50);

    strHashKey = RedisKey::MakeUserMarketKey(uUserId);
    // 个人黑店数据更新
    for( int32 i = 0 ; i < data.markets_size() ; ++i ) {
        auto row = data.markets(i);
    	string strSubKey = GlobalUtils::ToString(row.product_id());
        RedisProtoHelper::RedisSaveHSET(pConnection, strHashKey, strSubKey, row);
        MySQLProtoHelper::MySqlUserMarketInsertOnUpdate(m_pSqlLink, uUserId, row);
    }
    for( int32 i = 0 ; i < data.del_markets_size() ; ++i ) {
    	string strSubKey = GlobalUtils::ToString(data.del_markets(i));
        pConnection->hdel(strHashKey, strSubKey);
        MySQLProtoHelper::MySqlUserMarketDelete(m_pSqlLink, uUserId, data.del_markets(i));
    }

  	strHashKey = RedisKey::MakeUserExchangeKey(uUserId);
    // 用户兑换数据
    for( int32 i = 0 ; i < data.exchanges_size() ; ++i ) {
        auto row = data.exchanges(i);
    	string strSubKey = GlobalUtils::ToString(row.guid());
        RedisProtoHelper::RedisSaveHSET(pConnection, strHashKey, strSubKey, row);
        MySQLProtoHelper::MySqlUserExchangeDataInsertOnUpdate(m_pSqlLink, uUserId, row);
    }

    strHashKey = RedisKey::MakeUserDrawRmbKey(uUserId);
    // 兑换券抽话费活动数据更新
    for( int32 i = 0 ; i < data.draws_size() ; ++i ) {
        auto act = data.draws(i);
    	string strSubKey = GlobalUtils::ToString(act.act_id());
        RedisProtoHelper::RedisSaveHSET(pConnection, strHashKey, strSubKey, act);
        MySQLProtoHelper::MySqlDrawRmbInfoInsertOnUpdate(m_pSqlLink, uUserId, act);
    }

    strHashKey = RedisKey::MakeUserBombActKey(uUserId);
    for( int32 i = 0; i < data.cards_size() ; ++i ) {
        auto card = data.cards(i);
        string strSubKey = GlobalUtils::ToString(card.pos());
        RedisProtoHelper::RedisSaveHSET(pConnection, strHashKey, strSubKey, card);
        MySQLProtoHelper::MySqlBombActCardInfoInsertOnUpdate(m_pSqlLink, uUserId, card);
    }

    strHashKey = RedisKey::MakeUserTechKey(uUserId);
    for( int32 i = 0; i < data.techs_size() ; ++i ) {
        auto tech = data.techs(i);
        string strSubKey = GlobalUtils::ToString(tech.tech_id());
        RedisProtoHelper::RedisSaveHSET(pConnection, strHashKey, strSubKey, tech);
        MySQLProtoHelper::MySqlTechInfoInsertOnUpdate(m_pSqlLink, uUserId, tech);
    }

    strHashKey = RedisKey::MakeUserBuffKey(uUserId);
    for( int32 i = 0; i < data.buffs_size() ; ++i ) {
        auto buff = data.buffs(i);
        string strSubKey = GlobalUtils::ToString(buff.buff_id());
        RedisProtoHelper::RedisSaveHSET(pConnection, strHashKey, strSubKey, buff);
        MySQLProtoHelper::MySqlBuffInfoInsertOnUpdate(m_pSqlLink, uUserId, buff);
    }

    strHashKey = RedisKey::MakeUserTreasureKey(uUserId);
    for( int32 i = 0; i < data.treasures_size() ; ++i ) {
        auto tag = data.treasures(i);
        string strSubKey = GlobalUtils::ToString(tag.pos());
        RedisProtoHelper::RedisSaveHSET(pConnection, strHashKey, strSubKey, tag);
        MySQLProtoHelper::MySqlTreasureInfoInsertOnUpdate(m_pSqlLink, uUserId, tag);
    }

    strHashKey = RedisKey::MakeUserCounterKey(uUserId);
    for( int32 i = 0; i < data.counters_size() ; ++i ) {
        auto tag = data.counters(i);
        string strSubKey = GlobalUtils::ToString(tag.type());
        RedisProtoHelper::RedisSaveHSET(pConnection, strHashKey, strSubKey, tag);
        MySQLProtoHelper::MySqlDayCounterInfoInsertOnUpdate(m_pSqlLink, uUserId, tag);
    }

    strHashKey = RedisKey::MakeUserFriendKey(uUserId);
    for( int32 i = 0 ; i < data.friends_size() ; ++i ) {
        auto row = data.friends(i);
    	string strSubKey = GlobalUtils::ToString(row.t_id());
        RedisProtoHelper::RedisSaveHSET(pConnection, strHashKey, strSubKey, row);
        MySQLProtoHelper::MySqlTargetInfoInsertOnUpdate(m_pSqlLink, uUserId, row);
    }
    for( int32 i = 0 ; i < data.del_friends_size() ; ++i ) {
    	string strSubKey = GlobalUtils::ToString(data.del_friends(i));
        pConnection->hdel(strHashKey, strSubKey);
        MySQLProtoHelper::MySqlTargetInfoDelete(m_pSqlLink, uUserId, data.del_friends(i));
    }

    strHashKey = RedisKey::MakeUserBlockKey(uUserId);
    for( int32 i = 0 ; i < data.blocks_size() ; ++i ) {
        auto row = data.blocks(i);
    	string strSubKey = GlobalUtils::ToString(row.t_id());
        RedisProtoHelper::RedisSaveHSET(pConnection, strHashKey, strSubKey, row);
    }
    for( int32 i = 0 ; i < data.del_blocks_size() ; ++i ) {
    	string strSubKey = GlobalUtils::ToString(data.del_blocks(i));
        pConnection->hdel(strHashKey, strSubKey);
    }

    strHashKey = RedisKey::MakeUserFrozensKey(uUserId);
    for( int32 i = 0 ; i < data.frozens_size() ; ++i ) {
        auto row = data.frozens(i);
    	string strSubKey = GlobalUtils::ToString(row.asset_id());
        RedisProtoHelper::RedisSaveHSET(pConnection, strHashKey, strSubKey, row);
    }
    for( int32 i = 0 ; i < data.del_frozens_size() ; ++i ) {
    	string strSubKey = GlobalUtils::ToString(data.del_frozens(i));
        pConnection->hdel(strHashKey, strSubKey);
    }

    strHashKey = RedisKey::MakeUserGiftCounterKey(uUserId);
    for( int32 i = 0 ; i < data.gcounter_size() ; ++i ) {
        auto row = data.gcounter(i);
    	string strSubKey = GlobalUtils::ToString(row.item_id());
        RedisProtoHelper::RedisSaveHSET(pConnection, strHashKey, strSubKey, row);
    }

    strHashKey = RedisKey::MakeUserHuntBossInfoKey(uUserId);
    for( int32 i = 0 ; i < data.hunts_size() ; ++i ) {
        auto row = data.hunts(i);
    	string strSubKey = GlobalUtils::ToString(row.bossid());
        RedisProtoHelper::RedisSaveHSET(pConnection, strHashKey, strSubKey, row);
    }
    for( int32 i = 0 ; i < data.del_hunts_size() ; ++i ) {
    	string strSubKey = GlobalUtils::ToString(data.del_hunts(i));
        pConnection->hdel(strHashKey, strSubKey);
        MySQLProtoHelper::MySqlHuntBossSimpleDelete(m_pSqlLink, uUserId, data.del_hunts(i));
    }


    strHashKey = RedisKey::MakeUserBossInfoKey(uUserId);
    for( int32 i = 0 ; i < data.boss_size() ; ++i ) {
        auto row = data.boss(i);
    	string strSubKey = GlobalUtils::ToString(row.boss_id());
        RedisProtoHelper::RedisSaveHSET(pConnection, strHashKey, strSubKey, row);
    }
}
