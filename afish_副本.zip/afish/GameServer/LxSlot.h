/**
 * 抽奖类模版
 */

#pragma once

#include <string>
#include <sstream>
#include <map>
#include <set>
#include <vector>
using namespace std;

#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string.hpp>

#include <google/protobuf/stubs/common.h>
using namespace google::protobuf;

#include "ServerDefine.h"
#include "DataCache/RedisData.h"

// 单条进度
struct tagSlotBar {
    int32 _idx;
    float _rate;        // 每次push时取的比例
    int64 _cur;         // 当前值
    int64 _trigger;     // 触发值
    int64 _poolStake;   // 抽中时返还的奖励要去扣除奖池对应的stake数量
    int64 _reward;      // 奖励(每个类型的奖励不同)
    tagSlotBar() {
        _idx = 0;
        _rate = 0;
        _cur = 0;
        _trigger = 0;
        _poolStake = 0;
        _reward = 0;
    }
    tagSlotBar& operator=(const tagSlotBar& rhs) {
        _idx = rhs._idx;
        _rate = rhs._rate;
        _cur = rhs._cur;
        _trigger = rhs._trigger;
        _poolStake = rhs._poolStake;
        _reward = rhs._reward;
        return *this;
    }
};

// 单条抽奖规则
// _poolRate > 0
//      _poolStake <= 0 触发_cells.back()对应的奖励
//      _poolStake > 0 顺序遍历 _bars 判定对应的触发奖励
//      _curPool在gamble时按 stake*_poolRate/1000来增加
// _poolRate <= 0
//      _curPool规则不生效, 按顺序遍历 _bars 判定对应的触发奖励
struct tagSlotRule {
    int32 _id;
    int32 _poolRate;    // 赌注按比例放入到总奖池中, 如果为0, 表示无总奖池控制, >0时, 如果奖池<0, 则取_rule的最后一个奖励,
    int64 _poolStake;   // 当前奖池累计值
    vector<tagSlotBar> _bars;
    tagSlotRule() {
    }
    tagSlotRule& operator=(const tagSlotRule& rhs) {
        _id = rhs._id;
        _poolRate = rhs._poolRate;
        _poolStake = rhs._poolStake;
        _bars = rhs._bars;
        return *this;
    }

    void init(tagJsonSlotDraw* ptr, RedisConnection* pConnection) {
        _id = ptr->_ID;
        _poolRate = ptr->_BetTrigger[2];
        _poolStake = RedisData::GetSlotPoolData(pConnection, sGameUtils->GetServerId(), _id);
        _bars.clear();
        for( size_t i = 0; i < ptr->_Reward.size(); i+=4 ) {
            tagSlotBar bar;
            bar._idx = i/4;
            bar._rate = ptr->_Reward[i+1]/1000.0f;
            bar._cur = RedisData::GetSlotBarData(pConnection, sGameUtils->GetServerId(), _id, bar._idx);
            bar._trigger = ptr->_Reward[i];
            bar._poolStake = ptr->_Reward[i+2];
            bar._reward = ptr->_Reward[i+3];
            _bars.insert(_bars.begin(), bar);
        }
    }
    int64 roll(bool minReward, RedisConnection* pConnection) {
        int64 reward = 0;
        int64 poolStake = 0;
        if( minReward ) {
            int32 idxLast = _bars.size()-1;
            _bars[idxLast]._cur = 0;
            RedisData::SetSlotBarData(pConnection, sGameUtils->GetServerId(), _id, _bars[idxLast]._idx, _bars[idxLast]._cur);
            poolStake = _bars[idxLast]._poolStake;
            reward = _bars[idxLast]._reward;
        }
        else {
            // 无奖池控制 或者当前奖池够扣除
            for( size_t i = 0 ; i < _bars.size(); ++i ) {
                if( _bars[i]._cur >= _bars[i]._trigger ) {
                    // 触发了
                    _bars[i]._cur = 0;
                    poolStake = _bars[i]._poolStake;
                    reward = _bars[i]._reward;
                    RedisData::SetSlotBarData(pConnection, sGameUtils->GetServerId(), _id, _bars[i]._idx, _bars[i]._cur);
                    break;
                }
            }
        }
        if( _poolRate > 0 ) {
            _poolStake -= poolStake;
            RedisData::SetSlotPoolData(pConnection, sGameUtils->GetServerId(), _id, _poolStake);
        }
        return reward;
    }
    int64 gamble(int64 stake, RedisConnection* pConnection) {
        if( _poolRate > 0 ) {
            // 需要判定奖池规则
            _poolStake = stake * _poolRate/1000;
        }
        // 进度条全部更新
        for( size_t i = 0 ; i < _bars.size(); ++i ) {
            _bars[i]._cur += stake*_bars[i]._rate;
            RedisData::SetSlotBarData(pConnection, sGameUtils->GetServerId(), _id, _bars[i]._idx, _bars[i]._cur);
        }
        if( _poolRate > 0 ) {
            // 启用奖池控制
            if( _poolStake <= 0 ) {
                // 当前奖池累计数<0, 只会中最后一条
                return roll(true, pConnection);
            }
        }
        return roll(false, pConnection);
    }
};

// 捕鱼奖池抽奖
class LxSlotDrawFish {
    struct tagSlotDrawFishRule {
        int32 _maxNum;  // 数量触发点
        int64 _maxStake; // 赌注触发点
        tagSlotRule _rule;  // 单条单个奖池
        tagSlotDrawFishRule() {}
        tagSlotDrawFishRule& operator=(const tagSlotDrawFishRule& rhs) {
            _maxNum = rhs._maxNum;
            _maxStake = rhs._maxStake;
            _rule = rhs._rule;
            return *this;
        }
    };
public:
    LxSlotDrawFish() {}
    ~LxSlotDrawFish() {}
public:
    void init(RedisConnection* pConnection) {
        list<tagSlotDrawFishRule> lst;
        JDATA->SlotDrawPtr()->ForEach([&](tagJsonSlotDraw* ptr){
            if( ptr->_Type == e_jsonSlotDrawType_FishPool
                && ptr->_BetTrigger.size() == 3
                && ptr->_Reward.size() > 0
                && ptr->_Reward.size() % 4 == 0) {
                tagSlotDrawFishRule rule;
                rule._maxNum = ptr->_BetTrigger[0];
                rule._maxStake = ptr->_BetTrigger[1];
                rule._rule.init(ptr, pConnection);
                lst.push_front(rule);   // 表内数据按从小到大排列, 因此遍历时按正常遍历
            }
        });
        writeLock wl(_mutex);
        _rules.swap(lst);
    }
    //  返回用户奖励数值
    int64 gamble(int32 curNum, int64 curStake) {
        FETCH_RETURN(0);
        writeLock wl(_mutex);
        for( auto& rule : _rules ) {
            if( curNum >= rule._maxNum && curStake >= rule._maxStake ) {
                // 触发了
                return rule._rule.gamble(curStake, pConnection);
            }
        }
        return 0;
    }
private:
    boost::shared_mutex _mutex;
    list<tagSlotDrawFishRule> _rules;
};

#define sHSDFish Singleton<LxSlotDrawFish>::Instance()
