/**
 * 聊天模块
*/
#include "ChatThread.h"
#include "RedisManager/RedisManager.h"
#include "DataCache/ProtoCmdHelper.h"
#include "DataCache/RedisData.h"
#include "Include/RedisProtoHelper.h"
#include "LxGameLogHelper.h"
#include "HelperChat/HelperChat.h"
#include "../ChatServer.h"

ChatThread::ChatThread(boost::asio::io_service& io)
    : _io_service(io), _timer(io)
{
    m_pHelperChat = new HelperChat();
    _timer.expires_from_now(boost::posix_time::seconds(1));
    _timer.async_wait(boost::bind(&ChatThread::Start, this, boost::asio::placeholders::error));
}

ChatThread::~ChatThread() {
}

void ChatThread::Start(const boost::system::error_code& error) {
    _timer.cancel();
    bool inited = false;
    while( true ) {
        RedisConnectionIdGetter idGetter(enumRedisServerTypeData);
        auto pConnection = idGetter.GetConnection();
        if( pConnection == nullptr ) {
            sleep(1);
            continue;
        }
        if( !inited ) {
            m_pHelperChat->Load(pConnection);
            inited = true;
        }

        std::vector<r3c::StreamEntry> vecData;
        pConnection->xread(SYS_CHANNEL_CHAT_KEY, 100, 5000, vecData);
        vector<string> ids;
        for( size_t i = 0; i < vecData.size() ; ++i ) {
            auto ptr = &vecData[i];
            ids.push_back(ptr->id);
            for( size_t j = 0 ; j < ptr->fvpairs.size() ; ++j ) {
                ChatChannelCmd cmd;
                if( JsonProto::ProtoFromJson(ptr->fvpairs[j].value, cmd) ) {
                    ProcessMessage(pConnection, cmd);
                }
            }
        }
        if( !ids.empty() ) {
            pConnection->xdel(SYS_CHANNEL_CHAT_KEY, ids);
        }
    }
}

#define CMDCASE(name) case CHAT_##name: { Process##name(pConnection, req); break; }
void ChatThread::ProcessMessage(RedisConnection* pConnection, const ChatChannelCmd& req) {
    switch( req.cmd() ) {
    CMDCASE(MsgInfoReq);
    CMDCASE(ChatReq);
    CMDCASE(ChatGroupCreateReq);
    CMDCASE(ChatGroupRenameReq);
    CMDCASE(ChatGroupResetPwdReq);
    CMDCASE(ChatGroupInviteReq);
    CMDCASE(ChatGroupAcceptInviteReq);
    CMDCASE(ChatGroupSearchReq);
    CMDCASE(ChatGroupJoinReq);
    CMDCASE(ChatGroupQuitReq);
    CMDCASE(ChatGroupDismissReq);
    CMDCASE(ChatGroupKickReq);
    CMDCASE(ChatGroupClearChatReq);
    CMDCASE(ChatGroupListReq);
    CMDCASE(LxChatForGiftStatus);
    default:
        LOGERROR("unknown chat thread cmd[%lu]", req.cmd());
        break;
    }
}

/////////////////////////////////////////////////////////////////////////////////////////////
void ChatThread::ProcessMsgInfoReq(RedisConnection* pConnection, const ChatChannelCmd& req) {
    UserProtoCmd cmd;
    cmd.set_cmd(CHAT_MsgInfoResp);
    cmd.set_requestid(req.requestid());
    auto resp = cmd.mutable_msg_info_resp();
    for( int32 i = 0 ; i < req.msg_info_req().mids_size() ; ++i ) {
        MsgInfo tag;
        if( m_pHelperChat->GetMsgInfo(req.msg_info_req().mids(i), tag) ) {
            *resp->add_msgs() = tag;
        }
    }
    ProtoCmdHelper::PushUserCmd(pConnection, req.userid(), cmd);
}

void ChatThread::ProcessChatReq(RedisConnection* pConnection, const ChatChannelCmd& req) {
    UserProtoCmd cmd;
    cmd.set_cmd(CHAT_ChatResp);
    cmd.set_requestid(req.requestid());

    cmd.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    do {
        uint64 dstId = req.chat_req().dst();
        bool isPrivate = req.chat_req().is_private();
        string content = req.chat_req().content();
        if( dstId == 0 ) {
            if( RedisData::IsInMuteTime(pConnection, req.userid(), time(nullptr)) ) {
                cmd.set_errorcode(JDATA->ErrorCodePtr()->GetChatPublicMute());
                break;
            }
            TargetInfo src;
            if( !m_pHelperChat->GetTargetInfo(pConnection, req.userid(), src) ) {
                cmd.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
                break;
            }
            if( JDATA->VIPPtr()->PublicChatByID(src.t_vip()) == 0 ) {
                cmd.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
                break;
            }
            sChatServer->ChatPublic(pConnection, src, content);
        }
        else {
            int32 ret = 0;
            if( isPrivate ) {
                // 私聊
                ret = m_pHelperChat->ChatInPrivate(pConnection, req.userid(), dstId, content);
            }
            else {
                ret = m_pHelperChat->ChatInGroup(pConnection, dstId, req.userid(), content);
            }
            cmd.set_errorcode(ret);
        }
    }while(0);
    ProtoCmdHelper::PushUserCmd(pConnection, req.userid(), cmd);
}

void ChatThread::ProcessChatGroupCreateReq(RedisConnection* pConnection, const ChatChannelCmd& req) {
    UserProtoCmd cmd;
    cmd.set_cmd(CHAT_ChatGroupCreateResp);
    cmd.set_requestid(req.requestid());
    GroupInfo info;
    int32 ret = m_pHelperChat->CreateGroup(pConnection, req.userid(), req.chat_group_create_req().name(), req.chat_group_create_req().passwd(), info);
    cmd.set_errorcode(ret);
    if( ret == JDATA->ErrorCodePtr()->GetSuccess() ) {
        *(cmd.mutable_chat_group_create_resp()->mutable_group()) = info;
    }
    ProtoCmdHelper::PushUserCmd(pConnection, req.userid(), cmd);
}

void ChatThread::ProcessChatGroupRenameReq(RedisConnection* pConnection, const ChatChannelCmd& req) {
    UserProtoCmd cmd;
    cmd.set_cmd(CHAT_ChatGroupRenameResp);
    cmd.set_requestid(req.requestid());
    cmd.set_errorcode(m_pHelperChat->RenameGroup(pConnection, req.userid(), req.chat_group_rename_req().gid(), req.chat_group_rename_req().name()));
    ProtoCmdHelper::PushUserCmd(pConnection, req.userid(), cmd);
}

void ChatThread::ProcessChatGroupResetPwdReq(RedisConnection* pConnection, const ChatChannelCmd& req) {
    UserProtoCmd cmd;
    cmd.set_cmd(CHAT_ChatGroupResetPwdResp);
    cmd.set_requestid(req.requestid());
    cmd.set_errorcode(m_pHelperChat->ResetGroupPasswd(pConnection, req.userid(), req.chat_group_reset_pwd_req().gid(), req.chat_group_reset_pwd_req().passwd()));
    ProtoCmdHelper::PushUserCmd(pConnection, req.userid(), cmd);
}

void ChatThread::ProcessChatGroupInviteReq(RedisConnection* pConnection, const ChatChannelCmd& req) {
    UserProtoCmd cmd;
    cmd.set_cmd(CHAT_ChatGroupInviteResp);
    cmd.set_requestid(req.requestid());
    cmd.set_errorcode(m_pHelperChat->GroupInviteUser(pConnection, req.userid(), req.chat_group_invite_req()));
    ProtoCmdHelper::PushUserCmd(pConnection, req.userid(), cmd);
}

void ChatThread::ProcessChatGroupAcceptInviteReq(RedisConnection* pConnection, const ChatChannelCmd& req) {
    UserProtoCmd cmd;
    cmd.set_cmd(CHAT_ChatGroupAcceptInviteResp);
    cmd.set_requestid(req.requestid());
    cmd.set_errorcode(m_pHelperChat->UserAcceptInvite(pConnection, req.userid(), req.chat_group_accept_invite_req().msg_id()));
    ProtoCmdHelper::PushUserCmd(pConnection, req.userid(), cmd);
}

void ChatThread::ProcessChatGroupSearchReq(RedisConnection* pConnection, const ChatChannelCmd& req) {
    UserProtoCmd cmd;
    cmd.set_cmd(CHAT_ChatGroupSearchResp);
    cmd.set_requestid(req.requestid());
    cmd.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    do {
        auto ptr = m_pHelperChat->FindGroup(req.chat_group_search_req().gid());
        if( ptr == nullptr ) {
            cmd.set_errorcode(JDATA->ErrorCodePtr()->GetChatGroupNotFound());
            break;
        }
        if( ptr->IsPrivate() ) {
            cmd.set_errorcode(JDATA->ErrorCodePtr()->GetChatGroupNotFound());
            break;
        }
        auto resp = cmd.mutable_chat_group_search_resp();
        resp->set_gid(req.chat_group_search_req().gid());
        resp->set_num(ptr->MemberNum());
        string strName = ptr->Name();
        resp->set_name(ptr->Name());
        if( strName.empty() ) {
            resp->set_name(GlobalUtils::ToString(req.chat_group_search_req().gid()));
        }
        resp->set_has_pwd(ptr->HasPasswd());
    }while(0);
    ProtoCmdHelper::PushUserCmd(pConnection, req.userid(), cmd);
}

void ChatThread::ProcessChatGroupJoinReq(RedisConnection* pConnection, const ChatChannelCmd& req) {
    UserProtoCmd cmd;
    cmd.set_cmd(CHAT_ChatGroupJoinResp);
    cmd.set_requestid(req.requestid());
    cmd.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    do {
        GroupInfo gInfo;
        int32 ret = m_pHelperChat->JoinGroup(pConnection, req.userid(), req.chat_group_join_req().gid(), req.chat_group_join_req().passwd(), gInfo);
        if( ret != JDATA->ErrorCodePtr()->GetSuccess()) {
            cmd.set_errorcode(ret);
            break;
        }
        *(cmd.mutable_chat_group_join_resp()->mutable_group()) = gInfo;
    }while(0);
    ProtoCmdHelper::PushUserCmd(pConnection, req.userid(), cmd);
}

void ChatThread::ProcessChatGroupQuitReq(RedisConnection* pConnection, const ChatChannelCmd& req) {
    UserProtoCmd cmd;
    cmd.set_cmd(CHAT_ChatGroupQuitResp);
    cmd.set_requestid(req.requestid());
    cmd.set_errorcode(m_pHelperChat->QuitGroup(pConnection, req.userid(), req.chat_group_quit_req().gid()));
    ProtoCmdHelper::PushUserCmd(pConnection, req.userid(), cmd);
}

void ChatThread::ProcessChatGroupDismissReq(RedisConnection* pConnection, const ChatChannelCmd& req) {
    UserProtoCmd cmd;
    cmd.set_cmd(CHAT_ChatGroupDismissResp);
    cmd.set_requestid(req.requestid());
    cmd.set_errorcode(m_pHelperChat->DismissGroup(pConnection, req.userid(), req.chat_group_dismiss_req().gid()));
    ProtoCmdHelper::PushUserCmd(pConnection, req.userid(), cmd);
}

void ChatThread::ProcessChatGroupKickReq(RedisConnection* pConnection, const ChatChannelCmd& req) {
    UserProtoCmd cmd;
    cmd.set_cmd(CHAT_ChatGroupKickResp);
    cmd.set_requestid(req.requestid());
    cmd.set_errorcode(m_pHelperChat->GroupKickUser(pConnection, req.userid(), req.chat_group_kick_req().gid(), req.chat_group_kick_req().uid()));
    ProtoCmdHelper::PushUserCmd(pConnection, req.userid(), cmd);
}

void ChatThread::ProcessChatGroupClearChatReq(RedisConnection* pConnection, const ChatChannelCmd& req) {
    UserProtoCmd cmd;
    cmd.set_cmd(CHAT_ChatGroupClearChatResp);
    cmd.set_requestid(req.requestid());
    cmd.set_errorcode(m_pHelperChat->GroupClearChat(pConnection, req.userid(), req.chat_group_clear_chat_req().gid()));
    ProtoCmdHelper::PushUserCmd(pConnection, req.userid(), cmd);
}

void ChatThread::ProcessChatGroupListReq(RedisConnection* pConnection, const ChatChannelCmd& req) {
    UserProtoCmd cmd;
    cmd.set_cmd(CHAT_ChatGroupListResp);
    cmd.set_requestid(req.requestid());
    cmd.set_errorcode(JDATA->ErrorCodePtr()->GetSuccess());
    do {
        auto pUser = m_pHelperChat->FindUser(pConnection, req.userid());
        if( pUser == nullptr ) {
            cmd.set_errorcode(JDATA->ErrorCodePtr()->GetSystemError());
            break;
        }
        auto resp = cmd.mutable_chat_group_list_resp();
        pUser->ForEachGroup([&](int64 gid, int64 msgId){
            auto pGroup = m_pHelperChat->FindGroup(gid);
            if( pGroup == nullptr ) {
                LOGERROR("user[%lu] in unknown chat[%ld]", req.userid(), gid);
                return;
            }
            if( pGroup->IsPrivateBlocked(pConnection, req.userid()) ) {
                return;
            }
            GroupInfo gInfo;
            pGroup->GetGroupInfo(gInfo);
            // 查看一下是否删除过聊天记录, 如果删过, 只给他没删的部分
            auto info = resp->add_groups();
            *info = gInfo;
            if( !info->has_name() || info->name().empty() ) {
                info->set_name(GlobalUtils::ToString(info->group_id()));
            }
            if( msgId > 0 ) {
                info->clear_msgs();
                for( int32 i = 0 ; i < gInfo.msgs_size(); ++i ) {
                    if( gInfo.msgs(i) > msgId ) {
                        info->add_msgs(gInfo.msgs(i));
                    }
                }
            }
        });
        map<int64, GroupInfo> mapKicked;
        RedisProtoHelper::RedisLoadGroupInfo(pConnection, RedisKey::MakeUserKickedChatGroupKey(req.userid()), mapKicked);
        for( auto& it : mapKicked ) {
            *resp->add_kicked() = it.second;
        }
    }while(0);
    ProtoCmdHelper::PushUserCmd(pConnection, req.userid(), cmd);
}

void ChatThread::ProcessLxChatForGiftStatus(RedisConnection* pConnection, const ChatChannelCmd& req) {
    m_pHelperChat->ChatForGiftStatus(pConnection, req.lx_chat_for_gift_status().src(), req.lx_chat_for_gift_status().dst(), req.lx_chat_for_gift_status().gid(), req.lx_chat_for_gift_status().status());
}
