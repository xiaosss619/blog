#pragma once

#include "ServerDefine.h"
#include "DataCache/RedisData.h"

//
class ChatMsg
{
public:
	ChatMsg() { _msg.Clear(); }
	~ChatMsg() {};

	bool Init(RedisConnection* pConnection, int64 gid, uint64 speaker, const string& content) {
		int64 mid = RedisData::GenerateChatMsgId(pConnection);
		if( mid == 0 ) {
			return false;
		}
		_msg.Clear();
		_msg.set_msg_id(mid);
		_msg.set_group_id(gid);
		_msg.set_src(speaker);
		_msg.set_timestamp(time(nullptr));
		_msg.set_type(ECT_Common);
		_msg.set_content(content);

		string strData = JsonProto::ProtoToJson(_msg);
		pConnection->set(RedisKey::MakeSysChatMsgKey(mid), strData);
		return true;
	}
	// 礼物状态变化私聊
	bool Init(RedisConnection* pConnection, int64 gid, uint64 speaker, int64 giftId, int32 status) {
		int64 mid = RedisData::GenerateChatMsgId(pConnection);
		if( mid == 0 ) {
			return false;
		}
		_msg.Clear();
		_msg.set_msg_id(mid);
		_msg.set_group_id(gid);
		_msg.set_src(speaker);
		_msg.set_timestamp(time(nullptr));
		_msg.set_type(ECT_GiftStatus);
		{
			ostringstream content;
			content << giftId << "|" << status;
			_msg.set_content(content.str());
		}
		string strData = JsonProto::ProtoToJson(_msg);
		pConnection->set(RedisKey::MakeSysChatMsgKey(mid), strData);
		return true;
	}
	// 群邀请, gid是两人的私聊组id, group是邀请所在的群
	bool Init(RedisConnection* pConnection, int64 gid, uint64 invitor, const GroupInfo& group) {
		int64 mid = RedisData::GenerateChatMsgId(pConnection);
		if( mid == 0 ) {
			return false;
		}
		_msg.Clear();
		_msg.set_msg_id(mid);
		_msg.set_group_id(gid);
		_msg.set_src(invitor);
		_msg.set_timestamp(time(nullptr));
		_msg.set_type(ECT_Invitation);
		_msg.set_invitation_group(group.group_id());

		ostringstream os;
		os << group.group_id() << "|" << group.name() << "|" << group.members_size();
		_msg.set_content(os.str());

		string strData = JsonProto::ProtoToJson(_msg);
		pConnection->set(RedisKey::MakeSysChatMsgKey(mid), strData);
		return true;
	}
	// 用户加入群组
	bool Init(RedisConnection* pConnection, int64 gid, uint64 uid) {
		int64 mid = RedisData::GenerateChatMsgId(pConnection);
		if( mid == 0 ) {
			return false;
		}
		_msg.Clear();
		_msg.set_msg_id(mid);
		_msg.set_group_id(gid);
		_msg.set_src(uid);
		_msg.set_timestamp(time(nullptr));
		_msg.set_type(ECT_UserJoin);
		_msg.set_invitation_group(0);
		_msg.set_content("");
		string strData = JsonProto::ProtoToJson(_msg);
		pConnection->set(RedisKey::MakeSysChatMsgKey(mid), strData);
		return true;
	}
	// 用户离开群组
	bool Init(RedisConnection* pConnection, int64 gid, uint64 kicker, uint64 target) {
		int64 mid = RedisData::GenerateChatMsgId(pConnection);
		if( mid == 0 ) {
			return false;
		}
		_msg.Clear();
		_msg.set_msg_id(mid);
		_msg.set_group_id(gid);
		_msg.set_src(kicker);
		_msg.set_timestamp(time(nullptr));
		_msg.set_type(ECT_UserLeave);
		_msg.set_invitation_group(0);
		_msg.set_content(GlobalUtils::ToString(target));
		string strData = JsonProto::ProtoToJson(_msg);
		pConnection->set(RedisKey::MakeSysChatMsgKey(mid), strData);
		return true;
	}
	bool Init(const MsgInfo& rhs)
	{
		_msg.Clear();
		_msg = rhs;
		return true;
	}
	bool IsValid() { return true; }
	void Update(int32 dt) {};

	int64 MsgId() { return _msg.msg_id(); }
	int64 GroupId() { return _msg.group_id(); }

	void GetMsgInfo(MsgInfo& lhs) { lhs = _msg; }
	string Content() { return _msg.content(); }
	int64 GetKey() { return _msg.msg_id(); }
	int64 InvitationGroupId() {
		return _msg.invitation_group();
	}
private:
	MsgInfo _msg;
};
