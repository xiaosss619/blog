#pragma once

#include "ServerDefine.h"
#include "DataCache/RedisData.h"
#include "DataCache/ProtoCmdHelper.h"
#include "Include/RedisProtoHelper.h"

// 默认情况下 _groupChat中不记录聊天信息, 当用户删除一次聊天记录后, 本地会记录个人的聊天记录
//
class ChatGroup
{
public:
	ChatGroup() { _group.Clear(); };
	~ChatGroup() {};

	// 创建私聊组
	bool Init(int64 gid, uint64 src, uint64 dst, int64 now) {
		_group.Clear();
		// 私聊组的创建
		_group.set_group_id(gid);
		_group.add_members(src);
		_group.add_members(dst);
		_group.set_time_create(now);
		_group.set_is_private(true);
		return true;
	}
	// 创建多人聊天组
	bool Init(int64 gid, uint64 owner, const string& name, const string& passwd, int64 now) {
		_group.Clear();
		// 群聊组的创建
		_group.set_group_id(gid);
		_group.set_owner(owner);
		_group.add_members(owner);
		_group.set_name(name);
		_group.set_passwd(passwd);
		_group.set_time_create(now);
		_group.set_is_private(false);
		return true;
	}
	bool Init(const GroupInfo& rhs) {
		_group.Clear();
		_group = rhs;
		return true;
	}
	bool IsValid() { return true; }
	void Update(int32 dt) {};

	void GetGroupInfo(GroupInfo& lhs) {
		lhs = _group;
		if( !lhs.has_name() || lhs.name().empty() ) {
			lhs.set_name(GlobalUtils::ToString(lhs.group_id()));
		}
	}
	void Save(RedisConnection* pConnection) {
		RedisProtoHelper::RedisSaveHSET(pConnection, SYS_CHATS_KEY, GlobalUtils::ToString(_group.group_id()), _group);
	}

	void Chat(RedisConnection* pConnection, const MsgInfo& rhs) {
		UserProtoCmd cmd;
		cmd.set_cmd(CHAT_SyncChatMessage);
		auto ptr = cmd.mutable_sync_chat_message();
		ptr->set_gid(_group.group_id());
		*ptr->mutable_msg() = rhs;

		for( int32 i = 0 ; i < _group.members_size() ; i++ ) {
			uint64 uid = _group.members(i);
			if( !RedisData::IsUserBlocked(pConnection, uid, rhs.src()) ) {
				ProtoCmdHelper::PushUserCmd(pConnection, uid, cmd);
			}
		}
		_group.add_msgs(rhs.msg_id());
	}
	void AddMember(uint64 uid) { _group.add_members(uid); }
	void ResetMember() { _group.clear_members(); }
	void ForEachMember(boost::function<void(uint64)> func) {
		for( int32 i = 0 ; i < _group.members_size() ; i++ ) {
			func(_group.members(i));
		}
	}
	void ForEachMsg(boost::function<void(int64)> func) {
		for( int32 i = 0 ; i < _group.msgs_size() ; i++ ) {
			func(_group.msgs(i));
		}
	}
	bool IsFull() {
		return _group.members_size() >= JDATA->SystemConstPtr()->GetGroupChatMemberMax();
	}
    void OnRecycled() {}
	int32 MemberNum() { return _group.members_size(); }

	uint64 Owner() { return _group.owner(); }
	string Name() { return _group.name(); }
	bool IsPrivate() { return _group.is_private(); }
	void SetName(const string& name) { _group.set_name(name); }
	string Passwd() { return _group.passwd(); }
	bool HasPasswd() { return !_group.passwd().empty(); }
	void SetPasswd(const string& pwd) { _group.set_passwd(pwd); }
	int64 GetKey() { return _group.group_id(); }

	int32 MsgSize() { return _group.msgs_size(); }
	int64 GetMsg(int32 idx) { return _group.msgs(idx); }
	// 是否是一个拉黑的对象发过来的私聊
	bool IsPrivateBlocked(RedisConnection* pConnection, uint64 uid) {
		if( !IsPrivate() ) {
			return false;
		}
		for( size_t i = 0; i < _group.members(i); ++i ) {
			if( uid != _group.members(i) ) {
				if( RedisData::IsUserBlocked(pConnection, uid, _group.members(i) ) ) {
					return true;
				}
			}
		}
		return false;
	}

private:
	GroupInfo _group;
};
