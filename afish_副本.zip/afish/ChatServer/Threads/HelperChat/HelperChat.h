#pragma once

#include "ServerDefine.h"
#include "EntityPool.h"
#include "ChatUser.h"
#include "ChatGroup.h"
#include "ChatMsg.h"

class HelperChat
{
public:
	HelperChat();
	~HelperChat();
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
public:
	void Load(RedisConnection* pConnection);
	ChatUser* FindUser(RedisConnection* pConnection, uint64 userId);
	ChatGroup* FindGroup(int64 gid);
	bool GetTargetInfo(RedisConnection* pConnection, uint64 userId, TargetInfo& lhs);
	void UpdateTargetInfo(const TargetInfo& rhs);
	bool GetGroupInfo(int64 gid, GroupInfo& lhs);
	bool GetMsgInfo(int64 mid, MsgInfo& lhs);

	// 私聊
	int32 ChatInPrivate(RedisConnection* pConnection, uint64 src, uint64 dst, const string& content);
	// 私聊发送一条礼物状态
	void ChatForGiftStatus(RedisConnection* pConnection, uint64 src, uint64 dst, int64 giftId, int32 status);
	// 聊天组聊天
	int32 ChatInGroup(RedisConnection* pConnection, int64 gid, uint64 userId, const string& content);

	int32 CreateGroup(RedisConnection* pConnection, uint64 owner, const string& name, const string& passwd, GroupInfo& lhs);
	int32 DismissGroup(RedisConnection* pConnection, uint64 userId, int64 gid);
	int32 RenameGroup(RedisConnection* pConnection, uint64 userId, int64 gid, const string& name);
	int32 ResetGroupPasswd(RedisConnection* pConnection, uint64 userId, int64 gid, const string& passwd);
	int32 GroupInviteUser(RedisConnection* pConnection, uint64 userId, const ChatGroupInviteReq& req);
	int32 UserAcceptInvite(RedisConnection* pConnection, uint64 userId, int64 mid);
	int32 JoinGroup(RedisConnection* pConnection, uint64 userId, int64 gid, const string& passwd, GroupInfo& lhs);
	int32 QuitGroup(RedisConnection* pConnection, uint64 userId, int64 gid);
	int32 GroupKickUser(RedisConnection* pConnection, uint64 owner, int64 gid, uint64 target);
	int32 GroupClearChat(RedisConnection* pConnection, uint64 userId, int64 gid);
private:
	// 创建一个两人对话组,会检查是否有旧的对话记录, 如果不存在则创建一个
	uint64 MakeChatPrivateGroup(RedisConnection* pConnection, uint64 src, uint64 dst);
	int32 SendInvitation(RedisConnection* pConnection, uint64 userId, uint64 dstId, const GroupInfo& info);

	// 用户加入聊天组, 创建一个聊天消息
	void ChatForUserJoin(RedisConnection* pConnection, ChatGroup* pGroup, uint64 uid);
	// 用户离开聊天组, 创建一个群聊消息
	void ChatForUserLeave(RedisConnection* pConnection, ChatGroup* pGroup, uint64 kicker, uint64 targetId);
	void SaveKickedGroup(RedisConnection* pConnection, ChatGroup* pGroup, uint64 uid, bool isKicked);
private:
    EntityDriver<int64, ChatGroup> m_groups;
    EntityDriver<uint64, ChatUser> m_users;
    EntityDriver<int64, ChatMsg> m_msgs;
	bool m_bChatsInited;
};
