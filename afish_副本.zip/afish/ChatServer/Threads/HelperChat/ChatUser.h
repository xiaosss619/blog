#pragma once

#include "ServerDefine.h"
#include "DataCache/RedisData.h"
#include "Include/RedisProtoHelper.h"

struct tagGroupSimple {
	bool _myGroup;	// 是否自己是群主
	int64 _msgId;	// 清除到的最大聊天记录id
	tagGroupSimple() {
		_myGroup = false;
		_msgId = 0;
	}
	tagGroupSimple& operator=(const tagGroupSimple& rhs) {
		_myGroup = rhs._myGroup;
		_msgId = rhs._msgId;
		return *this;
	}
};

// 默认情况下 _groupChat中不记录聊天信息, 当用户删除一次聊天记录后, 本地会记录个人的聊天记录
//
class ChatUser
{
public:
	ChatUser() {
		_user.Clear();
		_groups.clear();
	}
	~ChatUser() {}

	bool Init(RedisConnection* pConnection, uint64 userId) {
		_user.Clear();
		_groups.clear();
		if( !RedisData::GetUserTargetInfo(pConnection, userId, _user) ) {
			LOGERROR("CHAT failed to get userinfo[%lud]", userId);
			return false;
		}
		return true;
	}
	void InitGroup(RedisConnection* pConnection, int64 gid, uint64 owner) {
		tagGroupSimple tag;
		tag._myGroup = (owner == _user.t_id());
		pConnection->hget(RedisKey::MakeUserGroupChatMsgKey(_user.t_id()), gid, tag._msgId);
		_groups[gid] = tag;
	}
	bool IsValid() { return true; }
	void Update(int32 dt) {};

	void GetTargetInfo(TargetInfo& lhs) { lhs = _user; }
	void UpdateTargetInfo(const TargetInfo& rhs) { _user = rhs; }
	int32 GetVip() { return _user.t_vip(); }
	bool InGroup(int64 gid) { return _groups.find(gid) != _groups.end(); }
	void JoinGroup(RedisConnection* pConnection, int64 gid, uint64 owner) {
		tagGroupSimple tag;
		tag._myGroup = (owner == _user.t_id());
		_groups[gid] = tag;

		pConnection->hdel(RedisKey::MakeUserKickedChatGroupKey(_user.t_id()), GlobalUtils::ToString(gid));
	}
	void LeaveGroup(RedisConnection* pConnection, int64 gid) {
		auto it = _groups.find(gid);
		if( it != _groups.end() ) {
			_groups.erase(it);
			pConnection->hdel(RedisKey::MakeUserGroupChatMsgKey(_user.t_id()), GlobalUtils::ToString(gid));
		}
	}
	int64 KickedByGroup(RedisConnection* pConnection, int64 gid) {
		int64 msgId = 0;
		auto it = _groups.find(gid);
		if( it != _groups.end() ) {
			msgId = it->second._msgId;
			_groups.erase(it);
			pConnection->hdel(RedisKey::MakeUserGroupChatMsgKey(_user.t_id()), GlobalUtils::ToString(gid));
		}
		return msgId;
	}

	void ForEachGroup(boost::function<void(int64, int64)> func) {
		for( auto& it : _groups ) {
			func(it.first, it.second._msgId);
		}
	}
	void ForEachGroupWithBreak(boost::function<bool(int64)> func) {
		for( auto& it : _groups ) {
			if( func(it.first) ) {
				break;
			}
		}
	}
	int32 GetOwnerNum() {
		int32 num = 0;
		for( auto& it : _groups ) {
			if( it.second._myGroup ) {
				++num;
			}
		}
		return num;
	}
	uint64 GetKey() { return _user.t_id(); }

	int64 GetGroupMsgId(int64 gid) {
		auto it = _groups.find(gid);
		if( it == _groups.end() ) {
			return 0;
		}
		return it->second._msgId;
	}
	void GroupClearChat(RedisConnection* pConnection, int64 gid, int64 mid) {
		auto it = _groups.find(gid);
		if( it != _groups.end() ) {
			it->second._msgId = mid;
			pConnection->hset(RedisKey::MakeUserGroupChatMsgKey(_user.t_id()), gid, mid);
		}
	}
private:
	TargetInfo _user;		// 用户基本信息
	map<int64, tagGroupSimple> _groups;
};
