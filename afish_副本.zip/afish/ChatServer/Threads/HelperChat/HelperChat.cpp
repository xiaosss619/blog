#include "HelperChat.h"
#include "RedisManager/RedisManager.h"
#include "Include/RedisProtoHelper.h"
#include "DataCache/RedisData.h"
#include "DataCache/ProtoCmdHelper.h"
#include "../ChatServer.h"

HelperChat::HelperChat()
{
    m_bChatsInited = false;
    m_groups.Init("ChatGroup", 100, 10);
    m_msgs.Init("ChatMsg", 1000, 100);
    m_users.Init("ChatUser", 100, 20);
}

HelperChat::~HelperChat() {
}

ChatUser* HelperChat::FindUser(RedisConnection* pConnection, uint64 userId) {
    auto ptr = m_users.GetEntity(userId);
    if( ptr == nullptr ) {
        ptr = m_users.CreateEntity(pConnection, userId);
    }
    return ptr;
}

ChatGroup* HelperChat::FindGroup(int64 gid) {
    return m_groups.GetEntity(gid);
}

bool HelperChat::GetTargetInfo(RedisConnection* pConnection, uint64 userId, TargetInfo& lhs) {
    auto ptr = FindUser(pConnection, userId);
    if( ptr == nullptr ) {
        return false;
    }
    ptr->GetTargetInfo(lhs);
    return true;
}

void HelperChat::UpdateTargetInfo(const TargetInfo& rhs) {
    auto ptr = FindUser(nullptr, rhs.t_id());
    if( ptr != nullptr ) {
        ptr->UpdateTargetInfo(rhs);
    }
}

bool HelperChat::GetGroupInfo(int64 gid, GroupInfo& lhs) {
    auto ptr = FindGroup(gid);
    if( ptr != nullptr ) {
        ptr->GetGroupInfo(lhs);
        return true;
    }
    return false;
}

bool HelperChat::GetMsgInfo(int64 mid, MsgInfo& lhs) {
    auto ptr = m_msgs.GetEntity(mid);
    if( ptr != nullptr ) {
        ptr->GetMsgInfo(lhs);
        return true;
    }
    return false;
}

void HelperChat::Load(RedisConnection* pConnection) {
    if( m_bChatsInited ) {
        return;
    }
    map<int64, GroupInfo> mapGroup;
    if( !RedisProtoHelper::RedisLoadGroupInfo(pConnection, SYS_CHATS_KEY, mapGroup) ) {
        LOGERROR("load chats from redis failed");
        return;
    }
    int32 maxPrivateMsgNum = JDATA->SystemConstPtr()->GetPrivateChatMessageNum();
    int32 maxGroupMsgNum = JDATA->SystemConstPtr()->GetGroupChatMessageNum();
    for( auto& it : mapGroup ) {
        set<uint64> members;
        for( int32 i = 0 ; i < it.second.members_size() ; i++ ) {
            uint64 uid = it.second.members(i);
            auto user = FindUser(pConnection, uid);
            if( user == nullptr ) {
                LOGERROR("unknown user[%lu] in group[%ld]", uid, it.first);
            }
            else {
                members.insert(uid);
                user->InitGroup(pConnection, it.first, it.second.owner());
            }
        }
        it.second.clear_members();
        for( auto& uid:members ){
            it.second.add_members(uid);
        }

        set<int64> msgs;
        for( int32 i = it.second.msgs_size()-1 ; i >= 0 ; i-- ) {
            int64 mid = it.second.msgs(i);
            string strData;
            if( pConnection->get(RedisKey::MakeSysChatMsgKey(mid), strData) ) {
                MsgInfo msg;
                if( JsonProto::ProtoFromJson(strData, msg) ) {
                    msgs.insert(mid);
                    m_msgs.CreateEntity(msg);
                }
            }
            if( it.second.owner() == 0 ) {
                // 私聊
                if( (int32)msgs.size() >= maxPrivateMsgNum ) {
                    break;
                }
            }
            else {
                // 群聊
                if( (int32)msgs.size() >= maxGroupMsgNum ) {
                    break;
                }
            }
        }
        it.second.clear_msgs();
        for( auto& mid : msgs ) {
            it.second.add_msgs(mid);
        }
        m_groups.CreateEntity(it.second);
    }
    m_bChatsInited = true;
}

uint64 HelperChat::MakeChatPrivateGroup(RedisConnection* pConnection, uint64 src, uint64 dst) {
    // 给两个人找一个旧的聊天组, 如果没有, 则创建一个新的
    ChatUser* pSrc = FindUser(pConnection, src);
    ChatUser* pDst = FindUser(pConnection, dst);
    if( pSrc == nullptr || pDst == nullptr ) {
        return 0;
    }
    int64 oldGid = 0;
    pSrc->ForEachGroupWithBreak([&](int64 gid){
        if( pDst->InGroup(gid) ) {
            ChatGroup* pGroup = FindGroup(gid);
            if( pGroup != nullptr && pGroup->IsPrivate() ) {
                oldGid = gid;
                return true;
            }
        }
        return false;
    });
    if( oldGid != 0 ) {
        return oldGid;
    }

    int64 gid = RedisData::GenerateChatGroupId(pConnection);
    // 创建一个私聊组
    ChatGroup* pGroup = m_groups.CreateEntity(gid, src, dst, time(nullptr));
    if( pGroup == nullptr ) {
        return 0;
    }
    // 保存一下
    pGroup->Save(pConnection);

    pSrc->JoinGroup(pConnection, gid, 0);
    pDst->JoinGroup(pConnection, gid, 0);

    SyncChatGroupData msg;
    pGroup->GetGroupInfo(*msg.mutable_group());

    sChatServer->ChatSync(pConnection, src, msg);
    sChatServer->ChatSync(pConnection, dst, msg);
    return gid;
}

// 私聊
int32 HelperChat::ChatInPrivate(RedisConnection* pConnection, uint64 userId, uint64 dstId, const string& content) {
    int64 gid = MakeChatPrivateGroup(pConnection, userId, dstId);
    auto pGroup = FindGroup(gid);
    if( pGroup == nullptr ) {
        return JDATA->ErrorCodePtr()->GetChatGroupNotFound();
    }

    ChatMsg* ptr = m_msgs.CreateEntity(pConnection, gid, userId, content);
    if( ptr == nullptr ) {
        return JDATA->ErrorCodePtr()->GetSystemError();
    }

    MsgInfo msg;
    ptr->GetMsgInfo(msg);
    pGroup->Chat(pConnection, msg);
    pGroup->Save(pConnection);
    return JDATA->ErrorCodePtr()->GetSuccess();
}

// 私聊
void HelperChat::ChatForGiftStatus(RedisConnection* pConnection, uint64 src, uint64 dst, int64 giftId, int32 status) {
    int64 gid = MakeChatPrivateGroup(pConnection, src, dst);
    auto pGroup = FindGroup(gid);
    if( pGroup == nullptr ) {
        LOGINFO("CHAT GIFT failed[%lu] [%lu] gift[%ld] status[%d]", src, dst, giftId, status);
        return ;
    }
    ChatMsg* ptr = m_msgs.CreateEntity(pConnection, gid, src, giftId, status);
    if( ptr == nullptr ) {
        LOGINFO("CHAT GIFT failed[%lu] [%lu] gift[%ld] status[%d]", src, dst, giftId, status);
        return ;
    }

    MsgInfo msg;
    ptr->GetMsgInfo(msg);
    pGroup->Chat(pConnection, msg);
    pGroup->Save(pConnection);
}

// 私聊发聊天组邀请
int32 HelperChat::SendInvitation(RedisConnection* pConnection, uint64 userId, uint64 dstId, const GroupInfo& info) {
    int64 gid = MakeChatPrivateGroup(pConnection, userId, dstId);
    auto pGroup = FindGroup(gid);
    if( pGroup == nullptr ) {
        return JDATA->ErrorCodePtr()->GetChatGroupNotFound();
    }
    ChatMsg* ptr = m_msgs.CreateEntity(pConnection, gid, userId, info);
    if( ptr == nullptr ) {
        return JDATA->ErrorCodePtr()->GetSystemError();
    }

    MsgInfo msg;
    ptr->GetMsgInfo(msg);
    pGroup->Chat(pConnection, msg);
    pGroup->Save(pConnection);

    return JDATA->ErrorCodePtr()->GetSuccess();
}

// 聊天组聊天
int32 HelperChat::ChatInGroup(RedisConnection* pConnection, int64 gid, uint64 userId, const string& content) {
    auto pGroup = FindGroup(gid);
    if( pGroup == nullptr ) {
        LOGERROR("CHAT group not found[%ld]", gid);
        return JDATA->ErrorCodePtr()->GetChatGroupNotFound();
    }
    auto pUser = FindUser(pConnection, userId);
    if( pUser == nullptr ) {
        LOGERROR("CHAT user not found[%ld]", userId);
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    if( !pUser->InGroup(gid) ) {
        LOGERROR("user[%ld] not in group[%ld]", userId, gid);
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    ChatMsg* ptr = m_msgs.CreateEntity(pConnection, gid, userId, content);
    if( ptr == nullptr ) {
        LOGERROR("create chat failed [%lu] [%ld] [%s]", userId, gid, content.c_str());
        return JDATA->ErrorCodePtr()->GetSystemError();
    }

    MsgInfo msg;
    ptr->GetMsgInfo(msg);
    pGroup->Chat(pConnection, msg);
    pGroup->Save(pConnection);
    return JDATA->ErrorCodePtr()->GetSuccess();
}

// 用户加入
void HelperChat::ChatForUserJoin(RedisConnection* pConnection, ChatGroup* pGroup, uint64 userId) {
    ChatMsg* ptr = m_msgs.CreateEntity(pConnection, pGroup->GetKey(), userId);
    if( ptr == nullptr ) {
        return;
    }

    MsgInfo msg;
    ptr->GetMsgInfo(msg);
    pGroup->Chat(pConnection, msg);
}

// 用户离开
void HelperChat::ChatForUserLeave(RedisConnection* pConnection, ChatGroup* pGroup, uint64 kicker, uint64 targetId) {
    ChatMsg* ptr = m_msgs.CreateEntity(pConnection, pGroup->GetKey(), kicker, targetId);
    if( ptr == nullptr ) {
        return;
    }

    MsgInfo msg;
    ptr->GetMsgInfo(msg);
    pGroup->Chat(pConnection, msg);
}

int32 HelperChat::CreateGroup(RedisConnection* pConnection, uint64 owner, const string& name, const string& passwd, GroupInfo& lhs) {
    auto pUser = FindUser(pConnection, owner);
    if( pUser == nullptr ) {
        LOGERROR("owner not found[%lu]", owner);
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    int32 groupNum = JDATA->VIPPtr()->CreateChatGroupByID(pUser->GetVip());
    if( groupNum == 0 ) {
        LOGERROR("user[%lu] can not create group", owner);
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    if( pUser->GetOwnerNum() >= groupNum ) {
        LOGERROR("user[%lud] creat max group now[%d]", owner, groupNum);
        return JDATA->ErrorCodePtr()->GetSystemError();
    }

    int64 gid = RedisData::GenerateChatGroupId(pConnection);
    // 创建一个群聊组
    ChatGroup* pGroup = m_groups.CreateEntity(gid, owner, name, passwd, time(nullptr));
    if( pGroup == nullptr ) {
        LOGERROR("user[%lu] can not create group", owner);
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    // 保存一下
    pGroup->Save(pConnection);
    pUser->JoinGroup(pConnection, gid, owner);
    pGroup->GetGroupInfo(lhs);
    return JDATA->ErrorCodePtr()->GetSuccess();
}

void HelperChat::SaveKickedGroup(RedisConnection* pConnection, ChatGroup* pGroup, uint64 uid, bool isKicked) {
    auto pUser = FindUser(pConnection, uid);
    if( pUser == nullptr ) {
        return;
    }
    SyncKickedByGroup msg;
    auto ptr = msg.mutable_info();
    pGroup->GetGroupInfo(*ptr);
    ptr->set_is_kicked(isKicked);
    ptr->clear_members();

    int64 mid = pUser->KickedByGroup(pConnection, pGroup->GetKey());
    if( mid > 0 ) {
        ptr->clear_msgs();
        pGroup->ForEachMsg([&](int64 msgId){
            if( msgId > mid ) {
                ptr->add_msgs(msgId);
            }
        });
    }
    RedisProtoHelper::RedisSaveHSET(pConnection, RedisKey::MakeUserKickedChatGroupKey(uid), GlobalUtils::ToString(pGroup->GetKey()), *ptr);
    sChatServer->ChatSync(pConnection, uid, msg);
}

int32 HelperChat::DismissGroup(RedisConnection* pConnection, uint64 userId, int64 gid) {
    auto pGroup = FindGroup(gid);
    if( pGroup == nullptr ) {
        return JDATA->ErrorCodePtr()->GetChatGroupNotFound();
    }
    if( pGroup->Owner() != userId ) {
        return JDATA->ErrorCodePtr()->GetChatGroupNotOwner();
    }
    SyncChatGroupDismissed msg;
    msg.set_gid(gid);
    pGroup->ForEachMember([&](uint64 uid){
        sChatServer->ChatSync(pConnection, uid, msg);
        if( uid != userId ) {
            // 群主不需要保留
            SaveKickedGroup(pConnection, pGroup, uid, false);
        }
    });
    m_groups.RemoveEntity(pGroup);
    pConnection->hdel(SYS_CHATS_KEY, GlobalUtils::ToString(gid));
    return JDATA->ErrorCodePtr()->GetSuccess();
}

int32 HelperChat::RenameGroup(RedisConnection* pConnection, uint64 userId, int64 gid, const string& name) {
    auto pGroup = FindGroup(gid);
    if( pGroup == nullptr ) {
        return JDATA->ErrorCodePtr()->GetChatGroupNotFound();
    }
    if( pGroup->Owner() != userId ) {
        return JDATA->ErrorCodePtr()->GetChatGroupNotOwner();
    }
    pGroup->SetName(name);

    SyncChatGroupRename msg;
    msg.set_gid(gid);
    msg.set_name(name);

    pGroup->ForEachMember([&](uint64 uid){
        sChatServer->ChatSync(pConnection, uid, msg);
    });
    pGroup->Save(pConnection);
    return JDATA->ErrorCodePtr()->GetSuccess();
}

int32 HelperChat::ResetGroupPasswd(RedisConnection* pConnection, uint64 userId, int64 gid, const string& passwd) {
    auto pGroup = FindGroup(gid);
    if( pGroup == nullptr ) {
        return JDATA->ErrorCodePtr()->GetChatGroupNotFound();
    }
    if( pGroup->Owner() != userId ) {
        return JDATA->ErrorCodePtr()->GetChatGroupNotOwner();
    }
    pGroup->SetPasswd(passwd);
    pGroup->Save(pConnection);
    return JDATA->ErrorCodePtr()->GetSuccess();
}

int32 HelperChat::GroupInviteUser(RedisConnection* pConnection, uint64 userId, const ChatGroupInviteReq& req) {
    auto pGroup = FindGroup(req.gid());
    if( pGroup == nullptr ) {
        return JDATA->ErrorCodePtr()->GetChatGroupNotFound();
    }
    if( pGroup->Owner() != userId ) {
        return JDATA->ErrorCodePtr()->GetChatGroupNotOwner();
    }
    GroupInfo gInfo;
    pGroup->GetGroupInfo(gInfo);
    for( int32 i = 0 ; i < req.targets_size() ; ++i ) {
        SendInvitation(pConnection, userId, req.targets(i), gInfo);
    }
    return JDATA->ErrorCodePtr()->GetSuccess();
}

int32 HelperChat::UserAcceptInvite(RedisConnection* pConnection, uint64 userId, int64 mid) {
    auto pMsg = m_msgs.GetEntity(mid);
    if( pMsg == nullptr ) {
        return JDATA->ErrorCodePtr()->GetChatGroupInvitationInvalid();
    }

    auto pUser = FindUser(pConnection, userId);
    if( pUser == nullptr ) {
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    if( pUser->InGroup(pMsg->InvitationGroupId()) ) {
        return JDATA->ErrorCodePtr()->GetSuccess();
    }
    // 判断消息的src是否是群主?
    auto pGroup = FindGroup(pMsg->InvitationGroupId());
    if( pGroup == nullptr || pGroup->IsPrivate() ) {
        return JDATA->ErrorCodePtr()->GetChatGroupNotFound();
    }
    if( pGroup->IsFull() ) {
        return JDATA->ErrorCodePtr()->GetChatGroupFull();
    }
    pUser->JoinGroup(pConnection, pGroup->GetKey(), pGroup->Owner());
    {
        // 给点同意的同步一个群信息
        SyncChatGroupData msg;
        pGroup->GetGroupInfo(*msg.mutable_group());
        sChatServer->ChatSync(pConnection, userId, msg);
    }

    SyncChatGroupNewUser msg;
    msg.set_gid(pGroup->GetKey());
    pUser->GetTargetInfo(*msg.mutable_user());
    pGroup->AddMember(userId);

    pGroup->ForEachMember([&](uint64 uid){
        // 给群组里所有人发送一个新用户
        sChatServer->ChatSync(pConnection, uid, msg);
    });
    ChatForUserJoin(pConnection, pGroup, userId);
    pGroup->Save(pConnection);

    return JDATA->ErrorCodePtr()->GetSuccess();
}

int32 HelperChat::JoinGroup(RedisConnection* pConnection, uint64 userId, int64 gid, const string& passwd, GroupInfo& lhs) {
    auto pUser = FindUser(pConnection, userId);
    if( pUser == nullptr ) {
        return JDATA->ErrorCodePtr()->GetSystemError();
    }

    auto pGroup = FindGroup(gid);
    if( pGroup == nullptr || pGroup->IsPrivate() ) {
        return JDATA->ErrorCodePtr()->GetChatGroupNotFound();
    }
    if( pGroup->IsFull() ) {
        return JDATA->ErrorCodePtr()->GetChatGroupFull();
    }

    SyncChatGroupNewUser msg;
    msg.set_gid(gid);
    pUser->GetTargetInfo(*msg.mutable_user());
    if( pGroup->Passwd() != passwd ) {
        return JDATA->ErrorCodePtr()->GetChatGroupPasswdFailed();
    }
    pGroup->AddMember(userId);

    pGroup->ForEachMember([&](uint64 uid){
        sChatServer->ChatSync(pConnection, uid, msg);
    });
    ChatForUserJoin(pConnection, pGroup, userId);
    pGroup->Save(pConnection);

    pGroup->GetGroupInfo(lhs);

    pUser->JoinGroup(pConnection, gid, pGroup->Owner());
    return JDATA->ErrorCodePtr()->GetSuccess();
}

int32 HelperChat::QuitGroup(RedisConnection* pConnection, uint64 userId, int64 gid) {
    auto pGroup = FindGroup(gid);
    if( pGroup == nullptr ) {
        return JDATA->ErrorCodePtr()->GetChatGroupNotFound();
    }
    if( pGroup->Owner() == userId ) {
        // 群主只能发解散, 不能发退出
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    SyncChatGroupDelUser msg;
    msg.set_gid(gid);
    msg.set_uid(userId);
    msg.set_kicked(false);
    vector<uint64> vecMember;
    pGroup->ForEachMember([&](uint64 uid){
        sChatServer->ChatSync(pConnection, uid, msg);
        if( uid != userId ) {
            vecMember.push_back(uid);
        }
        else {
            auto pUser = FindUser(pConnection, uid);
            if( pUser != nullptr ) {
                pUser->LeaveGroup(pConnection, gid);
            }
        }
    });
    pGroup->ResetMember();
    for( size_t i = 0; i < vecMember.size(); i++ ) {
        pGroup->AddMember(vecMember[i]);
    }
    ChatForUserLeave(pConnection, pGroup, 0, userId);
    pGroup->Save(pConnection);
    return JDATA->ErrorCodePtr()->GetSuccess();
}

int32 HelperChat::GroupKickUser(RedisConnection* pConnection, uint64 owner, int64 gid, uint64 target) {
    auto pGroup = FindGroup(gid);
    if( pGroup == nullptr ) {
        return JDATA->ErrorCodePtr()->GetChatGroupNotFound();
    }
    if( pGroup->Owner() != owner ) {
        return JDATA->ErrorCodePtr()->GetChatGroupNotOwner();
    }

    SyncChatGroupDelUser msg;
    msg.set_gid(gid);
    msg.set_uid(target);
    msg.set_kicked(true);

    vector<uint64> vecMember;
    pGroup->ForEachMember([&](uint64 uid){
        sChatServer->ChatSync(pConnection, uid, msg);
        if( uid != target ) {
            vecMember.push_back(uid);
        }
        else {
            SaveKickedGroup(pConnection, pGroup, uid, true);
        }
    });

    pGroup->ResetMember();
    for( size_t i = 0; i < vecMember.size(); i++ ) {
        pGroup->AddMember(vecMember[i]);
    }
    ChatForUserLeave(pConnection, pGroup, owner, target);
    pGroup->Save(pConnection);

    return JDATA->ErrorCodePtr()->GetSuccess();
}

int32 HelperChat::GroupClearChat(RedisConnection* pConnection, uint64 userId, int64 gid) {
    auto user = FindUser(pConnection, userId);
    if( user == nullptr ) {
        return JDATA->ErrorCodePtr()->GetSystemError();
    }
    if( user->InGroup(gid) ) {
        auto pGroup = FindGroup(gid);
        if( pGroup == nullptr ) {
            return JDATA->ErrorCodePtr()->GetChatGroupNotFound();
        }
        if( pGroup->MsgSize() > 0 ) {
            user->GroupClearChat(pConnection, gid, pGroup->GetMsg(pGroup->MsgSize()-1));
        }
    }
    else {
        pConnection->hdel(RedisKey::MakeUserKickedChatGroupKey(userId), GlobalUtils::ToString(gid));
    }

    return JDATA->ErrorCodePtr()->GetSuccess();
}
