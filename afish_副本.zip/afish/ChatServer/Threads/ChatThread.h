#pragma once

#include "ServerDefine.h"

class HelperChat;
class ChatThread
{
public:
	ChatThread(boost::asio::io_service& io);
	~ChatThread();

	void ProcessMessage(RedisConnection* pConnection, const ChatChannelCmd& cmd);
private:
    void Start(const boost::system::error_code& error);
	boost::asio::io_service& _io_service;
	boost::asio::deadline_timer _timer;
	HelperChat* m_pHelperChat;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
private:
	void ProcessMsgInfoReq(RedisConnection* pConnection, const ChatChannelCmd& cmd);
	void ProcessChatReq(RedisConnection* pConnection, const ChatChannelCmd& cmd);
	void ProcessChatGroupCreateReq(RedisConnection* pConnection, const ChatChannelCmd& cmd); // 创建聊天群
	void ProcessChatGroupRenameReq(RedisConnection* pConnection, const ChatChannelCmd& cmd); // 修改群名
	void ProcessChatGroupResetPwdReq(RedisConnection* pConnection, const ChatChannelCmd& cmd); // 修改群密码
	void ProcessChatGroupInviteReq(RedisConnection* pConnection, const ChatChannelCmd& cmd); // 修改群密码
	void ProcessChatGroupAcceptInviteReq(RedisConnection* pConnection, const ChatChannelCmd& cmd); // 接受邀请,加入群聊
	void ProcessChatGroupSearchReq(RedisConnection* pConnection, const ChatChannelCmd& cmd); // 群搜索
	void ProcessChatGroupJoinReq(RedisConnection* pConnection, const ChatChannelCmd& cmd); // 加入群聊请求
	void ProcessChatGroupQuitReq(RedisConnection* pConnection, const ChatChannelCmd& cmd); // 退出群聊请求
	void ProcessChatGroupDismissReq(RedisConnection* pConnection, const ChatChannelCmd& cmd); // 群主解散
	void ProcessChatGroupKickReq(RedisConnection* pConnection, const ChatChannelCmd& cmd); // 群主踢人
	void ProcessChatGroupClearChatReq(RedisConnection* pConnection, const ChatChannelCmd& cmd); // 清理聊天记录
	void ProcessChatGroupListReq(RedisConnection* pConnection, const ChatChannelCmd& cmd); // 聊天群列表
	void ProcessLxChatForGiftStatus(RedisConnection* pConnection, const ChatChannelCmd& req);// 向聊天栏发送礼物状态
};
