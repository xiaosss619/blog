/**
 * 礼物模块
*/
#include "GiftThread.h"
#include "RedisManager/RedisManager.h"
#include "Include/RedisProtoHelper.h"
#include "DataCache/RedisData.h"
#include "DataCache/ProtoCmdHelper.h"
#include "LxGameLogHelper.h"
#include "../ChatServer.h"

GiftThread::GiftThread(boost::asio::io_service& io)
    : _io_service(io), _timer(io)
{
    m_bGiftsLoaded = false;
    m_mapGift.clear();
    _timer.expires_from_now(boost::posix_time::seconds(1));
    _timer.async_wait(boost::bind(&GiftThread::Start, this, boost::asio::placeholders::error));
}

GiftThread::~GiftThread() {
}

void GiftThread::Start(const boost::system::error_code& error) {
    _timer.cancel();
    bool inited = false;
    while( true ) {
        RedisConnectionIdGetter idGetter(enumRedisServerTypeData);
        auto pConnection = idGetter.GetConnection();
        if( pConnection == nullptr ) {
            sleep(1);
            continue;
        }
        if( !inited ) {
            LoadGifts(pConnection);
            inited = true;
        }
        CheckExpire(pConnection);

        std::vector<r3c::StreamEntry> vecData;
        pConnection->xread(SYS_CHANNEL_GIFT_KEY, 100, 5000, vecData);
        vector<string> ids;
        for( size_t i = 0; i < vecData.size() ; ++i ) {
            auto ptr = &vecData[i];
            ids.push_back(ptr->id);
            for( size_t j = 0 ; j < ptr->fvpairs.size() ; ++j ) {
                GiftChannelCmd cmd;
                if( JsonProto::ProtoFromJson(ptr->fvpairs[j].value, cmd) ) {
                    switch( cmd.cmd() ) {
                    case CHAT_LxSaveGift:
                        ProcessLxSaveGift(pConnection, cmd.userid(), cmd.gift());
                        break;
                    case CHAT_RGiftAcceptReq:
                        ProcessRGiftAcceptReq(pConnection, cmd.userid(), cmd.accept());
                        break;
                    case CHAT_SGiftCancelReq:
                        ProcessSGiftCancelReq(pConnection, cmd.userid(), cmd.cancel());
                        break;
                    case CHAT_SGiftVerifyReq:
                        ProcessSGiftVerifyReq(pConnection, cmd.userid(), cmd.verify());
                        break;
                    case CHAT_RGiftGetReq:
                        ProcessRGiftGetReq(pConnection, cmd.userid(), cmd.recv());
                        break;
                    }
                }
            }
        }
        if( !ids.empty() ) {
            pConnection->xdel(SYS_CHANNEL_GIFT_KEY, ids);
        }
    }
}

void GiftThread::ChatForGiftStatus(RedisConnection* pConnection, uint64 src, uint64 dst, int64 gid, int32 status) {
    ChatChannelCmd cmd;
    cmd.set_cmd(CHAT_LxChatForGiftStatus);
    auto ptr = cmd.mutable_lx_chat_for_gift_status();
    ptr->set_src(src);
    ptr->set_dst(dst);
    ptr->set_gid(gid);
    ptr->set_status(status);
    ProtoCmdHelper::PushChatCmd(pConnection, cmd);
}

void GiftThread::GiftSyncStatus(RedisConnection* pConnection, uint64 userId, int64 giftId, int32 status) {
    UserProtoCmd cmd;
    cmd.set_cmd(CHAT_SyncGiftStatus);
    auto msg = cmd.mutable_sync_gift_status();
    msg->set_gid(giftId);
    msg->set_status(status);
    ProtoCmdHelper::PushUserCmd(pConnection, userId, cmd);
}

void GiftThread::RedisSaveGift(RedisConnection* pConnection, const GiftData& req) {
    if( !RedisProtoHelper::RedisSaveHSET(pConnection, SYS_GIFT_KEY, GlobalUtils::ToString(req.gid()), req) ) {
        LOGERROR("GIFT save error[%s]", req.DebugString().c_str());
    }
}

void GiftThread::LoadGifts(RedisConnection* pConnection) {
    if( m_bGiftsLoaded ) {
        return;
    }
    m_mapGift.clear();
    if( !RedisProtoHelper::RedisLoadGiftData(pConnection, SYS_GIFT_KEY, m_mapGift) ) {
        LOGERROR("load gift from redis failed");
        return;
    }
    int32 maxSeconds = JDATA->SystemConstPtr()->GetGiftRecordKeepTime()*TIME_DAY;
    int64 now = time(nullptr);
    vector<int64> vecExpired;
    for( auto& it : m_mapGift ) {
        uint64 sendId = it.second.sender().t_id();
        uint64 recvId = it.second.receiver().t_id();
        if( it.second.gtime() + maxSeconds <= now ) {
            vecExpired.push_back(it.first);
            pConnection->hdel(RedisKey::MakeUserGiftListKey(sendId), GlobalUtils::ToString(it.first));
            pConnection->hdel(RedisKey::MakeUserGiftListKey(recvId), GlobalUtils::ToString(it.first));
            LOGINFO("GIFT removed[%s]", it.second.DebugString().c_str());
        }
    }
    for(size_t i = 0 ; i < vecExpired.size() ; ++i ) {
        m_mapGift.erase(vecExpired[i]);
        pConnection->hdel(SYS_GIFT_KEY, GlobalUtils::ToString(vecExpired[i]));
    }
    m_bGiftsLoaded = true;
}

void GiftThread::CheckExpire(RedisConnection* pConnection) {
    map<int64, int64> mapClosed;
    pConnection->hgetall(SYS_GIFT_CLOSE_KEY, mapClosed);
    for( auto & it : mapClosed ) {
        auto itGift = m_mapGift.find(it.first);
        if( itGift != m_mapGift.end() ) {
            switch(itGift->second.status()) {
            case EGS_RecvAccepting:
            case EGS_SendVerify:
            {
                uint64 sender = itGift->second.sender().t_id();
                uint64 recv = itGift->second.receiver().t_id();
                int32 itemId = itGift->second.item().item_id();
                int64 itemNum = itGift->second.item().item_num();

                itGift->second.set_status(EGS_SystemClosed);

                vector<string> vec;
                vec.push_back(GlobalUtils::ToString(itemId));
                vec.push_back(GlobalUtils::ToString(itemNum));
                ProtoCmdHelper::PushGmCmd(pConnection, sender, EIC_GiftWithdraw, vec);

                sChatServer->SendMail(pConnection, sender, JDATA->SystemConstPtr()->GetGiftForceCloseMail(), itemId, itemNum+itGift->second.fee());
                RedisSaveGift(pConnection, itGift->second);
                GiftSyncStatus(pConnection, sender, it.first, itGift->second.status());
                GiftSyncStatus(pConnection, recv, it.first, itGift->second.status());

                if( itGift->second.status() == EGS_RecvAccepting ) {
                    ChatForGiftStatus(pConnection, recv, sender, itGift->first, itGift->second.status());
                }
                else {
                    ChatForGiftStatus(pConnection, sender, recv, itGift->first, itGift->second.status());
                }

                break;
            }
            default:
                LOGERROR("gift[%d] status not for close[%d]", it.first, itGift->second.status());
                break;
            }
        }
    }
    pConnection->del(SYS_GIFT_CLOSE_KEY);

    int64 now = time(nullptr);
    int32 maxSeconds = JDATA->SystemConstPtr()->GetGiftRecordKeepTime()*TIME_DAY;
    vector<int64> vecExpired;
    for( auto& it : m_mapGift ) {
        uint64 sender = it.second.sender().t_id();
        uint64 recv = it.second.receiver().t_id();
        int32 itemId = it.second.item().item_id();
        int64 itemNum = it.second.item().item_num();
        switch( it.second.status() ) {
        case EGS_RecvAccepting:
            if( now >= it.second.expires() ) {
                it.second.set_status(EGS_RecvTimeout);

                vector<string> vec;
                vec.push_back(GlobalUtils::ToString(itemId));
                vec.push_back(GlobalUtils::ToString(itemNum));
                ProtoCmdHelper::PushGmCmd(pConnection, sender, EIC_GiftWithdraw, vec);

                sChatServer->SendMail(pConnection, sender, JDATA->SystemConstPtr()->GetAcceptExpiredOrderMail(), itemId, itemNum+it.second.fee());
                RedisSaveGift(pConnection, it.second);
                GiftSyncStatus(pConnection, sender, it.first, it.second.status());
                GiftSyncStatus(pConnection, recv, it.first, it.second.status());
            }
            break;
        case EGS_SendVerify:
            if( now >= it.second.expires() ) {
                it.second.set_status(EGS_SendTimeout);

                vector<string> vec;
                vec.push_back(GlobalUtils::ToString(itemId));
                vec.push_back(GlobalUtils::ToString(itemNum));
                ProtoCmdHelper::PushGmCmd(pConnection, sender, EIC_GiftWithdraw, vec);

                sChatServer->SendMail(pConnection, sender, JDATA->SystemConstPtr()->GetSendExpiredOrderMail(), itemId, itemNum+it.second.fee());
                RedisSaveGift(pConnection, it.second);
                GiftSyncStatus(pConnection, sender, it.first, it.second.status());
                GiftSyncStatus(pConnection, recv, it.first, it.second.status());
            }
            break;
        }
        if( it.second.gtime() + maxSeconds <= now ) {
            vecExpired.push_back(it.first);
            pConnection->hdel(RedisKey::MakeUserGiftListKey(sender), GlobalUtils::ToString(it.first));
            pConnection->hdel(RedisKey::MakeUserGiftListKey(recv), GlobalUtils::ToString(it.first));
            LOGINFO("GIFT removed[%s]", it.second.DebugString().c_str());
        }
    }
    for(size_t i = 0 ; i < vecExpired.size() ; ++i ) {
        m_mapGift.erase(vecExpired[i]);
        pConnection->hdel(SYS_GIFT_KEY, GlobalUtils::ToString(vecExpired[i]));
    }
}

void GiftThread::ProcessLxSaveGift(RedisConnection* pConnection, uint64 userId, const GiftData& gift) {
    m_mapGift[gift.gid()] = gift;
    pConnection->hset(RedisKey::MakeUserGiftListKey(gift.sender().t_id()), gift.gid(), gift.gtime());
    pConnection->hset(RedisKey::MakeUserGiftListKey(gift.receiver().t_id()), gift.gid(), gift.gtime());

    GiftSyncStatus(pConnection, gift.sender().t_id(), gift.gid(), gift.status());
    GiftSyncStatus(pConnection, gift.receiver().t_id(), gift.gid(), gift.status());

    ChatForGiftStatus(pConnection, gift.sender().t_id(), gift.receiver().t_id(), gift.gid(), gift.status());
}

void GiftThread::ProcessRGiftAcceptReq(RedisConnection* pConnection, uint64 userId, const RGiftAcceptReq& req) {
    auto it = m_mapGift.find(req.gid());
    if( it == m_mapGift.end() ){
        return;
    }
    uint64 sender = it->second.sender().t_id();
    uint64 recv = it->second.receiver().t_id();

    if( userId != recv ) {
        LOGERROR("gift[%s] RGiftAcceptReq failed from[%lu]", it->second.DebugString(), userId);
        return;
    }
    if( it->second.status() != EGS_RecvAccepting ) {
        LOGERROR("gift[%s] RGiftAcceptReq failed from[%lu]", it->second.DebugString(), userId);
        return;
    }

    if( req.accept() ) {
        // 同意接收
        it->second.set_status(EGS_SendVerify);
        it->second.set_expires(time(nullptr)+JDATA->SystemConstPtr()->GetSendGiftsTime()*TIME_MIN);
    }
    else {
        it->second.set_status(EGS_RecvRejected);

        vector<string> vec;
        vec.push_back(GlobalUtils::ToString(it->second.item().item_id()));
        vec.push_back(GlobalUtils::ToString(it->second.item().item_num()));
        ProtoCmdHelper::PushGmCmd(pConnection, sender, EIC_GiftWithdraw, vec);

        sChatServer->SendMail(pConnection, sender, JDATA->SystemConstPtr()->GetAcceptCancelOrderMail(), it->second.item().item_id(), it->second.item().item_num()+it->second.fee());
    }

    RedisSaveGift(pConnection, it->second);
    GiftSyncStatus(pConnection, sender, req.gid(), it->second.status());
    GiftSyncStatus(pConnection, recv, req.gid(), it->second.status());

    ChatForGiftStatus(pConnection, recv, sender, req.gid(), it->second.status());
}

void GiftThread::ProcessSGiftCancelReq(RedisConnection* pConnection, uint64 userId, const SGiftCancelReq& req) {
    auto it = m_mapGift.find(req.gid());
    if( it == m_mapGift.end() ){
        return;
    }
    uint64 sender = it->second.sender().t_id();
    uint64 recv = it->second.receiver().t_id();

    if( sender != userId ) {
        LOGERROR("gift[%s] SGiftCancelReq failed from[%lu]", it->second.DebugString(), userId);
        return;
    }
    if( it->second.status() != EGS_RecvAccepting ) {
        LOGERROR("gift[%s] SGiftCancelReq failed from[%lu]", it->second.DebugString(), userId);
        return;
    }

    {
        it->second.set_status(EGS_SendCanceled);

        vector<string> vec;
        vec.push_back(GlobalUtils::ToString(it->second.item().item_id()));
        vec.push_back(GlobalUtils::ToString(it->second.item().item_num()));
        ProtoCmdHelper::PushGmCmd(pConnection, sender, EIC_GiftWithdraw, vec);
        sChatServer->SendMail(pConnection, sender, JDATA->SystemConstPtr()->GetSendCancelOrderMail(), it->second.item().item_id(), it->second.item().item_num()+it->second.fee());
    }
    RedisSaveGift(pConnection, it->second);
    GiftSyncStatus(pConnection, sender, req.gid(), it->second.status());
    GiftSyncStatus(pConnection, recv, req.gid(), it->second.status());

    ChatForGiftStatus(pConnection, sender, recv, req.gid(), it->second.status());
}

void GiftThread::ProcessSGiftVerifyReq(RedisConnection* pConnection, uint64 userId, const SGiftVerifyReq& req) {
    auto it = m_mapGift.find(req.gid());
    if( it == m_mapGift.end() ){
        return;
    }
    uint64 sender = it->second.sender().t_id();
    uint64 recv = it->second.receiver().t_id();

    if( sender != userId ) {
        LOGERROR("gift[%s] SGiftVerifyReq failed from[%lu]", it->second.DebugString(), userId);
        return;
    }
    if( it->second.status() != EGS_SendVerify ) {
        LOGERROR("gift[%s] SGiftVerifyReq failed from[%lu]", it->second.DebugString(), userId);
        return;
    }
    if( req.confirm() ) {
        // 同意发送
        it->second.set_status(EGS_RecvFetching);
    }
    else {
        it->second.set_status(EGS_SendCanceled);

        vector<string> vec;
        vec.push_back(GlobalUtils::ToString(it->second.item().item_id()));
        vec.push_back(GlobalUtils::ToString(it->second.item().item_num()));
        ProtoCmdHelper::PushGmCmd(pConnection, sender, EIC_GiftWithdraw, vec);

        sChatServer->SendMail(pConnection, sender, JDATA->SystemConstPtr()->GetSendCancelOrderMail(), it->second.item().item_id(), it->second.item().item_num()+it->second.fee());
    }

    RedisSaveGift(pConnection, it->second);
    GiftSyncStatus(pConnection, sender, req.gid(), it->second.status());
    GiftSyncStatus(pConnection, recv, req.gid(), it->second.status());

    ChatForGiftStatus(pConnection, sender, recv, req.gid(), it->second.status());
}

void GiftThread::ProcessRGiftGetReq(RedisConnection* pConnection, uint64 userId, const RGiftGetReq& req) {
    auto it = m_mapGift.find(req.gid());
    if( it == m_mapGift.end() ){
        return;
    }
    uint64 sender = it->second.sender().t_id();
    uint64 recv = it->second.receiver().t_id();

    if( userId != recv ) {
        LOGERROR("gift[%s] RGiftGetReq failed from[%lu]", it->second.DebugString(), userId);
        return;
    }
    if( it->second.status() != EGS_RecvFetching ) {
        LOGERROR("gift[%s] RGiftGetReq failed from[%lu]", it->second.DebugString(), userId);
        return;
    }
    it->second.set_status(EGS_Success);
    {
        vector<string> vec;
        vec.push_back(GlobalUtils::ToString(it->second.item().item_id()));
        vec.push_back(GlobalUtils::ToString(it->second.item().item_num()));
        ProtoCmdHelper::PushGmCmd(pConnection, recv, EIC_GiftRecv, vec);
    }

    RedisSaveGift(pConnection, it->second);
    GiftSyncStatus(pConnection, sender, req.gid(), it->second.status());
    GiftSyncStatus(pConnection, recv, req.gid(), it->second.status());
}

