/**
 * 定时器相关处理模块
*/
#include "GmThread.h"
#include "Include/RedisKey.h"
#include "Include/MySQLProtoHelper.h"
#include "DataCache/ProtoCmdHelper.h"
#include "../ChatServer.h"

GmThread::GmThread(boost::asio::io_service& io)
    : _io_service(io), _timer(io)
{
    m_mapNotice.clear();
    _timer.expires_from_now(boost::posix_time::seconds(5));
    _timer.async_wait(boost::bind(&GmThread::OnTimer5s, this, boost::asio::placeholders::error));
}

GmThread::~GmThread() {
}

void GmThread::OnTimer5s(const boost::system::error_code& error) {
    if( !error ) {
        RedisConnectionIdGetter idGetter(enumRedisServerTypeData);
        auto pConnection = idGetter.GetConnection();
        if( pConnection != nullptr ) {
            int64 now = time(nullptr);
            pConnection->setnx(RedisKey::MakeSysBombGamePoolKey(), 10523826000);
            pConnection->setnx(SYS_FIRE_INTERVAL, 300);
            InitGiftConfig(pConnection);
            CheckJsonReload(pConnection);
            CheckSystemNotice(pConnection, now);
            CheckMaintainace(pConnection);
            CheckGiftConfig(pConnection);
        }
        _timer.expires_from_now(boost::posix_time::seconds(5));
        _timer.async_wait(boost::bind(&GmThread::OnTimer5s, this, boost::asio::placeholders::error));
    }
}

void GmThread::InitGiftConfig(RedisConnection* pConnection) {
    if( !pConnection->exists(SYS_GIFT_FEE_KEY) ) {
        SetGiftConfig(pConnection, JDATA->SystemConstPtr()->GetGold(), 100);
        SetGiftConfig(pConnection, JDATA->SystemConstPtr()->GetCrystal(), 100);
        SetGiftConfig(pConnection, JDATA->SystemConstPtr()->GetCardDrawNuclearID(), 100);
    }
}

void GmThread::SetGiftConfig(RedisConnection* pConnection, int32 itemId, int32 fee) {
    GiftFeeData data;
    data.set_item_id(itemId);
    data.set_fee(fee);
    data.set_discount(0);
    data.set_start_time(0);
    data.set_end_time(0);
    RedisProtoHelper::RedisSaveHSET(pConnection, SYS_GIFT_FEE_KEY, GlobalUtils::ToString(itemId), data);
}

void GmThread::CheckJsonReload(RedisConnection* pConnection) {
    if(pConnection->exists(SYS_RELOAD_ALL) ) {
        pConnection->del(SYS_RELOAD_ALL);
        sChatServer->LxSimpleCmd(pConnection, CHAT_LxReloadJson);
    }
}

void GmThread::CheckSystemNotice(RedisConnection* pConnection, int64 tNow) {
    // 当前系统做一次广播, 同时移除过期数据
    vector<int32> vecExpire;
    for( auto & it : m_mapNotice ) {
        if( tNow - it.second.last_time() >= it.second.interval() ) {
            // 可以广播了
            list<string> lstData;
            lstData.push_back(it.second.content());
            if( it.second.channel().empty() ) {
                sChatServer->LxBoardcastChannelMsg(pConnection, "", it.second.content());
            }
            else {
                vector<string> vecChn;
                GlobalUtils::GetStrArray(it.second.channel(), "+", vecChn);
                for( size_t i = 0 ; i < vecChn.size() ; ++i ) {
                    sChatServer->LxBoardcastChannelMsg(pConnection, vecChn[i], it.second.content());
                }
            }
            it.second.set_cur_num(it.second.cur_num()+1);
            it.second.set_last_time(tNow);
        }
        if( it.second.cur_num() >= it.second.max_num() ) {
            vecExpire.push_back(it.first);
        }
    }
    for( size_t i = 0 ; i < vecExpire.size() ; i++ ) {
        m_mapNotice.erase(vecExpire[i]);
        pConnection->hdel(RedisKey::MakeSystemNoticeKey(), GlobalUtils::ToString(vecExpire[i]));
    }
    // 读取新的系统公告数据
    map<int32, string> mapNotice;
    if( pConnection->hgetall(RedisKey::MakeSystemNoticeKey(), mapNotice) ) {
        for( auto & it : mapNotice ) {
            if( m_mapNotice.find(it.first) == m_mapNotice.end() ) {
                vector<string> vec;
                GlobalUtils::GetStrArray(it.second, "|", vec);
                if( vec.size() >= 4 ) {
                    SystemNotice sn;
                    sn.set_idx(it.first);
                    sn.set_start_time(atol(vec[0].data()));
                    sn.set_interval(atoi(vec[1].data()));
                    sn.set_max_num(atoi(vec[2].data()));
                    sn.set_content(vec[3].data());
                    if( vec.size() >= 5 ) {
                        sn.set_channel(vec[4]);
                    }
                    else {
                        sn.set_channel("");
                    }
                    sn.set_cur_num(0);
                    sn.set_last_time(0);
                    m_mapNotice[it.first] = sn;
                }
            }
        }
    }
}

void GmThread::CheckMaintainace(RedisConnection* pConnection) {
    // 检查是否需要进行维护
    int32 flag = 0;
    if( pConnection->get(SYS_STATUS, flag) ) {
        if( flag == ESMS_InMaintain ) {
            if( !pConnection->exists(SYS_STATUS_KICK) ) {
                pConnection->set(SYS_STATUS_KICK, 1);
                sChatServer->LxSimpleCmd(pConnection, CHAT_LxServerMaintain);
            }
        }
        else {
            if( pConnection->exists(SYS_STATUS_KICK) ) {
                pConnection->del(SYS_STATUS_KICK);
            }
        }
    }
}

void GmThread::CheckGiftConfig(RedisConnection* pConnection) {
    int32 newFee = 0;
    pConnection->get(SYS_NEW_GIFT_FEE_KEY, newFee);
    if( newFee > 0 ) {
        pConnection->set(SYS_NEW_GIFT_FEE_KEY, 0);
        sChatServer->LxSimpleCmd(pConnection, CHAT_LxUpdateGiftFee);
    }
}
