#pragma once

#include "ServerDefine.h"

class GiftThread
{
public:
	GiftThread(boost::asio::io_service& io);
	~GiftThread();

	void OnTimer1s(const boost::system::error_code& error);
private:
    void LoadGifts(RedisConnection* pConnection);
    void CheckExpire(RedisConnection* pConnection);
    void RedisSaveGift(RedisConnection* pConnection, const GiftData& rhs);
    void GiftSyncStatus(RedisConnection* pConnection, uint64 userId, int64 giftId, int32 status);
    void ChatForGiftStatus(RedisConnection* pConnection, uint64 src, uint64 dst, int64 gid, int32 status);

    void Start(const boost::system::error_code& error);
private:
    void ProcessLxSaveGift(RedisConnection* pConnection, uint64 userId, const GiftData& rhs);
    void ProcessRGiftAcceptReq(RedisConnection* pConnection, uint64 userId, const RGiftAcceptReq& rhs);
    void ProcessSGiftCancelReq(RedisConnection* pConnection, uint64 userId, const SGiftCancelReq& rhs);
    void ProcessSGiftVerifyReq(RedisConnection* pConnection, uint64 userId, const SGiftVerifyReq& req);
    void ProcessRGiftGetReq(RedisConnection* pConnection, uint64 userId, const RGiftGetReq& rhs);
private:
	boost::asio::io_service& _io_service;
	boost::asio::deadline_timer _timer;
	map<int64, GiftData> m_mapGift;
    bool m_bGiftsLoaded;
};
