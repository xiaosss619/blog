#pragma once

// 负责处理GM后台的公共信息, 转发给所有游戏服

#include "ServerDefine.h"

class GmThread
{
public:
	GmThread(boost::asio::io_service& io);
	~GmThread();

	void OnTimer5s(const boost::system::error_code& error);
private:
	void OnInit(RedisConnection* pConnection);
private:
	// 检查是否有配置重新加载的指令
	void CheckJsonReload(RedisConnection* ptr);
	// 系统广播检测 增加/过期/广播
	void CheckSystemNotice(RedisConnection* pConnection, int64 tNow);
	// 检测系统维护指令
	void CheckMaintainace(RedisConnection* pConnection);

    // 礼物系统
    void InitGiftConfig(RedisConnection* pConnection);
    void SetGiftConfig(RedisConnection* pConnection, int32 itemId, int32 fee);
    void CheckGiftConfig(RedisConnection* pConnection);
///////////////////////////////////////////////////////////////////////////////////////
private:
	boost::asio::io_service& _io_service;
	boost::asio::deadline_timer _timer;
	// 系统定时广播
	map<int32, SystemNotice> m_mapNotice;
};
