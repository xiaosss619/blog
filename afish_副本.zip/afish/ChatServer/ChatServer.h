#pragma once

#include "Include/ServerDefine.h"

class RedisConnection;
class GiftThread;
class ChatThread;
class GmThread;
class ChatServer : public Poolize
{
// 服务器数量, 用于广播, 启动时设置, 之后只读, 不加锁
GETSET(int32, ServerCount);
public:
	ChatServer();
	virtual ~ChatServer();

	void ChatPublic(RedisConnection* pConnection, const TargetInfo& src, const string& content);
	void ChatSync(RedisConnection* pConnection, uint64 userId, const SyncChatGroupData& rhs);
	void ChatSync(RedisConnection* pConnection, uint64 userId, const SyncKickedByGroup& rhs);
	void ChatSync(RedisConnection* pConnection, uint64 userId, const SyncChatGroupDismissed& rhs);
	void ChatSync(RedisConnection* pConnection, uint64 userId, const SyncChatGroupRename& rhs);
	void ChatSync(RedisConnection* pConnection, uint64 userId, const SyncChatGroupNewUser& rhs);
	void ChatSync(RedisConnection* pConnection, uint64 userId, const SyncChatGroupDelUser& rhs);

	void LxBoardcastChannelMsg(RedisConnection* pConnection, const string& chn, const string& content);
	void LxSimpleCmd(RedisConnection* pConnection, int32 cmdId);

	void SendMail(RedisConnection* pConnection, uint64 uUserId, int32 nMailType, int32 itemId, int64 itemNum);
    void SendMail(RedisConnection* pConnection, uint64 uUserId, int32 nMailType, int64 iDiamond, int64 iGold, const map<int32, int64>& mapItem, const string& title, const string& content);

public:
	ChatThread* _chat;
	GiftThread* _gift;
	GmThread* _gm;
};

#define sChatServer Singleton<ChatServer>::Instance()
