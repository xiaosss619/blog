#include "ChatServer.h"
#include "DataCache/RedisData.h"
#include "DataCache/ProtoCmdHelper.h"
#include "Include/RedisKey.h"
#include "Include/MySQLProtoHelper.h"
#include "Threads/ChatThread.h"
#include "Threads/GiftThread.h"
#include "Threads/GmThread.h"

ChatServer::ChatServer()
	: Poolize(3)
{
	_chat = new ChatThread(get_io_service(0));
	_gift = new GiftThread(get_io_service(1));
	_gm = new GmThread(get_io_service(2));
}

ChatServer::~ChatServer() {
}

void ChatServer::ChatSync(RedisConnection* pConnection, uint64 userId, const SyncChatGroupData& rhs) {
	UserProtoCmd cmd;
	cmd.set_cmd(CHAT_SyncChatGroupData);
	*cmd.mutable_sync_chat_group_data() = rhs;
	ProtoCmdHelper::PushUserCmd(pConnection, userId, cmd);
}

void ChatServer::ChatSync(RedisConnection* pConnection, uint64 userId, const SyncKickedByGroup& rhs) {
	UserProtoCmd cmd;
	cmd.set_cmd(CHAT_SyncKickedByGroup);
	*cmd.mutable_sync_kicked_by_group() = rhs;
	ProtoCmdHelper::PushUserCmd(pConnection, userId, cmd);
}

void ChatServer::ChatSync(RedisConnection* pConnection, uint64 userId, const SyncChatGroupDismissed& rhs) {
	UserProtoCmd cmd;
	cmd.set_cmd(CHAT_SyncChatGroupDismissed);
	*cmd.mutable_sync_chat_group_dismissed() = rhs;
	ProtoCmdHelper::PushUserCmd(pConnection, userId, cmd);
}

void ChatServer::ChatSync(RedisConnection* pConnection, uint64 userId, const SyncChatGroupRename& rhs) {
	UserProtoCmd cmd;
	cmd.set_cmd(CHAT_SyncChatGroupRename);
	*cmd.mutable_sync_chat_group_rename() = rhs;
	ProtoCmdHelper::PushUserCmd(pConnection, userId, cmd);
}

void ChatServer::ChatSync(RedisConnection* pConnection, uint64 userId, const SyncChatGroupNewUser& rhs) {
	UserProtoCmd cmd;
	cmd.set_cmd(CHAT_SyncChatGroupNewUser);
	*cmd.mutable_sync_chat_group_new_user() = rhs;
	ProtoCmdHelper::PushUserCmd(pConnection, userId, cmd);
}

void ChatServer::ChatSync(RedisConnection* pConnection, uint64 userId, const SyncChatGroupDelUser& rhs) {
	UserProtoCmd cmd;
	cmd.set_cmd(CHAT_SyncChatGroupNewUser);
	*cmd.mutable_sync_chat_group_del_user() = rhs;
	ProtoCmdHelper::PushUserCmd(pConnection, userId, cmd);
}

void ChatServer::ChatPublic(RedisConnection* pConnection, const TargetInfo& src, const string& content) {
	ServerProtoCmd cmd;
	cmd.set_cmd(CHAT_SyncChatPublic);
	*cmd.mutable_src() = src;
	cmd.set_content(content);
	for( int32 i = 1 ; i <= GetServerCount() ; ++i ) {
		ProtoCmdHelper::PushServerCmd(pConnection, i, cmd);
	}
}

void ChatServer::LxBoardcastChannelMsg(RedisConnection* pConnection, const string& chn, const string& content) {
	ServerProtoCmd cmd;
	cmd.set_cmd(CHAT_LxBoardcastChannelMsg);
	cmd.set_channel(chn);
	cmd.set_content(content);
	for( int32 i = 1 ; i <= GetServerCount() ; ++i ) {
		ProtoCmdHelper::PushServerCmd(pConnection, i, cmd);
	}
}

void ChatServer::LxSimpleCmd(RedisConnection* pConnection, int32 cmdId) {
	ServerProtoCmd cmd;
	cmd.set_cmd(cmdId);
	for( int32 i = 1 ; i <= GetServerCount() ; ++i ) {
		ProtoCmdHelper::PushServerCmd(pConnection, i, cmd);
	}
}

void ChatServer::SendMail(RedisConnection* pConnection, uint64 uUserId, int32 nMailType, int32 itemId, int64 itemNum) {
	map<int32, int64> mapItem;
	mapItem[itemId] = itemNum;
	SendMail(pConnection, uUserId, nMailType, 0, 0, mapItem, "", "");
}

void ChatServer::SendMail(RedisConnection* pConnection, uint64 uUserId, int32 nMailType, int64 iDiamond, int64 iGold, const map<int32, int64>& mapItem, const string& title, const string& content) {
    LxMail mail;
	mail.set_mail_id(0);
	mail.set_mail_type(nMailType);
	mail.set_mail_time(time(nullptr));
	mail.set_mail_read(0);
	mail.set_mail_diamond(max(iDiamond, 0L));
	mail.set_mail_gold(max(iGold, 0L));
	mail.set_mail_title(title);
	mail.set_mail_content(content);
	if( mapItem.size() == 0 && iDiamond == 0 && iGold == 0 ) {
		mail.set_mail_rewarded(1);
	}
	else {
		mail.set_mail_rewarded(0);
	}
	for( auto& item : mapItem ) {
        if( item.second > 0 ) {
            auto pItem = mail.add_mail_items();
            pItem->set_item_id(item.first);
            pItem->set_item_change(item.second);
            pItem->set_item_num(item.second);
        }
	}
    pConnection->lpush(RedisKey::MakeUserOfflineMailKey(uUserId), JsonProto::ProtoToJson(mail));
	pConnection->expire(RedisKey::MakeUserOfflineMailKey(uUserId), TIME_DAY*30);
}
